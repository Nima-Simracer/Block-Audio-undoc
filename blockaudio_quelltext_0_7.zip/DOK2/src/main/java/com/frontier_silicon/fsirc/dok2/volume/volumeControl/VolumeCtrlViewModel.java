package com.frontier_silicon.fsirc.dok2.volume.volumeControl;

import android.app.Activity;
import androidx.databinding.BaseObservable;
import androidx.databinding.Observable;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import androidx.databinding.ObservableInt;

import android.view.View;
import android.widget.SeekBar;

import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.VolumeCtrlFragmentBinding;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.volume.VolumeDataModel;
import com.frontier_silicon.fsirc.dok2.volume.VolumeManager;
import com.frontier_silicon.fsirc.dok2.volume.multiroomVolume.MultiroomVolumeActivity;

/**
 * Created by cvladu on 09/05/2017.
 */

public class VolumeCtrlViewModel  extends BaseObservable implements SeekBar.OnSeekBarChangeListener, IMultiroomGroupingListener {

    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;
    private VolumeDataModel mVolumeModel;
    private VolumeCtrlFragmentBinding mBinding;
    private Activity mParentActivity;
    private VolumeManager mVolumeManager = VolumeManager.getInstance();
    private boolean isSeeking = false;

    public ObservableInt seekValue = new ObservableInt(0);
    public ObservableBoolean isMultiroomButtonVisible = new ObservableBoolean(false);
    public ObservableBoolean isVolumeControlVisible = new ObservableBoolean(false);
    public ObservableBoolean isMuted = new ObservableBoolean(false);
    public ObservableField<String> volumeSteps = new ObservableField<>("");

    public VolumeCtrlViewModel(VolumeCtrlFragmentBinding binding, Activity activity) {
        mBinding = binding;
        mParentActivity = activity;

        mVolumeModel = VolumeManager.getInstance().getVolumeDataModel();
    }

    void addListeners() {

        addPropertyListeners();
        registerMultiroomNotifCallback();
    }

    void removeListeners() {
        removePropertyListeners();
        unregisterMultiroomNotifiCallback();
    }

    private void addPropertyListeners() {
        mPropertyChangedCallback = new OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int propertyId) {
                if (mVolumeModel == null) {
                    return;
                }

                if (observable == mVolumeModel.volume) {
                    updateVolumeValue();
                } else if (observable == mVolumeModel.muted) {
                    updateMuted();
                } else if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby ||
                        observable == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode) {
                    updateIsVolumeControlVisible();
                }
            }
        };

        mVolumeModel.volume.addOnPropertyChangedCallback(mPropertyChangedCallback);
        mVolumeModel.muted.addOnPropertyChangedCallback(mPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby.addOnPropertyChangedCallback(mPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void removePropertyListeners() {
        mVolumeModel.volume.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        mVolumeModel.muted.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        mPropertyChangedCallback = null;
    }

    private void registerMultiroomNotifCallback() {
        MultiroomGroupManager.getInstance().addListener(this);
    }

    private void unregisterMultiroomNotifiCallback() {
        MultiroomGroupManager.getInstance().removeListener(this);
    }



    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (fromUser) {
            changeVolume(progress);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        isSeeking = true;
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        isSeeking = false;
    }

    private void changeVolume(int progress) {
        MultiroomGroupManager.getInstance().setMainVolume(progress, true);
        volumeSteps.set(getCurrentVolumeInSteps(progress));
    }

    private String getCurrentVolumeInSteps(int progress) {
        long maxSteps = MultiroomGroupManager.getInstance().getMaxVolumeSteps();
        long currentVolumeInSteps = RadioNodeUtil.convertPercentVolumeToRadioVolume(progress, maxSteps);
        return Math.round(currentVolumeInSteps) + "/" + (maxSteps - 1);
    }


    private void updateVolumeValue() {
        if (isSeeking) {
            return;
        }

        if (mVolumeModel == null) {
            return;
        }

        if(seekValue.get() != mVolumeModel.volume.get()) {
            seekValue.set(mVolumeModel.volume.get());
            volumeSteps.set(getCurrentVolumeInSteps(mVolumeModel.volume.get()));
        }
    }

    private void updateMuted() {
        if (mBinding != null) {
            isMuted.set(mVolumeModel.muted.get());
            int tintColor = GuiUtils.getColorFromAttribute(mBinding.buttonMute.getContext(), mVolumeModel.muted.get() ?  R.attr.grouping_delete_button_color : R.attr.icon_color);
            mBinding.buttonMute.setColorFilter(tintColor);
        }
    }

    public void onMuteButtonClicked(View view) {
        boolean mute = !mVolumeModel.muted.get();
        mVolumeManager.mute(mute);
        mVolumeModel.muted.set(mute);
    }

    public void onMultiroomVolumeClicked(View view) {
        NavigationHelper.goToActivity(mParentActivity, MultiroomVolumeActivity.class);
    }

    public void updateAll() {
        if (mVolumeModel == null){
            return;
        }

        updateMuted();
        updateVolumeValue();

        updateIsMultiroomVolumeButtonVisible();
        updateIsVolumeControlVisible();
    }

    private void updateIsVolumeControlVisible() {
        isVolumeControlVisible.set(!SpeakerDataManager.getInstance().isInStandby());
    }

    private void updateIsMultiroomVolumeButtonVisible() {
        isMultiroomButtonVisible.set(MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup());
    }

    @Override
    public void onGroupingUpdate() {
        if (mParentActivity != null) {
            mParentActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                  updateAll();
                }
            });
        }
    }

    public void dispose() {

        mVolumeModel = null;
        mBinding = null;
        mParentActivity = null;
        mVolumeManager = null;
    }

}
