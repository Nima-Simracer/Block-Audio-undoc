package com.frontier_silicon.fsirc.dok2.RemoteConfigModel

/**
 * Fassung 0.1 Block Audio (18.09.2026)
 *
 * WAR: holte ueber Firebase Remote Config die Steuerung fuer das OKTIV-Werbefenster.
 * Firebase ist ausgebaut (kein Projekt, kein Schluessel), und die Werbung fuer
 * Frontiers Nachfolge-App gehoert ohnehin nicht in eine Block-App.
 *
 * Die Klasse bleibt mit denselben Methoden stehen, damit nichts anderes bricht —
 * sie sagt jetzt nur immer "nein".
 */
class RemoteConfigUtils {

    fun shouldDisplayOktivPromoBasedOnCountry(): Boolean {
        return false
    }

    fun getFirmwareBlacklist(): ArrayList<OktivPromoFirmwareBlackList> {
        return arrayListOf()
    }
}
