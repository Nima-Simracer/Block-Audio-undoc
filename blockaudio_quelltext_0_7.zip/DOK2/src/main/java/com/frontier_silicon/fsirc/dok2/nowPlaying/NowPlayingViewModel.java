package com.frontier_silicon.fsirc.dok2.nowPlaying;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;

import android.content.Intent;

import androidx.databinding.Observable;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import androidx.databinding.ObservableInt;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;

import androidx.fragment.app.FragmentActivity;
import androidx.appcompat.app.AlertDialog;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.BasePlayConcurencyResponse;
import com.frontier_silicon.NetRemoteLib.Node.BasePlayRating;
import com.frontier_silicon.NetRemoteLib.Node.BasePlayRepeat;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavPresetCurrentPreset;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayConcurencyResponse;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIpodDockStatus;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.ExternalAppsOpener;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.LayoutDecider;
import com.frontier_silicon.fsirc.dok2.databinding.NowPlayingFragmentBinding;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.presets.PresetsActivity;
import com.frontier_silicon.fsirc.dok2.sources.SourceIconsResourceIdFactory;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.loggerlib.FsLogger;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by hcostescu on 10/05/17.
 */

public class NowPlayingViewModel implements IAlbumCoverListener, IAlbumPostprocessListener,
        RadioVisManager.IRadioVisCallback, LifecycleObserver {

    private static final long PROGRESS_UPDATE_TIME_MS = 1000;

    private NowPlayingDataModel mNowPlayingDataModel;
    private Observable.OnPropertyChangedCallback mNowPlayingPropertyChangedCallback;

    public ObservableField<String> playInfoName = new ObservableField<>();
    public ObservableBoolean isNowPlayingInfoVisible = new ObservableBoolean(false);
    public ObservableField<String> secondLineInfoText = new ObservableField<>();

    public ObservableBoolean isNowPlayingPlayStatusTextVisible = new ObservableBoolean(false);
    public ObservableField<String> playStatusText = new ObservableField<>();

    public ObservableBoolean castingAppIsVisible = new ObservableBoolean(false);
    public ObservableField<String> friendlyDurationText = new ObservableField<>();
    public ObservableField<String> trackElapsedText = new ObservableField<>();
    public ObservableBoolean isTextTrackElapsedVisible = new ObservableBoolean(false);
    public ObservableBoolean isTrackTimeVisible = new ObservableBoolean(false);
    public ObservableBoolean isSourceHelpVisible = new ObservableBoolean(false);
    public ObservableField<String> castingApp = new ObservableField<>();
    public ObservableBoolean isRepeatVisible = new ObservableBoolean(false);
    public ObservableField<Drawable> repeatButtonImage = new ObservableField<>();
    public ObservableField<String> repeatButtonContentDescription = new ObservableField<>();
    public ObservableBoolean isPlayButtonVisible = new ObservableBoolean(false);
    public ObservableBoolean isPauseButtonVisible = new ObservableBoolean(false);
    public ObservableBoolean isStopButtonVisible = new ObservableBoolean(false);
    public ObservableBoolean isShuffleVisible = new ObservableBoolean(false);
    public ObservableBoolean isShuffleChecked = new ObservableBoolean(false);
    public ObservableBoolean isPlayPosSeekBarVisible = new ObservableBoolean(false);
    public ObservableInt playPosSeekBarProgress = new ObservableInt(50);
    public ObservableBoolean isProgressBarVisible = new ObservableBoolean(false);
    public ObservableInt playPosProgressBar = new ObservableInt(50);
    public ObservableBoolean isNextButtonVisible = new ObservableBoolean(false);
    public ObservableBoolean isFMVisible = new ObservableBoolean(false);
    public ObservableBoolean isSpotifiHelpVisible = new ObservableBoolean(false);
    public ObservableBoolean isPresetVisible = new ObservableBoolean(false);
    public ObservableBoolean isPresetIndexVisible = new ObservableBoolean(false);
    public ObservableField<String> presetIndexText = new ObservableField<>("");
    public ObservableBoolean isBrowseHintHelpVisible = new ObservableBoolean(false);
    public ObservableBoolean isPrevVisible = new ObservableBoolean(false);
    public ObservableBoolean isShareVisible = new ObservableBoolean(false);
    public ObservableBoolean isProgressBufferingVisible = new ObservableBoolean(false);
    public ObservableInt FMProgress = new ObservableInt();
    public ObservableBoolean isImageAlbumArtOverlayVisible = new ObservableBoolean(false);
    public ObservableField<Drawable> imageAlbumArtOverlay = new ObservableField<>();
    public ObservableBoolean isDontTintImageAlbumArtOverlayVisible = new ObservableBoolean(false);
    public ObservableField<Drawable> dontTintImageAlbumArtOverlay = new ObservableField<>();
    public ObservableField<Drawable> imageAlbumArt = new ObservableField<>();
    public ObservableBoolean isImageAlbumArtVisible = new ObservableBoolean(false);
    public ObservableField<Drawable> imageCurrentSource = new ObservableField<>();
    public ObservableBoolean isImageCurrentSourceVisible = new ObservableBoolean(false);
    public ObservableField<Drawable> imageAlbumArtBackground = new ObservableField<>();
    public ObservableBoolean isLayoutDarkAlphaVisible = new ObservableBoolean(false);
    public ObservableField<Drawable> layoutMainBackground = new ObservableField<>();
    public ObservableBoolean imageAlbumArtAdjustViewBounds = new ObservableBoolean(true);
    public ObservableField<ImageView.ScaleType> imageAlbumArtScale = new ObservableField<>(ImageView.ScaleType.FIT_XY);
    public ObservableBoolean songThumbsUp = new ObservableBoolean(false);
    public ObservableBoolean songThumbsDown = new ObservableBoolean(false);
    public ObservableBoolean thumbsUpVisibility = new ObservableBoolean(false);
    public ObservableBoolean thumbsDownVisibility = new ObservableBoolean(false);
    public ObservableBoolean isSkipForwardVisible = new ObservableBoolean(false);
    public ObservableBoolean isSkipBackwardVisible = new ObservableBoolean(false);
    public ObservableBoolean avsAmazonLoginNotificationVisible = new ObservableBoolean(false);
    public ObservableBoolean is3PdaImageCurrentSourceVisible = new ObservableBoolean(false);
    public ObservableBoolean isPlayInfoTextFor3PdaVisible = new ObservableBoolean(false);
    public ObservableField<String> playInfoText = new ObservableField<>("");
    public ObservableField<String> spotifyHelpMessage = new ObservableField<>("");
    public ObservableField<Drawable> spotifyLogoPlaying = new ObservableField<>(null);
    public ObservableBoolean isSpotifyPlaying = new ObservableBoolean(false);
    public ObservableField<Drawable> spotifyBackgroundImage = new ObservableField<>();
    public ObservableBoolean isScrollingEnable = new ObservableBoolean(UndokPreferences.getInstance().getScrollingEnabled());


    public boolean isDMRPlaybackStarted = false;

    private long callbackId = -1;
    private ProgressRunnable progressRunnable = null;

    private RadioVisManager mRadioVisManager;

    boolean mIsStopping = false;

    private FragmentActivity mActivity;
    private Lifecycle mLifecycle;
    private NowPlayingFragmentBinding mBinding;
    private Snackbar snackbarErrorMessageKlassikRadio;

    public void init(FragmentActivity activity, NowPlayingFragmentBinding binding) {
        mBinding = binding;
        mActivity = activity;
        mLifecycle = mActivity.getLifecycle();
        mLifecycle.addObserver(this);

        mNowPlayingDataModel = NowPlayingManager.getInstance().getNowPlayingDataModel();

        if (progressRunnable == null) {
            progressRunnable = new ProgressRunnable();
        }

        mRadioVisManager = RadioVisManager.getInstance();

        updateAllObservables();

        registerPropertyChangedCallback();
    }

    public void setScrollingEnableState() {
        isScrollingEnable.set(UndokPreferences.getInstance().getScrollingEnabled());
    }

    private Drawable convertResourceToDrawable() {
        return convertResourceToDrawable(AlbumCoverUtil.updateAlbumArtworkOverlayImage());
    }

    private Drawable convertResourceToDrawable(int imageResource) {
        Drawable drawable;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            drawable = mActivity.getResources().getDrawable(imageResource);
        } else {
            drawable = mActivity.getResources().getDrawable(imageResource, mActivity.getTheme());
        }
        return drawable;
    }

    private String getErrorMessage() {
        String errMsg = "";
        if (isIpodMode()) {
            errMsg = mActivity.getString(R.string.play_error_ipod);
        } else {
            errMsg = getPlaybackErrorMessage();
            if (TextUtils.isEmpty(errMsg)) {
                errMsg = mActivity.getString(R.string.play_error);
            }
        }
        return errMsg;
    }

    private String getPlaybackErrorMessage() {
        if (mNowPlayingDataModel.isShuffleError.get()) {
            return "Too many items to shuffle";
        } else {
            return mNowPlayingDataModel.playErrorMsg.get();
        }
    }

    private void displayPopupErrorBasedOnCurrentMode(final String message) {
        NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();

        if (currentMode == NodeSysCapsValidModes.Mode.AIRABLE_DEEZER) {
            displayPopupForError(message);
        } else if (currentMode == NodeSysCapsValidModes.Mode.AIRABLE_KLASSIK && mActivity != null) {
            if (snackbarErrorMessageKlassikRadio == null) {
               showSnackbar(message);
            } else if (snackbarErrorMessageKlassikRadio != null && !snackbarErrorMessageKlassikRadio.isShown()) {
                showSnackbar(message);
            }
        }
    }

    private void showSnackbar(final String message) {
        snackbarErrorMessageKlassikRadio = Snackbar.make(mBinding.getRoot(), message, BaseTransientBottomBar.LENGTH_LONG);
        View v = snackbarErrorMessageKlassikRadio.getView();
        TextView tv = v.findViewById(R.id.snackbar_text);
        tv.setMaxLines(5);
        snackbarErrorMessageKlassikRadio.show();
    }

    private void displayPopupForError(final String message) {
        if (TextUtils.isEmpty(message)) {
            return;
        }

        NetRemote.getMainThreadExecutor().execute(() -> {
            String dialogKey = "freemium_error_message_dlg";
            if (DokUiUtils.isDestroyed(mActivity) || DialogsHolder.isShowing(dialogKey)) {
                return;
            }

            AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mActivity);

            builder.setTitle(mActivity.getString(R.string.subscribe));
            builder.setMessage(message);

            builder.setPositiveButton(mActivity.getString(R.string.subscribe), (arg0, arg1) -> {
                int subscribeLinkResourceId = getSubscribeResourceIdentifierBasedOnCurrentMode();
                Intent browse = new Intent(Intent.ACTION_VIEW, Uri.parse(mActivity.getString(subscribeLinkResourceId)));
                mActivity.startActivity(browse);
            });
            builder.setNegativeButton(android.R.string.cancel, null);

            AlertDialog dlg = builder.create();
            DialogsHolder.addDialogToCollection(dialogKey, dlg);
            dlg.show();
        });
    }

    private int getSubscribeResourceIdentifierBasedOnCurrentMode() {
        StringBuilder modeName = new StringBuilder();
        modeName.append(getCurrentModeNameForSubscribe());
        modeName.append("_register_link");
        int resId = mActivity.getResources().getIdentifier(modeName.toString() , "string", mActivity.getPackageName());

        return resId;
    }

    private String getCurrentModeNameForSubscribe() {
        NodeSysCapsValidModes.Mode currentMode= SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.get();
        return currentMode.name().toLowerCase();
    }

    private void updateTextInfo() {

        if (isBuffering()) {
            isNowPlayingPlayStatusTextVisible.set(true);
            playStatusText.set(mActivity.getString(R.string.buffering));

            isProgressBufferingVisible.set(true);

        } else if (mNowPlayingDataModel.isError() || mNowPlayingDataModel.isShuffleError()) {
            String errMsg = getErrorMessage();

            // If previous mode was Spotify, speaker sends waiting for users until a track starts to play
            if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.DMR) {
                if (errMsg.contains("Waiting for Users")) {
                    errMsg = "";
                }
            }
            isNowPlayingPlayStatusTextVisible.set(true);
            playStatusText.set(errMsg);

            if (!isDMRPlaybackStarted || SpeakerDataManager.getInstance().getCurrentMode() != NodeSysCapsValidModes.Mode.DMR) {
                isProgressBufferingVisible.set(false);
            }

        } else {
            isNowPlayingPlayStatusTextVisible.set(false);

            if (!isDMRPlaybackStarted || SpeakerDataManager.getInstance().getCurrentMode() != NodeSysCapsValidModes.Mode.DMR) {
                isProgressBufferingVisible.set(false);
            }
        }

        if (isIpodMode()) {
            NodeSysIpodDockStatus.Ord dockStatus = getIPodDockStatus();

            if (dockStatus == NodeSysIpodDockStatus.Ord.DOCKED_UNSUPPORTED_IPOD) {
                isNowPlayingPlayStatusTextVisible.set(true);
                playStatusText.set(mActivity.getString(R.string.play_error_ipod_not_supported));
            }

            if (dockStatus == NodeSysIpodDockStatus.Ord.DOCKED_UNKNOWN_DEVICE) {
                isNowPlayingPlayStatusTextVisible.set(true);
                playStatusText.set(mActivity.getString(R.string.play_error_ipod_unknown));
            }
        }
    }


    public void updateBufferingView(boolean isBufferingOn) {
        if (isBufferingOn) {
            playStatusText.set(mActivity.getString(R.string.buffering));
            isNowPlayingPlayStatusTextVisible.set(true);
            isProgressBufferingVisible.set(true);
        } else {
            isProgressBufferingVisible.set(false);
            playStatusText.set("");
        }
    }

    private void updateAllObservables() {

        enableRadioVisIfNeeded();

        updateFMControlVisibility();
        updateFMProgressSeekBar();

        updateSourceHelpVisible();
        updateSpotifyHelpVisibility();
        updateBrowseHelpVisibility();

        updateNextButtonVisibility();
        updatePlayPauseStopButtonVisibility();
        updateRepeatButtonVisibility();
        updatePreviousButtonVisibility();

        updateShuffleButtonVisibility();
        updateShareButtonVisibility();
        updatePresetVisibility();
        updateForActivePreset();

        updateSeekBarVisibility();
        updateProgressBarVisibility();
        updateDuration();
        updateProgressTimer();
        updateElapsedTime();

        displayDefaultIcon();

        updateTrackDescriptionButtonVisibility();
        updateFirstLineInfoText();
        updateSecondLine();
        updateThirdLine();

        updateCastingAppVisibility();

        updateAvsNotification();
        updateRepeatButton();
        updateShuffleButton();
        updateSpotifyLogoVIsibility();
    }

    private void updateSpotifyLogoVIsibility() {
        if (isSpotifyMode()) {
            if (mNowPlayingDataModel.isPlaying() || mNowPlayingDataModel.isPaused()) {
                isSpotifyPlaying.set(true);
            }
        } else {
            isSpotifyPlaying.set(false);

        }
    }

    private void updateAvsNotification() {
        avsAmazonLoginNotificationVisible.set(!SpeakerDataManager.getInstance().getSpeakerDataModel().isAvsLoggedIn.get() && SpeakerDataManager.getInstance().hasAvs());
    }

    private void updateSourceHelpVisible() {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio != null && radio.hasAVS()) {
            isSourceHelpVisible.set(false);
        } else {

            isSourceHelpVisible.set(isCurrentModeNone() && !LayoutDecider.isTabletAndLandscape(mActivity));
        }
    }

    private boolean isCurrentModeNone() {
        NodeSysCapsValidModes.Mode currentMode = getCurrentMode();
        return currentMode == NodeSysCapsValidModes.Mode.None;
    }


    private void updateNextButtonVisibility() {
        isNextButtonVisible.set(mNowPlayingDataModel.isNextAvailable() ||
                ((SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.DMR && isPlayPauseButtonSupported())
                        && mNowPlayingDataModel.dmrPlaying.get()));

        if (isIdle()) {
            isNextButtonVisible.set(false);
        }
    }

    private void updatePreviousButtonVisibility() {

        isPrevVisible.set(mNowPlayingDataModel.isPreviousAvailable() ||
                ((SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.DMR &&
                        isPlayPauseButtonSupported()) && mNowPlayingDataModel.dmrPlaying.get()));

        if (isIdle()) {
            isPrevVisible.set(false);
        }
    }

    private void updateShuffleButtonVisibility() {
        isShuffleVisible.set(mNowPlayingDataModel.isShuffleAvailable());
    }

    private void updateRepeatButtonVisibility() {
        isRepeatVisible.set(mNowPlayingDataModel.isRepeatAvailable());
    }

    private void updateSeekBarVisibility() {
        if (isPlayPosSeekBarVisible.get() != (mNowPlayingDataModel.isSeekBarAvailable() && isTrackTimeVisible.get())) {
            isPlayPosSeekBarVisible.set(mNowPlayingDataModel.isSeekBarAvailable() && isTrackTimeVisible.get());
        }
    }

    private void updateCastingAppVisibility() {
        String text = MainApplication.getContext().getString(R.string.casting_app, mNowPlayingDataModel.castingApp.get());
        castingApp.set(text);

        castingAppIsVisible.set(!TextUtils.isEmpty(mNowPlayingDataModel.castingApp.get()));
    }

    private void updateCapsInfluencedButtons() {
        updatePlayPauseStopButtonVisibility();
        updateNextButtonVisibility();
        updatePreviousButtonVisibility();
        updateShuffleButtonVisibility();
        updateRepeatButtonVisibility();
        updateSeekBarVisibility();
        updateProgressBarVisibility();
        updateRatingVisibility();
        updateSkipButtonsVisibility();
    }

    private void updateRatingVisibility() {

        thumbsUpVisibility.set(mNowPlayingDataModel.isThumbsUpAvailable());

        thumbsDownVisibility.set(mNowPlayingDataModel.isThumbsDownAvailable());
    }

    private void updateSkipButtonsVisibility() {

        isSkipForwardVisible.set(mNowPlayingDataModel.isSkipForwardAvailable());

        isSkipBackwardVisible.set(mNowPlayingDataModel.isSkipBackwardAvailable());
    }


    private void updatePlayStatusInfluencedControls() {
        updateBrowseHelpVisibility();
        updateShareButtonVisibility();
        updatePlayPauseStopButtonVisibility();
        updateNextButtonVisibility();
        updatePreviousButtonVisibility();
    }

    private void registerPropertyChangedCallback() {
        mNowPlayingPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                if (mNowPlayingDataModel == null) {
                    return;
                }

                if (observable == mNowPlayingDataModel.graphicUri) {
                    FsLogger.log("NowPlaying: updating graphics uri");
                    updateAlbumCover();
                } else if (observable == mNowPlayingDataModel.trackUpdated) {
                    updateFirstLineInfoText();
                    updateSecondLine();
                    updateThirdLine();

                } else if (observable == mNowPlayingDataModel.playInfoText ||
                        observable == mNowPlayingDataModel.artist) {

                    updatePresetVisibility();
                    updateForActivePreset();
                    updateShareButtonVisibility();
                } else if (observable == mNowPlayingDataModel.playInfoName) {
                    updateBrowseHelpVisibility();
                    updateSpotifyHelpVisibility();
                    updateProgressTimer();
                } else if (observable == mNowPlayingDataModel.duration) {
                    initializePlaybackProgress();
                    updateDuration();
                    updateProgressTimer();
                } else if (observable == mNowPlayingDataModel.repeatMode) {
                    updateRepeatButton();
                } else if (observable == mNowPlayingDataModel.isShuffle) {
                    updateShuffleButton();
                } else if (observable == mNowPlayingDataModel.playCaps) {
                    updateCapsInfluencedButtons();
                } else if (observable == mNowPlayingDataModel.infoArtistDescription ||
                        observable == mNowPlayingDataModel.infoAlbumDescription ||
                        observable == mNowPlayingDataModel.trackDescription) {
                    updateTrackDescriptionButtonVisibility();
                } else if (observable == mNowPlayingDataModel.playStatus) {
                    updateProgressTimer();
                    updatePlayStatusInfluencedControls();
                    updateTextInfo();
                    updateForActivePreset();
                    updateSpotifyLogoVIsibility();
                } else if (observable == mNowPlayingDataModel.fmPercentProgress) {
                    updateFMProgressSeekBar();
                } else if (observable == mNowPlayingDataModel.songRating) {
                    updateSongRating();
                } else if (observable == mNowPlayingDataModel.playErrorMsg) {
                    updateTextInfo();
                } else if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode) {
                    updateAllObservables();
                } else if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().isPresetNavigationSupported) {
                    updatePresetVisibility();
                    updateForActivePreset();
                } else if (observable == mNowPlayingDataModel.providerLogoUri) {
                    update3PdaProviderLogo(mNowPlayingDataModel.providerLogoUri.get());
                } else if (observable == mNowPlayingDataModel.elapsedTime) {
                    updateElapsedTimeOnPaused();
                } else if (observable == mNowPlayingDataModel.playErrPopupMessage) {
                    displayPopupErrorBasedOnCurrentMode(mNowPlayingDataModel.playErrPopupMessage.get());
                } else if (observable == mNowPlayingDataModel.concurrencyString) {
                    displayAmazonConcurencyAlert(mNowPlayingDataModel.concurrencyString.get());
                } else if (observable == mNowPlayingDataModel.notificationMessage) {
                    displayNotificationMessage(mNowPlayingDataModel.notificationMessage.get());
                } else if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().isAvsLoggedIn) {
                    avsAmazonLoginNotificationVisible.set(!SpeakerDataManager.getInstance().getSpeakerDataModel().isAvsLoggedIn.get() && SpeakerDataManager.getInstance().hasAvs());
                } else if (observable == mNowPlayingDataModel.dmrPlaying) {
                    updatePlayStatusInfluencedControls();
                }
            }
        };

        mNowPlayingDataModel.playInfoText.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.artist.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playInfoName.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.duration.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.elapsedTime.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.repeatMode.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.isShuffle.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playCaps.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.infoArtistDescription.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.infoAlbumDescription.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.trackDescription.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playStatus.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.fmPercentProgress.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.songRating.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playErrorMsg.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.graphicUri.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.trackUpdated.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.providerLogoUri.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playErrPopupMessage.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.concurrencyString.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.notificationMessage.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.dmrPlaying.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);

        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().isPresetNavigationSupported.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().isAvsLoggedIn.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);

    }

    private void unregisterPropertyChangedCallback() {

        mNowPlayingDataModel.playInfoText.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.artist.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.duration.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.repeatMode.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.isShuffle.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playCaps.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.elapsedTime.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playInfoName.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.infoArtistDescription.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.infoAlbumDescription.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.trackDescription.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playStatus.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.fmPercentProgress.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.songRating.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playErrorMsg.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.graphicUri.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.trackUpdated.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.providerLogoUri.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.playErrPopupMessage.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.concurrencyString.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.notificationMessage.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        mNowPlayingDataModel.dmrPlaying.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);

        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().isPresetNavigationSupported.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().isAvsLoggedIn.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
    }

    private void updateTrackDescriptionButtonVisibility() {
        if (!TextUtils.isEmpty(mNowPlayingDataModel.infoAlbumDescription.get()) ||
                !TextUtils.isEmpty(mNowPlayingDataModel.infoArtistDescription.get()) ||
                !TextUtils.isEmpty(mNowPlayingDataModel.trackDescription.get())) {
            isNowPlayingInfoVisible.set(true);
        } else {
            isNowPlayingInfoVisible.set(false);
        }
    }

    private void updateFirstLineInfoText() {
        playInfoName.set(mNowPlayingDataModel.playInfoName.get());
    }

    private void updateSecondLine() {
        String infoText = mNowPlayingDataModel.playInfoText.get();

        // show artist and album if available
        if (!TextUtils.isEmpty(mNowPlayingDataModel.artist.get())) {
            infoText = mNowPlayingDataModel.artist.get();

            if (!TextUtils.isEmpty(mNowPlayingDataModel.album.get())) {
                infoText = infoText + " (" + mNowPlayingDataModel.album.get() + ")";
            }
        } else {
            if (!TextUtils.isEmpty(mNowPlayingDataModel.album.get())) {
                infoText = mNowPlayingDataModel.album.get();
            }
        }
        secondLineInfoText.set(infoText);
    }

    private void updateThirdLine() {
        if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.FSDCA_3PDA &&
                !TextUtils.isEmpty(mNowPlayingDataModel.playInfoText.get())) {
            displayPlayInfoTextFor3Pda();
        } else {
            isPlayInfoTextFor3PdaVisible.set(false);
        }
    }

    private void displayPlayInfoTextFor3Pda() {
        String infoText = mNowPlayingDataModel.playInfoText.get();
        playInfoText.set(infoText);
        isPlayInfoTextFor3PdaVisible.set(true);
    }

    private void updateFMControlVisibility() {
        NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();

        isFMVisible.set(currentMode == NodeSysCapsValidModes.Mode.FM);
    }

    private boolean isCurrentModeValid() {
        NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();
        boolean result = currentMode != NodeSysCapsValidModes.Mode.UnknownMode &&
                currentMode != NodeSysCapsValidModes.Mode.None &&
                currentMode != NodeSysCapsValidModes.Mode.Audsync;

        return result;
    }

    public boolean isPlayPauseButtonSupported() {
        if (getCurrentMode() == NodeSysCapsValidModes.Mode.DMR) {
            return mNowPlayingDataModel.dmrPlaying.get();
        } else {
            if (mNowPlayingDataModel.isPauseAvailable()) {
                return true;
            }
        }
        return false;
    }

    public void onThumbsUpClicked(View v) {
        NowPlayingManager.getInstance().setThumbsUp();
    }

    public void onThumbsDownClicked(View v) {
        NowPlayingManager.getInstance().setThumbsDown();
    }

    public void onPlayClicked(View v) {

        if (isBugOnPlayPresent()) {
            NowPlayingManager.getInstance().stop();
        } else {
            NowPlayingManager.getInstance().play();
        }
    }

    private boolean isBugOnPlayPresent() {
        return mNowPlayingDataModel.isStopAvailable() && isStopped();
    }

    public void onPauseClicked(View v) {
        NowPlayingManager.getInstance().pause();
    }

    public void onStopClicked(View v) {
        NowPlayingManager.getInstance().stop();
    }

    private void updatePlayPauseStopButtonVisibility() {
        if (isPlayPauseButtonSupported()) {
            isStopButtonVisible.set(false);

            if (isStopped() || isIdle()) {
                isPlayButtonVisible.set(false);
                isPauseButtonVisible.set(false);

            } else if (isPaused()) {
                isPlayButtonVisible.set(true);
                isPauseButtonVisible.set(false);

            } else {
                isPlayButtonVisible.set(false);
                isPauseButtonVisible.set(true);
            }
        } else {
            isPlayButtonVisible.set(false);
            isPauseButtonVisible.set(false);
        }

        if (mNowPlayingDataModel.isStopAvailable()) {

            isPauseButtonVisible.set(false);
            if (!isStopped()) {
                isStopButtonVisible.set(true);
                isPlayButtonVisible.set(false);
            } else {
                isStopButtonVisible.set(false);
                isPlayButtonVisible.set(true);
            }
        } else {
            isStopButtonVisible.set(false);
        }
    }

    private boolean isStopped() {
        return mNowPlayingDataModel.isStopped();
    }

    public boolean isPaused() {
        return mNowPlayingDataModel.isPaused();
    }

    private boolean isIdle() {
        return mNowPlayingDataModel.isIdle();
    }

    private boolean isPlaying() {
        return mNowPlayingDataModel.isPlaying();
    }

    private boolean isBuffering() {
        return mNowPlayingDataModel.isBuffering();
    }

    private boolean isError() {
        return mNowPlayingDataModel.isError();
    }

    private NodeSysCapsValidModes.Mode getCurrentMode() {
        return SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.get();
    }

    public boolean isAuxInMode() {
        return (getCurrentMode() == NodeSysCapsValidModes.Mode.AuxIn);
    }

    private boolean isSpotifyMode() {
        return (getCurrentMode() == NodeSysCapsValidModes.Mode.Spotify);
    }

    private boolean isFsdca3PdaMode() {
        return (getCurrentMode() == NodeSysCapsValidModes.Mode.FSDCA_3PDA);
    }

    private NodeSysIpodDockStatus.Ord getIPodDockStatus() {
        return mNowPlayingDataModel.iPodDockStatus.get();
    }


    private boolean isIpodMode() {

        boolean isIPodMode = (SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.get() == NodeSysCapsValidModes.Mode.iPod);

        return isIPodMode;
    }

    private String getPopupMessage() {
        return mNowPlayingDataModel.playErrPopupMessage.get();
    }

    private boolean getIsElapsedTimeVisible() {
        return (mNowPlayingDataModel.duration.get() > 0);
    }

    public long getDuration() {
        return mNowPlayingDataModel.duration.get();
    }

    public long getPosition() {
        return mNowPlayingDataModel.elapsedTime.get();
    }

    private void updateShareButtonVisibility() {
        isShareVisible.set(!isAuxInMode() &&
                (mNowPlayingDataModel.isPlaying() || mNowPlayingDataModel.isPaused() || mNowPlayingDataModel.isStopped()));
    }

    private void updateSpotifyHelpVisibility() {
        showSpotifyHelpMessage();
        isSpotifiHelpVisible.set((isSpotifyMode() &&
                TextUtils.isEmpty(mNowPlayingDataModel.playInfoName.get())));

        if (DokUiUtils.isLightTheme()) {
            spotifyBackgroundImage.set(mActivity.getResources().getDrawable(R.drawable.btn_browse_spotify_black));
        } else {
            spotifyBackgroundImage.set(mActivity.getResources().getDrawable(R.drawable.btn_browse_spotify_white));
        }
    }

    private void showSpotifyHelpMessage() {
        if (ExternalAppsOpener.isAppInstalled(mActivity.getString(R.string.spotify_app_package_name), mActivity)) {
            spotifyHelpMessage.set(mActivity.getString(R.string.play_press_icon_to_open_spotify_app));
        } else {
            spotifyHelpMessage.set(mActivity.getString(R.string.play_press_icon_to_get_free_spotify_app));
        }
    }

    public void onSpotifyButtonPressed() {
        if (isSpotifyMode()) {
            ExternalAppsOpener.openSpotify(mActivity);
        }
    }

    private void updateAlbumCover() {
        boolean startedTask = false;

        if (canGetAlbumCover()) {
            AlbumCoverDownloader downloader = new AlbumCoverDownloader();
            downloader.getArtworkBitmapFromUrl(mNowPlayingDataModel.graphicUri.get(), getAlbumSearchQuery(),
                    this, isSpotifyMode(), mActivity.getApplicationContext());

            startedTask = true;
        }

        if (!startedTask) {
            if (canReturnEmptyAlbumCover()) {
                onAlbumCoverUpdate(null);
            }
        }
    }

    private boolean canReturnEmptyAlbumCover() {
        NodeSysCapsValidModes.Mode currentMode = getCurrentMode();
        boolean canReturnEmptyArt = (mNowPlayingDataModel.isError() || mNowPlayingDataModel.isIdle() ||
                !(currentMode == NodeSysCapsValidModes.Mode.DAB || currentMode == NodeSysCapsValidModes.Mode.FM));

        return canReturnEmptyArt;
    }

    public String getAlbumSearchQuery() {

        if (!TextUtils.isEmpty(mNowPlayingDataModel.playInfoText.get())) {
            return mNowPlayingDataModel.playInfoText.get();
        } else {
            if (!TextUtils.isEmpty(mNowPlayingDataModel.album.get()))
                return getSearchQuery();
            else {
                if (TextUtils.isEmpty(mNowPlayingDataModel.artist.get()))
                    return "";
                else
                    return getSearchQuery();
            }
        }
    }

    public String getSearchQuery() {
        return mNowPlayingDataModel.artist.get() + " " + playInfoName.get() + " " + mNowPlayingDataModel.album.get();
    }

    public boolean canGetAlbumCover() {
        boolean result;

        NodeSysCapsValidModes.Mode currentMode = getCurrentMode();

        result = !(isError() || (currentMode == NodeSysCapsValidModes.Mode.AuxIn ||
                currentMode == NodeSysCapsValidModes.Mode.FM ||
                currentMode == NodeSysCapsValidModes.Mode.DAB));
        return result;
    }

    public void updateAlbumCoverFromUrl(String imageUrl, IAlbumCoverListener listener) {
        AlbumCoverDownloader downloader = new AlbumCoverDownloader();
        downloader.getArtworkBitmapFromUrl(imageUrl, null, listener, false, mActivity);
    }

    public void updatePositionFake(long incrementMs) {
        mNowPlayingDataModel.elapsedTime.set(mNowPlayingDataModel.elapsedTime.get() + incrementMs);
    }

    public void setPosition(long positionMs) {
        mNowPlayingDataModel.elapsedTime.set(positionMs);
        startProgressTimer();
    }

    public boolean playPositionIsSmallerThanDuration() {
        return mNowPlayingDataModel.elapsedTime.get() < mNowPlayingDataModel.duration.get();
    }

    private void updateFMProgressSeekBar() {
        FMProgress.set(mNowPlayingDataModel.fmPercentProgress.get());
    }

    @Override
    public void onAlbumCoverUpdate(Bitmap albumCover) {

        if (mActivity == null) {
            return;
        }

        AlbumThreadPool.getInstance().clear();

        //We are sending null bitmaps too, to keep the order of processing
        AlbumThreadPool.getInstance().
                submit(new AlbumPostprocessRunnable(albumCover, mActivity.getApplicationContext(), this));
    }

    private void updateDuration() {
        long durationValue = mNowPlayingDataModel.duration.get();

        friendlyDurationText.set(GuiUtils.getMilisecAsTimeStringRoundedUp(durationValue));
        isTrackTimeVisible.set(durationValue > 0);
    }

    private void updateElapsedTime() {
        long elapsedTimeValue = mNowPlayingDataModel.elapsedTime.get();
        trackElapsedText.set(GuiUtils.getMilisecAsTimeStringRoundedDown(elapsedTimeValue));
        isTextTrackElapsedVisible.set(true);
        updateProgressBar(elapsedTimeValue);
        updateProgressBarVisibility();
    }

    private void updateProgressBar(long elapsedTimeValue) {
        playPosSeekBarProgress.set(getProgressPercent(elapsedTimeValue, mNowPlayingDataModel.duration.get()));
        playPosProgressBar.set(getProgressPercent(elapsedTimeValue, mNowPlayingDataModel.duration.get()));
    }

    private int getProgressPercent(long position, long duration) {
        float posNorm = 0;

        if (duration > 0) {
            posNorm = (float) position / (float) duration;
        }

        return (int) (posNorm * 100);
    }

    private void updateProgressBarVisibility() {
        isProgressBarVisible.set(!mNowPlayingDataModel.isSeekBarAvailable() && isTrackTimeVisible.get());
    }

    private void updateRepeatButton() {
        isRepeatVisible.set(mNowPlayingDataModel.isRepeatAvailable());

        Drawable drawable;
        if (mNowPlayingDataModel.repeatMode.get() == BasePlayRepeat.Ord.OFF) {
            drawable = mActivity.getResources().getDrawable(R.drawable.ic_repeat_off);
            repeatButtonContentDescription.set(mActivity.getString(R.string.voiceover_repeat_is_off));
        } else if (mNowPlayingDataModel.repeatMode.get() == BasePlayRepeat.Ord.REPEAT_ALL) {
            drawable = mActivity.getResources().getDrawable(R.drawable.ic_repeat_on);
            repeatButtonContentDescription.set(mActivity.getString(R.string.voiceover_repeat_is_on));
        } else {
            drawable = mActivity.getResources().getDrawable(R.drawable.ic_repeat_one);
            repeatButtonContentDescription.set(mActivity.getString(R.string.voiceover_repeat_one_is_on));
        }

        repeatButtonImage.set(drawable);
    }

    private void updateShuffleButton() {
        isShuffleVisible.set(mNowPlayingDataModel.isShuffleAvailable());
        isShuffleChecked.set(mNowPlayingDataModel.isShuffle.get());
    }


    private void updatePresetVisibility() {
        boolean mIsPresetSupported = SpeakerDataManager.getInstance().isPresetNavigationSupported();

        isPresetVisible.set(!LayoutDecider.isTabletAndLandscape(mActivity) && mIsPresetSupported);
    }

    // UNDC-11, are we playing a preset, if so let user know
    private void updateForActivePreset() {

        // If preset button is not visible, don't put a notification on top of it
        if (!isPresetVisible.get()) {
            isPresetIndexVisible.set(false);
            return;
        }

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        if (radio != null) {
            radio.getNode(NodeNavPresetCurrentPreset.class, false, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    NodeNavPresetCurrentPreset currentPreset = (NodeNavPresetCurrentPreset) node;
                    if (currentPreset.getValue() == currentPreset.getMaxPossibleValue())
                        isPresetIndexVisible.set(false);
                    else {
                        // Radio reports presets counting from zero, so it is necessary to add 1
                        presetIndexText.set(Long.toString(1 + currentPreset.getValue()));
                        isPresetIndexVisible.set(true);
                    }
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    isPresetIndexVisible.set(false);
                }
            });
        } else {
            isPresetIndexVisible.set(false);
        }
    }

    protected void unregisterNotifCallbacks() {
        enableRadioVisIfNeeded(false);
    }

    @Override
    public void onNewRadioVisImageUrl(String imageUrl) {
        if (TextUtils.isEmpty(imageUrl)) {
            onAlbumCoverUpdate(null);
        } else {
            updateAlbumCoverFromUrl(imageUrl, this);
        }
    }

    private void enableRadioVisIfNeeded() {
        NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();
        if ((currentMode != null) && (currentMode == NodeSysCapsValidModes.Mode.DAB) || (currentMode == NodeSysCapsValidModes.Mode.FM)) {
            enableRadioVisIfNeeded(true);
        } else {
            enableRadioVisIfNeeded(false);
        }
    }

    private void enableRadioVisIfNeeded(boolean enable) {
        if (enable) {
            mRadioVisManager.setListener(this);

            mRadioVisManager.refreshRadioVis();
        } else {
            mRadioVisManager.removeListener(this);
            mRadioVisManager.cleanup();
        }
    }

    private void updateBrowseHelpVisibility() {
        boolean isVisible = isCurrentModeValid() &&
                SpeakerDataManager.getInstance().isNavigationSupportedForCurrentMode() &&
                (mNowPlayingDataModel.isIdle() || mNowPlayingDataModel.isError()) &&
                TextUtils.isEmpty(mNowPlayingDataModel.playInfoName.get()) &&
                !LayoutDecider.isTabletAndLandscape(mActivity);

        isBrowseHintHelpVisible.set(isVisible);
    }

    private void startProgressTimer() {
        stopProgressTimer();

        DelayedPostsManager dpmInstance = DelayedPostsManager.getInstance();
        if (callbackId == -1) {
            callbackId = dpmInstance.registerNewCallbackID();
            dpmInstance.postDelayed(progressRunnable, callbackId, PROGRESS_UPDATE_TIME_MS);
        }
    }

    void stopProgressTimer() {
        DelayedPostsManager dpmInstance = DelayedPostsManager.getInstance();
        dpmInstance.removeCallbackId(callbackId);
        callbackId = -1;
    }

    public void updateProgressTimer() {

        if (!mNowPlayingDataModel.isPlaying())
            return;
        if (!DokUiUtils.isAtLeastResumed(mLifecycle)) {
            return;
        }

        if (getIsElapsedTimeVisible() && !isStopped()) {
            isTextTrackElapsedVisible.set(true);
            updateSeekBarVisibility();
            updateProgressBarVisibility();
            startProgressTimer();

            if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.DMR) {
                isProgressBarVisible.set(true);
            }
        } else {
            stopProgressTimer();
            isTextTrackElapsedVisible.set(false);
            isPlayPosSeekBarVisible.set(false);
            isProgressBarVisible.set(false);
        }
    }

    void updatePlaybackProgress() {
        if (isPlaying() || isPaused() || isError() || isIdle()) {
            if (getIsElapsedTimeVisible()) {
                long duration = getDuration();
                long position = getPosition();
                isTextTrackElapsedVisible.set(true);
                trackElapsedText.set(GuiUtils.getMilisecAsTimeStringRoundedDown(position));
                updateSeekBarVisibility();
                updateProgressBarVisibility();
                playPosSeekBarProgress.set(NowPlayingManager.getInstance().getProgressPercent(position, duration));
                playPosProgressBar.set(NowPlayingManager.getInstance().getProgressPercent(position, duration));
                // if we have progress buffering is not needed
                isProgressBufferingVisible.set(false);
            } else {
                if (SpeakerDataManager.getInstance().getCurrentMode() != NodeSysCapsValidModes.Mode.DMR) {
                    isTextTrackElapsedVisible.set(false);
                    isPlayPosSeekBarVisible.set(false);
                    isProgressBarVisible.set(false);
                }
            }
        }
    }

    private void updateElapsedTimeOnPaused() {
        if (isPaused()) {
            long duration = getDuration();
            long position = getPosition();
            trackElapsedText.set(GuiUtils.getMilisecAsTimeStringRoundedDown(position));
            playPosSeekBarProgress.set(NowPlayingManager.getInstance().getProgressPercent(position, duration));
            playPosProgressBar.set(NowPlayingManager.getInstance().getProgressPercent(position, duration));
        }
    }

    void initializePlaybackProgress() {
        trackElapsedText.set(GuiUtils.getMilisecAsTimeStringRoundedDown(0));
        friendlyDurationText.set(GuiUtils.getMilisecAsTimeStringRoundedUp(0));
        playPosSeekBarProgress.set(NowPlayingManager.getInstance().getProgressPercent(0, 0));
        playPosProgressBar.set(NowPlayingManager.getInstance().getProgressPercent(0, 0));
    }

    public class ProgressRunnable implements Runnable {
        private static final int MAX_FAKE_UPDATE = 1;
        private int mNumFakeUpdateIncrement = 0;

        @Override
        public void run() {
            if (mIsStopping) {
                return;
            }

            if (canIncrementFakePosition()) {
                showNextFakeTime();
            } else {
                showNextFakeTime();

                NowPlayingManager.getInstance().updatePlayPosition();
                mNumFakeUpdateIncrement = 0;
            }

            updatePlaybackProgress();

            if (callbackId != -1 && isPlaying()) {

                DelayedPostsManager.getInstance().postDelayed(progressRunnable, callbackId, PROGRESS_UPDATE_TIME_MS);
            }
        }

        private void showNextFakeTime() {
            mNumFakeUpdateIncrement++;
            if (mNowPlayingDataModel.isPlaying() && playPositionIsSmallerThanDuration()) {
                updatePositionFake(PROGRESS_UPDATE_TIME_MS);
            }
        }

        private boolean canIncrementFakePosition() {
            return (mNumFakeUpdateIncrement < MAX_FAKE_UPDATE);
        }
    }

    void setAlbumArtModeIcon(boolean enable) {

        NodeSysCapsValidModes.Mode mode = SpeakerDataManager.getInstance().getCurrentMode();
        if (!enable || isSpotifyMode() || isFsdca3PdaMode()) {
            isImageCurrentSourceVisible.set(false);
            return;
        }

        int imageId;
        if (mode != null && mode.isAirable()) {
            imageId = AlbumCoverUtil.UpdateAirableIconOverAlbum(mode);
        } else {
            imageId = SourceIconsResourceIdFactory.getModeIconResId(mode);
        }
        if (!isFsdca3PdaMode()) {
            imageCurrentSource.set(convertResourceToDrawable(imageId));
        }


        if (enable) {
            isImageCurrentSourceVisible.set(true);
            is3PdaImageCurrentSourceVisible.set(false);
        }
    }

    private void update3PdaProviderLogo(String url) {
        if (TextUtils.isEmpty(url)) {
            is3PdaImageCurrentSourceVisible.set(false);
        } else {
            AlbumCoverDownloader albumCoverDownloader = new AlbumCoverDownloader();
            albumCoverDownloader.getSVGProviderLogoFromUrl(url, albumCover -> {
                if (albumCover != null) {
                    Drawable drawable = new BitmapDrawable(MainApplication.getCurrentActivity().getResources(), albumCover);

                    if (is3PdaModeAndDefaultTheme()) {
                        drawable.setColorFilter(Color.BLACK, PorterDuff.Mode.MULTIPLY);
                    }

                    imageCurrentSource.set(drawable);
                    isImageCurrentSourceVisible.set(false);
                }
            });
        }
    }

    @Override
    public void onPostprocessedAlbum(final Bitmap postprocessedAlbum, final Bitmap blurredAlbum) {

        NetRemote.getMainThreadExecutor().execute(() -> {
            if (mIsStopping) {
                return;
            }

            Bitmap cover = postprocessedAlbum;

            // Set mode icon only if we have art work
            setAlbumArtModeIcon(cover != null);
            if (cover != null) {
                if (isSpotifyMode()) {
                    //  imageAlbumArtBackground.set(convertResourceToDrawable(R.drawable.ic_spotifybranding));
                    Drawable spotifyLogo = getSpotifyLogoBasedOnTheme();
                    spotifyLogoPlaying.set(spotifyLogo);
                    isSpotifyPlaying.set(true);
                } else {
                    //   imageAlbumArtBackground.set(null);
                    isSpotifyPlaying.set(false);
                }

                Drawable d = new BitmapDrawable(mActivity.getResources(), cover);
                imageAlbumArt.set(d);
                isImageAlbumArtVisible.set(true);
                display3PDAProviderLogoInTheSameTimeWithArtwork();

                isImageAlbumArtOverlayVisible.set(false);
                isDontTintImageAlbumArtOverlayVisible.set(false);
            } else {
                displayDefaultIcon();
            }

            imageAlbumArtAdjustViewBounds.set(true);
            imageAlbumArtScale.set(ImageView.ScaleType.FIT_XY);

            setBackgroundBlurredArtwork(blurredAlbum);
        });
    }

    private Drawable getSpotifyLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return mActivity.getResources().getDrawable(R.drawable.ic_spotify_logo_black);
        }

        return mActivity.getResources().getDrawable(R.drawable.ic_spotify_logo_white);
    }

    private void display3PDAProviderLogoInTheSameTimeWithArtwork() {
        if (isFsdca3PdaMode()) {
            is3PdaImageCurrentSourceVisible.set(true);
        }

    }

    private void displayDefaultIcon() {

        setNoBlurredBackground();

        isImageAlbumArtVisible.set(false);

        boolean hasAvs = false;
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        if (radio != null) {
            hasAvs = radio.hasAVS();
        }

        NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();

        if (currentMode == NodeSysCapsValidModes.Mode.Spotify ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_AMAZON_MP ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_DEEZER ||
                currentMode == NodeSysCapsValidModes.Mode.AVS ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_QOBUZ ||
                currentMode == NodeSysCapsValidModes.Mode.DAB ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_TIDAL ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_NAPSTER ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_DEEZER ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_AMAZON_MP ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_CALM ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_SAAVN ||
                currentMode == NodeSysCapsValidModes.Mode.AIRABLE_KLASSIK ||
                (currentMode == NodeSysCapsValidModes.Mode.None && hasAvs)) {
            isImageAlbumArtOverlayVisible.set(false);
            isDontTintImageAlbumArtOverlayVisible.set(true);
            dontTintImageAlbumArtOverlay.set(convertResourceToDrawable());
        } else {
            isDontTintImageAlbumArtOverlayVisible.set(false);
            isImageAlbumArtOverlayVisible.set(true);
            imageAlbumArtOverlay.set(convertResourceToDrawable());
        }
    }

    void setBackgroundBlurredArtwork(Bitmap blurAlbumArt) {

        boolean useBlurredArtwork = (blurAlbumArt != null && !isSpotifyMode() && !is3PdaModeAndDefaultTheme());

        if (useBlurredArtwork) {

            BitmapDrawable bgBlured = new BitmapDrawable(mActivity.getResources(), blurAlbumArt);
            layoutMainBackground.set(bgBlured);
            isLayoutDarkAlphaVisible.set(true);
        }
    }

    private boolean is3PdaModeAndDefaultTheme() {

        return isFsdca3PdaMode() && DokUiUtils.isLightTheme();
    }

    private void setNoBlurredBackground() {
        int color = GuiUtils.getColorFromAttribute(mActivity, R.attr.nowplaying_noartwork_background_color);
        layoutMainBackground.set(new ColorDrawable(color));
        isLayoutDarkAlphaVisible.set(false);
    }

    public void onNowPlayingInfoClicked(View v) {
        QobuzDetailedInfo qobuzDetailedInfo = QobuzDetailedInfo.getInstance();
        qobuzDetailedInfo.showNowPlayingDialogInfo(mActivity);
    }

    public void onSpotifyImageClicked(View v) {
        if (isSpotifyMode()) {
            ExternalAppsOpener.openSpotify(mActivity);
        }
    }

    public void onPresetsClicked(View v) {
        NavigationHelper.goToActivityForResult(mActivity, PresetsActivity.class, NavigationHelper.AnimationType.SlideToLeft, null, 12);
    }

    public void onScanForwardClicked(View v) {
        NowPlayingManager.getInstance().scanForward();
    }

    public void onScanBackwardClicked(View v) {
        NowPlayingManager.getInstance().scanBackward();
    }

    public void onShuffleChecked(CompoundButton v, boolean isChecked) {
        if (isChecked != isShuffleChecked.get()) {
            mNowPlayingDataModel.isShuffle.set(isChecked);

            NowPlayingManager.getInstance().enableShuffle(isChecked);
        }
    }

    public void onRepeatClicked(View view) {
        if (mNowPlayingDataModel.repeatMode.get() == BasePlayRepeat.Ord.OFF) {
            NowPlayingManager.getInstance().enableRepeat(BasePlayRepeat.Ord.REPEAT_ALL);
            mNowPlayingDataModel.repeatMode.set(BasePlayRepeat.Ord.REPEAT_ALL);
        } else if (mNowPlayingDataModel.repeatMode.get() == BasePlayRepeat.Ord.REPEAT_ALL && mNowPlayingDataModel.isRepeatOneAvailable()) {
            NowPlayingManager.getInstance().enableRepeat(BasePlayRepeat.Ord.REPEAT_ONE);
            mNowPlayingDataModel.repeatMode.set(BasePlayRepeat.Ord.REPEAT_ONE);
        } else {
            NowPlayingManager.getInstance().enableRepeat(BasePlayRepeat.Ord.OFF);
            mNowPlayingDataModel.repeatMode.set(BasePlayRepeat.Ord.OFF);
        }
    }

    private void updateSongRating() {
        // neutral
        if (mNowPlayingDataModel.songRating.get() == BasePlayRating.Ord.NEUTRAL) {
            songThumbsDown.set(false);
            songThumbsUp.set(false);
        }
        // thumbsUp
        if (mNowPlayingDataModel.songRating.get() == BasePlayRating.Ord.POSITIVE) {
            songThumbsUp.set(true);
            songThumbsDown.set(false);
        }
        // thumbsDown
        if (mNowPlayingDataModel.songRating.get() == BasePlayRating.Ord.NEGATIVE) {
            songThumbsUp.set(false);
            songThumbsDown.set(true);
        }
    }

    public void onSkipForwardClicked() {
        NowPlayingManager nowPlayingManager = NowPlayingManager.getInstance();

        if (nowPlayingManager.canSkipForward()) {
            nowPlayingManager.skipForward();
            updatePlaybackProgress();
        } else {
            nowPlayingManager.setEntireDuration();
            updatePlaybackProgress();
        }
    }

    public void onSkipBackwardClicked() {
        NowPlayingManager nowPlayingManager = NowPlayingManager.getInstance();

        if (nowPlayingManager.canSkipBackward()) {
            nowPlayingManager.skipBackward();
            updatePlaybackProgress();
        } else {
            nowPlayingManager.setInitialDuration();
            updatePlaybackProgress();
        }
    }


    public void dispose() {
        mIsStopping = true;

        unregisterPropertyChangedCallback();

        unregisterNotifCallbacks();

        stopProgressTimer();

        mNowPlayingPropertyChangedCallback = null;
        mNowPlayingDataModel = null;
        mRadioVisManager.cleanup();
        mRadioVisManager = null;

        mActivity = null;
        mBinding = null;
        if (mLifecycle != null) {
            mLifecycle.removeObserver(this);
            mLifecycle = null;
        }
    }

    private void displayAmazonConcurencyAlert(final String concurrencyString) {
        if (TextUtils.isEmpty(concurrencyString)) {
            return;
        }

        NetRemote.getMainThreadExecutor().execute(() -> {
            String dialogKey = "amazon_concurency_error_message_dlg";
            if (DokUiUtils.isDestroyed(mActivity) || DialogsHolder.isShowing(dialogKey)) {
                return;
            }

            String title = null;
            String message = null;
            try {
                JSONObject obj = new JSONObject(concurrencyString);

                if (obj.has("title") && obj.has("description")) {
                    title = obj.getString("title");
                    message = obj.getString("description");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mActivity);

            builder.setTitle(title);
            builder.setMessage(message);

            final Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();

            builder.setPositiveButton(android.R.string.yes, (arg0, arg1) ->
                    currentRadio.setNode(new NodePlayConcurencyResponse(BasePlayConcurencyResponse.Ord.TRUE), false));

            builder.setNegativeButton(android.R.string.no, (arg0, arg1) ->
                    currentRadio.setNode(new NodePlayConcurencyResponse(BasePlayConcurencyResponse.Ord.FALSE), false));

            builder.setOnDismissListener((dialogInterface) ->
                    currentRadio.setNode(new NodePlayConcurencyResponse(BasePlayConcurencyResponse.Ord.FALSE), false));

            AlertDialog dlg = builder.create();
            DialogsHolder.addDialogToCollection(dialogKey, dlg);
            dlg.show();
        });
    }

    private void displayNotificationMessage(String notificationMessage) {
        if (TextUtils.isEmpty(notificationMessage)) {
            return;
        }

        GuiUtils.showToast(notificationMessage, mActivity);
    }

}

