package com.frontier_silicon.fsirc.dok2.RemoteConfigModel

data class OktivPromoPopupModel(val isEnabledForAllCountries: Boolean,
                                val countries: ArrayList<OktivPromoCountryModel>,
                                val firmwareBlacklist: ArrayList<OktivPromoFirmwareBlackList>) {

    override fun toString(): String {
        var s = ""

        for (c in countries) {
            s += "${c.country} ${c.isEnabled}"
            s += "\n"
        }

        return s;
    }
}