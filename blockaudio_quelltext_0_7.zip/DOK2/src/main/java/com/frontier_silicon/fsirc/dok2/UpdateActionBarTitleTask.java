package com.frontier_silicon.fsirc.dok2;

import android.os.AsyncTask;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomGroupState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;

import java.util.List;

public class UpdateActionBarTitleTask extends AsyncTask<Void, Void, Boolean> {

	private AppCompatActivity mParentActivity;

    private String mTitle = "";
    private String mSubTitle = "";
	
	public UpdateActionBarTitleTask(AppCompatActivity parentActivity, String defaultTitle) {
		mParentActivity = parentActivity;
        mTitle = defaultTitle;
	}
	
	@Override
	protected Boolean doInBackground(Void... arg0) {

		return getCurrentConnectionName();
	}
	
	@Override
	protected void onPostExecute(Boolean result) {
		if (mParentActivity != null) {
			ActionBar actionBar = mParentActivity.getSupportActionBar();
			if (actionBar == null)
				return;
			
			// show curr. connected group/radio			
			View customView = actionBar.getCustomView();
			if (customView == null)
				return;

            TextView titleView = customView.findViewById(R.id.text);
            titleView.setText(mTitle);
            if (UndokPreferences.getInstance().getScrollingEnabled()) {
				titleView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
			} else {
				titleView.setEllipsize(TextUtils.TruncateAt.END);
			}

			TextView subTitleView = customView.findViewById(R.id.textCurrentConnection);
            subTitleView.setText(mSubTitle);

			if (TextUtils.isEmpty(mSubTitle)) {
				subTitleView.setVisibility(View.GONE);
			} else {
				subTitleView.setVisibility(View.VISIBLE);
			}
		}

		mParentActivity = null;
	}

	private boolean getCurrentConnectionName() {
        boolean ret = false;

        Radio currRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (currRadio != null && currRadio.isConnectionOk()) {

            String currentName = MultiroomGroupManager.getInstance().getCurrentNameOfGroupOrSpeaker();
            if (!TextUtils.isEmpty(currentName)) {
                mTitle = currentName;
            }

            if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {
				NodeMultiroomGroupState.Ord role = MultiroomGroupManager.getInstance().getCurrentDeviceGroupRole();

				mSubTitle = DokUiUtils.getFriendlyNameOrStereoSystemName(currRadio);
				if (role == NodeMultiroomGroupState.Ord.SERVER) {

					long numClients = MultiroomGroupManager.getInstance().getNumClientsForCurrentGroup();
					if (numClients > 0) {
						mSubTitle = mSubTitle + " + " + numClients;
					}
				} else if (role == NodeMultiroomGroupState.Ord.CLIENT) {
					// is client, we need to find server name
					List<MultiroomDeviceModel> groupDevices = MultiroomGroupManager.getInstance().getGroupOfRadio(currRadio);

					for (MultiroomDeviceModel deviceModel: groupDevices) {
						if (deviceModel.mGroupRole == NodeMultiroomGroupState.Ord.SERVER) {

							mSubTitle = deviceModel.toString() + " + " + (groupDevices.size()-1);
							return true;
						}
					}

					mSubTitle = DokUiUtils.getFriendlyNameOrStereoSystemName(currRadio) + " + " + groupDevices.size();
				}
            }

            ret = true;
        }

		return ret;
	}
}
