package com.frontier_silicon.fsirc.dok2;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.frontier_silicon.fsirc.dok2.gdpr.GDPRActivity;
import com.frontier_silicon.fsirc.dok2.gdpr.GDPRVersionManager;
import com.frontier_silicon.fsirc.dok2.home.HomeActivity;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;

public class SplashScreenActivity extends AppCompatActivity {

    public static final String FRAGMENT_TAG = "TAG_SPLASHSCREEN_FRAGMENT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    public void onResume() {
        super.onResume();

        if (GDPRVersionManager.isInternetConnectionAvailable(this)) {
            GDPRVersionManager.checkAsync(getResources().getString(R.string.gdpr_version_link), newVersionIsAvailable -> {
                GDPRVersionManager.setFirstCheckIsDone();
                if (!newVersionIsAvailable) {
                    sendAnalyticsMessage();
                }
                if (newVersionIsAvailable) {
                    openGDPRActivity();
                } else {
                    openHomeActivity();
                    UndokPreferences.getInstance().setInitialTutorialCompleted(true);
                }
            });
        } else {
            // skip GDPR checking if no internet connection is available
            openHomeActivity();
            UndokPreferences.getInstance().setInitialTutorialCompleted(true);
        }
    }
    private void sendAnalyticsMessage() {
        if (UndokPreferences.getInstance().shouldSendInstallEvent()) {
            AnalyticsSender.sendInstallEvent();
        }

        AnalyticsSender.sendThemeAnalytics();
        AnalyticsSender.sendFontAnalytics(this);
    }

    public void openHomeActivity() {
        NavigationHelper.goToActivity(this, HomeActivity.class, NavigationHelper.AnimationType.SlideToLeft, true);
    }

    public void openGDPRActivity() {
        NavigationHelper.goToActivity(this, GDPRActivity.class, NavigationHelper.AnimationType.SlideToLeft, true);
    }
}
