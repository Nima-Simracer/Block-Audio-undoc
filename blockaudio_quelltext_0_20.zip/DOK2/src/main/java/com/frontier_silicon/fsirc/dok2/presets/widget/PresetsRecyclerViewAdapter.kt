package com.frontier_silicon.fsirc.dok2.presets.widget

import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes
import com.frontier_silicon.components.multiroom.MultiroomGroupManager
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.databinding.GroupHeaderListItemBinding
import com.frontier_silicon.fsirc.dok2.databinding.PresetsListItemBinding
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication
import com.frontier_silicon.fsirc.dok2.presets.IPresetsControlListener
import com.frontier_silicon.fsirc.dok2.presets.PresetItemModel
import com.frontier_silicon.fsirc.dok2.sources.SourceIconsResourceIdFactory
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager
import java.util.*
import kotlin.collections.ArrayList

class PresetsRecyclerViewAdapter(val mListener: IPresetsControlListener) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>(), ItemTouchHelperAdapter {

    enum class ViewTypes {
        Preset,
        SpeakerName
    }

    var presetsList = ArrayList<PresetItemModel>()
    var mSwapOptionEnabled = false
    var mSourcePresetForSwap: PresetItemModel? = null

    inner class PresetViewHolder(val binding: PresetsListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun loadData(position: Int) {
            val currentMode = SpeakerDataManager.getInstance().currentMode
            val item = (presetsList?.get(position))
            binding.textViewPresetIndex.text = item?.let { getIndex(it) }
            binding.text1.text = item?.let { getText(it) }

            binding.presetViewWrapper.setOnClickListener {

                if (mSwapOptionEnabled) {
                    mListener.onSwap(mSourcePresetForSwap, item)
                    mSwapOptionEnabled = false
                } else {
                    mListener?.onPresetSelected(item)
                }
            }

            if (mSwapOptionEnabled) {
                if (item?.equals(mSourcePresetForSwap) == true) {
                    binding.imageViewSelectedPreset.visibility = View.VISIBLE
                } else {
                    binding.imageViewSelectedPreset.visibility = View.GONE
                }

                binding.buttonClearPreset.visibility = View.GONE
                binding.editPresets.visibility = View.GONE
                binding.buttonClearPreset.visibility = View.GONE
                binding.imageViewAddPreset.visibility = View.GONE
                return
            } else {
                binding.imageViewSelectedPreset.visibility = View.GONE
            }

            val isPresetEditAvailable =
                SpeakerDataManager.getInstance().speakerDataModel.isPresetEditionSupported.get()
            if (item != null) {
                if (SpeakerDataManager.getInstance().speakerDataModel.isCLearButtonFromPresetsVisible.get() && !item.isPresetEmpty && shouldDisplayClearButton(
                        item
                    )
                ) {
                    binding.buttonClearPreset.visibility = View.VISIBLE
                    binding.imageViewAddPreset.visibility = View.GONE
                } else if (isPresetEditAvailable && !item.isPresetEmpty) {
                    binding.editPresets.visibility = View.VISIBLE
                }
            }

            if (isPresetEditAvailable) {
                if (item?.isPresetEmpty == true) {
                    binding.imageViewAddPreset.visibility = View.VISIBLE
                    binding.editPresets.visibility = View.GONE

                } else {
                    binding.imageViewAddPreset.visibility = View.GONE
                }
            } else {
                binding.imageViewAddPreset.visibility = View.VISIBLE
            }


            binding.imageViewAddPreset.setOnClickListener {
                mListener?.onPresetAddSelected(item)
            }

            binding.buttonClearPreset.setOnClickListener {
                mListener?.onPresetDeleteRequested(item)
                binding.buttonClearPreset.visibility = View.INVISIBLE
            }


            binding.editPresets.setOnClickListener {
                mListener?.onPresetEditedRequested(item)
            }

        }
    }

    inner class PresetHeaderViewHolder(val binding: GroupHeaderListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun loadData(position: Int) {
            val item = (presetsList?.get(position))
            binding.text1.text = item?.let { getText(it) }
        }
    }


    fun swapItems(presetsList: List<PresetItemModel>) {
        this.presetsList.clear()
        this.presetsList.addAll(presetsList)

        notifyDataSetChanged()
    }

    fun swapPresets(item: PresetItemModel) {
        mSwapOptionEnabled = true
        mSourcePresetForSwap = item
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        val item = presetsList.get(position)
        return if (item.mIsSelectable) {
            ViewTypes.Preset.ordinal
        } else {
            ViewTypes.SpeakerName.ordinal
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {


        return if (viewType == ViewTypes.Preset.ordinal) {
            val binding = DataBindingUtil.inflate<PresetsListItemBinding>(
                LayoutInflater.from(parent.context),
                R.layout.presets_list_item,
                parent,
                false
            )

            PresetViewHolder(binding)
        } else {
            val binding = DataBindingUtil.inflate<GroupHeaderListItemBinding>(
                LayoutInflater.from(parent.context),
                R.layout.group_header_list_item,
                parent,
                false
            )

            PresetHeaderViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is PresetViewHolder) {
            holder.loadData(position)
        } else if (holder is PresetHeaderViewHolder) {
            holder.loadData(position)
        }
    }

    override fun getItemCount(): Int {
        return presetsList.size
    }


    private fun setImage(imageView: ImageView, currentMode: NodeSysCapsValidModes.Mode) {
        val imageId = SourceIconsResourceIdFactory.getModeIconResId(currentMode)
        imageView.setImageResource(imageId)
    }

    private fun getText(item: PresetItemModel): String? {
        var text = item.mName
        if (TextUtils.isEmpty(text)) {
            text = MainApplication.getContext().getString(R.string.preset_not_set)
        }
        return text
    }

    private fun getIndex(item: PresetItemModel): String? {
        return if (item.mIsSelectable) (item.mKeyId + 1).toString() + "." else ""
    }


    fun shouldDisplayClearButton(itemModel: PresetItemModel?): Boolean {
        if (itemModel?.mRadio == null) {
            return false
        }
        val radio = itemModel.mRadio
        val multiroomDeviceModel = MultiroomGroupManager.getInstance().getDeviceByUdn(radio.udn)
        return multiroomDeviceModel != null && (multiroomDeviceModel.isServer || multiroomDeviceModel.isLonely)
    }

    override fun onItemMove(fromPosition: Int, toPosition: Int) {
        if (fromPosition < toPosition) {
            for (i in fromPosition until toPosition) {
                Collections.swap(presetsList, i, i + 1)
            }
        } else {
            for (i in fromPosition downTo toPosition + 1) {
                Collections.swap(presetsList, i, i - 1)
            }
        }

        notifyItemMoved(fromPosition, toPosition)
    }

    override fun onItemMoveFinished(fromPosition: Int, toPosition: Int) {
        mListener?.onPresetReordered(presetsList, fromPosition, toPosition)
    }

}