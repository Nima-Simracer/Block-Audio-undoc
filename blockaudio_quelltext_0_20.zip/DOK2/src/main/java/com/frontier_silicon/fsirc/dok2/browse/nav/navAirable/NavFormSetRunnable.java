package com.frontier_silicon.fsirc.dok2.browse.nav.navAirable;

import com.frontier_silicon.NetRemoteLib.Node.NodeNavEncFormData;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavFormData;
import com.frontier_silicon.NetRemoteLib.Radio.ErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.NetRemoteLib.Radio.nodeCommunication.NodeSyncSetter;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormSetRunnable;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

public class NavFormSetRunnable extends FormSetRunnable {

    public NavFormSetRunnable(Radio radio, String params, long id, INavFormDataSendListener listener) {
        super(radio, params, id, listener);
    }

    @Override
    public void run() {
        FsLogger.log("form data set runnable started ", LogLevel.Info);

        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {
            if (sendFormDataEncryptedFirst())
                sendResultToListener(RadioNavigationUtil.getInstance().navigateNavItem(mRadio, mId));
            else
                sendResultToListener(false);
        }

        dispose();
    }

    private boolean sendFormDataEncryptedFirst() {
        String encryptedData = RadioNodeUtil.encryptWithRsaNode(mRadio, mParams);

        NodeNavEncFormData encFormDataNode = new NodeNavEncFormData(encryptedData);

        NodeSyncSetter formDataNodeSyncSetter = mRadio.nodeSyncSetter(encFormDataNode);

        if (formDataNodeSyncSetter.set()) {
            return true;
        } else if (formDataNodeSyncSetter.mErrorResponse != null &&
                formDataNodeSyncSetter.mErrorResponse.getFSStatus() == ErrorResponse.FSStatusCode.FS_NODE_DOES_NOT_EXIST) {
            NodeNavFormData node = new NodeNavFormData(mParams);
            return mRadio.nodeSyncSetter(node).set();
        }

        return false;
    }
}
