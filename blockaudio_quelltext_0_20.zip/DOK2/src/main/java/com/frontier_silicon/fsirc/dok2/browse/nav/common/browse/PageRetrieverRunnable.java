package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;

import java.util.List;

/**
 * Created by lsuhov on 30/06/16.
 */

public abstract class PageRetrieverRunnable implements Runnable {

    public interface IPageRetrieverListener {
        void onNavPageRetrieved(List<UnifiedBrowseListItem> listItems);
    }

    protected Radio mRadio;
    protected int mStartIndex;
    protected boolean mFirstPageOnly;
    protected IPageRetrieverListener mListener;

    public PageRetrieverRunnable(int startIndex, Radio radio, boolean firstPageOnly, IPageRetrieverListener listener) {
        mStartIndex = startIndex;
        mRadio = radio;
        mFirstPageOnly = firstPageOnly;
        mListener = listener;
    }

    @Override
    public abstract void run();

    protected void sendNavListToListener(List<UnifiedBrowseListItem> listItems) {
        if (mListener != null) {
            mListener.onNavPageRetrieved(listItems);
        }
    }

    protected void dispose() {
        mRadio = null;
        mListener = null;
    }
}
