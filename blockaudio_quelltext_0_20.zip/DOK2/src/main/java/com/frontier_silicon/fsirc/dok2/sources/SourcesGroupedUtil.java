package com.frontier_silicon.fsirc.dok2.sources;

import android.content.Context;

import com.frontier_silicon.fsirc.dok2.R;

import java.util.ArrayList;
import java.util.List;

public class SourcesGroupedUtil {
	
	static public List<SourceItemModel> getGroupedModesList(List<SourceItemModel> modesList, Context context, boolean castEnabled) {
		List<SourceItemModel> groupedModesList = new ArrayList<>();

        List<SourceItemModel> castAppsList = getCastAppsList(context);

        if (!castAppsList.isEmpty() && castEnabled) {
            SourceItemModel castAppsHeader = new SourceItemModel(context.getString(R.string.cast_apps_header),
                    "", false, SourcesRadioUtil.INVALID_MODE_KEY);
            groupedModesList.add(castAppsHeader);
            groupedModesList.addAll(castAppsList);
        } else {
            castAppsList.clear();
        }

        List<SourceItemModel> streamableModesList = getStreamableModes(modesList, true);
        List<SourceItemModel> nonStreamableModesList = getStreamableModes(modesList, false);
		
		if (!streamableModesList.isEmpty()) {

		    /* add Multi-room Source header only if there are also Standalone sources */
            if (!nonStreamableModesList.isEmpty() || !castAppsList.isEmpty()) {
                SourceItemModel streamableModesGroupHeader = new SourceItemModel(context.getString(R.string.multiroom_modes), "", false, SourcesRadioUtil.INVALID_MODE_KEY);
                groupedModesList.add(streamableModesGroupHeader);
            }
			groupedModesList.addAll(streamableModesList);
		}
		
		if (!nonStreamableModesList.isEmpty()) {
            if (!groupedModesList.isEmpty()) {
                SourceItemModel nonStreamableModesGroupHeader = new SourceItemModel(context.getString(R.string.standalone_modes), "", false, SourcesRadioUtil.INVALID_MODE_KEY);
                groupedModesList.add(nonStreamableModesGroupHeader);
            }
			groupedModesList.addAll(nonStreamableModesList);
		}

		return groupedModesList;
	}
	
	static private List<SourceItemModel> getStreamableModes(List<SourceItemModel> modesList, boolean streamable) {
		List<SourceItemModel> filteredModesList = new ArrayList<>();
		
		for (SourceItemModel mode : modesList) {
            if (streamable) {
                if (mode.mIsStreamable) {
                    filteredModesList.add(mode);
                }
            } else {
                if (!mode.mIsStreamable) {
                    filteredModesList.add(mode);
                }
            }
		}
		
		return filteredModesList;
	}

	static private ArrayList<SourceItemModel> getCastAppsList(Context context) {
        ArrayList<SourceItemModel> appList = new ArrayList<>();

        SourceItemModel google = new SourceItemModel(context.getString(R.string.google_cast_Google_Music), context.getString(R.string.google_cast_castApp), false, SourcesRadioUtil.INVALID_MODE_KEY);
        google.mApp = SourceItemModel.CastApp.PlayMusic;
        appList.add(google);

        SourceItemModel spotify = new SourceItemModel(context.getString(R.string.google_cast_Spotify), context.getString(R.string.google_cast_castApp),
                 false, SourcesRadioUtil.INVALID_MODE_KEY);
        spotify.mApp = SourceItemModel.CastApp.Spotify;
        appList.add(spotify);

        SourceItemModel tunein = new SourceItemModel(context.getString(R.string.google_cast_TuneIn), context.getString(R.string.google_cast_castApp),
                 false, SourcesRadioUtil.INVALID_MODE_KEY);
        tunein.mApp = SourceItemModel.CastApp.TuneIn;
        appList.add(tunein);

        SourceItemModel nprone = new SourceItemModel(context.getString(R.string.google_cast_NPR_One), context.getString(R.string.google_cast_castApp),
                 false, SourcesRadioUtil.INVALID_MODE_KEY);
        nprone.mApp = SourceItemModel.CastApp.NPROne;
        appList.add(nprone);

        SourceItemModel moreApps = new SourceItemModel(context.getString(R.string.google_cast_more_apps), context.getString(R.string.google_cast_castApp),
                false, SourcesRadioUtil.INVALID_MODE_KEY);
        moreApps.mApp = SourceItemModel.CastApp.MoreApps;
        appList.add(moreApps);

        return appList;
    }
}
