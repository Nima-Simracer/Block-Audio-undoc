package com.frontier_silicon.fsirc.dok2.settings.equalizer;

import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.Node.NodeDefs;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioEqPreset;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsEqPresets;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class EqualizerUtil {

	private Vector<IEqualizerListener> mListeners;
	private Radio mClientRadio;

	private CustomEqualizerUtil mCustomEqualizerUtil;

	public EqualizerUtil() {
		mListeners = new Vector<>();

		mCustomEqualizerUtil = new CustomEqualizerUtil();
	}
	
	synchronized public boolean removeListener(IEqualizerListener listener) {
		return mListeners.remove(listener);
	}
	
	synchronized public boolean addListener(IEqualizerListener listener) {
		return mListeners.add(listener);
	}
	
	synchronized public void notifyEqulizerPresetsUpdate(ArrayList<EqualizerItemModel> eqList) {
		for (IEqualizerListener listener : mListeners) {
			listener.onEqualizerPresetsUpdate(eqList);
		}
	}

	static public boolean isEqualizerSupported(Radio radio) {
		final boolean[] isEQSupported = {false};
		
		if (radio == null) {
			radio = NetRemoteManager.getInstance().getCurrentRadio();
		}

		if (radio != null) {
            List resultList = radio.nodeListSyncGetter(NodeSysCapsEqPresets.class).get();
            isEQSupported[0] = (resultList != null);
		}

		return isEQSupported[0];
	}
	
	public void setEqualizerPreset(long keyId) {
		Radio radio = mClientRadio;

		if (radio == null) {
			radio = NetRemoteManager.getInstance().getCurrentRadio();
		}

        radio.setNode(new NodeSysAudioEqPreset(keyId), false);
	}

	public void updateEqualizerPresetsList() {
        UpdateEqualizerPresetsTask updateEqualizersTask = new UpdateEqualizerPresetsTask();
        TaskHelper.execute(updateEqualizersTask);
	}

	private class UpdateEqualizerPresetsTask extends AsyncTask<Void, Integer, Boolean> {

		protected static final long CUSTOM_EQ_KEY_ID = 0;
		private ArrayList<EqualizerItemModel> mEqualizerPresetsList;
		
		public UpdateEqualizerPresetsTask() {
			
		}
		
		@Override
		protected Boolean doInBackground(Void... arg0) {
			boolean result = true;
			mEqualizerPresetsList = new ArrayList<>();

			Radio radio = mClientRadio;

			if (radio == null) {
				radio = NetRemoteManager.getInstance().getCurrentRadio();
			}

			// get for current device
			if (isEqualizerSupported(radio)) {
				result = getEqualizerList(radio);
			} else {
				mEqualizerPresetsList = null;
				result = false;
			}

			if (mEqualizerPresetsList != null) {
				for (EqualizerItemModel equalizerPresetItem : mEqualizerPresetsList) {
					if (equalizerPresetItem.mIsCustomEq) {
						mCustomEqualizerUtil.getCustomEQBands(mClientRadio, equalizerPresetItem.mEqualizerItemsList);

						equalizerPresetItem.mIsLoudnessAvailable = mCustomEqualizerUtil.isEqualizerLoudnessAvailable(mClientRadio);
						if (equalizerPresetItem.mIsLoudnessAvailable) {
							equalizerPresetItem.mIsLoudnessEnabled = mCustomEqualizerUtil.isEqualizerLoudnessEnabled(mClientRadio);
						}
					}
				}
			}
			
			return result;
		}
		
		private boolean getEqualizerList(Radio radio) {
			NodeSysAudioEqPreset currEqPreset = (NodeSysAudioEqPreset) radio.
                    nodeSyncGetter(NodeSysAudioEqPreset.class).get();

			if (currEqPreset == null) {
				mEqualizerPresetsList = null;
				return false;
			}
			
			final long currentEqKey = currEqPreset.getValue();
			
			radio.getListNode(NodeSysCapsEqPresets.class, "-1", NodeDefs.MaxItemsForList, true, new IGetNodeCallback() {
				@Override
				public void getNodeResult(NodeInfo node) {
					NodeSysCapsEqPresets eqListNode = (NodeSysCapsEqPresets)node;
					
					for (NodeSysCapsEqPresets.ListItem eqItem : eqListNode.getEntries()) {
						boolean isCurrentSelected = (currentEqKey == eqItem.getKey());
						boolean isCustomEq = (CUSTOM_EQ_KEY_ID == eqItem.getKey());
						
						EqualizerItemModel equalizerPresetItem = new EqualizerItemModel(eqItem.getLabel(), isCurrentSelected, isCustomEq, eqItem.getKey());							
						mEqualizerPresetsList.add(equalizerPresetItem);
					}
				}

				@Override
				public void getNodeError(Class nodeType, NodeErrorResponse error) {
					FsLogger.log("getListNode failed " + nodeType + " " + error, LogLevel.Error);
				}
			});
			
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			notifyEqulizerPresetsUpdate(mEqualizerPresetsList);
		}
		
	}

	public void setCustomEqualizerBandValue(Radio clientRadio, CustomEqualizerItemModel item) {
		mCustomEqualizerUtil.setCustomEqualizerBandValue(clientRadio, item);
	}

	public void setEqualizerLoudness(Radio clientRadio, boolean enable) {
		mCustomEqualizerUtil.setEqualizerLoudness(clientRadio, enable);
	}

	public void setClientRadio(Radio clientRadio) {
		mClientRadio = clientRadio;
	}
	
}
