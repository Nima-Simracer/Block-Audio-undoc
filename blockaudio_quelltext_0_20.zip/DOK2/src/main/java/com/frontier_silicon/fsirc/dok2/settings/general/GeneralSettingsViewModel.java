package com.frontier_silicon.fsirc.dok2.settings.general;

import android.app.Activity;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.settings.SettingsItemModel;
import com.frontier_silicon.fsirc.dok2.settings.SettingsType;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 11/10/2017.
 */

public class GeneralSettingsViewModel {

    private Activity mActivity;
    private GeneralSettingsAdapter mAdapter;

    public GeneralSettingsViewModel(Activity activity) {
        mActivity = activity;

        init();
    }

    private void init() {
        mAdapter = new GeneralSettingsAdapter(mActivity);
        EventBus.getDefault().register(this);
    }

    public void onResume() {
        populateAdapter();
    }

    @Subscribe
    public void notifyScrollStateChanged(ScrollStateEvent event) {
        populateAdapter();
    }

    private void populateAdapter() {
        List<SettingsItemModel> listOfSettings = getListOfSettings();

        mAdapter.setNewListOfSettings(listOfSettings);
    }

    private List<SettingsItemModel> getListOfSettings() {
        List<SettingsItemModel> list = new ArrayList<>();
/*
        if (shouldAddUndokAccountSetting()) {
            list.add(new SettingsItemModel(SettingsType.ACCOUNT_MANAGER, mActivity.getString(R.string.account_management), true));
        }
*/
        list.add(new SettingsItemModel(SettingsType.SPEAKER_LIST, SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.audio_systems, false, true), true));

        list.add(new SettingsItemModel(SettingsType.THEMES, mActivity.getString(R.string.select_theme), true));

        // Fassung 0.16 Audioblock (19.09.2026) — HERAUSGENOMMEN.
        // Fuehrte auf https://nuvola.link/undok-addstation ("Sender vorschlagen").
        // Die Seite gibt es nicht mehr, nuvola.link loest gar nicht mehr auf.
        // list.add(new SettingsItemModel(SettingsType.IR_STATION_SUGGESTION, mActivity.getString(R.string.ir_station_suggestion), true));

        addLoggingSetting(list);

        addScrollingSetting(list);

        addSendLog(list);

        list.add(new SettingsItemModel(SettingsType.CLEAR_APP_DATA, mActivity.getString(R.string.clear_app_data), false));

        list.add(new SettingsItemModel(SettingsType.EUROPEAN_DATA, mActivity.getString(R.string.settings_gdpr), true));


        // Fassung 0.16 Audioblock (19.09.2026) — BEIDE HERAUSGENOMMEN.
        //
        // "SmartRadio Service-Zustand" ging auf https://status.frontiersmart.com
        // und liefert dort 404. "FAQ" ging auf https://nuvola.link/undok-faq-de —
        // diese Netzadresse existiert nicht mehr (ERR_NAME_NOT_RESOLVED).
        //
        // Beides sind Frontier-Seiten, beide tot. Ein Eintrag, der immer ins
        // Leere fuehrt, ist schlimmer als gar keiner.
        //
        // Wenn Block eigene Seiten hat, kommen sie hier wieder herein — dann nur
        // die Adressen in strings.xml tauschen und diese Zeilen freigeben.
        // list.add(new SettingsItemModel(SettingsType.IT_SERVICE_STATUS,
        //         SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.service_status, true), true));
        //
        // list.add(new SettingsItemModel(SettingsType.FAQ, mActivity.getString(R.string.faq), true));

        list.add(new SettingsItemModel(SettingsType.ABOUT_APP, mActivity.getString(R.string.about), true));

        list.add(new SettingsItemModel(SettingsType.OPEN_SOURCE_SOFTWARE,  mActivity.getString(R.string.open_source_title), false));

        return list;
    }

    private boolean shouldAddUndokAccountSetting() {
        boolean shouldAdd = false;

        for (Radio radio: NetRemoteManager.getInstance().getRadios()) {
            if (radio != null && radio.hasFSDCA()) {
                shouldAdd = true;
            }
        }

        return shouldAdd;
    }

    private void addLoggingSetting(List<SettingsItemModel> list) {
        boolean enabled = CommonPreferences.getInstance().getLoggingEnabled();

        list.add(new SettingsItemModel(SettingsType.LOGGING_ENABLED,
                mActivity.getString(R.string.logging_enabled), null, false, true, enabled));
    }

    private void addScrollingSetting(List<SettingsItemModel> list) {
        boolean enabled = UndokPreferences.getInstance().getScrollingEnabled();

        list.add(new SettingsItemModel(SettingsType.SCROLLING_ENABLED,
                mActivity.getString(R.string.enable_scroll), null, false, true, enabled));
    }

    private void addSendLog(List<SettingsItemModel> settingsItemsList) {
        if (CommonPreferences.getInstance().getLoggingEnabled()) {
            settingsItemsList.add(new SettingsItemModel(SettingsType.SEND_LOG,
                    mActivity.getString(R.string.send_log), null, false, false, false));
        }
    }

    public GeneralSettingsAdapter getAdapter() {
        return mAdapter;
    }

    public void dispose() {
        mActivity = null;

        mAdapter.dispose();
        mAdapter = null;
        EventBus.getDefault().unregister(this);
    }
}
