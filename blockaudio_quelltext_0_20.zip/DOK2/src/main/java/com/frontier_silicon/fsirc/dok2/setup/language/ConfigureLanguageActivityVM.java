package com.frontier_silicon.fsirc.dok2.setup.language;

import android.app.Activity;
import androidx.databinding.ObservableField;

import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.setup.connectionType.SelectConnectionTypeActivity;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.Locale;

/**
 * Created by nbalazs on 20/03/2018.
 *
 */

public class ConfigureLanguageActivityVM {
    private Activity mActivity;

    public ObservableField<Boolean> isDetectAutomaticallyLanguageChacked = new ObservableField<>(false);
    public ObservableField<String> detectedLanguage = new ObservableField<>("");

    ConfigureLanguageActivityVM(Activity activity) {
        mActivity = activity;
    }

    public final void onNextPressed() {

        ((ConfigureLanguageActivity) mActivity).saveLanguage();
        NavigationHelper.goToActivity(mActivity, SelectConnectionTypeActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    public final void onBackPressed() {
        mActivity.onBackPressed();
    }

    public final void onAutoDetectLanguageChange(boolean checked){
        if (checked) {
            String phoneLanguage = Locale.getDefault().getDisplayLanguage();

            FsLogger.log("lang: lang is " + phoneLanguage);

            ((ConfigureLanguageActivity) mActivity).setAutoLanguage(phoneLanguage);
        }
    }
}
