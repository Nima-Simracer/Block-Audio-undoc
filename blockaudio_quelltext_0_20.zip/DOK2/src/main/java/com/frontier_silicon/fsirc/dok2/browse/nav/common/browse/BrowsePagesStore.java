package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavigationPageModel;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by lsuhov on 30/06/16.
 */

public class BrowsePagesStore {

    public static final int DEFAULT_START_KEY_ID = -1;

    private Map<Integer, NavigationPageModel> mPagesMap = new HashMap<>();

    private final int corePoolSize = 0;
    private final int maxPoolSize = 1;
    // Sets the amount of time an idle thread waits before terminating
    private final int KEEP_ALIVE_TIME = 1;
    // Sets the Time Unit to seconds
    private final TimeUnit KEEP_ALIVE_TIME_UNIT = TimeUnit.SECONDS;
    private BlockingQueue<Runnable> mNavigationRunnablesQueue = new LinkedBlockingQueue<>(100);
    private ExecutorService mThreadPoolExecutor;
    private Boolean mSearchItemWasFound = null;
    private Long mSearchKey = -1L;

    public BrowsePagesStore() {
        mThreadPoolExecutor = new ThreadPoolExecutor(corePoolSize, maxPoolSize, KEEP_ALIVE_TIME,
                KEEP_ALIVE_TIME_UNIT, mNavigationRunnablesQueue, new RejectedExecutionHandler() {
            @Override
            public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
                FsLogger.log("BrowsePagesStore: thread execution was rejected", LogLevel.Error);
            }
        });
    }

    public BrowseItemModel tryGetBrowseItemModel(int browsePosition) {
        int positionOfNavigationPage = getPositionOfNavigationPage(browsePosition);

        NavigationPageModel pageModel;

        synchronized (this) {
            if (mPagesMap.containsKey(positionOfNavigationPage)) {
                pageModel = mPagesMap.get(positionOfNavigationPage);
            } else {
                return null;
            }
        }

        int positionOfBrowseItemInNavigationPage = getPositionOfBrowseItemInNavigationPage(browsePosition);

        return pageModel.tryGetBrowseItemModel(positionOfBrowseItemInNavigationPage);
    }

    public void deleteItem(int browsePosition) {
        int positionOfNavigationPage = getPositionOfNavigationPage(browsePosition);

        NavigationPageModel pageModel;

        synchronized (this) {
            if (mPagesMap.containsKey(positionOfNavigationPage)) {
                pageModel = mPagesMap.get(positionOfNavigationPage);
            } else {
                return;
            }
        }
        int positionOfBrowseItemInNavigationPage = getPositionOfBrowseItemInNavigationPage(browsePosition);

        pageModel.deleteItem(positionOfBrowseItemInNavigationPage);
    }

    public void getBrowseItemModelAsync(int browsePosition, IBrowseItemModelRetrieveListener listener) {

        NavigationPageModel pageModel = getPageModelFromBrowsePosition(browsePosition);

        int positionOfBrowseItemInNavigationPage = getPositionOfBrowseItemInNavigationPage(browsePosition);

        pageModel.getBrowseItemModelAsync(positionOfBrowseItemInNavigationPage, listener);
    }

    private NavigationPageModel getPageModelFromBrowsePosition(int browsePosition) {
        int positionOfNavigationPage = getPositionOfNavigationPage(browsePosition);

        NavigationPageModel pageModel;

        synchronized (this) {
            if (!mPagesMap.containsKey(positionOfNavigationPage)) {
                pageModel = new NavigationPageModel(positionOfNavigationPage * FsComponentsConfig.MAX_NAV_LIST_ITEMS - 1 , mThreadPoolExecutor);
                mPagesMap.put(positionOfNavigationPage, pageModel);
            }

            return mPagesMap.get(positionOfNavigationPage);
        }
    }

    public void addNavListToStore(int pagePosition, List<UnifiedBrowseListItem> listItems) {
        int numberOfPages = (int)Math.ceil(listItems.size() / (float)FsComponentsConfig.MAX_NAV_LIST_ITEMS);

        synchronized (this) {
            for (int i = 0, tempPagePosition = pagePosition; i < numberOfPages; i++, tempPagePosition++) {
                int startPosition = i * FsComponentsConfig.MAX_NAV_LIST_ITEMS;
                int endPosition = Math.min(startPosition + FsComponentsConfig.MAX_NAV_LIST_ITEMS,
                        listItems.size());

                List<UnifiedBrowseListItem> listItemsForPage = listItems.subList(startPosition, endPosition);
                NavigationPageModel pageModel = new NavigationPageModel(tempPagePosition, listItemsForPage, mThreadPoolExecutor);
                mPagesMap.put(tempPagePosition, pageModel);
            }
        }
    }

    public boolean searchItemWasFound() {
        // the search item could be sent on the last page, that's why we need to check all the values
        NavigationPageModel navigationPageModel;
        synchronized (this) {
            for(int i=0; i<=mPagesMap.size() - 1; i++) {
                navigationPageModel = mPagesMap.get(i);
                if (navigationPageModel != null) {
                    mSearchItemWasFound = navigationPageModel.searchItemWasFound;
                    if (navigationPageModel.searchItemWasFound) {
                        mSearchKey = navigationPageModel.searchItemKey;
                    }
                }
            }
        }
        return mSearchItemWasFound != null ? mSearchItemWasFound : false;
    }

    public Long getSearchKey() {
        return mSearchKey;
    }

    public synchronized boolean isEmpty() {
        return mPagesMap.isEmpty();
    }

    public int getNumberOfItemsInStore() {
        int total = 0;

        synchronized (this) {
            for (NavigationPageModel navigationPageModel : mPagesMap.values()) {
                total += navigationPageModel.browseIRItemModels.size();
            }
        }

        return total;
    }

    public synchronized void clear() {
        Set<Integer> keys = mPagesMap.keySet();
        for (Integer key : keys) {
            NavigationPageModel navigationPageModel = mPagesMap.get(key);
            navigationPageModel.dispose();
        }
        FirebaseCrashlytics.getInstance().log("BrowsePagesStore clear");
        mPagesMap.clear();
        mNavigationRunnablesQueue.clear();
        mSearchItemWasFound = null;
        mSearchKey = -1L;
    }

    public int getPositionOfNavigationPage(int browseItemPosition) {
        int adjustedBrowseItemPosition = getBrowseItemPositionIncludingSearchPresence(browseItemPosition);

        int pagePosition = (int) Math.floor(adjustedBrowseItemPosition / FsComponentsConfig.MAX_NAV_LIST_ITEMS);

//        FsLogger.log("Page position " + pagePosition + " for browse item " + browseItemPosition, LogLevel.Info);
        return pagePosition;
    }

    private int getPositionOfBrowseItemInNavigationPage(int browseItemPosition) {
        int adjustedBrowseItemPosition = getBrowseItemPositionIncludingSearchPresence(browseItemPosition);

        int positionOfBrowseItemInNavigationPage = adjustedBrowseItemPosition % FsComponentsConfig.MAX_NAV_LIST_ITEMS;

//        FsLogger.log("Adjusted item position " + positionOfBrowseItemInNavigationPage + " for browse item " +
//                browseItemPosition, LogLevel.Info);
        return positionOfBrowseItemInNavigationPage;
    }

    private int getBrowseItemPositionIncludingSearchPresence(int browseItemPosition) {
        if (searchItemWasFound() && browsePositionIsFurtherThanFirstPage(browseItemPosition)) {
            return browseItemPosition + 1;
        } else {
            return browseItemPosition;
        }
    }

    private boolean browsePositionIsFurtherThanFirstPage(int browseItemPosition) {
        return browseItemPosition > (FsComponentsConfig.MAX_NAV_LIST_ITEMS - 2);
    }
}
