package com.frontier_silicon.fsirc.dok2.nowPlaying.googleCast;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.components.common.ExternalAppsOpener;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.R;

/**
 * Created by hcostescu on 15/05/17.
 */

public class NowPlayingGoogleCastFragment extends BaseFragment implements IChildFragment, IPageSwitchListener {
    public static final String FRAGMENT_TAG = "TAG_NOW_PLAYING_GOOGLE_CAST_FRAGMENT";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.now_playing_google_cast_fragment, container, false);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        setupControls();
    }

    private void setupControls() {
        ImageView castImageView = getView().findViewById(R.id.castImageAlbumArt);
        castImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ExternalAppsOpener.openGoogleHome(getActivity());
            }
        });
    }

    @Override
    public boolean isBackButtonHandledByFragment(boolean upButton) {
        return false;
    }

    @Override
    public void onBackButton() {
    }

    @Override
    public String getStaticTag() {
        return FRAGMENT_TAG;
    }

    @Override
    public void onFragmentActivated() {
        super.onFragmentActivatedBase();
    }

    @Override
    public void onFragmentDeactivated() {
        super.onFragmentDeactivatedBase();
    }
}