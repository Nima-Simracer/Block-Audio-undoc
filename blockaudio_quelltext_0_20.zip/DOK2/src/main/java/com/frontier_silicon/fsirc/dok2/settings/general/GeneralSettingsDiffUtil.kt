package com.frontier_silicon.fsirc.dok2.settings.general

import androidx.recyclerview.widget.DiffUtil
import com.frontier_silicon.fsirc.dok2.settings.SettingsItemModel

class GeneralSettingsDiffUtil<T: SettingsItemModel>: DiffUtil.Callback {
     var mOldList: List<T>
    var mNewList: List<T>

    constructor(oldList: List<T>, newList:  List<T>) {
        mOldList = oldList
        mNewList = newList
    }

    override fun getOldListSize(): Int {
        return mOldList.size
    }

    override fun getNewListSize(): Int {
        return mNewList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
       return mOldList[oldItemPosition].mShouldScroll == mNewList[newItemPosition]?.mShouldScroll
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return mOldList[oldItemPosition].mShouldScroll == mNewList[newItemPosition]?.mShouldScroll
    }
}