package com.frontier_silicon.fsirc.dok2.settings.airableQuality;

/**
 * Created by hcostescu on 11/3/2016.
 */

public interface IAirableQualitySoundListener {
     void onAirableQualitySoundUpdate(Long eqList);
}