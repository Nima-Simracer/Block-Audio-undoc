package com.frontier_silicon.fsirc.dok2.home;

import android.app.Activity;

import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.databinding.HomeListItemSpeakerCoreBinding;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 28/06/2017.
 */

public class HomeSingleGroupViewModel extends HomeBaseItemViewModel {

    private List<HomeListItemSpeakerCoreBinding> listOfItemBindings = new ArrayList<>();

    HomeSingleGroupViewModel(MultiroomItemModel itemModel, Activity activity) {
        super(itemModel, activity);

        init();
    }

    protected void init() {
        if (!mMultiroomItemModel.getIsGroupHeader()) {
            dispose();
            return;
        }

        super.init();

        updateSpeakerAvailability();
    }

    private void updateSpeakerAvailability() {
        MultiroomDeviceModel server = MultiroomGroupManager.getInstance().getServerDeviceFromGroupId(mMultiroomItemModel.getGroupId());

        isAvailable.set(server != null);
    }

    void addItemBinding(HomeListItemSpeakerCoreBinding itemBinding) {
        listOfItemBindings.add(itemBinding);
    }

    List<HomeListItemSpeakerCoreBinding> getListOfItemBinding() {
        return listOfItemBindings;
    }

    public void dispose() {
        listOfItemBindings.clear();

        super.dispose();
    }
}
