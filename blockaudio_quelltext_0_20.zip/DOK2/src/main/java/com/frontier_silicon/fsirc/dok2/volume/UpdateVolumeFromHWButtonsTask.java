package com.frontier_silicon.fsirc.dok2.volume;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.widget.TextView;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.R;

import static com.frontier_silicon.fsirc.dok2.R.string.volume;

public class UpdateVolumeFromHWButtonsTask extends AsyncTask<Void, Integer, Boolean> {

	private static final int INCREMENT_STEP = 1;

	private static final long DISMISS_DLG_WAIT_TIME_MS = 1000;
	private static final long UPDATE_VOL_DELAY_TIME_MS = 200;
	private static final int MIN_VOLUME_VALUE = 0;

	private int mKeyCode;

	private String mVolumeProgressDlgKey = "volume_progress_dialog";
	private ProgressDialog mProgressDlg;
	private Activity mParentActivity;

	private static long mLastVolumeKeyUpdateTime = 0;
	private static long mLastVolumeSetTime = 0;

	public UpdateVolumeFromHWButtonsTask(Activity parentActivity, int keyCode) {
		mParentActivity = parentActivity;
		mKeyCode = keyCode;
		mLastVolumeKeyUpdateTime = System.currentTimeMillis();
	}

	@Override
	protected void onPreExecute() {
		if (mParentActivity != null && !DialogsHolder.isShowingOrActivityIsFinishing(mVolumeProgressDlgKey, mParentActivity)) {
			mProgressDlg = new ProgressDialog(mParentActivity, R.style.CustomAlertDialogThemeVolume);
			mProgressDlg.setMessage(mParentActivity.getString(volume));
			mProgressDlg.setIndeterminate(false);
			mProgressDlg.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			mProgressDlg.setCancelable(true);
			mProgressDlg.setOnKeyListener(new OnKeyListener() {
				@Override
				public boolean onKey(DialogInterface dlg, int keyCode, KeyEvent event) {
					mParentActivity.onKeyDown(keyCode, event);
					return true;
				}
			});

			mProgressDlg.setMax((int) MultiroomGroupManager.getInstance().getMaxVolumeSteps() - 1);
			mProgressDlg.show();

			DialogsHolder.addDialogToCollection(mVolumeProgressDlgKey, mProgressDlg);
		} else {
			mProgressDlg = (ProgressDialog) DialogsHolder.getDialog(mVolumeProgressDlgKey);
		}
	}

	@Override
    protected Boolean doInBackground(Void... arg0) {
        MultiroomGroupManager.getInstance().initVolumeSteps();

        int maxVolSteps = (int) MultiroomGroupManager.getInstance().getMaxVolumeSteps();
        int maxVolumeValue = maxVolSteps - 1;

        int volume = MultiroomGroupManager.getInstance().getMainVolumeInSteps();

        if (System.currentTimeMillis() - mLastVolumeSetTime >= UPDATE_VOL_DELAY_TIME_MS) {

            if (mKeyCode == KeyEvent.KEYCODE_VOLUME_UP)
                volume = volume + INCREMENT_STEP;

            if (mKeyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                volume = volume - INCREMENT_STEP;

            if (volume > maxVolumeValue) {
                volume = maxVolumeValue;
            }

            if (volume < MIN_VOLUME_VALUE) {
                volume = MIN_VOLUME_VALUE;
            }

            publishProgress(volume);

            MultiroomGroupManager.getInstance().setMainVolumeInSteps(volume, true);


            int volumePercent = RadioNodeUtil.convertValueToPercent(volume, maxVolSteps);

            VolumeManager.getInstance().getVolumeDataModel().volume.set(volumePercent);


            mLastVolumeSetTime = System.currentTimeMillis();
        } else {
            publishProgress(volume);
        }

        return true;
    }

    @Override
	protected void onProgressUpdate(Integer... values) {
		int progress = values[0];
		if (DialogsHolder.isShowing(mProgressDlg)) {
			mProgressDlg.setProgress(progress);
		}
	}

	@Override
	protected void onPostExecute(Boolean result) {
		closeDialogDelayed();
	}

	private void closeDialogDelayed() {
		(new Handler()).postDelayed(new Runnable() {
            public void run() {
            	if (System.currentTimeMillis() - mLastVolumeKeyUpdateTime >= DISMISS_DLG_WAIT_TIME_MS) {
					if (mParentActivity != null && !mParentActivity.isFinishing()) {
						if (DialogsHolder.isShowing(mProgressDlg)) {
							mProgressDlg.dismiss();
							mProgressDlg = null;
						}
					}
				}
            }
        }, DISMISS_DLG_WAIT_TIME_MS);
	}

}
