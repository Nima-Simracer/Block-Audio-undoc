package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.di

import com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.fragmetns.CAFragmentFactory
import dagger.Module
import dagger.Provides

@Module
object ConnectivityAssistantProvideModule {

    @JvmStatic
    @Provides
    fun provideCAFragmentFactory(): CAFragmentFactory {
        return CAFragmentFactory()
    }


}