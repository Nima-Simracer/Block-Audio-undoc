package com.frontier_silicon.fsirc.dok2.settings.equalizer;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import com.frontier_silicon.loggerlib.LogLevel;
import com.frontier_silicon.NetRemoteLib.Node.NodeDefs;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeS16;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioEqLoudness;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsEqBands;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.components.NetRemoteManager;

public class CustomEqualizerUtil {

	public void getCustomEQBands(Radio clientRadio, ArrayList<CustomEqualizerItemModel> customEqBandsList) {
		if (clientRadio == null) {
			clientRadio = NetRemoteManager.getInstance().getCurrentRadio();
		}

		getEQBandsList(clientRadio, customEqBandsList);
	}

	private static final int MAX_LIST_ITEMS = 20;

	private void getEQBandsList(Radio radio, final ArrayList<CustomEqualizerItemModel> customEqBandsList) {
		// get custom eq. bands name and min/max value limits
		radio.getListNode(NodeSysCapsEqBands.class, "-1", MAX_LIST_ITEMS, true, new IGetNodeCallback() {
			@Override
			public void getNodeResult(NodeInfo node) {
				NodeSysCapsEqBands eqBandsListNode = (NodeSysCapsEqBands)node;

				for (NodeSysCapsEqBands.ListItem eqBandItem : eqBandsListNode.getEntries()) {
					long currValue = 0;
					CustomEqualizerItemModel equalizerBandItem = new CustomEqualizerItemModel(eqBandItem.getLabel(), currValue, eqBandItem.getMin(), eqBandItem.getMax(), eqBandItem.getKey());
					customEqBandsList.add(equalizerBandItem);
				}
			}

			@Override
			public void getNodeError(Class nodeType, NodeErrorResponse error) {
				FsLogger.log("getListNode failed " + nodeType + " " + error, LogLevel.Error);
			}
		});

		//get current values for each eq band
		for (CustomEqualizerItemModel equalizerBandItem : customEqBandsList) {
			equalizerBandItem.mValue = getEqBandValue(radio, equalizerBandItem.mKeyId);
		}
	}
	
	@SuppressWarnings("rawtypes")
	private long getEqBandValue(Radio clientRadio, long keyId) {
		long eqBandValue = 0;
		
		//TODO: this is kind of hack-y. use NodeSysAudioEqCustomParam* 
		final Class eqParamNodeClass = NodeDefs.Instance().GetNodeClass("netRemote.sys.audio.eqCustom.param" + keyId);
		
		if (clientRadio == null) {
			clientRadio = NetRemoteManager.getInstance().getCurrentRadio();
		}

		NodeS16 eqBandValueNode = (NodeS16) clientRadio.nodeSyncGetter(eqParamNodeClass).get();
        if (eqBandValueNode != null) {
            eqBandValue = eqBandValueNode.getValue();
        }
		
		return eqBandValue;
	}

	public void setCustomEqualizerBandValue(Radio clientRadio, CustomEqualizerItemModel item) {
		//TODO: this is kind of hack-y. use NodeSysAudioEqCustomParam*
		NodeInfo eqParamNodeClass = generateNodeInfoForEQBand(item.mKeyId, item.mValue);
		if (eqParamNodeClass != null) {
			
			if (clientRadio == null) {
				clientRadio = NetRemoteManager.getInstance().getCurrentRadio();
			}

            clientRadio.setNode(eqParamNodeClass, false);
			
		} else {
			FsLogger.log("setCustomEqualizerBandValue: can't instantiate node object for " + item.mKeyId, LogLevel.Error);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private NodeInfo generateNodeInfoForEQBand(long keyId, long value) {
		// Create a node to set the value
		NodeInfo node = null;
		try {
			Class eqParamNodeClass = NodeDefs.Instance().GetNodeClass("netRemote.sys.audio.eqCustom.param" + keyId);
            if (eqParamNodeClass == null) {
                return null;
            }

			Constructor con = eqParamNodeClass.getConstructor(new Class[] {Long.class});
			Object[] args = new Object[] {value};
			node = (NodeInfo)(con.newInstance(args));
		} catch (SecurityException | InstantiationException | NoSuchMethodException
                | IllegalArgumentException | InvocationTargetException | IllegalAccessException e) {
            e.printStackTrace();
		}

        return node;
	}
	
	public boolean isEqualizerLoudnessAvailable(Radio clientRadio) {
		boolean available = false;
		if (clientRadio == null) {
			clientRadio = NetRemoteManager.getInstance().getCurrentRadio();
		}

		NodeSysAudioEqLoudness loudnessNode = (NodeSysAudioEqLoudness) clientRadio.
                nodeSyncGetter(NodeSysAudioEqLoudness.class).get();

		available = (loudnessNode != null);

		return available;
	}

	public boolean isEqualizerLoudnessEnabled(Radio clientRadio) {
		boolean enabled = false;
		if (clientRadio == null) {
			clientRadio = NetRemoteManager.getInstance().getCurrentRadio();
		}

		NodeSysAudioEqLoudness loudnessNode = (NodeSysAudioEqLoudness) clientRadio.
                nodeSyncGetter(NodeSysAudioEqLoudness.class).get();

		if (loudnessNode != null) {
			enabled = (loudnessNode.getValueEnum() == NodeSysAudioEqLoudness.Ord.ON);
		}
		
		return enabled;
	}

	public void setEqualizerLoudness(Radio clientRadio, final boolean enable) {
		NodeInfo loudnessNodeInfo;
		if (enable) {
			loudnessNodeInfo = new NodeSysAudioEqLoudness(NodeSysAudioEqLoudness.Ord.ON);
		} else {
			loudnessNodeInfo = new NodeSysAudioEqLoudness(NodeSysAudioEqLoudness.Ord.OFF);
		}

		if (clientRadio == null) {
			clientRadio = NetRemoteManager.getInstance().getCurrentRadio();
		}

        clientRadio.setNode(loudnessNodeInfo, false);
	}

}
