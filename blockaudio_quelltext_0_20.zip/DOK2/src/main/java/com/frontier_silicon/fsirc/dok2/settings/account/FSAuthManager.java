package com.frontier_silicon.fsirc.dok2.settings.account;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.fsirc.dok2.settings.account.addDevice.FSDCADeviceModel;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.loggerlib.FsLogger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Created by mnisipeanu on 23/10/2017.
 */

public class FSAuthManager {
    private final static String TAG = "FsAuthManager";
    private static FSAuthManager instance;

    private OAuthToken token;

    private FSDCAEndpoints endpoints = new FSDCAEndpoints();
    private String endpoint = FSDCAEndpoints.Routes.getENDPOINT();
    private String clientId = endpoints.getCLientId();
    private String redirectUrl = FSDCAEndpoints.Routes.getREDIRECT_URL();

    private Handler mainHandler;

    private IFSDCAConnectionStatus connectionListener = null;
    private IFSDCAAuthenticationStatus mAuthenticationListener = null;
    private boolean enableDebug = true;
    private OkHttpClient mOkHttpClient = NetRemote.getOkHttpClientForInternet();
    private boolean mWasAccountDeleted = false;

    private List<FSDCADeviceModel>  mFsdcaAssociatedDevices = new CopyOnWriteArrayList<>();

    private FSAuthManager() {
        mainHandler = new Handler(Looper.getMainLooper());

        // check if we have saved a token
        getTokenFromPreferences();
    }

    public static FSAuthManager getInstance() {
        if (instance == null) {
            instance = new FSAuthManager();
        }

        return instance;
    }

    /**
     * remove token (this will not remove it on server side)
     */
    public void invalidateToken() {
        token = null;

        UndokPreferences.getInstance().setFsDcaToken(null);
    }

    public void setAuthenticationListener(final IFSDCAAuthenticationStatus listener) {

        this.mAuthenticationListener = () -> {
            if (listener == null) {
                return;
            }

            mainHandler.post(() -> listener.notAuthenticated());
        };
    }


    public void setConnectionListener(final IFSDCAConnectionStatus listener) {

        this.connectionListener = new IFSDCAConnectionStatus() {
            @Override
            public void onConnected() {
                if (listener == null) {
                    return;
                }
                mainHandler.post(() -> listener.onConnected());
            }

            @Override
            public void onFailedConnecting() {
                if (listener == null) {
                    return;
                }
                mainHandler.post(() -> listener.onFailedConnecting());
            }
        };
    }

    /**
     * invalidate tokens / logout
     */
    public void logout() {
        HttpUrl.Builder urlBuilder = HttpUrl.parse(endpoint).newBuilder();
        urlBuilder.addPathSegment("session");
        urlBuilder.addPathSegment("revoke");

        String url = urlBuilder.build().toString();
        if (enableDebug) {
            FsLogger.log("Do Post call to : " + url);
        }


        JSONObject obj = new JSONObject();
        try {
            if (token == null) {
                return;
            }

            obj.put("access_token", token.accessToken);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), obj.toString());

        final Request requestPost = new Request.Builder()
                .url(url)
                .post(body)

                .addHeader("Host", FSDCAEndpoints.Routes.getHOST_UI())
                //.addHeader("x-fsdca-command-source", "undok")

                .addHeader("Accept", "application/json, text/plain, */*")
                .addHeader("Authorization", "bearer " + token.accessToken)
                .addHeader("Connection", "keep-alive")
                .addHeader("Content-Type", "application/json")

                .build();

        mOkHttpClient.newCall(requestPost).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.code() == 204) {
                    invalidateToken();
                    mAuthenticationListener.notAuthenticated();
                } else {
                    FsLogger.log( "Log out code for fsdca is: " + response.code());
                }
            }
        });
    }

    /**
     * authenticate user and get access/refresh token
     *
     * @param activity calling activity
     */
    public void authenticate(Activity activity) {
        if (activity == null) {
            return;
        }
        
        // create login url
        String path = endpoints.getLoginURL();
        Uri uri = Uri.parse(path);

        // start external browser for login
        Intent launchBrowser = new Intent("android.intent.action.VIEW", uri);
        activity.startActivity(launchBrowser);

        activity.finish();
    }

    /**
     * get token (saved/renew it from server if expired)
     *
     * @param listener token listener
     */
    public void getToken(final OnToken listener) {

        // duplicate token listener to force listener result run on main thread
        final OnToken callback = new OnToken() {
            @Override
            public void onToken(final OAuthToken newToken) {

                mainHandler.post(() -> listener.onToken(newToken));
            }

            @Override
            public void onFailed(final Error error) {
                mainHandler.post(() -> listener.onFailed(error));
            }
        };

        // check token
        if ((token != null) && (!token.isExpired())) {
            callback.onToken(token);
        } else if (token != null && token.isExpired()) {
            refreshAccessToken(callback);
        } else if (token == null) {
            callback.onFailed(new Error(Error.TOKEN_UNAVAILABLE, ""));
            if (mAuthenticationListener != null) {
                mAuthenticationListener.notAuthenticated();
            }
        }
    }

    private void refreshAccessToken(OnToken callback) {
        if (token != null && token.isExpired()) {
            // post code for token
            HttpUrl.Builder urlBuilder = HttpUrl.parse(endpoint).newBuilder();
            urlBuilder.addPathSegment("auth");
            urlBuilder.addPathSegment("token");

            String url = urlBuilder.build().toString();
            if (enableDebug) {
                FsLogger.log("Do Post call to : " + url);
            }

            JSONObject json = new JSONObject();
            try {
                json.put("grant_type", "refresh_token");
                json.put("refresh_token", token.refreshToken);
            } catch (JSONException e) {
                e.printStackTrace();
                callback.onFailed(new Error(Error.RESPONSE_FORMAT_ERROR, ""));
            }

            if (enableDebug) {
                FsLogger.log("PostJson: " + json.toString());
            }
            RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), json.toString());

            final Request request = new Request.Builder()
                    .url(url)
                    .post(body)
                    .addHeader("Host", FSDCAEndpoints.Routes.getHOST())
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Authorization", "Bearer " + token.refreshToken)
                    .addHeader("x-fsdca-command-source", "undok")
                    .addHeader("Cache-Control", "no-cache")
                    .build();


            mOkHttpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    callback.onFailed(new Error(Error.RESPONSE_FORMAT_ERROR, ""));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.code() == 401) {
                        invalidateToken();
                        mAuthenticationListener.notAuthenticated();

                    } else if (response.code() == 200) {
                        ResponseBody body1 = response.body();

                        if (body1 != null) {
                            String out = body1.string();

                            if (enableDebug) {
                                FsLogger.log( "Tokens response: " + out);
                            }

                            try {
                                convertTokenJson(out);
                                UndokPreferences.getInstance().setFsDcaToken(token.toJson().toString());

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            callback.onToken(token);
                        } else {
                            callback.onFailed(new Error(Error.RESPONSE_FORMAT_ERROR, ""));
                        }
                    } else {
                        callback.onFailed(new Error(Error.RESPONSE_FORMAT_ERROR, ""));
                        invalidateToken();
                    }
                }
            });
        }
    }

    /**
     * check if we have a token
     *
     * @return
     */
    public boolean isConnected() {
        if (token == null) {
            return false;
        }

        return true;
    }


    /**
     * get authorization token for radio device
     *
     * @param deviceId            radio client id
     * @param deviceTokenListener response listener
     */
    public void authorizeDevice(final String deviceId, final IAuthorizeCode deviceTokenListener) {
        getToken(new OnToken() {
            @Override
            public void onToken(OAuthToken token) {
                doRequestForAuthorizeCode(deviceId, deviceTokenListener);
            }

            @Override
            public void onFailed(Error error) {
                FsLogger.log("Failed retrieving access token based on refresh token");
            }
        });
    }

    private void doRequestForAuthorizeCode(String deviceId, final IAuthorizeCode callback) {

        // post code for token
        HttpUrl.Builder urlBuilder = HttpUrl.parse(endpoint).newBuilder();
        urlBuilder
                .addPathSegment("auth")
                .addPathSegment("code")
                .addPathSegment("authorize")
                .addPathSegment(deviceId)
                .addQueryParameter("scope", "device")
                .addQueryParameter("response_type", "code");

        String url = urlBuilder.build().toString();
        if (enableDebug) {
            FsLogger.log("Do Get call to : " + url);
        }

        final Request request = new Request.Builder()
                .url(url).get()
                .addHeader("Host", FSDCAEndpoints.Routes.getHOST())
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", "Bearer " + token.accessToken)
                .addHeader("x-fsdca-command-source", "undok")
                .addHeader("Cache-Control", "no-cache")
                .build();


        mOkHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onRetrievingFailed(new Error(Error.RESPONSE_FORMAT_ERROR, ""));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (enableDebug) {
                    FsLogger.log( "Authorize device code: " + response.code());
                }
                try {
                    ResponseBody body = response.body();
                    if (body != null) {
                        String out = body.string();
                        if (enableDebug) {
                            FsLogger.log("Authorize device response: " + out);
                        }

                        JSONObject json = new JSONObject(out);

                        if (json.has("error")) {
                            // handle API error
                            callback.onRetrievingFailed(new Error(
                                    json.getString("error"),
                                    json.getString("error_description")
                            ));

                        } else {

                            AuthorizeDeviceCode authorizeCode = new AuthorizeDeviceCode();
                            authorizeCode.parseResponse(json);

                            callback.onAuthorizeCode(authorizeCode);
                        }

                    } else {
                        callback.onRetrievingFailed(new Error(Error.RESPONSE_FORMAT_ERROR, ""));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void getUser(final OnData dataCallback) {
        getToken(new OnToken() {
            @Override
            public void onToken(OAuthToken token) {
                doRequestForUserInfo(dataCallback);
            }

            @Override
            public void onFailed(Error error) {
                FsLogger.log("Failed retrieving access token based on refresh token");
            }
        });
    }

    private void doRequestForUserInfo(final OnData dataCallback) {

        // options/get code for token
        HttpUrl.Builder urlBuilder = HttpUrl.parse(endpoint).newBuilder();
        urlBuilder.addPathSegment("user");

        urlBuilder.addQueryParameter("include", "oauth_provider_tokens");

        String url = urlBuilder.build().toString();
        if (enableDebug) {
            FsLogger.log("Do Get call to : " + url);
        }

        final Request requestGet = new Request.Builder()
                .url(url)

                .addHeader("Host", FSDCAEndpoints.Routes.getHOST())
                .addHeader("x-fsdca-command-source", "undok")
                .addHeader("Accept", "application/json, text/plain, */*")
                .addHeader("Authorization", "bearer " + token.accessToken)
                .addHeader("Connection", "keep-alive")
                .addHeader("Content-Type", "application/vnd.api+json")

                .build();

        mOkHttpClient.newCall(requestGet).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.code() == 200) {
                    final ResponseBody body = response.body();
                    if (body != null) {
                        final String out = body.string();

                        if (enableDebug) {
                            FsLogger.log( "Response for user info " + out);
                            FsLogger.log("Response code for user info is: " + response.code());
                        }

                        if (dataCallback != null) {
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        dataCallback.onData(new JSONObject(out));
                                    } catch (JSONException e) {

                                    }
                                }
                            });

                        }
                    }
                } else if (response.code() == 401 || response.code() == 404) {
                    invalidateToken();
                    mAuthenticationListener.notAuthenticated();
                } else {
                    FsLogger.log("Response code for user info is: " + response.code());
                }
            }
        });
    }

    /*
    https://auth-ui-fsdca-test.frontier-silicon.com/oauth/authorize?response_type=code&client_id=" + CLIENT_ID + "&scope=user&redirect_uri=" + RETURN_URL;
     */

    /**
     * @param intent
     */
    public void setLoginUiFilterIntent(Intent intent) {
        if (intent != null) {

            Uri uri = intent.getData();
            if ((uri != null) && (uri.toString().contains(redirectUrl))) {
                // received web ui redirect

                String code = getCode(uri);

                if ((code != null) && (!code.isEmpty())) {
                    exchangeCodeForToken(code);
                } else {
                    // add a failed reason
                    connectionListener.onFailedConnecting();
                }
            }
        }
    }

    /**
     * get auth code from return uri
     *
     * @param uri return uri
     * @return return code as String
     */
    private String getCode(Uri uri) {

        final String code = uri.getQueryParameter("code");

        return code;
    }

    /**
     * exchange call API to exchange code for token
     *
     * @param code auth code received on previous step
     */
    private void exchangeCodeForToken(String code) {

        // post code for token
        HttpUrl.Builder urlBuilder = HttpUrl.parse(endpoint).newBuilder();
        urlBuilder.addPathSegment("auth");
        urlBuilder.addPathSegment("code");
        urlBuilder.addPathSegment("token");

        String url = urlBuilder.build().toString();
        if (enableDebug) {
            FsLogger.log("Do Post call to : " + url);
        }

        JSONObject json = new JSONObject();
        try {
            json.put("grant_type", "authorization_code");
            json.put("code", code);
            json.put("client_id", clientId);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (enableDebug) {
            FsLogger.log("PostJson for tokens " + json.toString());
        }
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), json.toString());

        final Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Host", FSDCAEndpoints.Routes.getHOST())
                .addHeader("Content-Type", "application/json")
                .addHeader("x-fsdca-command-source", "undok")
                .build();

        mOkHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                connectionListener.onFailedConnecting();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    ResponseBody body1 = response.body();
                    if (body1 != null) {
                        String out = body1.string();
                        if (enableDebug) {
                            Log.d(TAG, "Response: " + out);
                        }

                        convertTokenJson(out);
                        UndokPreferences.getInstance().setFsDcaToken(token.toJson().toString());

                        connectionListener.onConnected();
                    } else {
                        connectionListener.onFailedConnecting();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    connectionListener.onFailedConnecting();
                }

            }


        });
    }

    public void getAssociatedDevices(FSDCADeviceModel.IDevicesListener listener) {
        getToken(new OnToken() {
            @Override
            public void onToken(OAuthToken token) {
                getUserAssociatedDevices(listener);
            }

            @Override
            public void onFailed(Error error) {
                sendFinishEvent(listener);
                FsLogger.log("Failed retrieving access token based on refresh token");
            }
        });
    }


    private void getUserAssociatedDevices(FSDCADeviceModel.IDevicesListener listener) {
        Request request = new Request.Builder()
                .url(FSDCAEndpoints.Routes.getGET_DEVICES())
                .addHeader("Authorization", "Bearer " + token.accessToken)
                .build();

        FsLogger.log("Get devices: " + request.toString());

        mOkHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                sendFinishEvent(listener);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                ResponseBody body = response.body();

                if (body != null) {
                    String stringResponse = body.string();
                    response.close();
                    mainHandler.post(() -> getDevices(stringResponse, listener));

                }
            }
        });
    }

    private void getDevices(String response, FSDCADeviceModel.IDevicesListener listener) {
        List<FSDCADeviceModel> devices = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray jsonDevices = jsonObject.getJSONArray("data");
            for (int i=0; i<jsonDevices.length(); i++) {
                devices.add(FSDCADeviceModel.getDeviceFromJsonObject(jsonDevices.getJSONObject(i)));
            }

            setAssociatedDevices(devices);
            sendFinishEvent(listener);
            
        } catch (JSONException e) {
            sendFinishEvent(listener);
            e.printStackTrace();
        }
    }

    private void sendFinishEvent(FSDCADeviceModel.IDevicesListener listener) {
        if (listener != null) {
            listener.onDevicesRetrieved();
        }
    }

    public void setAssociatedDevices(List<FSDCADeviceModel> devices) {
         mFsdcaAssociatedDevices.clear();

        if (devices != null && devices.size() > 0) {
            mFsdcaAssociatedDevices.addAll(devices);
        }
    }

    public List<FSDCADeviceModel> getAssociatedDevices() {
        return mFsdcaAssociatedDevices;
    }

    /**
     * convert received json string into Token class
     *
     * @param data json in String format
     * @return return received token
     * @throws JSONException
     */
    private OAuthToken convertTokenJson(String data) throws JSONException {
        JSONObject json = new JSONObject(data);

        if (token == null) {
            token = new OAuthToken();
        }

        // update token information
        token.accessToken = json.getString("access_token");
        token.refreshToken = json.getString("refresh_token");
        token.expire = json.getInt("expires_in");
        token.created = json.getInt("created_at");
        token.scopes.add(json.getString("scope"));

        return token;
    }

    /**
     * get token to preferences
     */
    private void getTokenFromPreferences() {
        String fsToken = UndokPreferences.getInstance().getFsDcaToken();

        if (fsToken != null) {
            try {
                token = new OAuthToken();
                token.fromJson(fsToken);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * save token to preferences
     */

    public interface OnToken {
        void onToken(OAuthToken token);

        void onFailed(Error error);
    }

    public interface IAuthorizeCode {
        void onAuthorizeCode(AuthorizeDeviceCode code);

        void onRetrievingFailed(Error error);
    }


    // parse json
    // {"access_token":"b8e4cc87be08757afc3ff89ef433316def7b771aaedb42689780ec9b7326ce28","token_type":"bearer","expires_in":7199,"refresh_token":"de41e16ce643fcf9c1b75d374296a44296f7611036e746e64a17b1ff75811c83","scope":"user","created_at":1508844407}

    public interface OnData {
        void onData(JSONObject data);
    }

    public class Error {
        public final static String RESPONSE_FORMAT_ERROR = "response_format_error";
        public final static String TOKEN_UNAVAILABLE = "token_unavailable";

        public String error;
        public String description;

        public Error(String error, String description) {
            this.error = error;
            this.description = description;
        }
    }

    public void setWasAccountDeleted(boolean wasDeleted) {
        mWasAccountDeleted = wasDeleted;
    }

    public boolean getWasAccountDeleted() {
        return mWasAccountDeleted;
    }

    public String getAccessToken() {

        return token.accessToken;
    }
}
