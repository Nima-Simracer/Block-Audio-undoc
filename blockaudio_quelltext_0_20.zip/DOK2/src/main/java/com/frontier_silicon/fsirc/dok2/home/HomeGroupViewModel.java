package com.frontier_silicon.fsirc.dok2.home;

import android.app.Activity;
import android.view.View;

import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.multiroom.MultiroomEditGroupManager;

/**
 * Created by lsuhov on 08/05/2017.
 */

public class HomeGroupViewModel extends HomeBaseItemViewModel {
    public HomeGroupViewModel(MultiroomItemModel multiroomItemModel, Activity activity) {
        super(multiroomItemModel, activity);

        init();
    }

    protected void init() {
        if (!mMultiroomItemModel.getIsGroupHeader()) {
            dispose();
            return;
        }

        super.init();
    }

    public void onEditGroupClicked(View view) {
        MultiroomEditGroupManager.getInstance().showEditGroupDialog(mMultiroomItemModel);
    }

    public void dispose() {
        super.dispose();
    }
}
