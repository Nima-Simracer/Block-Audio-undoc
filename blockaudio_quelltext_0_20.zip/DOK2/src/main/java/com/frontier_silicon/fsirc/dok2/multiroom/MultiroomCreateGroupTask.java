package com.frontier_silicon.fsirc.dok2.multiroom;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;

import com.frontier_silicon.components.common.BaseShowProgressDialogTask;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.IDialogButtonsResponse;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.IMultiroomOperationListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.multiroom.MultiroomOperation;
import com.frontier_silicon.fsirc.dok2.R;

import java.util.List;

public class MultiroomCreateGroupTask extends BaseShowProgressDialogTask<Boolean> {

    private final MultiroomEditGroupUtil mEditGroupUtil;
    private final List<MultiroomEditGroupItemModel> mAllRadios;
    private final String mNewGroupName;
    private final MultiroomItemModel mMultiroomItemModel;
    private List<MultiroomOperation> mOperationList;
    private IMultiroomOperationListener mListener;

    private boolean mIsCurrentModeStreamable = false;
    private boolean mGroupNameDuplicated = false;
    private boolean mTooManyClients = false;

    public MultiroomCreateGroupTask(Context context, List<MultiroomEditGroupItemModel> allRadios,
                                    String newGroupName, MultiroomItemModel multiroomItemModel,
                                    IMultiroomOperationListener listener) {
        this.mContext = context;
        this.mAllRadios = allRadios;
        this.mNewGroupName = newGroupName;
        this.mMultiroomItemModel = multiroomItemModel;
        this.mListener = listener;
        mEditGroupUtil = new MultiroomEditGroupUtil();

        mDialogKey = "create_group_task";
        mLoadingMessage = mContext.getString(R.string.multiroom_update_task_dlg);
        TASK_TIMEOUT_MS = 5 * 1000;
        mDialogCancelable = false;
    }

    @Override
    protected Boolean doInBackground(Integer... params) {
        boolean resultOk;
        mTooManyClients = false;
        mIsCurrentModeStreamable = false;
        mGroupNameDuplicated = false;

        this.mOperationList = mEditGroupUtil.getOperationsList(this.mAllRadios, false, this.mNewGroupName, this.mMultiroomItemModel);
        int numClientsInGroup = mEditGroupUtil.getNumFinalClientsInGroup(this.mAllRadios, false, this.mMultiroomItemModel);

        resultOk = !mOperationList.isEmpty();

        if (mEditGroupUtil.checkNumClientsInGroup(this.mMultiroomItemModel, numClientsInGroup)) {
            //mEditGroupUtil.powerOnIfStandby(this.mMultiroomItemModel.getRadio());

            mGroupNameDuplicated = MultiroomGroupManager.getInstance().isGroupNameDuplicated(this.mNewGroupName);
            mIsCurrentModeStreamable = mEditGroupUtil.isCurrentModeStreamable(this.mMultiroomItemModel.getRadio());
        } else {
            mTooManyClients = true;
        }

        return resultOk;
    }

    @Override
    protected void onPostExecute(final Boolean result) {
        super.onPostExecute(result);

        if (result != null) {

            final boolean dismissEditGroupDlg = (result && !mGroupNameDuplicated && mIsCurrentModeStreamable && !mTooManyClients);
            final boolean allPreconditionsMet = (mIsCurrentModeStreamable && !mTooManyClients);

            if (mGroupNameDuplicated) {
                mEditGroupUtil.showDuplicateGroupDialog(this.mContext, this.mNewGroupName, new IDialogButtonsResponse() {
                    @Override
                    public void onPositiveClicked() {
                        continueNewMultiroomGroupCreation(allPreconditionsMet);
                    }

                    @Override
                    public void onNegativeClicked() {
                        Dialog dialog = DialogsHolder.getDialog(MultiroomEditGroupDialog.DIALOG_KEY);

                        if (dialog != null) {
                            dialog.show();
                        }
                    }

                    @Override
                    public void onNeutralClicked() {
                    }
                });
            } else {
                continueNewMultiroomGroupCreation(allPreconditionsMet);
            }

            if (dismissEditGroupDlg) {
                if (!DialogsHolder.activityIsFinishing((Activity) this.mContext)) {
                    DialogsHolder.dismissDialog(MultiroomEditGroupDialog.DIALOG_KEY);
                }
            }
        }

    }

    private void continueNewMultiroomGroupCreation(boolean canStartImmediately) {
        if (canStartImmediately) {
            createNewMultiroomGroup(this.mContext, this.mNewGroupName, this.mOperationList);

            if (!DialogsHolder.activityIsFinishing((Activity) MultiroomCreateGroupTask.this.mContext)) {
                DialogsHolder.dismissDialog(MultiroomEditGroupDialog.DIALOG_KEY);
            }
        } else {
            if (mTooManyClients) {
                mEditGroupUtil.notifyTooManyClientsInGroup(this.mContext);
            } else {
                MultiroomDialogsUtil.showSelectStreamableModeDlg((Activity) this.mContext, this.mMultiroomItemModel.getRadio(), new MultiroomDialogsUtil.ISelectStreamableModeListener() {
                    @Override
                    public void onSelectedStreamableMode(boolean streamableModeSelected) {
                        if (streamableModeSelected) {
                            createNewMultiroomGroup(MultiroomCreateGroupTask.this.mContext, MultiroomCreateGroupTask.this.mNewGroupName, MultiroomCreateGroupTask.this.mOperationList);

                            if (!DialogsHolder.activityIsFinishing((Activity) MultiroomCreateGroupTask.this.mContext)) {
                                DialogsHolder.dismissDialog(MultiroomEditGroupDialog.DIALOG_KEY);
                            }
                        }
                    }
                });
            }
        }
    }

    private void createNewMultiroomGroup(final Context context, final String newGroupName, List<MultiroomOperation> operationList) {
        if (!TextUtils.isEmpty(newGroupName)) {
            MultiroomOperationsQueueExecutorTask executorTask = new MultiroomOperationsQueueExecutorTask(context,
                    operationList, this.mListener);
            TaskHelper.execute(executorTask);
        }
    }
}
