package com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable;

import com.frontier_silicon.NetRemoteLib.Node.NodeNavRefresh;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavStatus;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

public class ContextMessageCloseRunnable implements Runnable {

    public interface IContextMessageDataSendListener {
        void onContextMessageSend(boolean params);
    }

    private static final boolean ENABLE_SYNC_OPS = true;
    private Radio mRadio;
    private IContextMessageDataSendListener mListener;

    public ContextMessageCloseRunnable(Radio radio, IContextMessageDataSendListener listener) {
        mRadio = radio;
        mListener = listener;
    }

    @Override
    public void run() {
        FsLogger.log("ContextMessageCloseRunnable started, trying to refresh the underlying list ", LogLevel.Info);

        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {
            boolean result = mRadio.nodeSyncSetter(new NodeNavRefresh(new Long(1))).set();
            NodeNavStatus statusNode = RadioNavigationUtil.waitForNavStatusReady(mRadio);
            if(statusNode!=null && statusNode.getValue() >= 0)
                sendResultToListener(result);
        }
        dispose();
    }

    private void sendResultToListener(boolean result) {
        if (mListener != null) {
            mListener.onContextMessageSend(result);
        }
    }

    private void dispose() {
        mRadio = null;
        mListener = null;
    }
}
