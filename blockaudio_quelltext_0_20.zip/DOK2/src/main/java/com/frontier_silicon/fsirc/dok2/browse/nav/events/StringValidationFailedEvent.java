package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by hcostescu on 11/10/2016.
 */

public class StringValidationFailedEvent {
    public StringValidationFailedEvent()
    {
    }
}
