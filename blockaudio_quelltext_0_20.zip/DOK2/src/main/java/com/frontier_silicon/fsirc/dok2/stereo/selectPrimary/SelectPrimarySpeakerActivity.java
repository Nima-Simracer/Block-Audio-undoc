package com.frontier_silicon.fsirc.dok2.stereo.selectPrimary;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;

/**
 * Created by lsuhov on 03/08/2017.
 */

public class SelectPrimarySpeakerActivity extends UndokActivityBase {

    SelectPrimarySpeakerViewModel mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.stereo_select_primary);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.stereo_setup);

        setupControls();
    }

    private void setupControls() {
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.list);

        mViewModel = new SelectPrimarySpeakerViewModel(this, recyclerView);
    }

    @Override
    protected void onResume() {
        super.onResume();

        mViewModel.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

        mViewModel.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }
    }
}
