package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.app.Activity;
import android.app.Dialog;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable.ContextFormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.ContextBrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextBrowseResultEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextCloseEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextRefreshEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextShowLoadingProgressEvent;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

/**
 * Created by lsuhov on 23/11/2016.
 */

public class ContextMenuDialogViewModel {

    public ObservableBoolean showLoading = new ObservableBoolean(false);
    public ObservableBoolean showListview = new ObservableBoolean(false);
    public ObservableBoolean showNoResult = new ObservableBoolean(false);
    public ObservableField<String> title = new ObservableField<>("");

    private Activity mActivity;
    private Dialog mDialog;
    private int mBrowseItemPosition;
    private BrowseItemModel mBrowseItemModel;

    private ContextBrowseAdapter mAdapter;
    boolean mIsClosed = false;
    //by default, on dismiss the underlying NavList should not be refreshed. If in a specific case we do want
    //to refresh, the setting must be changed before.
    private boolean mShouldRefreshUnderlying = false;

    public ContextMenuDialogViewModel(Activity activity, int browseItemPosition, BrowseItemModel browseItemModel) {
        mActivity = activity;
        mBrowseItemPosition = browseItemPosition;
        mBrowseItemModel = browseItemModel;

        mAdapter = new ContextBrowseAdapter();

        EventBus.getDefault().register(this);
    }

    public ContextBrowseAdapter getAdapter() {
        return mAdapter;
    }

    public void onStart(Dialog dialog) {
        mIsClosed = false;
        mDialog = dialog;

        ContextBrowseManager.getInstance().navigateToDirectory(mBrowseItemModel.getKey());
    }

    @Subscribe
    public void onShowLoadingProgress(ContextShowLoadingProgressEvent event) {
        if (!mIsClosed && !mActivity.isFinishing()) {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mIsClosed) {
                        return;
                    }

                    showLoadingLayout();
                }
            });
        }
    }

    @Subscribe
    public void onNavigationResult(final ContextBrowseResultEvent event) {
        if (!mIsClosed && !mActivity.isFinishing()) {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mIsClosed) {
                        return;
                    }

                    onNavigationImpl(event.result);
                }
            });
        }
    }

    @Subscribe
    public void onRefreshEventCompleted(ContextRefreshEvent event) {
        ContextBrowseManager.getInstance().refreshCurrentList(-1);
    }

    @Subscribe
    public void onContextCloseEvent(ContextCloseEvent event) {
        if(mDialog != null) {
            this.mShouldRefreshUnderlying = event.getShouldRefreshUnderlying();
            mDialog.dismiss();
            FirebaseCrashlytics.getInstance().log("ContextMenuDialogViewModel onContextCloseEvent");
            ContextBrowseManager.getInstance().clearAll();
        }
    }

    public boolean getShouldRefreshUnderlying(){
        return this.mShouldRefreshUnderlying;
    }

    void onNavigationImpl(EIRNavigationResult result) {

        if (result == EIRNavigationResult.Success || result == EIRNavigationResult.TotalItemsNotRetrieved) {
            showListViewLayout();
            NodeSysCapsValidModes.Mode mode = SpeakerDataManager.getInstance().getCurrentMode();
            if ( mode == NodeSysCapsValidModes.Mode.AIRABLE_CALM ||
                    mode == NodeSysCapsValidModes.Mode.AIRABLE_KLASSIK
            ) {
                int browseContextListSize = ContextBrowseManager.getInstance().getTotalCountForCurrentList();
                if (browseContextListSize == 1) {
                    title.set(mBrowseItemModel.getName());
                } else if (browseContextListSize > 1) {
                    BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(BrowseManagerFactory.ContextBrowse);
                    BrowseItemModel browseItemModel = browseManager.tryGetBrowseItemModel(0);
                    browseManager.deleteItem(0);
                    title.set(browseItemModel.getName());
                }
            }

            mAdapter.notifyDataSetChanged();

        } else {
            showNoResultsLayout();
        }
    }

    void showLoadingLayout() {
        showLoading.set(true);
        showListview.set(false);
        showNoResult.set(false);
    }

    private void showListViewLayout() {
        showLoading.set(false);
        showListview.set(true);
        showNoResult.set(false);
    }

    private void showNoResultsLayout() {
        showNoResult.set(true);
        showListview.set(false);
        showLoading.set(false);
    }

    public void dispose() {
        mActivity = null;
        mIsClosed = true;
        mAdapter = null;
        mBrowseItemModel = null;
        mDialog = null;

        EventBus.getDefault().unregister(this);
        FirebaseCrashlytics.getInstance().log("ContextMenuDialogViewModel dispose");
        ContextBrowseManager.getInstance().clearAll();
        ContextFormManager.getInstance().clearItemsLoaded();
    }
}
