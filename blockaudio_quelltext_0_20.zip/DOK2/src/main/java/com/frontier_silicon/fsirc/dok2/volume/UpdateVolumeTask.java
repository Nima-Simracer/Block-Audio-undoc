package com.frontier_silicon.fsirc.dok2.volume;

import android.os.AsyncTask;

import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Created by cvladu on 20/10/16.
 */

public class UpdateVolumeTask extends AsyncTask<Void, Integer, Boolean> {
    private List<IVolumeUpdatesListener> mListeners = new CopyOnWriteArrayList<>();
    private int mVolume = 0;
    private boolean mMuted = false;

    public UpdateVolumeTask(IVolumeUpdatesListener listener) {
        setInterfaceListener(listener);
    }

    @Override
    protected Boolean doInBackground(Void... arg0) {

        long steps = 0;
        int maxTries = 5;
        // Until steps is non-zero we can't get feedback from radio on volume
        // This seems to always take a long time in particular scenarios
        while ((steps == 0) && (maxTries > 0)) {
            MultiroomGroupManager.getInstance().initVolumeSteps();

            mVolume = MultiroomGroupManager.getInstance().getMainVolume();

            mMuted = MultiroomGroupManager.getInstance().getMainMute();

            steps = MultiroomGroupManager.getInstance().getMaxVolumeSteps();

            maxTries--;

            if (steps == 0) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // Safe to ignore
                }
            }
        }

        if (steps == 0)
            FsLogger.log("VolumeCtrlFragment failed to find steps for volume", LogLevel.Error);


        return true;
    }

    @Override
    protected void onPostExecute(Boolean result) {
        notifyUpdateVolumeTask(mVolume, mMuted);
        mListeners.clear();
    }

    public void setInterfaceListener(IVolumeUpdatesListener iVolumeUpdatesListener) {
        if (iVolumeUpdatesListener != null) {
            mListeners.add(iVolumeUpdatesListener);
        }
    }

    private void notifyUpdateVolumeTask(int volume, boolean isMuted) {

        for (int i=0; i<mListeners.size(); i++) {
            IVolumeUpdatesListener listener = mListeners.get(i);
            listener.onVolumeRetrieved(volume, isMuted);
        }
    }
}
