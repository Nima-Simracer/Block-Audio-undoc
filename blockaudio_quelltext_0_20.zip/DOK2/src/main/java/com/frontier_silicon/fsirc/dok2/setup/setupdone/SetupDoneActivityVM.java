package com.frontier_silicon.fsirc.dok2.setup.setupdone;

import android.app.Activity;
import androidx.databinding.ObservableField;

import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.setup.EStateOfCheckingHeadlessSetup;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.welcome.WelcomeActivity;

/**
 * Created by nbalazs on 22/03/2018.
 *
 */

public class SetupDoneActivityVM {
    private Activity mActivity;

    public ObservableField<Boolean> isExitSetupVisible = new ObservableField<>(false);
    
    public ObservableField<Boolean> isSetupCompleteImageView = new ObservableField<>(false);
    
    public ObservableField<String> descriptionText = new ObservableField<>();
    
    public ObservableField<String> completeSetupHeaderText = new ObservableField<>();

    public ObservableField<Boolean> isCompleteSetupHeaderTextVisible = new ObservableField<>(false);

    SetupDoneActivityVM(Activity activity) {
        mActivity = activity;

        completeSetupHeaderText.set(mActivity.getResources().getString(R.string.done));

        descriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_complete_success_description, true));

        isExitSetupVisible.set(FsComponentsConfig.SHOW_EXIT_HUI_SETUP_BUTTON);

        initViewsBasedOnSetupSuccessStatus();
    }

    public final void onSetupAnotherAudioSystemClicked() {
        NavigationHelper.goToExistingActivityAndClearBackStack(mActivity, WelcomeActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    public final void onStartUsingMyAudioSystemClicked() {
        NavigationHelper.goToHomeAndClearActivityStack(mActivity);
        SetupManager.getInstance().dispose();
    }

    private void initViewsBasedOnSetupSuccessStatus() {

        EStateOfCheckingHeadlessSetup mStateOfSetup = SetupManager.getInstance().getStateOfSetup();

        if (mStateOfSetup == null) {
            return;
        }

        switch (mStateOfSetup) {
            case NodesWereNotSetCorrectly:
            case CouldntConnectToWiFi:
                isCompleteSetupHeaderTextVisible.set(true);
                completeSetupHeaderText.set(mActivity.getResources().getString(R.string.fail));
                break;
            case CouldntFindDeviceWithSSDP:
                isCompleteSetupHeaderTextVisible.set(true);
                completeSetupHeaderText.set(mActivity.getResources().getString(R.string.warning));
                break;
            case SuccesfullSetup:
                isCompleteSetupHeaderTextVisible.set(false);
                isSetupCompleteImageView.set(true);
                break;
            default:
                isCompleteSetupHeaderTextVisible.set(false);
                isSetupCompleteImageView.set(true);
                break;
        }

        switch (mStateOfSetup) {
            case NodesWereNotSetCorrectly:
                descriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_complete_nodes_not_set_correctly_description, true));
                break;
            case CouldntConnectToWiFi:
                descriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_complete_couldnt_connect_to_wifi_description, true));
                break;
            case CouldntFindDeviceWithSSDP:
                descriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_complete_couldnt_find_with_ssdp_description, true));
                break;
            case SuccesfullSetup:
                descriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_complete_success_description, true));
                break;
            default:
                break;
        }
    }
}
