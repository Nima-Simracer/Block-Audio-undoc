package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by cvladu on 09/02/17.
 */

public class HideErrorMessageEvent {

    public HideErrorMessageEvent(){}
}
