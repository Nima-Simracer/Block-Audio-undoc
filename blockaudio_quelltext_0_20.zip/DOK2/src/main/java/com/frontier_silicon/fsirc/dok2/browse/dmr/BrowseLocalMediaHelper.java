package com.frontier_silicon.fsirc.dok2.browse.dmr;

import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.MediaStore;

import androidx.core.content.res.ResourcesCompat;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * This class is responsible for all logic related to
 * displaying media content items on screen. This includes querying
 * the <code>MediaStore.Audio</code>, controlling filter selection
 * and icon changes
 */
public class BrowseLocalMediaHelper {
    private final String LOG_TAG = getClass().getSimpleName() + ": ";
    private Context mContext;
    private BrowseDMRAdapter mMediaAdapter;
    private final MediaHandler mMediaHandler;
    private final String[] ARTIST_QUERY;
    private final String[] ARTIST_ALBUMS_QUERY;
    private final String[] ALBUMS_QUERY;
    private final String[] TRACKS_QUERY;
    private final String[] GENRES_QUERY;
    private final String[] GENRE_ALBUMS_QUERY;
    private final String[] PLAYLIST_QUERY;
    private final String[] PLAYLIST_MEMBERS_QUERY;
    private final String ARTISTS_SORT_ORDER;
    private final String ALBUMS_SORT_ORDER;
    private final String TRACK_ALL_SORT_ORDER;
    private final String TRACK_ALBUM_SORT_ORDER;
    private final String GENRE_SORT_ORDER;
    private final String ALBUM_ARTIST_TRACK_SELECTION;
    private final String ALBUM_TRACKS_SELECTION;
    private final String MUSIC_ONLY_SELECTION;
    private final String ARTISTS_LOOKUP_SELECTION;
    private boolean mIsRootLevel;
    private ImageView mFilterButton;
    private TextView mSelectionLabel;
    private ArrayDeque<BrowseDMRItemModel> mMediaBackStack2;

    private Drawable lastFilterDrawable;

    public BrowseLocalMediaHelper(Context context, BrowseDMRAdapter mediaAdapter, MediaHandler mediaHandler) {
        mContext = context;
        mMediaBackStack2 = new ArrayDeque<>();

        mMediaAdapter = mediaAdapter;
        mMediaHandler = mediaHandler;
        ARTIST_QUERY = new String[]{
                MediaStore.Audio.Artists._ID,
                MediaStore.Audio.Artists.ARTIST
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ARTIST_ALBUMS_QUERY = new String[]{
                    MediaStore.Audio.Artists.Albums.ALBUM,
                    MediaStore.Audio.Artists.Albums.ALBUM_ID

            };
        } else {
            ARTIST_ALBUMS_QUERY = new String[]{
                    MediaStore.Audio.Artists.Albums.ALBUM,
                    MediaStore.Audio.Artists._ID
            };
        }
        ALBUMS_QUERY = new String[]{
                MediaStore.Audio.Albums._ID,
                MediaStore.Audio.Albums.ALBUM,
                MediaStore.Audio.Albums.ARTIST
        };
        TRACKS_QUERY = new String[]{
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST_ID,
        };
        GENRES_QUERY = new String[]{
                MediaStore.Audio.Genres._ID,
                MediaStore.Audio.Genres.NAME
        };
        GENRE_ALBUMS_QUERY = new String[]{
                "DISTINCT " + MediaStore.Audio.Genres.Members.ALBUM_ID,
                MediaStore.Audio.Genres.Members.ALBUM,
                MediaStore.Audio.Genres.Members.ARTIST_ID,
                MediaStore.Audio.Genres.Members._ID
        };
        PLAYLIST_QUERY = new String[]{
                MediaStore.Audio.Playlists._ID,
                MediaStore.Audio.Playlists.NAME
        };
        PLAYLIST_MEMBERS_QUERY = new String[]{
                MediaStore.Audio.Playlists.Members.AUDIO_ID,
                MediaStore.Audio.Playlists.Members.TITLE,
        };

        ALBUM_ARTIST_TRACK_SELECTION = MediaStore.Audio.Media.ALBUM + " =? AND " + MediaStore.Audio.Media.ARTIST_ID + " =?";
        ALBUM_TRACKS_SELECTION = MediaStore.Audio.Media.ALBUM + " =? ";

        ARTISTS_LOOKUP_SELECTION = MediaStore.Audio.Artists.ARTIST + " =?";
        MUSIC_ONLY_SELECTION = MediaStore.Audio.Media.IS_MUSIC + " !=?";

        ARTISTS_SORT_ORDER = MediaStore.Audio.Artists.ARTIST + " COLLATE NOCASE ASC";
        ALBUMS_SORT_ORDER = MediaStore.Audio.Albums.ALBUM + " COLLATE NOCASE ASC";
        TRACK_ALL_SORT_ORDER = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";
        TRACK_ALBUM_SORT_ORDER = MediaStore.Audio.Media.TRACK + " COLLATE NOCASE ASC";
        GENRE_SORT_ORDER = MediaStore.Audio.Genres.NAME + " COLLATE NOCASE ASC";
    }

    public void setAdapter(BrowseDMRAdapter mediaAdapter) {
        mMediaAdapter = mediaAdapter;
    }

    /**
     * Moves the displayed media items down a level
     * within the tree based on the selected item. Additional
     * returning the type of the selected item to allowing
     * for related actions such as altering view elements to be
     * taken.
     *
     * @param selectedPosition The media item selected by the user
     * @return The type of item selected
     */
    public BrowseDMRItemModel updateDisplay(int selectedPosition) {
        BrowseDMRItemModel selectedItem = mMediaAdapter.getItem(selectedPosition);

        if (selectedItem != null) {
            BrowseDMRItemModel.Types selectedType = selectedItem.getType();

            if (selectedType == BrowseDMRItemModel.Types.TRACK) {
                createPlayableList(selectedPosition);
            }

            return updateDisplay(selectedItem);
        }

        return null;
    }

    public BrowseDMRItemModel updateDisplay(BrowseDMRItemModel selectedItem) {
        BrowseDMRItemModel.Types selectedType = selectedItem.getType();

        switch (selectedType) {
            case ARTIST:
                mMediaBackStack2.add(selectedItem);
                new QueryAlbums().execute(selectedItem.getItemId());
                break;
            case ALBUM_ALL:
                mMediaBackStack2.add(selectedItem);
                new QueryTracks(false).execute(selectedItem.getDisplayText(), String.valueOf(selectedItem.getArtistId()));
                break;

            case ALBUM:
                mMediaBackStack2.add(selectedItem);
                new QueryTracks(true).execute(selectedItem.getDisplayText(), String.valueOf(selectedItem.getArtistId()));
                break;
            //case BrowseDMRItemModel.TRACK:
            //    createPlayableList(selectedPosition);
            //    break;
            case GENRE:
                mMediaBackStack2.add(selectedItem);
                new QueryGenresAlbums().execute(selectedItem.getItemId());
                break;
            case PLAYLIST:
                mMediaBackStack2.add(selectedItem);
                new QueryPlaylistsMembers().execute(selectedItem.getItemId());
                break;


            case ROOT_ARTISTS:
                mMediaBackStack2.add(selectedItem);
                new QueryArtists().execute();
                break;
            case ROOT_ALL_ALBUMS:
                mMediaBackStack2.add(selectedItem);
                new QueryAllAlbums().execute();
                break;
            case ROOT_ALL_TRACKS:
                mMediaBackStack2.add(selectedItem);
                new QueryAllTracks().execute();
                break;
            case ROOT_ALL_GENRES:
                mMediaBackStack2.add(selectedItem);
                new QueryGenres().execute();
                break;
            case ROOT_ALL_PLAYLISTS:
                mMediaBackStack2.add(selectedItem);
                new QueryPlaylists().execute();
                break;
        }

        if (mSelectionLabel != null && selectedType != BrowseDMRItemModel.Types.TRACK) {
            if (mSelectionLabel.getVisibility() == View.GONE) {
                mSelectionLabel.setVisibility(View.VISIBLE);
                FsLogger.log(LOG_TAG + "setting selection label to visible");
            } else {
                FsLogger.log("selection label is: " + mSelectionLabel.getVisibility());
            }

            mSelectionLabel.setText(selectedItem.getDisplayText());
        }

        mIsRootLevel = false;
        return selectedItem;
    }

    /**
     * Moves up a layer within the tree
     * based on the first item currently in view
     * and the currently selected filter.
     */
    public boolean navigateUpTree() {

        int backStackSize = mMediaBackStack2.size();

        if (backStackSize >= 2) {
            mMediaBackStack2.removeLast();

            BrowseDMRItemModel selected = mMediaBackStack2.pollLast();
            updateDisplay(selected);

            if (selected.getDisplayText().isEmpty()) {
                mMediaHandler.hideSelectionLabel();
                mIsRootLevel = true;
            } else {
                mSelectionLabel.setText(selected.getDisplayText());
            }

            return true;
        }

        return false;
    }

    /**
     * Adds a <code>List</code> of media items to the media
     * adapter. Additionally checking the input list is not empty.
     *
     * @param mediaList The list of audio content to be displayed
     */
    private void updateAdapter(List<BrowseDMRItemModel> mediaList) {
        mMediaAdapter.replaceContents(mediaList);

        if (mMediaHandler != null) {
            mMediaHandler.setupEmptyListView(mediaList.size());
        }

        mMediaHandler.setupEmptyListView(mediaList.size());
    }

    public void restoreAdapter() {
        if (!mIsRootLevel) {

            if (mMediaBackStack2.size() > 0) {
                BrowseDMRItemModel item = updateDisplay(mMediaBackStack2.pollLast());

                if (!item.getDisplayText().isEmpty()) {

                    if (lastFilterDrawable != null) {
                        mFilterButton.setImageDrawable(lastFilterDrawable);
                    }
                }
            }


        }
    }

    /**
     * Changes the media items displayed on screen to
     * match one of the top level filter items.
     *
     * @param selectionPosition The position of the selected filter in the list
     */
    public void changeTopLevelFilter(int selectionPosition) {
        resetToRoot();

        Resources resources = mContext.getResources();
        Drawable filterDrawable = null;
        if (selectionPosition == BrowseDMRFilterAdapter.mArtistsFilter) {
            mMediaBackStack2.add(new BrowseDMRItemModel(BrowseDMRItemModel.Types.ROOT_ARTISTS, "", -1));
            new QueryArtists().execute();
            filterDrawable = ResourcesCompat.getDrawable(resources, R.drawable.btn_filter_artist, null);

        } else if (selectionPosition == BrowseDMRFilterAdapter.mAlbumsFilter) {
            mMediaBackStack2.add(new BrowseDMRItemModel(BrowseDMRItemModel.Types.ROOT_ALL_ALBUMS, "", -1));
            new QueryAllAlbums().execute();
            filterDrawable = ResourcesCompat.getDrawable(resources, R.drawable.btn_filter_album, null);

        } else if (selectionPosition == BrowseDMRFilterAdapter.mSongsFilter) {
            mMediaBackStack2.add(new BrowseDMRItemModel(BrowseDMRItemModel.Types.ROOT_ALL_TRACKS, "", -1));
            new QueryAllTracks().execute();
            filterDrawable = ResourcesCompat.getDrawable(resources, R.drawable.btn_filter_song, null);

        } else if (selectionPosition == BrowseDMRFilterAdapter.mGenreFilter) {
            mMediaBackStack2.add(new BrowseDMRItemModel(BrowseDMRItemModel.Types.ROOT_ALL_GENRES, "", -1));
            new QueryGenres().execute();
            filterDrawable = ResourcesCompat.getDrawable(resources, R.drawable.btn_filter_genre, null);

        } else if (selectionPosition == BrowseDMRFilterAdapter.mPlaylistsFilter) {
            mMediaBackStack2.add(new BrowseDMRItemModel(BrowseDMRItemModel.Types.ROOT_ALL_PLAYLISTS, "", -1));
            new QueryPlaylists().execute();
            filterDrawable = ResourcesCompat.getDrawable(resources, R.drawable.btn_filter_playlist, null);
        }

        if (mFilterButton != null && filterDrawable != null) {
            mFilterButton.setImageDrawable(filterDrawable);
            lastFilterDrawable = filterDrawable;
        }
    }

    /**
     * Converts the list of <code>BrowseDMRItemModel</code> items currently
     * in the BrowseDMRAdapter into a list of <code>MediaStore.Audio</code> <code>Uri</code> objects
     * that can be sent to the local media playback library
     *
     * @param selectedPosition The position of the user selected item in the list
     */
    public void createPlayableList(int selectedPosition) {
        List<BrowseDMRItemModel> selectedMedia = mMediaAdapter.getItems();
        List<Uri> uriList = new ArrayList<>();
        //Build the list from the selected position to the end

        for (int i = 0; i < selectedMedia.size(); i++) {
            uriList.add(Uri.parse(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI.toString() + "/" + selectedMedia.get(i).getItemId()));
        }

        if (uriList.size() > 0) {
            mMediaHandler.invokePlayMediaList(uriList, selectedPosition);
        }
    }


    /**
     * Used to determine if the data currently in
     * view is the top of the tree structure
     *
     * @return <code>true</code> when data for a top level filter is being displayed, otherwise false
     */
    public boolean isNavRootLevel() {
        return mIsRootLevel;
    }

    /**
     * Should be called when the displayed
     * data changes to one of the top level
     * filters
     */
    private void resetToRoot() {
        mIsRootLevel = true;
        mMediaBackStack2.clear();
    }

    /**
     * Provides a imageButton that should be updated to represent
     * the selected top level filter.
     *
     * @param imageButton The button view to be updated
     */
    public void setFilterButton(ImageButton imageButton) {
        mFilterButton = imageButton;
    }

    /**
     * Provide a text view which should be updated to show the item
     * that was previously selected from the media list
     *
     * @param selectionLabel The label to be updated with selection values
     */
    public void setSelectionLabel(TextView selectionLabel) {
        mSelectionLabel = selectionLabel;
    }

    private class QueryArtists extends AsyncTask<Void, Void, List<BrowseDMRItemModel>> {

        @Override
        protected List<BrowseDMRItemModel> doInBackground(Void... voids) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();

            BrowseDMRItemModel.Types type = BrowseDMRItemModel.Types.ARTIST;
            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Artists.EXTERNAL_CONTENT_URI,
                        ARTIST_QUERY,
                        null,
                        null,
                        ARTISTS_SORT_ORDER);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    //int itemId = getItemId(cursor);

                    mediaList.add(new BrowseDMRItemModel(type, cursor.getString(1), cursor.getLong(0), -1));
                } while (cursor.moveToNext());

            } else {
                FsLogger.log(LOG_TAG + "No artists available to display", LogLevel.Error);
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaList) {
            updateAdapter(mediaList);
        }
    }

    private class QueryAlbums extends AsyncTask<Long, Void, List<BrowseDMRItemModel>> {

        @Override
        protected List<BrowseDMRItemModel> doInBackground(Long... longs) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();

            BrowseDMRItemModel.Types type = BrowseDMRItemModel.Types.ALBUM;
            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Artists.Albums.getContentUri("external", longs[0]),
                        ARTIST_ALBUMS_QUERY,
                        null,
                        null,
                        ALBUMS_SORT_ORDER);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    mediaList.add(new BrowseDMRItemModel(type, cursor.getString(0), cursor.getInt(1), longs[0]));
                } while (cursor.moveToNext());

            } else {
                FsLogger.log(LOG_TAG + "No albums available for artist", LogLevel.Error);
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaList) {
            updateAdapter(mediaList);
        }
    }

    private class QueryAllAlbums extends AsyncTask<Integer, Void, List<BrowseDMRItemModel>> {

        @Override
        protected List<BrowseDMRItemModel> doInBackground(Integer... integers) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();
            BrowseDMRItemModel.Types type = BrowseDMRItemModel.Types.ALBUM_ALL;

            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,
                        ALBUMS_QUERY,
                        null,
                        null,
                        ALBUMS_SORT_ORDER);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int artistId = lookupArtistsId(cursor.getString(2));

                    mediaList.add(new BrowseDMRItemModel(type, cursor.getString(1), cursor.getInt(0), artistId));
                } while (cursor.moveToNext());

            } else {
                FsLogger.log(LOG_TAG + "No albums found in the media store", LogLevel.Error);
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaList) {
            updateAdapter(mediaList);
        }
    }

    private class QueryTracks extends AsyncTask<String, Void, List<BrowseDMRItemModel>> {
        private boolean mFilterArtist = false;

        QueryTracks(boolean filterArtist) {
            this.mFilterArtist = filterArtist;
        }

        @Override
        protected List<BrowseDMRItemModel> doInBackground(String... strings) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();

            BrowseDMRItemModel.Types type = BrowseDMRItemModel.Types.TRACK;
            String albumName = strings[0];

            String selection;
            String[] selectionArgs;
            if (this.mFilterArtist) {

                String artistId = strings[1];
                selectionArgs = new String[]{albumName, artistId};
                selection = ALBUM_ARTIST_TRACK_SELECTION;

            } else {
                selectionArgs = new String[]{albumName/*, artistId*/};
                selection = ALBUM_TRACKS_SELECTION;
            }
            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        TRACKS_QUERY,
                        selection,
                        selectionArgs,
                        TRACK_ALBUM_SORT_ORDER);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    mediaList.add(new BrowseDMRItemModel(type, cursor.getString(1), cursor.getInt(0), Long.valueOf(strings[1])));
                } while (cursor.moveToNext());

            } else {
                FsLogger.log(LOG_TAG + "No tracks available for Album", LogLevel.Error);
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaItems) {
            updateAdapter(mediaItems);
        }
    }

    private class QueryAllTracks extends AsyncTask<Void, Void, List<BrowseDMRItemModel>> {

        @Override
        protected List<BrowseDMRItemModel> doInBackground(Void... voids) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();
            BrowseDMRItemModel.Types type = BrowseDMRItemModel.Types.TRACK;

            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        TRACKS_QUERY,
                        MUSIC_ONLY_SELECTION,
                        new String[]{"0"},
                        TRACK_ALL_SORT_ORDER);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    mediaList.add(new BrowseDMRItemModel(type, cursor.getString(1), cursor.getInt(0), -1));
                } while (cursor.moveToNext());
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaItems) {
            updateAdapter(mediaItems);
        }
    }

    private class QueryGenres extends AsyncTask<Void, Void, List<BrowseDMRItemModel>> {

        @Override
        protected List<BrowseDMRItemModel> doInBackground(Void... voids) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();
            BrowseDMRItemModel.Types type = BrowseDMRItemModel.Types.GENRE;

            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI,
                        GENRES_QUERY,
                        null,
                        null,
                        GENRE_SORT_ORDER);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    mediaList.add(new BrowseDMRItemModel(type, cursor.getString(1), cursor.getInt(0), -1));
                } while (cursor.moveToNext());
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaItems) {
            updateAdapter(mediaItems);
        }
    }

    private class QueryGenresAlbums extends AsyncTask<Long, Void, List<BrowseDMRItemModel>> {

        @Override
        protected List<BrowseDMRItemModel> doInBackground(Long... longs) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();
            List<Integer> knownAlbums = new ArrayList<>();
            //int type = BrowseDMRItemModel.ALBUM;

            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Genres.Members.getContentUri("external", longs[0]),
                        GENRE_ALBUMS_QUERY,
                        null,
                        null,
                        null);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int albumId = cursor.getInt(0);

                    if (!knownAlbums.contains(albumId)) {
                        knownAlbums.add(albumId);
                        mediaList.add(new BrowseDMRItemModel(BrowseDMRItemModel.Types.ALBUM, cursor.getString(1), cursor.getInt(0), cursor.getInt(2)));
                    }

                } while (cursor.moveToNext());
            } else {
                FsLogger.log(LOG_TAG + String.format(Locale.getDefault(), "No members found for genre: %d", longs[0]));
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaItems) {
            updateAdapter(mediaItems);
        }
    }

    private class QueryPlaylists extends AsyncTask<Void, Void, List<BrowseDMRItemModel>> {

        @Override
        protected List<BrowseDMRItemModel> doInBackground(Void... voids) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();
            //int type = BrowseDMRItemModel.PLAYLIST;

            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Playlists.EXTERNAL_CONTENT_URI,
                        PLAYLIST_QUERY,
                        null,
                        null,
                        null);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    mediaList.add(new BrowseDMRItemModel(BrowseDMRItemModel.Types.PLAYLIST, cursor.getString(1), cursor.getInt(0), -1));
                } while (cursor.moveToNext());
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaItems) {
            updateAdapter(mediaItems);
        }
    }

    private class QueryPlaylistsMembers extends AsyncTask<Long, Void, List<BrowseDMRItemModel>> {

        @Override
        protected List<BrowseDMRItemModel> doInBackground(Long... longs) {
            List<BrowseDMRItemModel> mediaList = new ArrayList<>();
            BrowseDMRItemModel.Types type = BrowseDMRItemModel.Types.TRACK;

            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Playlists.Members.getContentUri("external", longs[0]),
                        PLAYLIST_MEMBERS_QUERY,
                        null,
                        null,
                        null);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    mediaList.add(new BrowseDMRItemModel(type, cursor.getString(1), cursor.getInt(0), -1));
                } while (cursor.moveToNext());
            }

            if (cursor != null) {
                cursor.close();
            }

            return mediaList;
        }

        @Override
        protected void onPostExecute(List<BrowseDMRItemModel> mediaItems) {
            updateAdapter(mediaItems);
        }
    }

    /**
     * Returns the <code>MediaStore.Audio.Artists._id</code> value
     * for the specified artist name. If two artists exist with
     * the same name, the first is returned.
     *
     * @param artistsName The text name of a artist
     * @return The Id value for the give artist
     */
    private int lookupArtistsId(String artistsName) {
        int result = -1;

        if ((artistsName != null) && (!artistsName.isEmpty())) {
            Cursor cursor = null;
            try {
                cursor = mContext.getContentResolver().query(
                        MediaStore.Audio.Artists.EXTERNAL_CONTENT_URI,
                        ARTIST_QUERY,
                        ARTISTS_LOOKUP_SELECTION,
                        new String[]{artistsName},
                        null);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (cursor != null && cursor.moveToFirst()) {
                result = cursor.getInt(0);
                cursor.close();
            }
        }

        return result;
    }
}
