package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import com.frontier_silicon.NetRemoteLib.Node.NodeFsdcaState;

/**
 * Created by cvladu on 15/03/2018.
 */

public interface IAddDeviceState {

    void onFSDCAState(NodeFsdcaState node);
}
