package com.frontier_silicon.fsirc.dok2.settings.speaker;

import java.util.List;

public interface IAboutSpeakerListener {

	void onEditNameBtnClick(AboutSpeakerModel item);
	
	void onDeviceInfoUpdated();

	void onUpdateAboutDevicesList(List<AboutSpeakerModel> devicesInfoList);

	void onKeepNetworkConnectedClicked();
	
}
