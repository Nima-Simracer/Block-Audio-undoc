package com.frontier_silicon.fsirc.dok2.settings.avs;

import android.app.ProgressDialog;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.widget.ImageButton;
import android.widget.Toast;

import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.authorization.AuthCancellation;
import com.amazon.identity.auth.device.api.authorization.AuthorizeListener;
import com.amazon.identity.auth.device.api.authorization.AuthorizeResult;
import com.amazon.identity.auth.device.api.workflow.RequestContext;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;

public class LwaLoginActivity extends UndokActivityBase {
    private final int TIMER_TIMEOUT = 30 * 1000;
    private RequestContext mRequestContext;
    private ImageButton mLoginButton;

    private Radio mClientRadio;
    private HasAvsTokenRetrieverTimerTask mHasAvsTokenChecker;
    private ProgressDialog mProgressDlg;
    private Long mPostDelayedId;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.avs_login_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.amazon_alexa);
        setupControls();

        mRequestContext = RequestContext.create(this);
        mRequestContext.registerListener(new AuthorizationListenerImpl());

        Bundle bundle = getIntent().getExtras();
        if ((bundle != null) && (bundle.containsKey("radioUDN"))) {
            mClientRadio = NetRemoteManager.getInstance().getRadio(bundle.getString("radioUDN"));

        }
    }

    private void getMetadataInfo() {
        AVSManager.getInstance().getMetadataInfoFromSpeaker(mClientRadio, new AVSManager.IAvsResponse() {
            @Override
            public void onSuccess() {
                AVSManager.getInstance().authorize(mRequestContext);
            }

            @Override
            public void onError() {
                Toast.makeText(LwaLoginActivity.this, R.string.avs_fail_login, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        mRequestContext.onResume();
    }

    private void setupControls() {
        mLoginButton = findViewById(R.id.login_with_amazon);

        mLoginButton.setOnClickListener(v -> {
           getMetadataInfo();

        });
    }


    class AuthorizationListenerImpl extends AuthorizeListener {

        @Override
        public void onSuccess(AuthorizeResult authorizeResult) {
            final String authorizationCode = authorizeResult.getAuthorizationCode();
            final String redirectUri = authorizeResult.getRedirectURI();
            final String clientId = authorizeResult.getClientId();

            sendAuthorizationCodeToTheSpeaker(authorizationCode, redirectUri, clientId);

        }

        @Override
        public void onError(AuthError authError) {
            Toast.makeText(LwaLoginActivity.this, R.string.avs_fail_login, Toast.LENGTH_LONG).show();

        }

        @Override
        public void onCancel(AuthCancellation authCancellation) {

        }
    }

    private void sendAuthorizationCodeToTheSpeaker(String authorizationCode, String redirectUri, String clientId) {
        AVSManager.getInstance().sendDataToTheSpeaker(authorizationCode, redirectUri, clientId, mClientRadio, new AVSManager.IAvsResponse() {
            @Override
            public void onSuccess() {
                startCheckingForToken();
            }

            @Override
            public void onError() {
                Toast.makeText(LwaLoginActivity.this, R.string.avs_fail_login, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void startCheckingForToken() {
        mHasAvsTokenChecker = new HasAvsTokenRetrieverTimerTask();
        mHasAvsTokenChecker.startAvsTokenRetriever(mClientRadio, () -> {
            dispose();
            NavigationHelper.goToActivity(LwaLoginActivity.this, AvsFinishActivity.class, NavigationHelper.AnimationType.SlideToLeft, true);
        });

        showProgressDialog();
        startTimeoutTimer();
    }

    private void stopCheckingForToken() {
        if (mHasAvsTokenChecker != null) {
            mHasAvsTokenChecker.stopAvsTokenChecker();
        }
    }

    private void startTimeoutTimer() {
        mPostDelayedId = DelayedPostsManager.getInstance().registerNewCallbackID();

        DelayedPostsManager.getInstance().postDelayed(()-> {
            stopLoadingAndDisplayErrorMessage();
            stopCheckingForToken();
        }, mPostDelayedId, TIMER_TIMEOUT);
    }

    private void stopTimeoutTimer() {
        DelayedPostsManager.getInstance().removeCallbackId(mPostDelayedId);
    }

    private void showProgressDialog() {

        mProgressDlg = new ProgressDialog(this);

        mProgressDlg.setMessage(getString(R.string.avs_connecting_speaker));
        mProgressDlg.setIndeterminate(true);
        mProgressDlg.setCancelable(false);
        mProgressDlg.show();

        DialogsHolder.addDialogToCollection("avs_generic_key", mProgressDlg);
    }

    private void stopProgressDialog() {
       DialogsHolder.dismissDialog(mProgressDlg);
    }


    private void dispose() {
        stopProgressDialog();
        stopCheckingForToken();
        if (mPostDelayedId != null) {
            stopTimeoutTimer();
        }

        mClientRadio = null;
        mHasAvsTokenChecker = null;
    }

    private void stopLoadingAndDisplayErrorMessage() {

        stopProgressDialog();
        Toast.makeText(MainApplication.getCurrentActivity(), MainApplication.getCurrentActivity().getString(R.string.something_went_wrong),
                Toast.LENGTH_LONG).show();

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        dispose();
    }
}
