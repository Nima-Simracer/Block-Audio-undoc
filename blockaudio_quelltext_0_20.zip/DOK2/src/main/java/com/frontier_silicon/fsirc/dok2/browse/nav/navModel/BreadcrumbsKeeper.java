package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import android.text.TextUtils;

import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Created by lsuhov on 30/06/16.
 *
 * The search path is cached until another one is encountered. In this way we can display the search
 * layout virtually in all lists, after we encounter the search list item
 */

public class BreadcrumbsKeeper {
    private Stack<Long> mBreadCrumbs = new Stack<>();
    private List<Long> mSearchNavigationPath = new ArrayList<>();
    private int mSearchDepth = -1;
    private String mSearchText = null;

    private long mPreviousRegisteredDepth = -1;
    private long mCurrentRegisteredDepth = -1;

    public BreadcrumbsKeeper() {}

    public synchronized List<Long> getBreadCrumbs() {
        return new ArrayList<>(mBreadCrumbs);
    }

    synchronized void addToBreadcrumbs(long key) {
        mBreadCrumbs.push(key);
    }

    synchronized void pop() {
        if (mBreadCrumbs.size() > 0) {
            mBreadCrumbs.pop();
        }
        //only when removing items from breadcrumbs (on back), if we reach the root for search items
        //then searchDepth (the place of last search done) must be reset
        if(mBreadCrumbs.size() < (mSearchNavigationPath.size() - 1))
            this.mSearchDepth = -1;
    }

    synchronized int size() {
        if (hasSearchText()) {
            return 1;
        }
        return mBreadCrumbs.size();
    }

    public synchronized void clear() {
        FirebaseCrashlytics.getInstance().log("BreadcrumbsKeeper clear");

        mBreadCrumbs.clear();
        mSearchNavigationPath.clear();
        mSearchText = null;
        resetRegisteredDepth();
        resetSearchDepth();
    }

    public void updateRegisteredDepth(long depth){
        mPreviousRegisteredDepth = mCurrentRegisteredDepth;
        mCurrentRegisteredDepth = depth;
    }

    public void resetRegisteredDepth(){
        mPreviousRegisteredDepth = -1;
        mCurrentRegisteredDepth = -1;
    }

    public void resetSearchDepth(){
        this.mSearchDepth = -1;
    }

    public void setSearchDepth(){
        //if inside a podcast directory after a search, reset the breadCrumbs to the directory before search
        //then do a search again. Else just set the current searchDepth to the current breadCrumbs size.
        if((this.mSearchDepth != -1)
                && (this.mBreadCrumbs.size() > this.mSearchDepth)){
                //&& (!this.mInIRSearch)){
            List<Long> tempBreadCrumbs = new ArrayList<>(this.mBreadCrumbs.subList(0, this.mSearchDepth));
            this.mBreadCrumbs.clear();
            this.mBreadCrumbs.addAll(tempBreadCrumbs);
        }else {
            this.mSearchDepth = this.mBreadCrumbs.size();
        }
    }

    public synchronized List<Long> getBreadCrumbsAfterSearch() {
        ArrayList<Long> result = null;
        if(hasSearchText())
            if(!notInSearchDirectory()) {
                result = new ArrayList<>(mBreadCrumbs);
                result.subList(0, mSearchDepth).clear();
            }
        return result;
    }

    //returns true if we are not currently in a directory that resulted from a previous search
    public boolean notInSearchDirectory(){
        boolean result = true;
        if(this.mSearchDepth != -1 && (this.mBreadCrumbs.size() > this.mSearchDepth)){
            result = false;
        }
        return result;
    }

    public void updateNavPathAndDepth(Long key){
        boolean shouldUpdate = true;

        if(key != RadioNavigationUtil.INVALID_INT32_KEY
                && (this.mCurrentRegisteredDepth >=0 && this.size() > this.mCurrentRegisteredDepth))
            shouldUpdate = false;

        if(shouldUpdate) {
            if (key == RadioNavigationUtil.INVALID_INT32_KEY) {
                this.pop();
            } else {
                this.addToBreadcrumbs(key);
            }
        }
    }

    public List<Long> getSearchNavigationPath() {
        return new ArrayList<>(mSearchNavigationPath);
    }

    void createSearchPath(Long searchKey) {
        FirebaseCrashlytics.getInstance().log("BreadcrumbsKeeper Creating search path");
        clearSearchNavigationPath();

        mSearchNavigationPath.addAll(new ArrayList<>(mBreadCrumbs));
        mSearchNavigationPath.add(searchKey);

        FirebaseCrashlytics.getInstance().log("BreadcrumbsKeeper Created search path");
    }

    void clearSearchNavigationPath() {
        mSearchNavigationPath.clear();
    }

    boolean hasSearchNavigationPath() {
        return !mSearchNavigationPath.isEmpty();
    }

    /**
     * If the user exits a directory that has search, based on this,
     * the app stops displaying the search layout and deletes the search text.
     */
    public boolean searchIsAvailable(){
        if(!hasSearchNavigationPath())
            return false;
        if(mBreadCrumbs.size() < (mSearchNavigationPath.size() - 1))
            return false;
        for(int i = 0; i < mSearchNavigationPath.size() - 1; i++)
            if(mSearchNavigationPath.get(i) != mBreadCrumbs.elementAt(i))
                return false;
        return true;
    }

    void setSearchText(String searchText) {
        mSearchText = searchText;
    }

    public String getSearchText() {
        return mSearchText;
    }

    public void clearSearchText() {
        mSearchText = null;
    }

    public boolean hasSearchText() {
        return !TextUtils.isEmpty(mSearchText);
    }
}
