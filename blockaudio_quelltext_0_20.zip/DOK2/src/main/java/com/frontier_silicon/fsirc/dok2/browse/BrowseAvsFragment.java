package com.frontier_silicon.fsirc.dok2.browse;

import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;

/**
 * Created by adanaila on 10/18/2016.
 */

public class BrowseAvsFragment extends BaseFragment implements IChildFragment,
        IPageSwitchListener {
    public static final String FRAGMENT_TAG = "TAG_BROWSE_AVS_FRAGMENT";
    private TextView txtFooter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.browse_avs_fragment, container, false);
        txtFooter = rootView.findViewById(R.id.avsNews);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        setHasOptionsMenu(false);
    }

    private void setText() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            txtFooter.setText(Html.fromHtml(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.avs_browse_fragment_footer, true), Html.FROM_HTML_MODE_COMPACT));
        } else {
            txtFooter.setText(Html.fromHtml(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.avs_browse_fragment_footer, true)));
        }

        txtFooter.setMovementMethod(LinkMovementMethod.getInstance());
    }

    @Override
    public synchronized void onFragmentActivated() {
    }

    @Override
    public synchronized void onFragmentDeactivated() {
    }

    @Override
    public void onResume() {
        super.onResume();

        setText();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public boolean isBackButtonHandledByFragment(boolean upButton) {
        return false;
    }

    @Override
    public void onBackButton() {
    }

    @Override
    public String getStaticTag() {
        return FRAGMENT_TAG;
    }
}
