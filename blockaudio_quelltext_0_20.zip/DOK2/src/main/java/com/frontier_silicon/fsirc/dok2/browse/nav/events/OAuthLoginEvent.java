package com.frontier_silicon.fsirc.dok2.browse.nav.events;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;

/**
 * Created by cvladu on 21/01/2018.
 */

public class OAuthLoginEvent {
    public BrowseItemModel mBrowseItemModel;

    public enum OAuthType {
        Amazon,
        Tidal,
        Qobuz,
        SAAVN
    }

    public OAuthLoginEvent(BrowseItemModel browseItemModel) {
        mBrowseItemModel = browseItemModel;
    }


}
