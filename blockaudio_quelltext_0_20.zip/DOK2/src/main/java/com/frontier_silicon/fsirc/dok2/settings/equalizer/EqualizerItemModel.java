package com.frontier_silicon.fsirc.dok2.settings.equalizer;

import java.util.ArrayList;

public class EqualizerItemModel {

	public String mName;
	public boolean mIsSet;
	public boolean mIsCustomEq;
	public boolean mIsLoudnessAvailable = false;
	public boolean mIsLoudnessEnabled = false;
	public long mKeyId;

	public ArrayList<CustomEqualizerItemModel> mEqualizerItemsList;

	public EqualizerItemModel(String name, boolean isSet, boolean isCustomEq, long keyId) {
		mName = name;
		mIsSet = isSet;
		mIsCustomEq = isCustomEq;
		mKeyId = keyId;

		mEqualizerItemsList = new ArrayList<CustomEqualizerItemModel>();
	}
	
}
