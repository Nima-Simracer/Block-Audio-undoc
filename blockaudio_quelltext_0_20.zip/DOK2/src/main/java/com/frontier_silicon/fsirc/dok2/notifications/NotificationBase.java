package com.frontier_silicon.fsirc.dok2.notifications;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.os.Build;
import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.TaskStackBuilder;

import android.text.TextUtils;
import android.widget.RemoteViews;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.frontier_silicon.NetRemoteLib.IRadioNotificationState;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayCaps;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoName;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayStatus;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.AppInBackgroundEvent;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.ConnectedSpeakerActivity;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import static com.frontier_silicon.fsirc.dok2.notifications.NotificationMode.IR;
import static com.frontier_silicon.fsirc.dok2.notifications.NotificationMode.MP;
import static com.frontier_silicon.fsirc.dok2.notifications.NotificationMode.Podcasts;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Created by mnisipeanu on 11/07/2017.
 */

public abstract class NotificationBase {

    final int notificationId;
    private static final String TAG = "NotificationBase ";

    protected int defaultArtWork = R.drawable.ic_dmrdisplay;
    final int sizeSmallImage;
    final int sizeBigImage;

    protected Context mContext = null;

    private float densityMultiplier;
    int colorTintRes;

    /* notification data */
    protected String mTitle = "";
    protected String mText = "";

    protected Bitmap artworkNormal;
    protected Bitmap artworkSmall;

    protected NotificationMode mode;

    /* notification */
    protected NotificationCompat.Builder notiBuilder;
    protected NotificationManagerCompat notificationManager;
    protected Notification notification;
    protected Handler mHandler;

    protected RemoteViews contentView;
    protected RemoteViews contentCompactView;

    protected PendingIntent mPlayIntent = null;
    protected PendingIntent mPauseIntent = null;

    protected PendingIntent mSwipeDismissIntent = null;
    protected PendingIntent updateTrackInfoIntent = null;
    protected PendingIntent updateTrackArtworkIntent = null;


    boolean visibleProgress = false;
    public final static String NOTIFICATION_CHANNEL_ID = "fs-undoc-notification";
    public final static String NOTIFICATION_CHANNEL = "UNDOK Notification";

    /* radio related */
    private Radio mRadio;
    protected NodePlayStatus mPlayStatus;
    protected static boolean playbackStarted = false;
    protected NodePlayCaps playCaps;

    private static Service mForegroundService;

    public abstract Notification create();
    public abstract NotificationBase update();
    public abstract void updateArtwork(Bitmap bitmap);

    private IRadioNotificationState radioNotificationState = new IRadioNotificationState() {
        @Override
        public void onChange(boolean isPaused) {
            FsLogger.log(TAG + " notification state changed to paused=" + isPaused);

            // if notification is enabled then this radio need updates available
            if (isPaused && (mRadio != null)) {
                mRadio.resume();
            }
        }
    };

    private INodeNotificationCallback nodeNotification = new INodeNotificationCallback() {
        @Override
        public void onNodeUpdated(NodeInfo node) {
            FsLogger.log(TAG + "node updated " + node + " - " + node.getName());

            if (node instanceof NodePlayInfoName) {
                if (mode == MP) {
                    FsLogger.log(TAG + "update track on mode: " + mode);

                    // update track info to widget
                    requestTrackUpdate();
                }
            } else if (node instanceof NodePlayStatus) {

                if (mPlayStatus != null &&
                        ((NodePlayStatus) node).getValueEnum() == mPlayStatus.getValueEnum()) {
                    return;
                }

                mPlayStatus = (NodePlayStatus) node;
                FsLogger.log(TAG + "node " + node + " is instance of NodePlayStatus");

                if (isPlaying()) {
                    if (!playbackStarted) {
                        setPlayStarted(true);//.update().show();
                    }

                    // update track info to widget
                    requestTrackUpdate();

                } else if (isPaused()) {
                    FsLogger.log(TAG + "Paused ...");
                    if (playbackStarted) {
                        setPlayStarted(false).update().show();
                    }
                } else if (isBuffering()) {
                    FsLogger.log(TAG + "buffering ...");
                    if (!playbackStarted) {
                        setPlayStarted(true).update().show();
                    }
                } else if (isIdle()) {
                    FsLogger.log(TAG + "Idle ...");
                    if (playbackStarted) {
                        setPlayStarted(false).update().show();
                    }
                } else if (isStopped()) {
                    FsLogger.log(TAG + "stopped ...");

                    setPlayStarted(false);//.update().show();
                    requestTrackUpdate();
                    resetPlayInfo();
                    NotificationBase.this.update().show();
                }
            }  else {
                FsLogger.log(TAG + " onNodeUpdated nothing to do: mode: " + mode + ", node: " + node);
            }
        }
    };

    public void setPlayStatusFirstTime(NodePlayStatus playStatus) {
        mPlayStatus = playStatus;
    }

    public void removeRadioNotificationListener() {
        if (mRadio != null) {
            mRadio.removeNotificationListener(nodeNotification);
        }
    }

    public void addRadioNotificationListener() {
        if (mRadio != null) {
            removeRadioNotificationListener();
            mRadio.addNotificationListener(nodeNotification);
        }
    }

    public NotificationBase(NotificationMode mode, int notificationId, int imgSmallSize, int imgBigSize){
        this.sizeSmallImage = imgSmallSize;
        this.sizeBigImage = imgBigSize;
        this.notificationId = notificationId;
        this.mode = mode;
    }

    private void createChannel(){

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel mChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, NOTIFICATION_CHANNEL, NotificationManager.IMPORTANCE_DEFAULT);

            // Configure the notification channel.
            mChannel.setDescription(NOTIFICATION_CHANNEL);
            mChannel.enableLights(false);
            // Sets the notification light color for notifications posted to this
            // channel, if the device supports this feature.
            //mChannel.setLightColor(Color.GREEN);
            mChannel.enableVibration(false);
            mChannel.setSound(null, null);
            mChannel.setImportance(NotificationManager.IMPORTANCE_LOW);


            // workaround, vibration is still enabled even if set to false
            mChannel.setVibrationPattern(new long[]{0, 0, 0, 0,0, 0, 0, 0, 0});

            NotificationManager mNotificationManager =
                    (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);

            mNotificationManager.createNotificationChannel(mChannel);
        }

    }

    public NotificationBase setContext(Context ctx) {
        this.mContext = ctx;
        this.densityMultiplier = ctx.getResources().getDisplayMetrics().density;
        this.mHandler = new Handler();

        createChannel();
        this.notificationManager = NotificationManagerCompat.from(mContext);

        setTint(R.color.controls_tint_color) ;

        Bitmap tmp = getAlbumArtwork(null);
        this.artworkNormal = scaleDownBitmap(tmp, sizeBigImage);
        this.artworkSmall = scaleDownBitmap(tmp, sizeSmallImage);

        return this;
    }

    public NotificationBase requestTrackUpdate(){
        try {
            FsLogger.log(TAG + "send intent to update track info");

            if (updateTrackInfoIntent != null) {
                updateTrackInfoIntent.send();
            }
        } catch (PendingIntent.CanceledException e) {
            e.printStackTrace();
        }

        return this;
    }

    public NotificationBase requestTrackArtworkUpdate(){
        try {
            FsLogger.log(TAG + "send intent to update track artwork");

            updateTrackArtworkIntent.send();
        } catch (PendingIntent.CanceledException e) {
            e.printStackTrace();
        }

        return this;
    }

    public NotificationBase setContext(Context ctx, Radio radio) {
        setContext(ctx);

        setRadio(radio);
        return this;
    }

    public boolean updateRadio(Radio radio, boolean forced){

        FsLogger.log("radio: " + radio + " - mRadio: " + mRadio);

        if (radio != null) {

            FsLogger.log("radio UDN: " + radio.getUDN());
            FsLogger.log("mRadio: " + mRadio.getUDN());

            if (!mRadio.getUDN().equals(radio.getUDN()) || forced) {
                setRadio(radio);
                return true;
            }
        }

        return false;
    }

    public boolean startForeground(Service localService) {
        if (localService != null) {
            mForegroundService = localService;
        }

        try {
            return startForeground();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * restart foreground for last service
     */
    public boolean startForeground() throws Exception{

        if (mForegroundService != null) {
            mForegroundService.startForeground(notificationId, notification);

            return true;
        }

        return false;
    }

    public NotificationBase stopForeground(){

        try {
            mForegroundService.stopForeground(false);

            if (mForegroundService != null) {
                mForegroundService.stopSelf();
            }
        } catch (NullPointerException e) {

        } finally {
            mForegroundService = null;
        }

        return this;
    }

    public NotificationBase setRadio(Radio radio) {

        if (radio != null) {

            mRadio = radio;

            mPlayIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.PLAY, mode);
            mPauseIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.PAUSE, mode);

            mSwipeDismissIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.DISMISS_NOTIFICATION, mode);
            updateTrackInfoIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.UPDATE_TRACK, mode);
            updateTrackArtworkIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.UPDATE_TRACK_ARTWORK, mode);

            mRadio.removeNotificationStateListener(radioNotificationState);
            mRadio.addNotificationStateListener(radioNotificationState);

            // notifications
            addRadioNotificationListener();
        }

        return this;
    }

    public NotificationBase remove() {
        if (mRadio != null) {
            mRadio.removeNotificationStateListener(radioNotificationState);
            mRadio.removeNotificationListener(nodeNotification);
        }

        if (notificationManager != null) {
            notificationManager.cancel(notificationId);
        }

        return this;
    }

    /**
     * get a pending intent that will open ConnectedSpeaker activity
     * @return
     */
    protected PendingIntent getOpenAppIntent(){
        Intent resultIntent = new Intent(mContext, ConnectedSpeakerActivity.class);

        // Create the TaskStackBuilder and add the intent, which inflates the back stack
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(mContext);
        stackBuilder.addNextIntentWithParentStack(resultIntent);

        // Get the PendingIntent containing the entire back stack
        return stackBuilder.getPendingIntent(0, PendingIntent.FLAG_IMMUTABLE);
    }

    public static void cancel(Context ctx, int notifyId) {
        String ns = Context.NOTIFICATION_SERVICE;
        NotificationManager nMgr = (NotificationManager) ctx.getSystemService(ns);
        nMgr.cancel(notifyId);
    }

    /**
     * create a notification and show it
     */
    public void show() {
        if (notificationManager != null) {
            try {
                notificationManager.notify(notificationId, notification);
            } catch (RuntimeException e) {
                // bad array lengths RuntimeException because image too big
                FsLogger.log(TAG + "exception on show notification", LogLevel.Error);
                try {
                    notificationManager.notify(notificationId, notification);
                } catch (RuntimeException e2) {
                    //
                }
            }
        }
    }

    protected void resetPlayInfo(){
        // reset image info
        Bitmap tmp = getAlbumArtwork(null);
        artworkNormal = scaleDownBitmap(tmp, sizeBigImage);
        artworkSmall = scaleDownBitmap(tmp, sizeSmallImage);

        mTitle = "";
        mText = "";
    }

    public NotificationBase setData(String title, String text) {
        if (title == null) {
            title = "";
        }

        if (text == null) {
            text = "";
        }

        this.mTitle = title;
        this.mText = text;

        return this;
    }

    public NotificationBase setPlayStatus(NodePlayStatus status) {
        this.mPlayStatus = status;

        return this;
    }

    public NotificationBase playCaps(NodePlayCaps caps) {
        this.playCaps = caps;

        return this;
    }

    public NotificationBase setPlayStarted(boolean isStarted) {
        playbackStarted = isStarted;

        return this;
    }

    public NotificationBase setArtwork(Bitmap artwork) {
        this.artworkNormal = getAlbumArtwork(artwork);

        return this;
    }

    public NotificationBase setTint(int colorRes) {
        this.colorTintRes = colorRes;

        return this;
    }

    /**
     * return album artwork or default image
     * @param artWorkBitmap
     * @return
     */
    protected Bitmap getAlbumArtwork(Bitmap artWorkBitmap) {
        if (artWorkBitmap == null) {
            return tintResource(defaultArtWork, this.colorTintRes);
        } else {

            return artWorkBitmap;
        }
    }

    /**
     * load artwork from url, artwork is updated in notification
     *
     * @param artworkUrl
     */
    public void loadArtwork(Context ctx, final String artworkUrl) {
        if (mHandler != null) {
            mHandler.post(new LoadImage(ctx, artworkUrl));
        }
    }

    /**
     * scaled a bitmap to new size
     * @param photo
     * @param newHeight
     * @return
     */
    protected Bitmap scaleDownBitmap(Bitmap photo, int newHeight) {

        int h= (int) (newHeight*densityMultiplier);
        int w= (int) (h * photo.getWidth()/((double) photo.getHeight()));

        //FsLogger.log(TAG + "original size: " + photo.getByteCount() + " (" + photo.getHeight() + "x" + photo.getWidth() + ")");
        Bitmap p2 = Bitmap.createScaledBitmap(photo, w, h, true);

        if (p2.getByteCount() < photo.getByteCount()) {
            //FsLogger.log(TAG + "scaled size (" + newHeight + "): " + p2.getByteCount() + " (" + p2.getHeight() + "x" + p2.getWidth() + ")");

            return p2;
        }

        return photo;
    }

    /**
     * get a resource and apply a tint
     * @param resId
     * @param colorRes
     * @return
     */
    protected Bitmap tintResource(int resId, int colorRes) {

        Bitmap bm = null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        try {
            bm = BitmapFactory.decodeResource(mContext.getResources(),
                    resId, options);

            //FsLogger.log(TAG + "resource size: " + bm.getByteCount() + " (" + bm.getHeight() + "x" + bm.getWidth() + ")");
        } catch (Error ee) {
        } catch (Exception e) {
        }

        return tintImage(bm, colorRes);
    }

    /**
     * apply a tint to a bitmap
     * @param bitmap
     * @param colorRes
     * @return
     */
    protected Bitmap tintImage(Bitmap bitmap, int colorRes){
        Paint paint = new Paint();
        paint.setColorFilter(new PorterDuffColorFilter(colorRes, PorterDuff.Mode.SRC_IN));
        Bitmap bitmapResult = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapResult);
        canvas.drawBitmap(bitmap, 0, 0, paint);

        return bitmapResult;
    }

    public boolean isPlaying() {
        boolean isPlaying = false;
        if (mPlayStatus != null) {
            isPlaying = (mPlayStatus.getValueEnum() == NodePlayStatus.Ord.PLAYING);
        } else if (mode == IR) {
            isPlaying = playbackStarted;
        }

        return isPlaying;
    }

    public boolean isPaused() {
        boolean isPaused = false;
        if (mPlayStatus != null) {
            isPaused = (mPlayStatus.getValueEnum() == NodePlayStatus.Ord.PAUSED);
        } else if (mode == IR) {
            isPaused = !playbackStarted;
        }

        return isPaused;
    }

    public boolean isBuffering() {
        boolean isBuffering = false;
        if (mPlayStatus != null) {
            isBuffering = (mPlayStatus.getValueEnum() == NodePlayStatus.Ord.BUFFERING ||
                    mPlayStatus.getValueEnum() == NodePlayStatus.Ord.REBUFFERING);
        }

        return isBuffering;
    }

    public boolean isIdle() {
        boolean isIdle = false;
        if (mPlayStatus != null) {
            isIdle = (mPlayStatus.getValueEnum() == NodePlayStatus.Ord.IDLE);
        }

        return isIdle;
    }

    public boolean isStopped() {
        boolean isStopped = false;
        if (mPlayStatus != null) {
            isStopped = (mPlayStatus.getValueEnum() == NodePlayStatus.Ord.STOPPED);
        } else if (mode == IR) {
            isStopped = !playbackStarted;
        }

        return isStopped;
    }

    public boolean isPauseAvailable() {
        boolean isAvailable = false;

        if (playCaps != null) {
            isAvailable = (playCaps.DoesSupport(NodePlayCaps.Operation.Pause));
        }

        return isAvailable;
    }

    public void dismissAllResources() {
        mContext = null;
        contentView = null;
        contentCompactView = null;
        mPlayIntent = null;
        mPauseIntent = null;
        mSwipeDismissIntent = null;
        updateTrackInfoIntent = null;
        updateTrackArtworkIntent = null;
        artworkNormal = null;
        artworkSmall = null;
    }

    private class LoadImage implements Runnable {
        private final Context mContext;
        String url;

        public LoadImage(Context mContext, String artworkUrl) {
            this.mContext = mContext;
            url = artworkUrl;
        }

        public void run() {
            if (!TextUtils.isEmpty(url)) {
                Glide.with(mContext)
                        .asBitmap()
                        .load(url)
                        .into(new SimpleTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                FsLogger.log("getAlbumArtwork RESPONSE for " + url);
                                updateArtwork(resource);

                            }
                        });
            } else {
                updateArtwork(null);
            }
        }
    }
}
