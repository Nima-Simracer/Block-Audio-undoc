package com.frontier_silicon.fsirc.dok2.update;

import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;

import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

class AllDevicesIsuRunnable implements Runnable {
    private final Object mLock = new Object();
    private IAllDevicesIsuListener mIAllDevicesIsuListener;

    private List<Radio> mAllDevices;
    private HashMap<String, IsuItemModel> mHashItemModels;
    private Timer mTimer;
    private TimerTask mTimerTask;
    private final int mFinishDelay = 300_000;
    //private final int mFinishDelay = 40_000;

    public AllDevicesIsuRunnable(IAllDevicesIsuListener iAllDevicesIsuListener, List<Radio> devicesList,
                                 HashMap<String, IsuItemModel> mapDevicesUpdates) {
        setAllDevicesIsuListener(iAllDevicesIsuListener);

        mAllDevices = devicesList;
        mHashItemModels = mapDevicesUpdates;
    }

    public void setAllDevicesIsuListener(IAllDevicesIsuListener iAllDevicesIsuListener) {
        synchronized (mLock) {
            mIAllDevicesIsuListener = iAllDevicesIsuListener;
        }
    }

    @Override
    public void run() {
        if (mAllDevices == null || mHashItemModels == null) {
            onFailed();
            return;
        }

        for (int i = 0; i < mAllDevices.size(); i++) {
            startIsuForItemIfNeeded(mAllDevices.get(i));
        }

        mTimerTask = new IsuFinishedTimerTask();
        mTimer = new Timer();
        mTimer.schedule(mTimerTask, mFinishDelay);
    }

    private void startIsuForItemIfNeeded(Radio radio) {
        String sn = radio.getSN();
        if (TextUtils.isEmpty(sn))
            return;

        IsuItemModel isuItem = mHashItemModels.get(sn);
        if (isuItem == null)
            return;

        if (isuItem.mUpdateState != NodeSysIsuState.Ord.UPDATE_AVAILABLE)
            return;

        isuItem.mIsUpdating = true;
        isuItem.mCurrentVersion = "";

        startIsuOnDevice(radio, isuItem);
    }

    private void startIsuOnDevice(Radio radio, final IsuItemModel isuItem) {
        UpdateFirmwareRunnable updateRunnable = new UpdateFirmwareRunnable(radio, isuItem);

        updateRunnable.run();
    }

    private void onFailed() {
        synchronized (mLock) {
            if (mIAllDevicesIsuListener != null)
                mIAllDevicesIsuListener.failed();
        }

        dispose();
    }

    private void onFinish() {
        synchronized (mLock) {
            if (mIAllDevicesIsuListener != null)
                mIAllDevicesIsuListener.isuFinished();
        }

        dispose();
    }

    private class IsuFinishedTimerTask extends TimerTask {

        @Override
        public void run() {

            if (mHashItemModels != null) {
                for (IsuItemModel isuItemModel : mHashItemModels.values()) {
                    isuItemModel.mIsUpdating = false;
                }
            }

            onFinish();
        }
    }

    private void dispose() {
        mAllDevices = null;
        mHashItemModels = null;
        mTimer = null;
        mTimerTask = null;
        mIAllDevicesIsuListener = null;
    }
}
