package com.frontier_silicon.fsirc.dok2.baseActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SpeakersDiscoveryManager;
import com.frontier_silicon.fsirc.dok2.UserFeedbackForm;
import com.frontier_silicon.fsirc.dok2.connection.RadioPINManager;
import com.frontier_silicon.fsirc.dok2.util.ThemeUtil;

/**
 * Created by lsuhov on 15/02/2017.
 */

public abstract class UndokActivityBase extends AppCompatActivity {

    private MainMenuHandler mMainMenuHandler;
    private SpeakerLostWatcher mSpeakerLostWatcher;
    private int mOldThemeId = -1;
    private boolean mEnableDiscoveryOfSpeakers = true;
    private boolean mEnableNoWiFiWatcher = true;
    private NoWiFiWatcher mNoWiFiWatcher;
    private ConnectionLostWatcher mConnectionLostWatcher;
    private boolean mEnableVolumeFromHwButtonsWatcher = true;
    private VolumeFromHwButtonsWatcher mVolumeFromHwButtonsWatcher;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        ThemeUtil.applyTheme(this);
        mOldThemeId = ThemeUtil.getThemeResId();

        if(getResources().getBoolean(R.bool.portrait_only)){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }

        super.onCreate(savedInstanceState);

        UserFeedbackForm.getInstance().setActivity(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mOldThemeId != ThemeUtil.getThemeResId()) {
            recreate();
            return;
        }

        initNoWiFiWatcher();
        initVolumeFromHwButtonsWatcher();

        if (mMainMenuHandler != null) {
            mMainMenuHandler.registerSpeakerDataListener();
        }

        if (mEnableDiscoveryOfSpeakers) {
            SpeakersDiscoveryManager.getInstance().tryStartDiscovery();
        }

        if (mNoWiFiWatcher != null) {
            mNoWiFiWatcher.registerListener();
        }

        if (mSpeakerLostWatcher != null) {
            mSpeakerLostWatcher.registerSpeakersDiscoveryListener();

            if (mSpeakerLostWatcher.checkIfSpeakerWasLost()) {
                return;
            }
        }

        if (mConnectionLostWatcher != null) {
            mConnectionLostWatcher.registerConnectionStateListener();
        }

        IPodDockManager.getInstance().onResume(this);
    }

    @Override
    protected void onPause() {
        RadioPINManager.getInstance().savePINs(this);

        UserFeedbackForm.getInstance().setPaused();

        if (mMainMenuHandler != null) {
            mMainMenuHandler.unregisterSpeakerDataListener();
        }

        if (mNoWiFiWatcher != null) {
            mNoWiFiWatcher.unregisterListener();
        }

        if (mSpeakerLostWatcher != null) {
            mSpeakerLostWatcher.unregisterSpeakersDiscoveryListener();
        }

        if (mConnectionLostWatcher != null) {
            mConnectionLostWatcher.removeConnectionStateListener();
        }

        IPodDockManager.getInstance().onPause();

        super.onPause();
    }

    @Override
    protected void onStop() {
        DialogsHolder.dismissAllRegisteredDialogs();

        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mMainMenuHandler != null) {
            mMainMenuHandler.dispose();
        }

        if (mSpeakerLostWatcher != null) {
            mSpeakerLostWatcher.dispose();
        }

        if (mNoWiFiWatcher != null) {
            mNoWiFiWatcher.dispose();
        }

        if (mVolumeFromHwButtonsWatcher != null) {
            mVolumeFromHwButtonsWatcher.dispose();
        }

        if (mConnectionLostWatcher != null) {
            mConnectionLostWatcher.dispose();
        }
    }

    protected void setupAppBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    protected void enableUpNavigation() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public void setTitle(int resId) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(resId);
        }
    }

    public void setTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    public void enableMainMenu() {
        enableMainMenu(0);
    }

    public void enableMainMenu(int menuOptions) {
        mMainMenuHandler = new MainMenuHandler(this, menuOptions);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (menu == null) {
            return super.onPrepareOptionsMenu(menu);
        }

        if (mMainMenuHandler != null) {
            mMainMenuHandler.onPrepareOptionsMenu(menu);
        }

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            super.onBackPressed();

            onBackOrUp();
            return true;
        }

        if (mMainMenuHandler != null && mMainMenuHandler.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        onBackOrUp();
    }

    protected void onBackOrUp() {
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (mMainMenuHandler != null) {
            getMenuInflater().inflate(R.menu.main, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (mEnableVolumeFromHwButtonsWatcher && mVolumeFromHwButtonsWatcher.canHandleKey(keyCode)) {

            mVolumeFromHwButtonsWatcher.startVolumeUpdateTask(keyCode);
            return true;
        } else {
            return super.onKeyDown(keyCode, event);
        }
    }



    protected void initSpeakerLostWatcher(SpeakerLostHandlingType handlingType) {
        if (mSpeakerLostWatcher == null) {
            mSpeakerLostWatcher = new SpeakerLostWatcher(this, handlingType);
        }
    }

    protected void initSpeakerConnectionLostWatcher() {
        if (mConnectionLostWatcher == null) {
            mConnectionLostWatcher = new ConnectionLostWatcher(this);
        }
    }

    protected void addUdnToSpeakerLostWatcher(String udn) {

        if (mSpeakerLostWatcher == null) {
            mSpeakerLostWatcher = new SpeakerLostWatcher(this);
        }

        mSpeakerLostWatcher.addSpeakerUdn(udn);
    }

    /**
     * All activities need the discovery of speakers enabled, except for SETUP section.
     * Discovery is enabled by default
     */
    protected void disableDiscoveryOfSpeakers() {
        mEnableDiscoveryOfSpeakers = false;
    }

    /**
     * All activities need to know if WiFi is disabled except for Setup and NoWiFi screens
     * The watcher is enabled by default
     */
    protected void disableNoWiFiWatcher() {
        mEnableNoWiFiWatcher = false;
    }

    private void initNoWiFiWatcher() {
        if (mEnableNoWiFiWatcher && mNoWiFiWatcher == null) {
            mNoWiFiWatcher = new NoWiFiWatcher(this);
        }
    }

    protected void disableVolumeFromHwButtonsWatcher() {
        mEnableVolumeFromHwButtonsWatcher = false;
    }

    private void initVolumeFromHwButtonsWatcher() {
        if (mEnableVolumeFromHwButtonsWatcher && mVolumeFromHwButtonsWatcher == null) {
            mVolumeFromHwButtonsWatcher = new VolumeFromHwButtonsWatcher(this);
        }
    }

}
