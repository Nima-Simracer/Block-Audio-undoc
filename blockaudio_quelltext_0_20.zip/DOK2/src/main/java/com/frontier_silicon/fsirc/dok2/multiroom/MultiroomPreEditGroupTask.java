package com.frontier_silicon.fsirc.dok2.multiroom;

import android.app.Activity;
import android.content.Context;
import androidx.appcompat.app.AlertDialog;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoFriendlyName;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.BaseShowProgressDialogTask;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.IButtonsResponseWithTextListener;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.IMultiroomOperationListener;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.connection.RadioPINManager;
import com.frontier_silicon.fsirc.dok2.DialogsOpener;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by hcostescu on 10/7/2016.
 */

public class MultiroomPreEditGroupTask extends BaseShowProgressDialogTask<Boolean> {

    private MultiroomItemModel mMultiroomItemModel;
    private IMultiroomOperationListener mOperationListener;
    private Activity mParentActivity;
    private long mPostDelayedId;

    private Radio masterRadio = null;

    private enum DialogType {None, ServerSpeakerState, EditGroupDialog, PinDialog, MessageDialog}

    private DialogType displayDialog;

    public MultiroomPreEditGroupTask(Activity parentActivity, MultiroomItemModel multiroomItemModel, IMultiroomOperationListener listener) {
        this.mParentActivity = parentActivity;
        this.mContext = parentActivity;
        this.mMultiroomItemModel = multiroomItemModel;
        this.mOperationListener = listener;

        mDialogKey = "pre_edit_dialog";
        mLoadingMessage = parentActivity.getString(R.string.loading);
        mDialogCancelable = false;

        displayDialog = DialogType.None;
    }

    @Override
    protected void onPreExecute() {
        initTimeoutTimer();
        showProgressDialogWithDelay();
    }

    private void showProgressDialogWithDelay() {

        Runnable runnable = () -> showProgressDialog();

        mPostDelayedId = DelayedPostsManager.getInstance().registerNewCallbackID();
        DelayedPostsManager.getInstance().postDelayed(runnable, mPostDelayedId, 1000);
    }

    private void stopProgressDialog() {
        DelayedPostsManager.getInstance().removeCallbackId(mPostDelayedId);
    }


    @Override
    protected Boolean doInBackground(Integer... params) {
        checkRadioSourceForGrouping();
        return true;
    }

    private void checkRadioSourceForGrouping() {
        Radio radio = mMultiroomItemModel.getRadio();
        if (mMultiroomItemModel.getIsGroupHeader()) {
            MultiroomDeviceModel device = MultiroomGroupManager.getInstance().getServerDeviceFromGroupId(mMultiroomItemModel.getGroupId());
            if (device != null) {
                radio = device.mRadio;
            } else {   //Display error message
                displayDialog = DialogType.ServerSpeakerState;
            }
        }
        masterRadio = radio;
        if (radio != null) {
            radio.getCurrentModeAsListItem(true, currentMode -> {
                if (currentMode == null) {
                    checkRadioPINBeforeEditGroup();
                } else {
                    if (!currentMode.getStreamable()) {
                        showStandaloneMessage();

                    } else {
                        checkRadioPINBeforeEditGroup();
                    }
                }
            });
        } else {
            displayDialog = DialogType.ServerSpeakerState;
        }
    }

    private void checkRadioPINBeforeEditGroup() {
        //check PIN for group master
        if (masterRadio != null) {
            masterRadio.allowRequestsForInvalidPIN(true);

            masterRadio.getNode(NodeSysInfoFriendlyName.class, true/*sync*/, true/*forceUncached*/, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    masterRadio.allowRequestsForInvalidPIN(false);
                    displayDialog = DialogType.EditGroupDialog;
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    masterRadio.allowRequestsForInvalidPIN(false);

                    if (NetRemoteManager.isPinError(error)) {
                        displayDialog = DialogType.PinDialog;
                    } else {
                        displayDialog = DialogType.ServerSpeakerState;
                    }
                }
            });
        }
    }

    private void showStandaloneMessage() {
        if (masterRadio == null)
            return;
        displayDialog = DialogType.MessageDialog;
    }

    private void showEditGroupDialog(Context context/*,
                                     String newGroupName, List<MultiroomOperation> operationList*/) {

        if (DialogsHolder.isShowingOrActivityIsFinishing(MultiroomEditGroupDialog.DIALOG_KEY, (Activity) context)) {
            return;
        }

        if (mMultiroomItemModel != null) {
            MultiroomEditGroupDialog editGroupDialog = new MultiroomEditGroupDialog(mParentActivity, mOperationListener);
            editGroupDialog.createDialog(mMultiroomItemModel, null, null/*, newGroupName, operationList*/);
        }
    }

    private void showPINDialog() {
        RadioPINManager.getInstance().showIncorrectPINDialog(mParentActivity, masterRadio, new IButtonsResponseWithTextListener() {
            @Override
            public void onOkClicked(String response) {
                MultiroomPreEditGroupTask preEditGroupTask = new MultiroomPreEditGroupTask(mParentActivity,
                        mMultiroomItemModel, mOperationListener);
                TaskHelper.execute(preEditGroupTask);
            }

            @Override
            public void onCancelClicked() {
            }
        });
    }

    @Override
    protected void onPostExecute(final Boolean result) {
        super.onPostExecute(result);
        stopProgressDialog();

        if (mParentActivity == null || mParentActivity.isFinishing()) {
            return;
        }

        mParentActivity.runOnUiThread(() -> {
            switch (displayDialog) {
                case ServerSpeakerState:
                    AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mContext);
                    builder
                            .setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.title_server_speaker_state_unknown, true))
                            .setMessage(R.string.text_server_speaker_state_unknown)
                            .setNeutralButton("OK", null)
                            .show();
                    break;
                case EditGroupDialog:
                    showEditGroupDialog(mContext/*,null,null*/);
                    break;
                case PinDialog:
                    if (masterRadio != null)
                        showPINDialog();
                    break;
                case MessageDialog:

                    DialogsOpener.showMessageDialog(mContext, R.string.uncompatible_mode_title, R.string.error_non_multiroom_mode_description, new IButtonsResponseWithTextListener() {
                        @Override
                        public void onOkClicked(String response) {
                            MultiroomDialogsUtil.showSelectStreamableModeDlg(mParentActivity, masterRadio, streamableModeSelected -> {
                                if (streamableModeSelected && !DialogsHolder.activityIsFinishing(mParentActivity)) {
                                    DialogsHolder.dismissDialog(MultiroomEditGroupDialog.DIALOG_KEY);

                                    // retry group edit with delay
                                    new Timer().schedule(new TimerTask() {
                                        @Override
                                        public void run() {
                                            mParentActivity.runOnUiThread(() -> {
                                                if (DialogsHolder.activityIsFinishing(mParentActivity)) {
                                                    return;
                                                }

                                                MultiroomPreEditGroupTask preEditGroupTask = new MultiroomPreEditGroupTask(
                                                        mParentActivity, mMultiroomItemModel, mOperationListener);
                                                TaskHelper.execute(preEditGroupTask);
                                            });
                                        }
                                    }, 1200);

                                }
                            });
                        }

                        @Override
                        public void onCancelClicked() {
                        }
                    });
                    break;
            }
        });
    }
}
