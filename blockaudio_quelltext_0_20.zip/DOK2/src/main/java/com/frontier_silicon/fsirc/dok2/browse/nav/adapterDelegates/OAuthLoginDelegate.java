package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import android.content.Context;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.OAuthLoginEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.AmazonSignUpEvent;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseAmazonLoginBinding;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by hcostescu on 11/08/17.
 */

public class OAuthLoginDelegate extends RecyclerViewListItemDelegate {
    private int mBrowseType;
    private Context activity;

    public OAuthLoginDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        activity = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseAmazonLoginBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_amazon_login,
                parent, false);

        return new OAuthLoginDelegate.BrowseAmazonLoginViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder,  int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {

        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(mBrowseType);
        BrowseItemModel mNavBrowseItemModel = browseManager.tryGetBrowseItemModel(position);

        if(mNavBrowseItemModel != null && mNavBrowseItemModel.getType() == BrowseItemType.OAuth &&
                mNavBrowseItemModel.getSubType() == BrowseItemType.MessageButton)  {

            EventBus.getDefault().post(new OAuthLoginEvent(mNavBrowseItemModel));
        } else if (mNavBrowseItemModel != null && mNavBrowseItemModel.getType() == BrowseItemType.OAuth &&
                mNavBrowseItemModel.getSubType() == BrowseItemType.MessageText)  {
            EventBus.getDefault().post(new AmazonSignUpEvent(mNavBrowseItemModel));
        }
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
    }

    private static class BrowseAmazonLoginViewHolder extends ListItemViewHolder {
            BrowseAmazonLoginBinding  mBinding;
        BrowseAmazonLoginViewHolder(BrowseAmazonLoginBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
