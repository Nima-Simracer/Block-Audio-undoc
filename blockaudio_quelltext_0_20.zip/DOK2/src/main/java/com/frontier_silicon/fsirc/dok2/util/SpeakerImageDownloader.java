package com.frontier_silicon.fsirc.dok2.util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;

import java.io.IOException;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by lsuhov on 13/10/2017.
 */

public class SpeakerImageDownloader {

    public interface ISpeakerImageDownloaderListener {
        void onImageDownloaded(BitmapDrawable bitmapDrawable);
    }

    private Radio mRadio;
    private Context mContext;
    private ISpeakerImageDownloaderListener mListener;
    private int mNumberOfTries = 0;

    public SpeakerImageDownloader(Radio radio, Context context, ISpeakerImageDownloaderListener listener) {
        mRadio = radio;
        mContext = context;
        mListener = listener;
    }

    public void download() {
        if (mRadio.getSpeakerImageBitmap() != null) {
            notifyListener(mListener, getBitmapDrawable(mRadio.getSpeakerImageBitmap()));
        } else {
            downloadImage();
        }
    }

    private void downloadImage() {
        if (mRadio.getImageURL() == null || mRadio.isDDXMLBlocked()) {
            notifyListener(mListener, (BitmapDrawable) MainApplication.getContext().getResources().getDrawable(R.drawable.ic_smart_radio_colored));
            dispose();
            return;
        }

        final String bitmapURL;
        bitmapURL = mRadio.getImageURL().toString();
        Request request = new Request.Builder().url(bitmapURL).build();
        NetRemote.getOkHttpClient().newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                retryDownload();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                if (response.isSuccessful()) {
                    InputStream inputStream = response.body().byteStream();
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    response.close();
                    mRadio.setSpeakerImageBitmap(bitmap);
                    notifyListener(mListener, getBitmapDrawable(bitmap));
                } else {
                    returnDefaultImage();
                }

                dispose();
            }
        });
    }

    private BitmapDrawable getBitmapDrawable(Bitmap bitmap) {
        BitmapDrawable bitmapDrawable = null;

        if (mContext != null) {
            Resources resources = mContext.getResources();
            bitmapDrawable = new BitmapDrawable(resources, bitmap);
        }

        return bitmapDrawable;
    }

    private void retryDownload() {
        if (mNumberOfTries == 0) {
            mNumberOfTries++;
            downloadImage();
        } else {
            returnDefaultImage();
            dispose();
        }
    }

    private void returnDefaultImage() {
        notifyListener(mListener, (BitmapDrawable) MainApplication.getContext().getResources().getDrawable(R.drawable.ic_smart_radio_colored));
    }

    private void notifyListener(ISpeakerImageDownloaderListener listener, BitmapDrawable bitmapDrawable) {
        NetRemote.getMainThreadExecutor().execute(() -> {
            if (listener != null) {
                listener.onImageDownloaded(bitmapDrawable);
            }
        });
    }

    private void dispose() {
        mRadio = null;
        mContext = null;
        mListener = null;
    }
}
