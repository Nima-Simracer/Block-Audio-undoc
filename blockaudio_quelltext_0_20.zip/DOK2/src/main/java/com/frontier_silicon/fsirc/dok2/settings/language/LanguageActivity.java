package com.frontier_silicon.fsirc.dok2.settings.language;

import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.RadioFromBundleExtractor;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Created by hcostescu on 11/19/2016.
 */

public class LanguageActivity extends UndokActivityBase implements ILanguageUpdate, ILanguageSettingClickListener {

    private LanguageUtil mLanguageUtil;
    private ArrayList<LanguageItemModel> mLanguagesList;
    private LanguageArrayAdapter mListAdapter;
    private ListView mListView;
    private Button mSaveLanguage;
    private TextView mAutomaticallyDetectedLanguage;
    private CheckBox mLanguageCheckBox;

    private Radio mClientRadio = null;
    private LanguageItemModel languageItemModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_language_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.undok_language);

        Bundle bundle = getIntent().getExtras();
        mClientRadio = RadioFromBundleExtractor.extractRadio(bundle, LanguageActivity.class);

        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
        addUdnToSpeakerLostWatcher(bundle.getString(NavigationHelper.RADIO_UDN_ARG));

    }

    @Override
    protected void onResume() {
        super.onResume();

        setupControls();
    }

    protected void setupControls() {

        mListView = findViewById(R.id.languagesAvailableListView);
        mAutomaticallyDetectedLanguage = findViewById(R.id.textLanguageDetected);
        mSaveLanguage = findViewById(R.id.saveLanguageButton);


        mLanguageUtil = new LanguageUtil(mClientRadio);

        mLanguagesList = new ArrayList<>();
        mListAdapter = new LanguageArrayAdapter(this, R.layout.language_settings_list_item, R.id.text1, mLanguagesList, this);
        mListView.setAdapter(mListAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                onListItemClicked(position);
            }
        });

        mLanguageUtil.getLanguageList(this,null);

        mLanguageCheckBox = findViewById(R.id.detectLanguage);
        mLanguageCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                onCheckBoxSelected();
            } else {
                mListView.setVisibility(View.VISIBLE);
                mAutomaticallyDetectedLanguage.setVisibility(View.GONE);
                mSaveLanguage.setVisibility(View.GONE);
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mClientRadio = null;
    }


    private void onCheckBoxSelected() {
        boolean bLanguageCompatible = false;
        mListView.setVisibility(View.GONE);
        mAutomaticallyDetectedLanguage.setVisibility(View.VISIBLE);
        String phoneLanguage = Locale.getDefault().getDisplayLanguage();

        if (mListAdapter != null) {
            for (LanguageItemModel lItem : mLanguagesList) {
                if (lItem.mName.equalsIgnoreCase(phoneLanguage)) {
                    languageItemModel = lItem;
                    mAutomaticallyDetectedLanguage.setText(lItem.mName);
                    mSaveLanguage.setVisibility(View.VISIBLE);

                    mSaveLanguage.setOnClickListener(v -> {
                        SaveLanguage(languageItemModel);
                        mLanguageCheckBox.setChecked(false);
                        mSaveLanguage.setVisibility(View.GONE);
                        mAutomaticallyDetectedLanguage.setVisibility(View.GONE);
                        mListView.setVisibility(View.VISIBLE);
                    });
                    bLanguageCompatible = true;
                }
            }
        }
        if (!bLanguageCompatible)
            mAutomaticallyDetectedLanguage.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.phone_lanuage_incompatible, true));
    }

    private void onListItemClicked(int position)
    {
        try {
            final LanguageItemModel ltem = mListAdapter.getItem(position);
            if (!ltem.mIsSet) {
                mLanguageUtil.setLanguage(ltem.mKeyId, new ILanguageSet() {
                    @Override
                    public void langugageSet() {
                        ltem.mIsProgressVisible = false;
                        ltem.mIsSet = true;
                        mListAdapter.notifyDataSetChanged();
                    }
                });
            }
        } catch (Exception e) {
        }
    }

    @Override
    public void onLanguageUpdate(ArrayList<LanguageItemModel> lList) {
        if (lList != null) {
            mLanguagesList.clear();
            mLanguagesList.addAll(lList);
            mListAdapter.notifyDataSetChanged();

            if (mLanguageCheckBox.isChecked()) {
                onCheckBoxSelected();
            }

        }
    }

    @Override
    public void onListItemClick(LanguageItemModel item) {
        if (!item.mIsSet)
            SaveLanguage(item);
    }

    private void SaveLanguage(final LanguageItemModel item) {
        try {
            if (item != null && mListAdapter != null) {
                for (LanguageItemModel lItem : mLanguagesList) {
                    if (lItem.mKeyId == item.mKeyId) {
                        lItem.mIsSet = false;
                        lItem.mIsProgressVisible = true;
                    } else {
                        lItem.mIsSet = false;
                        lItem.mIsProgressVisible = false;
                    }
                }
                mListAdapter.notifyDataSetChanged();
            }
            mLanguageUtil.setLanguage(item.mKeyId, new ILanguageSet() {
                @Override
                public void langugageSet() {
                    for (LanguageItemModel lItem : mLanguagesList) {
                        if (lItem.mKeyId == item.mKeyId) {
                            lItem.mIsSet = true;
                            lItem.mIsProgressVisible = false;
                        } else {
                            lItem.mIsSet = false;
                            lItem.mIsProgressVisible = false;
                        }
                    }
                    mListAdapter.notifyDataSetChanged();
                }
            });
        } catch (Exception e) {
        }
    }
}
