package com.frontier_silicon.fsirc.dok2.stereo.editSystem;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomDeviceTransportOptimisation;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomRescanUtil;
import com.frontier_silicon.components.stereo.IStereoOperationResult;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.fsirc.dok2.DialogsOpener;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

/**
 * Created by lsuhov on 17/08/2017.
 */

public class EditStereoSystemViewModel {

    public ObservableBoolean isNetworkOptimized = new ObservableBoolean(false);
    public ObservableBoolean isUnpairing = new ObservableBoolean(false);

    private MultiroomDeviceModel mPrimaryDeviceModel;
    private Activity mActivity;
    private boolean mNetworkOptimizationCheckedProgramatically = false;

    EditStereoSystemViewModel(MultiroomDeviceModel primaryDeviceModel, Activity activity) {
        mPrimaryDeviceModel = primaryDeviceModel;
        mActivity = activity;

        init();
    }

    private void init() {
        retrieveNetworkOptimizationValue();
    }

    private void retrieveNetworkOptimizationValue() {
        Radio radio = mPrimaryDeviceModel.mRadio;
        if (radio == null) {
            return;
        }

        radio.getNode(NodeMultiroomDeviceTransportOptimisation.class, false, new IGetNodeCallback() {
            @Override
            public void getNodeResult(NodeInfo node) {
                if (mActivity == null) {
                    return;
                }

                NodeMultiroomDeviceTransportOptimisation optimised = (NodeMultiroomDeviceTransportOptimisation)node;

                mNetworkOptimizationCheckedProgramatically = true;
                isNetworkOptimized.set(optimised.getValue() > 0);
            }

            @Override
            public void getNodeError(Class nodeType, NodeErrorResponse error) {}
        });
    }

    public void onNetworkOptimizationChecked(CompoundButton buttonView, final boolean isChecked) {
        if (mNetworkOptimizationCheckedProgramatically) {
            mNetworkOptimizationCheckedProgramatically = false;
            return;
        }

        Radio radio = mPrimaryDeviceModel.mRadio;
        if (radio == null) {
            return;
        }

        isNetworkOptimized.set(isChecked);

        NodeMultiroomDeviceTransportOptimisation.Ord value = isChecked ? NodeMultiroomDeviceTransportOptimisation.Ord.ENABLED :
                NodeMultiroomDeviceTransportOptimisation.Ord.DISABLED;
        radio.setNode(new NodeMultiroomDeviceTransportOptimisation(value), false, new ISetNodeCallback() {
            @Override
            public void setNodeSuccess(NodeInfo node) {

                if (DokUiUtils.isDestroyed(mActivity)) {
                    return;
                }

                int messageId = isChecked ? R.string.network_optimisation_set_to_on : R.string.network_optimisation_set_to_off;
                GuiUtils.showToast(mActivity.getString(messageId), mActivity);
            }

            @Override
            public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                if (DokUiUtils.isDestroyed(mActivity)) {
                    return;
                }

                GuiUtils.showToast(mActivity.getString(R.string.network_optimisation_set_failed), mActivity);
            }
        });
    }

    public void onUnpairClicked(View v) {
        isUnpairing.set(true);

        StereoManager.getInstance().unpairStereoSystem(mPrimaryDeviceModel.mRadio, new IStereoOperationResult() {
            @Override
            public void onStereoOperationComplete(final boolean success) {
                isUnpairing.set(false);

                MultiroomRescanUtil.getInstance().rescanMultiroomDevicesAndGroups();

                if (DokUiUtils.isDestroyed(mActivity)) {
                    return;
                }

                mActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (DokUiUtils.isDestroyed(mActivity)) {
                            return;
                        }

                        if (success) {
                            Toast.makeText(mActivity.getApplicationContext(), R.string.unpair_successful, Toast.LENGTH_LONG).show();

                            NavigationHelper.goToHomeAndClearActivityStack(mActivity);
                        } else {
                            DialogsOpener.showMessageDialogWithOkButton(mActivity, "unpair_failed", -1, R.string.unpair_failed);
                        }
                    }
                });
            }
        });
    }

    public void dispose() {
        mPrimaryDeviceModel = null;
        mActivity = null;
    }
}
