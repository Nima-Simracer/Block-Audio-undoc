package com.frontier_silicon.fsirc.dok2.util;

import android.app.Activity;
import androidx.lifecycle.Lifecycle;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import androidx.databinding.ObservableField;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.widget.ImageButton;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.bumptech.glide.signature.ObjectKey;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.ExternalAppsOpener;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.BuildConfig;
import com.frontier_silicon.fsirc.dok2.R;

/**
 * Created by lsuhov on 02/02/16.
 */
public class DokUiUtils {

    public static void setTintToActionMenu(Context context, MenuItem menuItem) {
        if (menuItem != null) {
            Drawable actionDrawable = menuItem.getIcon();
            GuiUtils.setTintToDrawable(actionDrawable, context, R.attr.navigationbar_icon_color);
        }
    }

    public static void decideStateOfMuteButton(boolean mute, ImageButton muteButton, int muteAttrColor, int unmuteAttrColor) {
        muteButton.setImageResource(mute ? R.drawable.ic_unmute : R.drawable.ic_mute);

        int tintColor = GuiUtils.getColorFromAttribute(muteButton.getContext(), mute ? unmuteAttrColor : muteAttrColor);
        muteButton.setColorFilter(tintColor);
    }

    public static boolean isDestroyed(Context context) {
        if (context == null) {
            return true;
        }

        if (context instanceof FragmentActivity || context instanceof Activity) {
            Activity activity = (Activity) context;
            if (activity.isFinishing() ||
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && activity.isDestroyed())) {
                return true;
            }
        }
        return false;
    }

    public static boolean isAtLeastResumed(Lifecycle lifecycle) {
        return lifecycle != null && lifecycle.getCurrentState().isAtLeast(Lifecycle.State.RESUMED);
    }

    public static boolean isAtLeastStarted(Lifecycle lifecycle) {
        return lifecycle != null && lifecycle.getCurrentState().isAtLeast(Lifecycle.State.STARTED);
    }

    public static boolean isDestroyed(Lifecycle lifecycle) {
        return lifecycle != null && lifecycle.getCurrentState() == Lifecycle.State.DESTROYED;
    }

    public static void setImageIntoObservableDrawable(final ObservableField<BitmapDrawable> observableDrawable,
                                                      Radio radio, final Activity activity) {
        if (radio.getImageURL() == null) {
            return;
        }

        final String bitmapURL = radio.getImageURL().toString();

        Glide.with(activity)
                .asBitmap()
                .load(bitmapURL)
                .apply(RequestOptions.signatureOf(new ObjectKey(radio.getUDN())))
                .into(new SimpleTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        if (resource == null || activity == null) {
                            observableDrawable.set(null);
                        } else {
                            Resources resources = activity.getResources();
                            BitmapDrawable bitmapDrawable = new BitmapDrawable(resources, resource);

                            observableDrawable.set(bitmapDrawable);
                        }
                    }
                });
    }

    public static String getFriendlyNameOrStereoSystemName(Radio radio) {
        if (!radio.isStereoCapable()) {
            return radio.getFriendlyName();
        }

        MultiroomDeviceModel deviceModel = MultiroomGroupManager.getInstance().getDeviceByUdn(radio.getUDN());

        if (deviceModel != null && deviceModel.isStereoCapable() && !TextUtils.isEmpty(deviceModel.mStereoSystemName)) {
            return deviceModel.mStereoSystemName;
        } else {
            return radio.getFriendlyName();
        }
    }

    public static boolean openSpotify(Activity activity)
    {
        String marketUrl,packageName;
        if (!BuildConfig.putOnAmazonStore) {
            return ExternalAppsOpener.openSpotify(activity);
        }
        else {
            marketUrl = activity.getString(R.string.spotify_amazon_url);
            packageName = activity.getString(R.string.spotify_amazon_package_name);
            return ExternalAppsOpener.openSpotify(packageName,marketUrl, activity);
        }
    }

    public enum FeedbackType {
        Logs,
        Feedback;
    }

    public static  String getInfoForFeedbackAndLogs(FeedbackType type, String softwareVersion,Context context) {
        StringBuilder sb = new StringBuilder();
        String deviceModel = "Device Model: " + android.os.Build.MODEL + ", " + android.os.Build.MANUFACTURER + (type == FeedbackType.Logs ? "\n" : "%0D%0A");
        String speakerModel = "";
        if (NetRemoteManager.getInstance().getCurrentRadio() != null) {
            speakerModel = "Speaker Model: " + NetRemoteManager.getInstance().getCurrentRadio().getModelName() + "\n";
        }
        int version = android.os.Build.VERSION.SDK_INT ;
        String versionRelease ="SDK=" + version + ", " + android.os.Build.VERSION.RELEASE + (type == FeedbackType.Logs ? "\n" : "%0D%0A");
        String undokVersion = "Undok version: " + getAppVersion(context) + (type == FeedbackType.Logs ? "\n" : "%0D%0A");
        String swVersion = "Software Version:" + softwareVersion + (type == FeedbackType.Logs ? "\n" : "%0D%0A");

        sb.append(deviceModel + speakerModel + versionRelease + undokVersion + swVersion);

        return sb.toString();
    }

    public static String getAppVersion(Context context) {
        String version = "";

        PackageInfo pInfo;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            version = pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return version;
    }

    public static int dpToPx(int dp, Activity activity) {
        float value =0;
        if (activity != null) {
            DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
            float density = displayMetrics.density;
            value = dp * density;
        }

        return Math.round(value);
    }

    public static boolean isLightTheme() {
        int themeResId = ThemeUtil.getThemeResId();
        return  themeResId == R.style.UndokThemeMain;
    }
}
