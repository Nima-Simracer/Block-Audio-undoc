package com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.UnifiedFormListItem;

import java.util.List;

public abstract class FormRetrieverRunnable implements Runnable {

    public interface INavFormRetrieverListener {
        void onNavFormRetrieved(List<UnifiedFormListItem> listItems);
    }

    protected Radio mRadio;
    protected INavFormRetrieverListener mListener;

    public FormRetrieverRunnable(Radio radio, INavFormRetrieverListener listener) {
        mRadio = radio;
        mListener = listener;
    }

    protected void sendNavListToListener(List<UnifiedFormListItem> listItems) {
        if (mListener != null) {
            mListener.onNavFormRetrieved(listItems);
        }
    }

    protected void dispose() {
        mRadio = null;
        mListener = null;
    }
}
