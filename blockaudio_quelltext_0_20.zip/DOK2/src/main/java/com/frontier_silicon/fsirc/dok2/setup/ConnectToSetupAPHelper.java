package com.frontier_silicon.fsirc.dok2.setup;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.IConnectToSetupAPListener;
import com.frontier_silicon.loggerlib.LogLevel;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.setup.AccessPointConfig.AccessPointModel;

import java.util.Timer;
import java.util.TimerTask;

public class ConnectToSetupAPHelper {

    private static ConnectToSetupAPHelper mInstance;

    public boolean mManuallyConnectingToRadio = false;

    private volatile boolean mWiFiListenersAreRegistered = false;
    private SetupManager mSetupManager = null;
    private Activity mActivity = null;
    private WifiConnectedReceiver mWiFiConnectedReceiver;
    private IConnectToSetupAPListener mConnectToAPListener = null;
    private Timer mConnectToAPTimer = null;
    private Timer mCheckConnectionToAPTimer = null;

    private ConnectToSetupAPHelper() {
        mSetupManager = SetupManager.getInstance();
        mWiFiConnectedReceiver = new WifiConnectedReceiver();
    }

    public static ConnectToSetupAPHelper getInstance() {
        if (mInstance == null)
            mInstance = new ConnectToSetupAPHelper();

        return mInstance;
    }

    public void attachActivity(Activity activity, IConnectToSetupAPListener connectToHeadlessAP) {
        mActivity = activity;
        mConnectToAPListener = connectToHeadlessAP;

        registerNetworkListeners();
    }

    public void detachActivity() {
        mActivity = null;
        mConnectToAPListener = null;
    }

    private void registerNetworkListeners() {
        if (!mWiFiListenersAreRegistered) {
            if (mActivity.registerReceiver(mWiFiConnectedReceiver, new IntentFilter(WifiManager.NETWORK_STATE_CHANGED_ACTION)) != null) {
                mWiFiListenersAreRegistered = true;
            }
        }
    }

    public void unregisterNetworkListeners() {
        if (mWiFiListenersAreRegistered) {
            try {
                mActivity.unregisterReceiver(mWiFiConnectedReceiver);
            } catch (Exception ignored) { }
            mWiFiListenersAreRegistered = false;
        }
    }

    public void tryConnectToAP(AccessPointModel apModel) {
        if (apModel == null || apModel.getIsGroupHeader())
            return;

        ScanResult scanResult = apModel.getScanResult();

        if (!checkIfShouldTryConnectToAP(scanResult))
            return;

        mSetupManager.connectToAccessPoint(scanResult);
        FsLogger.log("Connecting to AP - " + scanResult.SSID);

        startConnectToAPTimer(scanResult);

        refreshShownListOfAP();
    }

    private class ConnectToAPFailedTimerTask extends TimerTask {
        private ScanResult scanResult;

        private ConnectToAPFailedTimerTask(ScanResult scanResult) {
            this.scanResult = scanResult;
        }

        @Override
        public void run() {
            cleanConnectToAPTimer();

            mSetupManager.reconnectToInitialWiFiNetwork();

            FsLogger.log("ConnectToAPFailedTimerTask -> connectToAPFailed: " + this.scanResult.SSID);
            connectToAPFailed();
        }
    }

    private void startConnectToAPTimer(ScanResult scanResult) {

        cleanConnectToAPTimer();
        mConnectToAPTimer = new Timer();
        long delay = 1000 * FsComponentsConfig.SECONDS_TO_WAIT_UNTIL_CURRENTLY_CONNECTING_AP_SHOULD_BE_DISMISSED;

        mConnectToAPTimer.schedule(new ConnectToAPFailedTimerTask(scanResult), delay);
    }

    private void cleanConnectToAPTimer() {
        if (mConnectToAPTimer != null) {
            mConnectToAPTimer.cancel();
            mConnectToAPTimer.purge();
            mConnectToAPTimer = null;
        }

        FsLogger.log("cleanConnectToAPTimer()");
    }

    private boolean checkIfShouldTryConnectToAP(ScanResult scanResult) {
        if (!mSetupManager.canConnectToAP(scanResult))
            return false;

        //ensuring that the selected AP isn't encrypted
        if (!AccessPointUtil.isOpenAP(scanResult)) {
            CharSequence text = SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.cannot_connect_to_encrypted_ap, false);
            GuiUtils.showToast(text, mActivity.getApplicationContext());
            return false;
        }

        return true;
    }

    private class WifiConnectedReceiver extends BroadcastReceiver {
        public void onReceive(Context c, Intent intent) {
            FsLogger.log("Received network state changed");

            final String action = intent.getAction();

            if (action == null) {
                return;
            }

            if (action.equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {
                NetworkInfo networkInfo = intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
                if (networkInfo == null) {
                    FsLogger.log("Received network NETWORK_STATE_CHANGED_ACTION but networkInfo is null");
                    return;
                }

                if (networkInfo.isConnected() && (networkInfo.getType() == ConnectivityManager.TYPE_WIFI)) {
                    // state: CONNECTED/CONNECTED

                    FsLogger.log("Received network NETWORK_STATE_CHANGED_ACTION true : " + networkInfo.toString());
                    //trying to increase the chances of successful connection from first attempt
                    AccessPointUtil.bindWifiNetworkToProcess();

                    // Trying to prevent the case when the AP connection is not fully made.
                    // We suspect that the NetRemote connection may not succeed or be greatly delayed,
                    // because of this.
                    bookCheckConnectionToAP();

                } else //noinspection StatementWithEmptyBody
                    if (!networkInfo.isConnectedOrConnecting()) {
                    // state: DISCONNECTED/DISCONNECTED
                    FsLogger.log("Received network NETWORK_STATE_CHANGED_ACTION false : " + networkInfo.toString());
                } else {
                    // state: CONNECTING/CONNECTING
                    // CONNECTING/OBTAINING_IPADDR
                }
            }
        }
    }

    private class CheckConnectionToAPTask extends TimerTask {

        @Override
        public void run() {
            cleanCheckConnectionToApTimer();

            if (mActivity == null) {
                return;
            }

            mActivity.runOnUiThread(() -> {
                if (mSetupManager.isDisposed()) {
                    return;
                }

                if (mSetupManager.isConnectedToAnyAP()) {
                    onConnectedWiFi(true);
                } else {
                    onDisconnectedWiFi();
                }
            });
        }
    }

    private void bookCheckConnectionToAP() {
        cleanCheckConnectionToApTimer();

        mCheckConnectionToAPTimer = new Timer();
        mCheckConnectionToAPTimer.schedule(new CheckConnectionToAPTask(), 2000);
    }

    private synchronized void cleanCheckConnectionToApTimer() {
        if (mCheckConnectionToAPTimer != null) {
            mCheckConnectionToAPTimer.cancel();
            mCheckConnectionToAPTimer.purge();
            mCheckConnectionToAPTimer = null;
        }
    }

    private void onConnectedWiFi(boolean retry) {
        cleanConnectToAPTimer();
        AccessPointUtil.bindWifiNetworkToProcess();

        String currentSSID = AccessPointUtil.getSSIDOfCurrentConnection();
        FsLogger.log("Connected to Wi-Fi " + currentSSID);

        if (isTryingToConnectToAnAPChosenByUser(currentSSID)) {
            mSetupManager.connectToCurrentRadio();
        } else if (isConnectedToHeadlessAPButDifferentRadioConnection(currentSSID)) {
            mSetupManager.closeRadioConnection();
            mSetupManager.connectToCurrentRadio();
        } else if (!mSetupManager.isConnectedToHeadlessAP()) {

            if (mSetupManager.isConnectingToHeadlessAP()) {
                if (retry) {
                    // wait 2 seconds and retry
                    FsLogger.log("onConnectedWiFi() -> retry checkup for: " + currentSSID);

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        // ignore
                    }

                    onConnectedWiFi(false);
                } else {
                    FsLogger.log("onConnectedWiFi() -> connectedToAPFailed: " + currentSSID);
                    connectToAPFailed();
                }
            }

            mSetupManager.closeRadioConnection();
        }
    }

    private void onDisconnectedWiFi() {
        FsLogger.log("onDisconnectedWiFi() -> wifi disconnected: ");
        AccessPointUtil.unbindWiFiNetworkToProcess();

        mSetupManager.closeRadioConnection();
    }

    private boolean isTryingToConnectToAnAPChosenByUser(String ssid) {
        return mSetupManager.isConnectingToHeadlessAP() && ssid.equals(mSetupManager.getSSIDOfConnectingAP());
    }

    private boolean isConnectedToHeadlessAPButDifferentRadioConnection(String ssid) {
        return mSetupManager.isConnectedToHeadlessAP() && mSetupManager.isConnectedToAnotherRadioConnection(ssid);
    }

    public void checkConnectionToAPAndRadio() {
        if (!mSetupManager.isConnectedToHeadlessAP()) {
            return;
        }

        if (mSetupManager.isConnectedToRadio())
            return;

        if (mSetupManager.isConnectingToRadio())
            return;

        mManuallyConnectingToRadio = true;
        mSetupManager.connectToCurrentRadio();

        refreshShownListOfAP();
    }

    private void refreshShownListOfAP() {
        if (mActivity == null)
            return;

        mActivity.runOnUiThread(() -> {
            if (mConnectToAPListener != null)
                mConnectToAPListener.refreshList();
        });
    }

    private void connectToAPFailed() {
        if (mActivity == null)
            return;

        mActivity.runOnUiThread(() -> {
            if (mConnectToAPListener != null)
                mConnectToAPListener.onConnectToApFailed();
        });
    }
}
