package com.frontier_silicon.fsirc.dok2.presets;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.databinding.Observable;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayAddPresetStatus;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.LayoutDecider;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingManager;
import com.frontier_silicon.fsirc.dok2.presets.bottomFragment.IBottomFragment;
import com.frontier_silicon.fsirc.dok2.presets.bottomFragment.PresetBottomFragment;
import com.frontier_silicon.fsirc.dok2.presets.widget.PresetsRecyclerViewAdapter;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;

import javax.inject.Inject;

public class PresetsFragment extends BaseFragment implements IPresetsListener, IPresetsControlListener, IPageSwitchListener, IBottomFragment {

    public static final String FRAGMENT_TAG = "TAG_PRESETS_FRAGMENT";
    public static final String EDIT_PRESET_TAG = "EDIT_PRESET_DIALOG";

    private RecyclerView mRecyclerView;
    private ArrayList<PresetItemModel> mPresetItemsList;

    private TextView mPresetsNotSupportedText;
    private TextView mTextPresetsStandByMessage;
    private PresetsUtil mPresetsUtil;

    private boolean mIsPresetNavigationEnabled;
    private boolean mUpdateLayoutFirstTime = true;

    private ProgressBar mEmptyProgressBar;
    private INodeNotificationCallback mNotifCallback;
    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;

    private boolean isNodePlayAddPresetStatusExists;

    @Inject
    public PresetsRecyclerViewAdapter mAdapter;
    @Inject
    public ItemTouchHelper mItemTouchHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.presets_fragment, container, false);

        return rootView;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initPresetsUtil();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        inject();
        setupControls();

        if (mIsRestoreInstance) {
            mIsRestoreInstance = false;
            onFragmentActivated();
        }
    }

    private void inject() {
        ((MainApplication) getActivity().getApplication()).initPresetsComponent(this).inject(this);
    }

    private void fragmentInitialize() {

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        mUpdateLayoutFirstTime = true;

        if (radio != null) {
            RadioNodeUtil.fsNodeExists(radio, NodePlayAddPresetStatus.class, new RadioNodeUtil.NodeExists() {

                @Override
                public void onNode(boolean exists) {
                    FsLogger.log("node exists: " + exists);
                    isNodePlayAddPresetStatusExists = exists;

                    if (isNodePlayAddPresetStatusExists) {
                        registerNotifCallbacks();
                        registerRadioNotifications();
                    }

                    addPresetSupported();
                }
            });
        }
    }

    private void initPresetsUtil() {
        if (mPresetsUtil == null) {
            mPresetsUtil = new PresetsUtil();
            mPresetsUtil.setListener(this);
        }
    }

    public void onResume() {
        super.onResume();

        fragmentInitialize();

        if (isNodePlayAddPresetStatusExists) {
            registerRadioNotifications();
        }
    }

    public void onPause() {
        super.onPause();

        fragmentUninitialize();

        unregisterRadioNotifications();
    }

    private void showPresetEditionFeatureDialog() {
        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(getActivity());
        builder.setTitle(R.string.preset_reorder_tutorial_title);
        builder.setMessage(R.string.preset_reorder_tutorial_message);

        builder.setPositiveButton(android.R.string.ok, (dialog, which) -> {
            dialog.dismiss();
        });

        AlertDialog dialog = builder.create();
        DialogsHolder.addDialogToCollection("PRESET_REORDER_DIALOG", dialog);

        dialog.show();
        UndokPreferences.getInstance().setPresetReorderFeatureDialogShown(true);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mPresetsUtil != null) {
            mPresetsUtil.removeListener();
        }

        DialogsHolder.dismissAllRegisteredDialogs();
    }

    private void setupControls() {
        mPresetItemsList = new ArrayList<>();

        mRecyclerView = getView().findViewById(R.id.presetsRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setAdapter(mAdapter);

//        if (mItemTouchHelper != null && SpeakerDataManager.getInstance().getSpeakerDataModel().isPresetEditionSupported.get()) {
//            mItemTouchHelper.attachToRecyclerView(mRecyclerView);
//        }

        mEmptyProgressBar = getActivity().findViewById(R.id.emptyProgressBar);

        mPresetsNotSupportedText = getView().findViewById(R.id.textPresetsNotSupported);
        mTextPresetsStandByMessage = getView().findViewById(R.id.textPresetsStandByMessage);
    }

    private void registerRadioNotifications() {
        unregisterRadioNotifications();

        if (mPropertyChangedCallback == null) {
            mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable observable, int i) {
                    if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode ||
                            observable == NowPlayingManager.getInstance().getNowPlayingDataModel().playCaps) {
                        if (mIsFragmentActive && mPresetItemsList != null) {
                            addPresetSupported();
                        }
                    } else if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby) {
                        onPowerChange();
                    }
                }
            };
        }
        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.addOnPropertyChangedCallback(mPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby.addOnPropertyChangedCallback(mPropertyChangedCallback);
        NowPlayingManager.getInstance().getNowPlayingDataModel().playCaps.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void unregisterRadioNotifications() {
        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        NowPlayingManager.getInstance().getNowPlayingDataModel().playCaps.removeOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    @Override
    public void onPresetsUpdate(ArrayList<PresetItemModel> presetsList) {
        if (presetsList != null && mAdapter != null) {
            mPresetItemsList.clear();
            mPresetItemsList.addAll(presetsList);
            mAdapter.swapItems(mPresetItemsList);
            showPresetList();

//            if (SpeakerDataManager.getInstance().getSpeakerDataModel().isPresetEditionSupported.get() && !UndokPreferences.getInstance().getPresetReorderDialogWasShown()) {
//                DelayedPostsManager.getInstance().postDelayed(() -> showPresetEditionFeatureDialog(), 1000);
//            }
        }
    }

    @Override
    public void onPresetsSupportedCapsUpdate(boolean navigatePresetsSupported, boolean addPresetsSupported) {
        if (mIsPresetNavigationEnabled != navigatePresetsSupported || mUpdateLayoutFirstTime) {
            mIsPresetNavigationEnabled = navigatePresetsSupported;
            mUpdateLayoutFirstTime = false;
            updatePresetsLayout();
        }
    }

    private void updatePresetsLayout() {

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio != null && SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby.get()) {
            if (radio.isVenice()) {
                if (LayoutDecider.isTabletAndLandscape(getActivity())) {
                    showPresetsStandbyForVenice();
                } else {
                    Activity activity = getActivity();
                    if (activity instanceof PresetsActivity) {
                        activity.onBackPressed();
                    }
                }
            } else {
                showPresetsStandbyForAllOthers();
            }
        } else if (mIsPresetNavigationEnabled) {
            showPresetsLoading();
            mPresetsUtil.updatePresetsList();
        } else {
            showPresetsNotSupported();
        }
    }

    private void showPresetsLoading() {
        mEmptyProgressBar.setVisibility(View.VISIBLE);
        mPresetsNotSupportedText.setVisibility(View.GONE);
        mRecyclerView.setVisibility(View.GONE);
        mTextPresetsStandByMessage.setVisibility(View.GONE);
    }

    private void showPresetList() {
        mEmptyProgressBar.setVisibility(View.GONE);
        mPresetsNotSupportedText.setVisibility(View.GONE);
        mRecyclerView.setVisibility(View.VISIBLE);
        mTextPresetsStandByMessage.setVisibility(View.GONE);
    }

    private void showPresetsStandbyForVenice() {
        mEmptyProgressBar.setVisibility(View.GONE);
        mPresetsNotSupportedText.setVisibility(View.GONE);
        mRecyclerView.setVisibility(View.GONE);
        mTextPresetsStandByMessage.setVisibility(View.VISIBLE);
    }

    private void showPresetsStandbyForAllOthers() {
        mEmptyProgressBar.setVisibility(View.GONE);
        mPresetsNotSupportedText.setVisibility(View.GONE);
        mRecyclerView.setVisibility(View.VISIBLE);
        mTextPresetsStandByMessage.setVisibility(View.GONE);
    }

    private void showPresetsNotSupported() {
        mEmptyProgressBar.setVisibility(View.GONE);
        mPresetsNotSupportedText.setVisibility(View.VISIBLE);
        mRecyclerView.setVisibility(View.GONE);
    }

    @Override
    public void onPresetAddSelected(PresetItemModel presetItem) {
        addPResetAndRefreshTheList(presetItem);
    }

    private void addPResetAndRefreshTheList(PresetItemModel presetItem) {
        mPresetsUtil.addPreset(presetItem.mKeyId);

        // manual refresh presets
        addPresetSupported();
    }

    @Override
    public void onPresetDeleteRequested(final PresetItemModel presetItem) {

        mPresetsUtil.deletePreset(presetItem, new ISetNodeCallback() {
            @Override
            public void setNodeSuccess(NodeInfo node) {
                updatePresetsLayout();
            }

            @Override
            public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                updatePresetsLayout();
            }
        });
    }

    @Override
    public void onPresetEditedRequested(PresetItemModel presetItem) {
        showBottomFragment(presetItem);
    }

    @Override
    public void onPresetSelected(PresetItemModel presetItemModel) {
        selectPreset(presetItemModel);
    }

    @Override
    public void onPresetReordered(ArrayList<PresetItemModel> presetList, int fromPosition, int toPosition) {
        mPresetsUtil.reorderPresets(presetList, fromPosition, toPosition, new ISetNodeCallback() {
            @Override
            public void setNodeSuccess(NodeInfo node) {
                Toast.makeText(getActivity(), getString(R.string.preset_reorder_successful), Toast.LENGTH_LONG).show();
                updatePresetsLayout();
            }

            @Override
            public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                Toast.makeText(getActivity(), getString(R.string.preset_reorder_unsuccessful), Toast.LENGTH_LONG).show();

            }
        });
    }

    @Override
    public void onSwap(PresetItemModel source, PresetItemModel destination) {
        mPresetsUtil.swapPresets(source, destination);
        updatePresetsLayout();
    }

    private void showPresetEditDialog(PresetItemModel presetItem) {
        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.edit_preset_layout, null);
        EditText nameEditText = alertLayout.findViewById(R.id.preset_name_edit_text);
        EditText urlEditText = alertLayout.findViewById(R.id.url_edit_text);
        TextView presetNumber = alertLayout.findViewById(R.id.preset_index);

        presetNumber.setText(getString(R.string.preset_number, String.valueOf(presetItem.mKeyId + 1)));
        nameEditText.setText(presetItem.mName);
        urlEditText.setText(presetItem.mPresetUrl);

        alertLayout.findViewById(R.id.save).setOnClickListener(v -> {
            String name = nameEditText.getText().toString();
            String url = urlEditText.getText().toString();

            saveEditedPreset(String.valueOf(presetItem.mKeyId), name, presetItem.mType, url);
        });

        alertLayout.findViewById(R.id.cancel).setOnClickListener(v -> {
            DialogsHolder.dismissDialog(EDIT_PRESET_TAG);
        });

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(getActivity());
        builder.setView(alertLayout);

        AlertDialog dialog = builder.create();
        DialogsHolder.addDialogToCollection(EDIT_PRESET_TAG, dialog);

        dialog.show();
    }

    private void saveEditedPreset(String key, String name, String type, String url) {

        mPresetsUtil.saveEditedPreset(key, name, type, url, new ISetNodeCallback() {
            @Override
            public void setNodeSuccess(NodeInfo node) {

                if (DokUiUtils.isDestroyed(getActivity())) {
                    return;
                }

                Toast.makeText(getActivity(), getString(R.string.preset_updated_successfully), Toast.LENGTH_LONG).show();
                DialogsHolder.dismissDialog(EDIT_PRESET_TAG);

                // manual refresh presets
                updatePresetsLayout();
            }

            @Override
            public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                if (DokUiUtils.isDestroyed(getActivity())) {
                    return;
                }

                Toast.makeText(getActivity(), R.string.preset_not_updated_successfully, Toast.LENGTH_LONG).show();
                DialogsHolder.dismissDialog(EDIT_PRESET_TAG);
            }
        });
    }

    private void selectPreset(PresetItemModel presetItem) {
        mPresetsUtil.selectPreset(presetItem);

        switchToNowPlayingFragment();
    }

    private void switchToNowPlayingFragment() {
        if (LayoutDecider.isTabletAndLandscape(getActivity()))
            return;

        // go back (only possible fragment is now playing)
        try {
            getActivity().onBackPressed();
        } catch (Exception e) {
        }
    }

    @Override
    public void onFragmentActivated() {
        if (!super.onFragmentActivatedBase())
            return;

        fragmentInitialize();
    }

    @Override
    public void onFragmentDeactivated() {
        if (!super.onFragmentDeactivatedBase())
            return;

        fragmentUninitialize();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ((MainApplication) getActivity().getApplication()).deinitPresetsComponent();
    }

    private void fragmentUninitialize() {
        unregisterNotifCallbacks();
    }

    public void registerNotifCallbacks() {
        unregisterNotifCallbacks();

        if (NetRemoteManager.getInstance().checkConnection()) {
            mNotifCallback = new INodeNotificationCallback() {
                @Override
                public void onNodeUpdated(NodeInfo node) {
                    if (node instanceof NodePlayAddPresetStatus) {
                        onPresetAddStatus((NodePlayAddPresetStatus) node);
                    }
                }
            };

            NetRemoteManager.getInstance().getCurrentRadio().addNotificationListener(mNotifCallback);
        }
    }

    protected void unregisterNotifCallbacks() {
        if (NetRemoteManager.getInstance().checkConnection()) {
            if (mNotifCallback != null) {
                NetRemoteManager.getInstance().getCurrentRadio().removeNotificationListener(mNotifCallback);
                mNotifCallback = null;
            }
        }
    }

    private void onPowerChange() {
        NetRemote.getMainThreadExecutor().execute(() -> updatePresetsLayout());
    }

    private void addPresetSupported() {
        NetRemote.getMainThreadExecutor().execute(() -> {
            boolean isPresetNavigationSupported = SpeakerDataManager.getInstance().isPresetNavigationSupported();
            mPresetsUtil.addPresetSupported(isPresetNavigationSupported);
        });
    }

    private void onPresetAddStatus(final NodePlayAddPresetStatus node) {
        final boolean presetStoredOk = (node.getValueEnum() == NodePlayAddPresetStatus.Ord.PRESET_STORRED);

        NetRemote.getMainThreadExecutor().execute(() -> {
            Activity parentActivity = getActivity();
            if (DokUiUtils.isDestroyed(parentActivity)) {
                return;
            }

            if (presetStoredOk) {
                Toast.makeText(parentActivity, R.string.preset_added, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(parentActivity, R.string.preset_not_added, Toast.LENGTH_SHORT).show();
            }

            updatePresetsLayout();
        });
    }

    public void showBottomFragment(PresetItemModel presetItem) {
        PresetBottomFragment bottomFragment = new PresetBottomFragment(this, presetItem);
        if (getActivity() != null && !getActivity().isFinishing()) {
            bottomFragment.show(getActivity().getSupportFragmentManager(), "PRESETS_BOTTOM_FRAGMENT");
        }
    }

    //BottomFragment callbacks
    @Override
    public void onReplace(PresetItemModel presetItemModel) {
        addPResetAndRefreshTheList(presetItemModel);
    }

    @Override
    public void onEdit(PresetItemModel presetItemModel) {
        showPresetEditDialog(presetItemModel);
    }

    @Override
    public void onDelete(PresetItemModel presetItemModel) {
        saveEditedPreset(String.valueOf(presetItemModel.mKeyId), "", presetItemModel.mType, "");
    }

    @Override
    public void onSwap(@NonNull PresetItemModel presetItem) {
        mAdapter.swapPresets(presetItem);
    }
}

