package com.frontier_silicon.fsirc.dok2.notifications;

import android.app.Notification;
import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.os.Build;
import androidx.core.app.NotificationCompat;

import android.util.Log;
import android.view.View;
import android.widget.RemoteViews;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.loggerlib.FsLogger;

/**
 * Created by mnisipeanu on 15/05/2017.
 */

public class IRNotification extends NotificationBase{
    public final static int NOTIFICATION_ID = 27910;
    private static final String TAG = "IRNotification ";
    private final static int DEFAULT_ARTWORK = R.drawable.ic_internetradiodisplay;

    private static IRNotification instance;

    private PendingIntent mStopIntent = null;
    private PendingIntent mPodcastPlayIntent = null;
    private PendingIntent mExitIntent = null;

    private Bitmap playBtn;
    private Bitmap stopBtn;
    private Bitmap pauseBtn; // for podcast only

    private Bitmap exitBtn;
    private long mLastUpdate;

    public static IRNotification newInstance() {
        if (instance == null) {
            instance = new IRNotification();
        }

        return instance;
    }

    public static IRNotification getInstance() {
        return instance;
    }

    public IRNotification(){
        //super(42/*int imgSmallSize*/, 96/*int imgBigSize*/);
        super(NotificationMode.IR, NOTIFICATION_ID, 32/*int imgSmallSize*/, 42/*int imgBigSize*/);
        this.defaultArtWork = DEFAULT_ARTWORK;
    }

    /**
     * create a new notification and update return it
     * @return
     */
    public Notification create() {
        if (notiBuilder == null) {
            notiBuilder = new NotificationCompat.Builder(mContext, NOTIFICATION_CHANNEL_ID);
            notiBuilder
                    .setSmallIcon(R.drawable.ic_notificationicon)
                    .setDeleteIntent(mSwipeDismissIntent)
                    .setCategory(NotificationCompat.CATEGORY_SERVICE)
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setShowWhen(false)
                    .setSound(null);

            notiBuilder.setContentIntent(getOpenAppIntent());

            if (Build.VERSION.SDK_INT > 23) {
                notiBuilder.setStyle(new NotificationCompat.DecoratedCustomViewStyle());

            } else {
                notiBuilder.setStyle(new androidx.core.app.NotificationCompat.Style() {
                    @Override
                    public void setBuilder(androidx.core.app.NotificationCompat.Builder builder) {
                        super.setBuilder(builder);
                    }
                });
            }

            notiBuilder.setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            notiBuilder.setColor(this.colorTintRes);

            contentCompactView = new RemoteViews(mContext.getPackageName(), R.layout.notification_ir_custom_media_compact);

            notiBuilder.setCustomBigContentView(contentCompactView);
            notiBuilder.setCustomContentView(contentCompactView);

            // other setups
            playBtn = tintResource(R.drawable.ic_play, this.colorTintRes);
            stopBtn = tintResource(R.drawable.ic_stop, this.colorTintRes);
            pauseBtn = tintResource(R.drawable.ic_pause, this.colorTintRes);
            exitBtn = tintResource(R.drawable.ic_close_notification, this.colorTintRes);

            contentCompactView.setImageViewBitmap(R.id.play_remove, exitBtn);
            contentCompactView.setOnClickPendingIntent(R.id.play_remove, mExitIntent);
        }

        this.update();

        FsLogger.log(TAG + "created notification: " + NOTIFICATION_ID);
        return this.notification;
    }

    @Override
    public NotificationBase setRadio(Radio radio){
        super.setRadio(radio);

        if (radio == null) {
            return this;
        }

        mPodcastPlayIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.PLAY, mode);
        mStopIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.STOP, mode);

        if (radio.isMinuet()) {
            mPlayIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.PLAY, mode);
        } else {
            mPlayIntent = mStopIntent;
        }

        mExitIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.DISMISS_NOTIFICATION, mode);;
        return this;
    }

    @Override
    public NotificationBase remove() {
        super.remove();

        instance = null;

        return this;
    }

    /**
     * update a notification, after update you have to invoke show to update screen with new notification
     * @return
     */
    public IRNotification update() {
        if (notiBuilder == null || contentCompactView == null) {
            FsLogger.log(TAG + "skip notification update builder is null, " + mText + " - " + mTitle);
            return null;
        }


        if (mTitle.equals("") && mText.equals("")) {
            FsLogger.log(TAG + "BUFFERING: " + mText + " - " + mTitle);
            mTitle = mContext.getString(R.string.buffering);

            visibleProgress = true;
            contentCompactView.setProgressBar(R.id.progressBar, 100, 100, true);
            contentCompactView.setViewVisibility(R.id.progressBar, View.VISIBLE);
            contentCompactView.setViewVisibility(R.id.text, View.GONE);
        } else if (visibleProgress) {
            visibleProgress = false;

            contentCompactView.setViewVisibility(R.id.progressBar, View.GONE);
            contentCompactView.setViewVisibility(R.id.text, View.VISIBLE);
        }

        // update compact notification view
        contentCompactView.setImageViewBitmap(R.id.imageView, artworkSmall);

        contentCompactView.setTextViewText(R.id.title, mTitle);
        contentCompactView.setTextViewText(R.id.text, mText);

        if (isPlaying()) {

            // update in custom view

            if (isPauseAvailable()) {
                //FsLogger.log(TAG + "IS Podcast");

                contentCompactView.setImageViewBitmap(R.id.play_pause, pauseBtn);
                contentCompactView.setOnClickPendingIntent(R.id.play_pause, mPauseIntent);
            } else {
                //FsLogger.log(TAG + "IS Radio");

                contentCompactView.setImageViewBitmap(R.id.play_pause, stopBtn);
                contentCompactView.setOnClickPendingIntent(R.id.play_pause, mStopIntent);
            }

        } else {

            // update in custom view

            contentCompactView.setImageViewBitmap(R.id.play_pause, playBtn);
            if (isPauseAvailable()) {
                //FsLogger.log(TAG + "IS Podcast");
                contentCompactView.setOnClickPendingIntent(R.id.play_pause, mPodcastPlayIntent);
            } else {
                //FsLogger.log(TAG + "IS Radio");
                contentCompactView.setOnClickPendingIntent(R.id.play_pause, mPlayIntent);
            }

        }

        notification = notiBuilder.build();
        notification.flags = Notification.FLAG_FOREGROUND_SERVICE;
        mLastUpdate = System.currentTimeMillis();
        return this;
    }

    public void updateArtwork(Bitmap bitmap) {
        FsLogger.log(TAG + "try to update artwork to notification ");

        if ((contentCompactView != null) && (notiBuilder != null)) {

            Bitmap tmp = getAlbumArtwork(bitmap);

            tmp = scaleDownBitmap(tmp, sizeSmallImage);

            if (!artworkSmall.sameAs(tmp)) {
                try {
                    artworkSmall = tmp;
                    contentCompactView.setImageViewBitmap(R.id.imageView, artworkSmall);

                    notificationManager.notify(notificationId, notiBuilder.build());
                } catch (RuntimeException e) {
                    FsLogger.log(TAG + "artwork not updated");
                }
            }
        } else {
            FsLogger.log(TAG + "contentView: " + contentView + " - notiBuilder: " + notiBuilder);
        }
    }

}
