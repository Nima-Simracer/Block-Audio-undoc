package com.frontier_silicon.fsirc.dok2.sources;

import com.frontier_silicon.NetRemoteLib.Node.BaseCastTos;
import com.frontier_silicon.NetRemoteLib.Node.BaseSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeCastTos;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysMode;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SourcesRadioUtil {
	
	static public final int INVALID_MODE_KEY = -1;

	static public void setModeAsync(Radio radio, long key, final RadioNodeUtil.INodeSetResultListener listener) {

		if (radio != null) {
			NodeSysMode modeNode = new NodeSysMode(key);
			RadioNodeUtil.setNodeToRadioAsync(radio, modeNode, new RadioNodeUtil.INodeSetResultListener() {
				@Override
				public void onNodeSetResult(boolean success) {
					if (listener != null) {
						listener.onNodeSetResult(success);
					}
				}
			});
		}
	}

    public static void getAvailableModes(final IAllSourcesRetrieverListener listener) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                MultiroomDeviceModel multiroomDeviceModel = MultiroomGroupManager.getInstance().getCurrentSelectedDevice();
                if (multiroomDeviceModel != null && multiroomDeviceModel.mRadio != null) {
                    SourcesRadioUtil sourcesRadioUtil = new SourcesRadioUtil();

                    if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {
                        sourcesRadioUtil.getAvailableModesForCurrentGroup(multiroomDeviceModel, modesList ->
                                generateSourcesMap(modesList, listener));
                    } else {
                        sourcesRadioUtil.getModes(multiroomDeviceModel.mRadio, modesList ->
                                generateSourcesMap(modesList, listener), false);
                    }
                }
            }

            private void generateSourcesMap(List<SourceItemModel> modesList, IAllSourcesRetrieverListener listener) {
                // We need to know whether this radio can support cast before moving on, so we can decide
                // whether to show the cast apps as valid sources
                NodeCastTos.Ord ord = SpeakerDataManager.getInstance().getSpeakerDataModel().castTosStatus.get();
                boolean isCastEnabled = ord != null && ord == BaseCastTos.Ord.ACTIVE;

                final List<SourceItemModel> groupedModesList = SourcesGroupedUtil.getGroupedModesList(
                        modesList, MainApplication.getContext(), isCastEnabled);

                List<SourceItemModel> newGroupList = new ArrayList<>();
                Map<SourceItemModel, List<SourceItemModel>> newSourcesMap = new HashMap<>();

                SourceItemModel currentSourceItem = null;
                for (SourceItemModel item : groupedModesList) {

                    if (item.mIsCurrentModeSelected) {
                        currentSourceItem = item;
                    }

                    if (item.mKey == SourcesRadioUtil.INVALID_MODE_KEY || !SourcesRadioUtil.isModeWithOwnInput(item.mModeId)) {
                        newSourcesMap.put(item, new ArrayList<SourceItemModel>());
                        newGroupList.add(item);
                    } else {
                        boolean found = false;
                        for (SourceItemModel keyMode : newSourcesMap.keySet()) {
                            if (keyMode.mModeId.equals(item.mModeId) && keyMode.mIsStreamable == item.mIsStreamable) {

                                if (keyMode.mRadio != item.mRadio || !keyMode.mName.equals(item.mName)) {
                                    if (!newSourcesMap.get(keyMode).contains(keyMode)) {
                                        newSourcesMap.get(keyMode).add(keyMode);
                                    }
                                }

                                newSourcesMap.get(keyMode).add(item);

                                //UNDC-1213: Missing check mark on header
                                if (!keyMode.mIsCurrentModeSelected && item.mIsCurrentModeSelected) {
                                    List<SourceItemModel> listOfSubModeItems = newSourcesMap.get(keyMode);
                                    newSourcesMap.remove(keyMode);

                                    newSourcesMap.remove(keyMode);
                                    int positionOfModeItemToBeRemoved = newGroupList.indexOf(keyMode);
                                    newGroupList.remove(keyMode);

                                    newSourcesMap.put(item, listOfSubModeItems);
                                    newGroupList.add(positionOfModeItemToBeRemoved, item);
                                }

                                found = true;
                                break;
                            }
                        }

                        if (!found) {
                            newSourcesMap.put(item, new ArrayList<SourceItemModel>());
                            newGroupList.add(item);
                        }
                    }
                }

                listener.onAllSourcesRetrieved(newGroupList, newSourcesMap, currentSourceItem);
            }

        }, "GetSourcesForGroupThread");

        t.start();
    }

    public static void getStreamableModes(final IAvailableSourcesListener listener, final Radio radio) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                SourcesRadioUtil sourcesRadioUtil = new SourcesRadioUtil();
                sourcesRadioUtil.getModes(radio, listener, true);
            }
        }, "GetStreamableModesThread");

        thread.start();
    }

    private void getAvailableModesForCurrentGroup(MultiroomDeviceModel multiroomDeviceModel, IAvailableSourcesListener listener) {
        List<SourceItemModel> allModes = new ArrayList<>();

        getAllModes(multiroomDeviceModel, allModes);

        allModes = cleanupAllModes(allModes);

        // sort radios alphabetically
        Collections.sort(allModes, new Comparator<SourceItemModel>() {
            @Override
            public int compare(SourceItemModel leftItem, SourceItemModel rightItem) {
                int compareValue = (int) (leftItem.mKey - rightItem.mKey);
                if (compareValue == 0) {
                    if (leftItem.mRadio == null) {
                        compareValue = -1;
                    } else if (rightItem.mRadio == null) {
                        compareValue = 1;
                    } else {
                        compareValue = DokUiUtils.getFriendlyNameOrStereoSystemName(leftItem.mRadio)
                                .compareTo(DokUiUtils.getFriendlyNameOrStereoSystemName(rightItem.mRadio));
                    }
                }
                return compareValue;
            }
        });

        if (listener != null) {
            listener.onSourcesUpdate(allModes);
        }
    }

    private void getAllModes(MultiroomDeviceModel multiroomDeviceModel, final List<SourceItemModel> allModes) {
        MultiroomGroupManager multiroomGroupManager = MultiroomGroupManager.getInstance();
        List<MultiroomDeviceModel> devicesInGroup = multiroomGroupManager.getAllDevicesForGroupId(multiroomDeviceModel.mGroupId);
        MultiroomDeviceModel serverDeviceModel = multiroomGroupManager.getServerDeviceFromGroupId(multiroomDeviceModel.mGroupId);

        if (serverDeviceModel != null && serverDeviceModel.mRadio != null) {
            getModesForRadio(serverDeviceModel.mRadio, true, new IAvailableSourcesListener() {

                @Override
                public void onSourcesUpdate(List<SourceItemModel> sourcesList) {
                    if (sourcesList == null) {
                        sourcesList = new ArrayList<>();
                    }
                    allModes.addAll(sourcesList);
                }
            });
        }

        for (MultiroomDeviceModel clientDevice : devicesInGroup) {
            if (clientDevice.equals(serverDeviceModel) || clientDevice.mRadio == null) {
                continue;
            }

            getModesForRadio(clientDevice.mRadio, false, new IAvailableSourcesListener() {
                @Override
                public void onSourcesUpdate(List<SourceItemModel> sourcesList) {
                    if (sourcesList == null) {
                        sourcesList = new ArrayList<>();
                    }
                    allModes.addAll(sourcesList);
                }
            });
        }
    }

    private void getModesForRadio(final Radio radio,  final boolean isServer, final IAvailableSourcesListener listener) {
        NodeSysCapsValidModes allModesNode = radio.getValidModesSync();

        if (allModesNode != null) {
            List<BaseSysCapsValidModes.ListItem> selectableModesList = new ArrayList<>();

            // show only selectable sources
            for (NodeListItem item : allModesNode.getEntries()) {
                NodeSysCapsValidModes.ListItem modeItem = (NodeSysCapsValidModes.ListItem) item;
                if (modeItem.getSelectable()) {
                    selectableModesList.add(modeItem);
                }
            }

            if (isServer) {
                createModeItemListForCurrentRadio(radio, selectableModesList, false, listener);
            } else {
                List<SourceItemModel> modesList = createModeItemList(radio, selectableModesList, null, false);
                if (listener != null) {
                    listener.onSourcesUpdate(modesList);
                }
            }
        }
    }

	void getModes(final Radio radio, final IAvailableSourcesListener listener, final boolean onlyStreamableModes) {
        NodeSysCapsValidModes allModesNode = radio.getValidModesSync();
        if (allModesNode == null)
            return;

		List<BaseSysCapsValidModes.ListItem> selectableModesList = new ArrayList<>();
        for (BaseSysCapsValidModes.ListItem item : allModesNode.getEntries()) {

            /* Don't show modes that can't be selected. */
            if (!(item.getSelectable())) {
                continue;
            }

            /* Add to the list we are building up. */
            selectableModesList.add(item);
        }

        createModeItemListForCurrentRadio(radio, selectableModesList, onlyStreamableModes, listener);
	}
	
	void createModeItemListForCurrentRadio(final Radio radio, final List<BaseSysCapsValidModes.ListItem> modesList,
                                                         final boolean onlyStreamableModes,  final IAvailableSourcesListener listener) {
        radio.getCurrentModeAsListItem(true, currentMode -> {
            List<SourceItemModel> modes = createModeItemList(radio, modesList, currentMode, onlyStreamableModes);

            if (listener != null) {
                listener.onSourcesUpdate(modes);
            }
        });
	}

	List<SourceItemModel> createModeItemList(Radio radio, List<BaseSysCapsValidModes.ListItem> modesList,
                                             NodeSysCapsValidModes.ListItem currMode, boolean onlyStreamableModes) {
		ArrayList<SourceItemModel> modes = new ArrayList<>();

		for (BaseSysCapsValidModes.ListItem item : modesList) {

            SourceItemModel modeItem = new SourceItemModel(item.getLabel(), item.getId(),  item.getStreamable(), item.getKey());

            modeItem.mRadio = radio;

            if (currMode != null && currMode.getKey() == (long) item.getKey()) {
                modeItem.mIsCurrentModeSelected = true;
            }

            if (onlyStreamableModes) {
                if (modeItem.mIsStreamable) {
                    modes.add(modeItem);
                }
            } else {
                modes.add(modeItem);
            }
		}

		return modes;
	}


    private List<SourceItemModel> cleanupAllModes(List<SourceItemModel> allModes) {
        List<SourceItemModel> allModesListClean = new ArrayList<>();

        // add all server sources first
        Iterator<SourceItemModel> it = allModes.iterator();
        while (it.hasNext()) {
            SourceItemModel item = it.next();

            if (SourcesRadioUtil.isModeWithOwnInput(item.mModeId)) {
                // add sources that might have different inputs for other radios
                allModesListClean.add(item);
            } else {
                // add common sources once
                boolean sourceExists = false;
                for (SourceItemModel existingItem : allModesListClean) {
                    if (item.mModeId.equals(existingItem.mModeId)) {
                        sourceExists = true;
                        break;
                    }
                }

                if (!sourceExists) {
                    allModesListClean.add(item);
                }
            }
        }

        return allModesListClean;
    }


    static public boolean isModeWithOwnInput(String modeId) {
		NodeSysCapsValidModes.Mode modeEnum = NodeSysCapsValidModes.ConvertIdToEnum(modeId);

		return !(modeEnum == NodeSysCapsValidModes.Mode.IR ||
				modeEnum == NodeSysCapsValidModes.Mode.Spotify || modeEnum.isAirable());
	}

}
