package com.frontier_silicon.fsirc.dok2.nowPlaying;

/**
 * Created by hcostescu on 11/15/2016.
 */

import android.app.Activity;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;
import android.view.View;
import android.widget.TextView;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import static com.frontier_silicon.fsirc.dok2.R.id.trackDescription;
import static com.frontier_silicon.fsirc.dok2.R.id.albumDescription;
import static com.frontier_silicon.fsirc.dok2.R.id.artistDescription;

public class QobuzDetailedInfo {
    static QobuzDetailedInfo mQobuzDetailedInfo;
    DialogInterface.OnClickListener mOnClickListener;

    public static QobuzDetailedInfo getInstance()
    {
        if(mQobuzDetailedInfo == null) {
            mQobuzDetailedInfo = new QobuzDetailedInfo();
            mQobuzDetailedInfo.setQobuzTrackInfo(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
        }

        return  mQobuzDetailedInfo;
    }

    public void setQobuzTrackInfo(DialogInterface.OnClickListener onClickListener) {

        mOnClickListener = onClickListener;
    }

    public void showNowPlayingDialogInfo(Activity activity) {

        NowPlayingDataModel mNowPlayingDataModel = NowPlayingManager.getInstance().getNowPlayingDataModel();

        String dialogKey = "qobuz_track_info";
        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, activity))
            return;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity);
        builder.setTitle(activity.getString(R.string.info_button));

        View dialogView = View.inflate(activity,R.layout.qobuz_track_info,null);

        TextView trackTextView = (TextView)dialogView.findViewById(trackDescription);
        if (mNowPlayingDataModel.trackDescription.get().isEmpty())
            trackTextView.setVisibility(View.GONE);
        else {
            trackTextView.setVisibility(View.VISIBLE);
            String trackDescription = activity.getString(R.string.track_description) +  mNowPlayingDataModel.trackDescription.get();
            trackTextView.setText(trackDescription);
        }

        TextView albumTextView = (TextView)dialogView.findViewById(albumDescription);
        if (mNowPlayingDataModel.infoAlbumDescription.get().isEmpty())
            albumTextView.setVisibility(View.GONE);
        else {
            albumTextView.setVisibility(View.VISIBLE);
            String albumDescription = activity.getString(R.string.album_description) + mNowPlayingDataModel.infoAlbumDescription.get();
            albumTextView.setText(albumDescription);
        }

        TextView artistTextView = (TextView)dialogView.findViewById(artistDescription);
        if (mNowPlayingDataModel.infoArtistDescription.get().isEmpty())
            artistTextView.setVisibility(View.GONE);
        else {
            artistTextView.setVisibility(View.VISIBLE);
            String artistDescription = activity.getString(R.string.artist_description) + mNowPlayingDataModel.infoArtistDescription.get();
            artistTextView.setText(artistDescription);
        }

        builder.setView(dialogView);
        builder.setNegativeButton(android.R.string.cancel, null);

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);

        if (mOnClickListener != null) {
            mOnClickListener.onClick(dlg,0);
        }
        dlg.show();
    }
}

