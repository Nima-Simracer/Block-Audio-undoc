package com.frontier_silicon.fsirc.dok2.baseActivity;

import android.app.Activity;

import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Created by lsuhov on 10/07/2017.
 *
 * Class that intends to redirect the user to desired location if the speaker disappears
 */

public class SpeakerLostWatcher implements IRadioDiscoveryListener {

    private Activity mActivity;
    private SpeakerLostHandlingType mHandlingType;
    private List<String> mListOfUdnToWatch = new CopyOnWriteArrayList<>();

    public SpeakerLostWatcher(Activity activity) {
        mActivity = activity;
        mHandlingType = SpeakerLostHandlingType.GoToHome;
    }

    public SpeakerLostWatcher(Activity activity, SpeakerLostHandlingType handlingType) {
        mActivity = activity;
        mHandlingType = handlingType;
    }

    public void addSpeakerUdn(String udn) {
        mListOfUdnToWatch.add(udn);

        checkIfSpeakerWasLost();
    }

    public void registerSpeakersDiscoveryListener() {
        NetRemoteManager.getInstance().addRadioDiscoveryListener(this);
    }

    public void unregisterSpeakersDiscoveryListener() {
        NetRemoteManager.getInstance().removeRadioDiscoveryListener(this);
    }


    public boolean checkIfSpeakerWasLost() {
        for (String udnOfSpeaker : mListOfUdnToWatch) {
            Radio radio = NetRemoteManager.getInstance().getRadio(udnOfSpeaker);
            if (radio == null) {
                handleSpeakerLost();

                return true;
            }
        }

        return false;
    }

    @Override
    public void onRadioFound(Radio radio) {}

    @Override
    public void onRadioLost(Radio radio, boolean rescanInProgress) {
        for (String udnOfSpeaker : mListOfUdnToWatch) {
            if (radio.getUDN().equals(udnOfSpeaker)) {
                handleSpeakerLost();
            }
        }
    }

    private void handleSpeakerLost() {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        mActivity.runOnUiThread(() -> {
            if (DokUiUtils.isDestroyed(mActivity)) {
                return;
            }

            if (mHandlingType == SpeakerLostHandlingType.GoToHome) {
                NavigationHelper.goToHomeAndClearActivityStack(mActivity);
            } else if (mHandlingType == SpeakerLostHandlingType.GoBack) {
                mActivity.onBackPressed();
            }
        });
    }

    @Override
    public void onRadioUpdated(Radio radio) {}

    public void dispose() {
        mActivity = null;
        mListOfUdnToWatch.clear();
    }
}
