package com.frontier_silicon.fsirc.dok2.RemoteConfigModel

data class OktivPromoCountryModel( val isEnabled: Boolean, val country: String) {
}