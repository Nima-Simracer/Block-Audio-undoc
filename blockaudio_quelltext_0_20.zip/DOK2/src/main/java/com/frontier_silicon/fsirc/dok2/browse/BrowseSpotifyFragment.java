package com.frontier_silicon.fsirc.dok2.browse;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.ExternalAppsOpener;
import com.frontier_silicon.components.common.LayoutDecider;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.FragmentFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.ContextBrowseManager;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IParentActivity;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

public class BrowseSpotifyFragment extends BaseFragment implements IChildFragment, IPageSwitchListener {

	public static final String FRAGMENT_TAG = "TAG_BROWSE_SPOTIFY_FRAGMENT";
	private static final String SPOTIFY_ICON_SPAN_TOKEN = "[ICON]";
    private static final String SPOTIFY_PARTNER_TOKEN = "\\[partner_device\\]";

	private View mSpotifyInfoLayout;
	private Button mOpenSpotifyBtn;
	private TextView mBrowseNotSupportedText;

	private TextView mMiddleInfoText;
	private TextView mLearnMoreLinkText;
	
	public BrowseSpotifyFragment() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.browse_spotify_fragment, container, false);
		ContextBrowseManager.getInstance().CloseContextDialog(false);
		
		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		setHasOptionsMenu(true);
		
		setupControls();
	}
	
	public void onResume() {
		super.onResume();

	}
	
	public void onPause() {
		super.onPause();
	}
	
	private void setupControls() {
		mOpenSpotifyBtn = getView().findViewById(R.id.buttonOpenSpotify);
		if (ExternalAppsOpener.isAppInstalled(getString(R.string.spotify_app_package_name), getActivity())) {
			mOpenSpotifyBtn.setText(R.string.play_press_icon_to_open_spotify_app);
		} else {
			mOpenSpotifyBtn.setText(R.string.get_spotify_free);
		}

		mOpenSpotifyBtn.setOnClickListener(v -> {
			boolean appStartedOk = DokUiUtils.openSpotify(getActivity());
			if (appStartedOk) {
				DelayedPostsManager.getInstance().postDelayed(() ->
						switchToNowPlayingFragment(), 500);
			}
		});

		mBrowseNotSupportedText =  getView().findViewById(R.id.textBrowseNotSupported);

		mLearnMoreLinkText =  getView().findViewById(R.id.textSpotifyLearnMoreLink);
		mLearnMoreLinkText.setOnClickListener(view -> openSpotifyLearnMoreLink());

		mSpotifyInfoLayout = getView().findViewById(R.id.layoutSpotifyInfo);
	}

	private void openSpotifyLearnMoreLink() {
		Activity parentActiviy = getActivity();
		if (parentActiviy != null) {
			String linkUrl = parentActiviy.getString(R.string.spotify_learn_more_link);
			Intent openLinkIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl));
			parentActiviy.startActivity(openLinkIntent);
		}
	}

	private void updateMiddleInfoSpannable() {
		  /*String rawText = mMiddleInfoText.getText().toString();

        String radioName = "Radio";
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio != null) {
            radioName = DokUiUtils.getFriendlyNameOrStereoSystemName(radio);
        }
        //rawText = rawText.replaceAll(SPOTIFY_PARTNER_TOKEN, TextViewStringUtils.bold(radioName).toString());

        Resources res = getResources();
        String text = String.format(res.getString(R.string.spotify_middle_info), radioName, radioName)  ;
        CharSequence styledText = Html.fromHtml(text);

        mMiddleInfoText.setText(styledText);

		int startIdx = rawText.indexOf(SPOTIFY_ICON_SPAN_TOKEN);
		int endIdx = startIdx + SPOTIFY_ICON_SPAN_TOKEN.length();

		if (startIdx >= 0) {
			SpannableStringBuilder ssb = new SpannableStringBuilder(mMiddleInfoText.getText());
			ssb.setSpan(new ImageSpan(getActivity(), R.drawable.ic_spotifyconnect, ImageSpan.ALIGN_BOTTOM), startIdx, endIdx, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
			mMiddleInfoText.setText(ssb, TextView.BufferType.SPANNABLE);
		}
		*/
	}

	private void switchToNowPlayingFragment() {
		if (LayoutDecider.isTabletAndLandscape(getActivity()))
			return;
		
		try {
            IParentActivity parentActivity = (IParentActivity) getActivity();
			parentActivity.switchFragment(FragmentFactory.NOW_PLAYING_TAG);
		} catch (Exception e) {
		}
	}

	@Override
	public boolean isBackButtonHandledByFragment(boolean upButton) {
		return false;
	}

	@Override
	public void onBackButton() {
	}

	@Override
	public String getStaticTag() {
		return FRAGMENT_TAG;
	}

	@Override
	public synchronized void onFragmentActivated() {
		updateBrowseSupported();

	}

	private void updateBrowseSupported() {
		if (SpeakerDataManager.getInstance().isInStandby()) {
            mBrowseNotSupportedText.setVisibility(View.VISIBLE);
            mSpotifyInfoLayout.setVisibility(View.GONE);
		} else {
            mSpotifyInfoLayout.setVisibility(View.VISIBLE);
            mBrowseNotSupportedText.setVisibility(View.GONE);
		}
	}

	@Override
	public synchronized void onFragmentDeactivated() {
	}

}
