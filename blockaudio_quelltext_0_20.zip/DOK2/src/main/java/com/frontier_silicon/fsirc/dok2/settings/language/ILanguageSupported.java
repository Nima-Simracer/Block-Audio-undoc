package com.frontier_silicon.fsirc.dok2.settings.language;

/**
 * Created by hcostescu on 25/11/16.
 */

public interface ILanguageSupported {
    void OnLanguageIsSupported(Boolean isLanguageSupported);
}
