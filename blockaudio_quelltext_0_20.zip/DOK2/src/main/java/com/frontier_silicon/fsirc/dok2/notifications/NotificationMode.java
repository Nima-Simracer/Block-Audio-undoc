package com.frontier_silicon.fsirc.dok2.notifications;

/**
 * Created by mnisipeanu on 11/07/2017.
 */

public enum NotificationMode {
    DMR,
    IR,
    MP,
    Podcasts
}
