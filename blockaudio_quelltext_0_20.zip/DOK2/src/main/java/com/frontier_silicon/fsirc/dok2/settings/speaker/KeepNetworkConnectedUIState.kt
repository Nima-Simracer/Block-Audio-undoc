package com.frontier_silicon.fsirc.dok2.settings.speaker

enum class KeepNetworkConnectedUIState {
    Success, Error
}
