package com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware

data class OpenSourceSoftwareModel(val name: String, val license:String, val url: String, val selectable: Boolean = false)
