package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseFormItemNotLoadedViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.R;

/**
 * Created by lsuhov on 06/11/2016.
 */

public class BrowseFormItemNotLoadedDelegate extends RecyclerViewListItemDelegate {

    private int mBrowseType;

    public BrowseFormItemNotLoadedDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        View view = layoutInflater.inflate(R.layout.browse_list_item_not_loaded, parent, false);
        return new FormItemNotLoadedViewHolder(view, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        FormItemNotLoadedViewHolder notLoadedViewHolder = (FormItemNotLoadedViewHolder) holder;

        FormManager formManager = BrowseManagerFactory.getFormManager(mBrowseType);
        notLoadedViewHolder.mViewModel = new BrowseFormItemNotLoadedViewModel(position, adapter, formManager);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        FormItemNotLoadedViewHolder formNotLoadedViewHolder = (FormItemNotLoadedViewHolder) holder;
        BrowseFormItemNotLoadedViewModel viewModel = formNotLoadedViewHolder.mViewModel;
        if (viewModel != null) {
            viewModel.dispose();
            formNotLoadedViewHolder.mViewModel = null;
        }
    }

    protected static class FormItemNotLoadedViewHolder extends ListItemViewHolder {
        public BrowseFormItemNotLoadedViewModel mViewModel;

        FormItemNotLoadedViewHolder(View view, RecyclerViewListItemDelegate delegate) {
            super(view, delegate);
        }
    }
}
