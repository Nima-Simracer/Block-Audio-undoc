package com.frontier_silicon.fsirc.dok2.browse.nav.contextModel;

import com.frontier_silicon.NetRemoteLib.Node.BaseNavContextList;
import com.frontier_silicon.NetRemoteLib.Node.BaseNavContextStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavContextStatus;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.PageRetrieverRunnable;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.UnifiedBrowseListItem;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;

/**
 * Created by adanaila on 21/11/16.
 */

public class ContextPageRetrieverRunnable extends PageRetrieverRunnable{

    public ContextPageRetrieverRunnable(int startIndex, Radio radio, boolean firstPageOnly, IPageRetrieverListener listener) {
        super(startIndex, radio, firstPageOnly, listener);
    }

    @Override
    public void run() {
        FsLogger.log("navigation runnable started " + mStartIndex, LogLevel.Info);

        ArrayList<UnifiedBrowseListItem> navList = new ArrayList<>();

        boolean forceUncached = true;
        NodeNavContextStatus statusNode = (NodeNavContextStatus) mRadio.
                nodeSyncGetter(NodeNavContextStatus.class, forceUncached).get();

        if (statusNode == null || statusNode.getValueEnum() == BaseNavContextStatus.Ord.FAIL ||
                statusNode.getValueEnum() == BaseNavContextStatus.Ord.FATAL_ERR) {
            sendNavListToListener(navList);
            dispose();
            return;
        }

        String startKey = "" + mStartIndex;
        ArrayList<BaseNavContextList.ListItem> returnedNavList = RadioNavigationUtil.getContextList(mRadio, startKey, mFirstPageOnly);

        if (returnedNavList != null) {
            for (BaseNavContextList.ListItem li: returnedNavList) {
                navList.add(new UnifiedBrowseListItem(li));
            }
        }

        sendNavListToListener(navList);

        dispose();
    }
}
