package com.frontier_silicon.fsirc.dok2.update;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;

public class AllDevicesIsuManager {
    public final Object mLock = new Object();

	private static AllDevicesIsuManager mInstance = null;
	private List<Radio> mAllSpeakers;
	private HashMap<String /*radio unique id*/, IsuItemModel> mHashItemModels = new HashMap<>();
	
	private Thread mCheckUpdatesThread;
	private AllDevicesCheckForUpdateRunnable mCheckUpdatesRunnable;
	private IAllDevicesIsuListener mIAllDevicesIsuListener;
	private Thread mGroupedIsuThread;
	private AllDevicesIsuRunnable mAllDevicesIsuRunnable;
	
	private AllDevicesIsuManager() {}
	
	public static AllDevicesIsuManager getInstance () {
		if (mInstance == null)
			mInstance = new AllDevicesIsuManager();
		
		return mInstance;
	}
	
	public void setAllDevices(List<Radio> allDevices) {
        synchronized (mLock) {
            mAllSpeakers = allDevices;
            if (mAllSpeakers == null)
                return;

            for (int i = 0; i < allDevices.size(); i++) {
                Radio radio = allDevices.get(i);
                if (radio == null)
                    continue;

                String sn = radio.getSN();
                if (TextUtils.isEmpty(sn))
                    continue;

                if (!mHashItemModels.containsKey(sn)) {
                    IsuItemModel itemModel = new IsuItemModel();
                    mHashItemModels.put(sn, itemModel);
                }
            }
        }
	}

    public void addDevice(Radio radio) {
        IsuItemModel itemModel;
        synchronized (mLock) {
            String sn = radio.getSN();
            if (TextUtils.isEmpty(sn))
                return;

            if (!mHashItemModels.containsKey(sn)) {
                itemModel = new IsuItemModel();
                mHashItemModels.put(sn, itemModel);
            } else {
                itemModel = mHashItemModels.get(sn);
            }

            if (!mAllSpeakers.contains(radio)) {
                mAllSpeakers.add(radio);
            }
        }

        addDeviceToCheckUpdatesRunnableIfNeeded(radio, itemModel);
    }

    private void addDeviceToCheckUpdatesRunnableIfNeeded(Radio radio, IsuItemModel itemModel) {
        if (isCheckingForUpdate()) {
            mCheckUpdatesRunnable.addDevice(radio, itemModel);
        }
    }

    public void removeDevice(Radio radio) {
        synchronized (mLock) {
            if (mAllSpeakers.contains(radio)) {
                mAllSpeakers.remove(radio);
            }
        }

        removeDeviceFromCheckUpdatesRunnable(radio);
    }

    private void removeDeviceFromCheckUpdatesRunnable(Radio radio) {
        if (isCheckingForUpdate()) {
            mCheckUpdatesRunnable.removeDevice(radio);
        }
    }

    public void setIAllDevicesIsuListener(IAllDevicesIsuListener iAllDevicesIsuListener) {
        mIAllDevicesIsuListener = iAllDevicesIsuListener;
    }

    public void removeIAllDevicesIsuListener() {
        mIAllDevicesIsuListener = null;
    }

	public void checkForUpdates(IAllDevicesIsuListener iAllDevicesIsuListener) {
        if (iAllDevicesIsuListener != null) {
            mIAllDevicesIsuListener = iAllDevicesIsuListener;
        }

		if (allRadiosHaveUpdatesAvailable()) {
			if (mIAllDevicesIsuListener != null)
                mIAllDevicesIsuListener.updatesAreAvailable(true);
			return;
		}
		
		if (!isCheckingForUpdate()) {
			mCheckUpdatesRunnable = new AllDevicesCheckForUpdateRunnable(mIAllDevicesIsuListener, getCloneOfRadioList(), getCloneOfHashMap());
			mCheckUpdatesThread = new Thread(mCheckUpdatesRunnable);
			mCheckUpdatesThread.start();
		}
		else {
            mCheckUpdatesRunnable.setIAllDevicesCheckUpdatesListener(mIAllDevicesIsuListener);
        }
	}
	
	public boolean allRadiosHaveUpdatesAvailable() {

		return checkUpdateAvailability(true);
	}

    public boolean atLeastOneRadioHasAvailableUpdate() {
        return checkUpdateAvailability(false);
    }

    private boolean checkUpdateAvailability(boolean allRadios) {
        boolean hasUpdates = false;

        synchronized (mLock) {
            for (int i = 0; i < mAllSpeakers.size(); i++) {
                Radio radio = mAllSpeakers.get(i);
                if (radio == null)
                    continue;

                String sn = radio.getSN();
                if (TextUtils.isEmpty(sn))
                    continue;

                IsuItemModel isuItemModel = mHashItemModels.get(sn);
                if (isuItemModel.mUpdateState == NodeSysIsuState.Ord.UPDATE_AVAILABLE) {
                    hasUpdates = true;

                    if (!allRadios) {
                        break;
                    }
                } else if (allRadios) {
                    hasUpdates = false;
                    break;
                }
            }
        }
        return hasUpdates;
    }
	
	public void addListenersForItemModelAndUpdateStateAccordingly(Radio radio,
			ICheckForUpdateListener iCheckForUpdateListener, IUpdateFirmwareListener iUpdateFirmwareListener) {

        String sn = radio.getSN();
        if (TextUtils.isEmpty(sn))
            return;

        IsuItemModel isuItemModel;
        synchronized (mLock) {
            isuItemModel = mHashItemModels.get(sn);
        }

		if (isuItemModel != null) {
			synchronized (isuItemModel.mLock) {
				isuItemModel.mCheckUpdateListener = iCheckForUpdateListener;
				isuItemModel.mUpdateListener = iUpdateFirmwareListener;
			}

			if (isuItemModel.mCurrentVersionWasRetrieved)
				iCheckForUpdateListener.onCurrentVersionRetrieved(isuItemModel.mCurrentVersion);

			if (isuItemModel.mIsUpdating) {
				iUpdateFirmwareListener.onProgress(0);
			} else if (isuItemModel.mUpdateState == NodeSysIsuState.Ord.CHECK_IN_PROGRESS) {
				iCheckForUpdateListener.onCheckingUpdate();
			} else if (isuItemModel.mUpdateState == NodeSysIsuState.Ord.CHECK_FAILED) {
				iCheckForUpdateListener.onCheckFailed(isuItemModel.mErrorType);
			} else if (isuItemModel.mUpdateState == NodeSysIsuState.Ord.IDLE ||
					isuItemModel.mUpdateState == NodeSysIsuState.Ord.UPDATE_NOT_AVAILABLE) {
				iCheckForUpdateListener.onNoAvailableUpdate();
			} else if (isuItemModel.mUpdateState == NodeSysIsuState.Ord.UPDATE_AVAILABLE) {
				iCheckForUpdateListener.onAvailableUpdate(isuItemModel.mUpdateVersion, isuItemModel.mUpdateDescription,
						isuItemModel.mIsMandatory);
			} else if (isuItemModel.mUpdateState == null) {
                if (!isCheckingForUpdate()) {
                    checkForUpdates(null);
                }
            }
		}
	}
	
	public void startIsu(IAllDevicesIsuListener allDevicesIsuListener) {
		if (!isUpdating()) {
			mAllDevicesIsuRunnable = new AllDevicesIsuRunnable(allDevicesIsuListener, getCloneOfRadioList(), getCloneOfHashMap());
			mGroupedIsuThread = new Thread(mAllDevicesIsuRunnable);
			mGroupedIsuThread.start();
		}
		else {
            mAllDevicesIsuRunnable.setAllDevicesIsuListener(allDevicesIsuListener);
        }
	}


    public void setIsuProgress(String sn, long progress) {
        IsuItemModel isuItemModel;

        synchronized (mLock) {
            isuItemModel = mHashItemModels.get(sn);
        }

        if ((isuItemModel != null) && (isuItemModel.mUpdateListener != null)) {
            isuItemModel.mUpdateListener.onProgress(progress);
        }
    }

	
	public boolean isCheckingForUpdate() {
		return mCheckUpdatesThread != null && mCheckUpdatesThread.isAlive() &&
				!mCheckUpdatesThread.isInterrupted();
	}
	
	public boolean isUpdating() {
		if (mGroupedIsuThread != null && mGroupedIsuThread.isAlive() &&
				!mGroupedIsuThread.isInterrupted() && mAllDevicesIsuRunnable != null) {
            return true;
        }

        List<IsuItemModel> itemModels = new ArrayList<>();
        synchronized (mLock) {
            itemModels.addAll(mHashItemModels.values());
        }

        for (IsuItemModel isuItemModel : itemModels) {
            if (isuItemModel.mIsUpdating || isuItemModel.mIsRestarting) {
                return true;
            }
        }

        return false;
	}

    public void updateFirmware(Radio radio) {
        String sn = radio.getSN();
        if (TextUtils.isEmpty(sn))
            return;

        IsuItemModel isuItemModel;
        synchronized (mLock) {
            isuItemModel = mHashItemModels.get(sn);
        }
        if (isuItemModel == null)
            return;

        UpdateFirmwareRunnable mUpdateFirmwareRunnable =
                new UpdateFirmwareRunnable(radio, isuItemModel);
        Thread mUpdateFirmwareThread = new Thread(mUpdateFirmwareRunnable);
        mUpdateFirmwareThread.start();
    }

    public IsuItemModel getIsuModel(Radio radio) {
        if (radio == null) {
            return null;
        }

        String sn = radio.getSN();

        synchronized (mLock) {
            return mHashItemModels.get(sn);
        }
    }

    private List<Radio> getCloneOfRadioList() {
        List<Radio> clonedList= new ArrayList<>();

        synchronized (mLock) {
            clonedList.addAll(mAllSpeakers);
        }

        return clonedList;
    }

    private HashMap<String, IsuItemModel> getCloneOfHashMap() {
        HashMap<String, IsuItemModel> clonedMap = new HashMap<>();

        synchronized (mLock) {
            clonedMap.putAll(mHashItemModels);
        }

        return clonedMap;
    }
}
