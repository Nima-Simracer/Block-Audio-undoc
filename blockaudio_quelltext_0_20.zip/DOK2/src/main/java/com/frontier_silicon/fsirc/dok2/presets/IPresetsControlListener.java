package com.frontier_silicon.fsirc.dok2.presets;

import java.util.ArrayList;

public interface IPresetsControlListener {

	void onPresetAddSelected(PresetItemModel presetItem);

	void onPresetDeleteRequested(PresetItemModel presetItem);

	void onPresetEditedRequested(PresetItemModel presetItem);

	void onPresetSelected(PresetItemModel presetItem);

	void onPresetReordered(ArrayList<PresetItemModel> presetList, int fromPosition, int toPosition);

	void onSwap(PresetItemModel source, PresetItemModel destination);
}
