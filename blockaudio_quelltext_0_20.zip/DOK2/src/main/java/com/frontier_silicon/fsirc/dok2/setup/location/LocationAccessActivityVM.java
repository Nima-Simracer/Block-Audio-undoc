package com.frontier_silicon.fsirc.dok2.setup.location;

import android.app.Activity;
import android.os.Build;

import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.listOfAP.ListOfAccessPointActivity;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.manualAPSelection.ManualAccessPointSelectionActivity;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;

/**
 * Created by nbalazs on 08/03/2018.
 *
 */

public final class LocationAccessActivityVM {

    private Activity mActivity;

    LocationAccessActivityVM(Activity activity) {
        mActivity = activity;
    }

    public void onBackPressed() {
        mActivity.onBackPressed();
    }

    public void onNextPressed() {
        if ((Build.VERSION.SDK_INT < Build.VERSION_CODES.M)) {
            if (PermissionsUtil.requestLocationPermission(mActivity, true)) {
                NavigationHelper.goToActivity(mActivity, ListOfAccessPointActivity.class, NavigationHelper.AnimationType.SlideToLeft, true, null);
            }
        } else if ((Build.VERSION.SDK_INT < Build.VERSION_CODES.O)) {
            if (PermissionsUtil.requestLocationPermission(mActivity, true)) {
                NavigationHelper.goToActivity(mActivity, ListOfAccessPointActivity.class, NavigationHelper.AnimationType.SlideToLeft, true, null);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (PermissionsUtil.requestLocationPermission(mActivity, true)) {
                NavigationHelper.goToActivity(mActivity, ManualAccessPointSelectionActivity.class, NavigationHelper.AnimationType.SlideToLeft, true, null);
            }
        } else {
            NavigationHelper.goToActivity(mActivity, ManualAccessPointSelectionActivity.class);
        }
    }
}
