package com.frontier_silicon.fsirc.dok2.RemoteConfigModel

data class OktivPromoFirmwareBlackList(val version: String) {
}