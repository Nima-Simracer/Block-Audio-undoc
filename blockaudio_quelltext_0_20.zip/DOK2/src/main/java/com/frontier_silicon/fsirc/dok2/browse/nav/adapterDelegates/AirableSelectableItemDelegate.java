package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import android.text.Editable;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.AirableItemSelectionManager;

/**
 * Created by adanaila on 09/12/2016.
 */

public abstract class AirableSelectableItemDelegate extends RecyclerViewListItemDelegate {
    protected final int USERNAME_PASSWORD_MAX_LENGTH= 50;
    protected void createEditorListeners(TextView tv){
        //TODO move all listener creation and binding here
        TextView.OnEditorActionListener editorActionListener = new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (event == null &&
                        (actionId == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_GO)) {
                    
                    AirableItemSelectionManager.getInstance().selectNextItemOnPage(v);
                    return true;
                }
                return false;
            }
        };

        tv.setOnEditorActionListener(editorActionListener);
    }

    protected void replaceCharacters(Editable editable) {
        for(int i = USERNAME_PASSWORD_MAX_LENGTH; i< editable.length(); i++) {
            editable.replace(i, i+1, "");
        }
    }
}
