package com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig;

public interface IDateTimeStateListener {

    void onDateTimeStateUpdate(DateTimeParams dateTimeParams);

}
