package com.frontier_silicon.fsirc.dok2;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import androidx.appcompat.app.AlertDialog;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.frontier_silicon.components.common.BaseSanitizer;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.ErrorSanitizerMessageType;
import com.frontier_silicon.components.common.FriendlyNameSanitizer;
import com.frontier_silicon.components.common.FriendlyNameSanitizer.IFriendlyNameSanitizerListener;
import com.frontier_silicon.components.common.IButtonsResponseWithTextListener;
import com.frontier_silicon.components.common.PinSanitizer;
import com.frontier_silicon.components.common.PinSanitizer.IPinSanitizerListener;
import com.frontier_silicon.fsirc.dok2.util.FriendlyNameSanitizerErrorHandler;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

public class DialogsOpener {

	public static String mFriendlyNameDialogKey = "FriendlyName_Dialog";
    public static String mPinDialogKey = "Pin_Dialog";
	public static String mMessageDialogKey = "Message_Dialog";

	public static void showEnterPinDialog(Activity activity, String radioName, IButtonsResponseWithTextListener buttonsResponseListener) {
		String message = activity.getString(R.string.enter_pin_description, radioName);
		
		showPinDialog(activity, R.string.enter_pin_title, message, buttonsResponseListener);
	}
	
	public static void showChangePinDialog(Activity activity, String radioName, IButtonsResponseWithTextListener buttonsResponseListener) {
        showPinDialog(activity, R.string.change_pin, null, buttonsResponseListener);
	}

	private static void showPinDialog(final Activity activity, int titleId, String message,
                                      IButtonsResponseWithTextListener buttonsResponseListener) {

        if (DialogsHolder.isShowingOrActivityIsFinishing(mPinDialogKey, activity))
            return;

        final AlertDialog dialog = setupPINDialog(activity, buttonsResponseListener, message);

        dialog.setTitle(titleId);
        dialog.setCancelable(true);

		/* Make sure the dialogue renders nicely on all devices. */
        Window window = dialog.getWindow();
        WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.gravity = Gravity.CENTER_HORIZONTAL;
        window.setAttributes(params);
        window.setGravity(Gravity.CENTER_HORIZONTAL);

        dialog.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                DialogsHolder.dismissDialog(dialog);
            }
        });

        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        dialog.show();

        DialogsHolder.addDialogToCollection(mFriendlyNameDialogKey, dialog);

        BaseSanitizer sanitizer = new PinSanitizer();
        final EditText editText = dialog.findViewById(R.id.editText);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

        ((PinSanitizer) sanitizer).appendSanitizerToEditText(editText, activity, new IPinSanitizerListener() {

            @Override
            public void onNewPIN(boolean goodPin) {
                Button okButton = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
                okButton.setEnabled(goodPin);
            }

            @Override
            public void onPinTooBig() {
                editText.setError(activity.getString(R.string.length_of_pin_is_inappropriate));
            }
        });
    }
	
	public static void showChangeFriendlyNameDialog(String currentFriendlyName, Activity activity, int maxLengthOfFriendlyName,
                                                      final IButtonsResponseWithTextListener buttonsResponseListener) {

		showFriendlyNameDialog(activity, buttonsResponseListener, R.string.change_friendly_name_title,
                currentFriendlyName, maxLengthOfFriendlyName);
	}

	private static void showFriendlyNameDialog(final Activity activity, final IButtonsResponseWithTextListener buttonsResponseListener,
                                               int titleId, String textToPutInEdit, int maxLengthOfFriendlyName) {

		if (DialogsHolder.isShowingOrActivityIsFinishing(mFriendlyNameDialogKey, activity))
			return;

		final AlertDialog dialog = setupChangeFriendlyNameDialog(activity, buttonsResponseListener,
                textToPutInEdit, maxLengthOfFriendlyName);

		dialog.setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(titleId, true));
		dialog.setCancelable(true);

		/* Make sure the dialogue renders nicely on all devices. */
		Window window = dialog.getWindow();
		WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
		params.gravity = Gravity.CENTER_HORIZONTAL;
		window.setAttributes(params);
		window.setGravity(Gravity.CENTER_HORIZONTAL);

		dialog.setOnDismissListener(dialogInterface -> DialogsHolder.dismissDialog(dialog));

		dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        dialog.show();

		DialogsHolder.addDialogToCollection(mFriendlyNameDialogKey, dialog);

        final EditText editText = dialog.findViewById(R.id.editText);
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    String friendlyName = editText.getText().toString();

                    DialogsHolder.dismissDialog(mFriendlyNameDialogKey);

                    if (buttonsResponseListener != null)
                        buttonsResponseListener.onOkClicked(friendlyName);

                    return true;
                }

                return false;
            }
        });
	}

	private static AlertDialog setupChangeFriendlyNameDialog(final Activity activity,
                                                             final IButtonsResponseWithTextListener buttonsResponseListener,
                                                             String textToPutInEdit, int maxLengthOfFriendlyName) {
		BaseSanitizer sanitizer;

		final AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity);

		final View dialogLayout = activity.getLayoutInflater().inflate(R.layout.edit_text_dialog, null);
		builder.setView(dialogLayout);

		final EditText editText = dialogLayout.findViewById(R.id.editText);

		editText.setHint(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.friendly_name_hint, true));
		editText.setText(textToPutInEdit);
		editText.setSingleLine(true);
        editText.setInputType(EditorInfo.TYPE_CLASS_TEXT | EditorInfo.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
		editText.setSelection(0, editText.getText().length());
		editText.requestFocus();

		sanitizer = new FriendlyNameSanitizer(maxLengthOfFriendlyName);
        final FriendlyNameSanitizerErrorHandler errorHandler = new FriendlyNameSanitizerErrorHandler(maxLengthOfFriendlyName);
		((FriendlyNameSanitizer) sanitizer).appendSanitizerToEditText(editText, activity, new IFriendlyNameSanitizerListener() {
			@Override
			public void onSubmitFriendlyName(String friendlyName) {
			}

			@Override
			public void onNewFriendlyName(String friendlyName) {
			}

			@Override
			public void onBadFriendlyName(ErrorSanitizerMessageType errorMessageType) {
                errorHandler.handleMessageErrorType(activity, errorMessageType, editText);
			}
		});

        TextView messageTextView = dialogLayout.findViewById(R.id.dialogMessage);
        messageTextView.setVisibility(View.GONE);

		builder.setPositiveButton(android.R.string.ok, (dialogInterface, i) -> {
            String friendlyName = editText.getText().toString();

            DialogsHolder.dismissDialog(mFriendlyNameDialogKey);

            if (buttonsResponseListener != null)
                buttonsResponseListener.onOkClicked(friendlyName);
        });

		builder.setNegativeButton(android.R.string.cancel, (dialogInterface, i) -> {
            DialogsHolder.dismissDialog(mFriendlyNameDialogKey);

            if (buttonsResponseListener != null)
                buttonsResponseListener.onCancelClicked();
        }
		);

		final AlertDialog dialog = builder.create();

		return dialog;
	}

	private static AlertDialog setupPINDialog(Activity activity, final IButtonsResponseWithTextListener buttonsResponseListener, String message) {
		final AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity);

		final View dialogLayout = activity.getLayoutInflater().inflate(R.layout.pin_dialog, null);
		builder.setView(dialogLayout);

		final EditText editText = dialogLayout.findViewById(R.id.editText);
		editText.setSingleLine(true);
		editText.setSelection(0, editText.getText().length());
		editText.requestFocus();

        TextView messageTextView = dialogLayout.findViewById(R.id.dialogMessage);
		if (!TextUtils.isEmpty(message)) {
			messageTextView.setText(message);
		} else {
            messageTextView.setVisibility(View.GONE);
        }

		builder.setPositiveButton(android.R.string.ok, (dialogInterface, i) -> {
            String pinText = editText.getText().toString();

            DialogsHolder.dismissDialog(mFriendlyNameDialogKey);

            if (buttonsResponseListener != null)
                buttonsResponseListener.onOkClicked(pinText);
        });

		builder.setNegativeButton(android.R.string.cancel, (dialogInterface, i) -> {
            DialogsHolder.dismissDialog(mFriendlyNameDialogKey);

            if (buttonsResponseListener != null)
                buttonsResponseListener.onCancelClicked();
        }
		);

		final AlertDialog dialog = builder.create();

		return dialog;
	}

	public static void showMessageDialog(Context context, int titleId, int messageId, final IButtonsResponseWithTextListener buttonsResponseListener) {
		
		if (DialogsHolder.isShowing(mMessageDialogKey))
			return;
		
		AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(context);
    	
    	builder.setTitle(titleId);
		builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(messageId, true));
		
		builder.setCancelable(true)
	       .setNegativeButton(android.R.string.cancel, (dialogInterface, id) -> {
                if (buttonsResponseListener != null)
                    buttonsResponseListener.onCancelClicked();
           })
	       .setPositiveButton(android.R.string.ok, (dialog, id) -> {
                if (buttonsResponseListener != null)
                    buttonsResponseListener.onOkClicked(null);
           });
		
		Dialog mMessageDialog = builder.create();
		mMessageDialog.setOnDismissListener(dialog -> {
            if (buttonsResponseListener != null)
                buttonsResponseListener.onCancelClicked();
        });
		
		DialogsHolder.addDialogToCollection(mMessageDialogKey, mMessageDialog);
		
		mMessageDialog.show();
	}

    public static void showMessageDialogWithOkButton(Activity activity, String dialogKey, int titleId, int messageId) {
        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, activity)) {
            return;
        }

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity);

        if (titleId != -1) {
            String title = activity.getString(titleId);
            if (title.contains(SmartRadioStringsManager.INSTANCE.getSMART_RADIO())) {
                builder.setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(titleId, true));
            } else if (title.contains(SmartRadioStringsManager.INSTANCE.getSMART_RADIOS())) {
                builder.setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(titleId, false));
            } else {
                builder.setTitle(titleId);
            }
        }
        if (messageId != -1) {
            String message = activity.getString(messageId);
            if (message.contains(SmartRadioStringsManager.INSTANCE.getSMART_RADIO())) {
                builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(messageId, true));
            } else if (message.contains(SmartRadioStringsManager.INSTANCE.getSMART_RADIOS())) {
                builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(messageId, false));
            } else {
                builder.setMessage(messageId);
            }
        }

        builder.setPositiveButton(android.R.string.ok, null);

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);
        dlg.show();
    }

}
