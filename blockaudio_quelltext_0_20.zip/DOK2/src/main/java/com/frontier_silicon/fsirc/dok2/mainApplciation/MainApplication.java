package com.frontier_silicon.fsirc.dok2.mainApplciation;

import android.app.Application;
import android.content.Context;
import android.os.StrictMode;

import androidx.multidex.MultiDex;
import androidx.appcompat.app.AppCompatActivity;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.ActivityLifecycleHandler;
import com.frontier_silicon.fsirc.dok2.BuildConfig;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.connection.ConnectionManager;
import com.frontier_silicon.fsirc.dok2.connection.RadioPINManager;
import com.frontier_silicon.fsirc.dok2.gdpr.GDPRVersionManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.dependencyInjection.ApplicationComponent;
import com.frontier_silicon.fsirc.dok2.mainApplciation.dependencyInjection.DaggerApplicationComponent;
import com.frontier_silicon.fsirc.dok2.notifications.NotificationManager;
import com.frontier_silicon.fsirc.dok2.presets.IPresetsControlListener;
import com.frontier_silicon.fsirc.dok2.presets.di.PresetsComponent;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.IOnItemSelected;
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.OpenSourceSoftwareActivity;
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.di.OpenSourceSoftwareComponent;
import com.frontier_silicon.fsirc.dok2.settings.theme.ThemeDialogManager;
import com.frontier_silicon.fsirc.dok2.settings.theme.UndokThemes;
import com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.di.ConnectivityAssistantComponent;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemeUtil;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.TraceLevel;

import java.util.ArrayList;
import java.util.List;

/**
 * Fassung 0.1 Block Audio (18.09.2026)
 *
 * Geaendert gegenueber dem Frontier-Original:
 *
 *  1. initFirebaseRemoteConfig() und alle Firebase-Einbindungen ENTFERNT.
 *     Grund: google-services.json war im uebergebenen Quelltext leer, es gibt kein
 *     Firebase-Projekt mehr. FirebaseRemoteConfig.getInstance() im Start der Anwendung
 *     ist der wahrscheinlichste Grund dafuer, dass die App kurz aufgeht und sofort
 *     wieder zu ist.
 *
 *  2. ENABLE_GDPR_VERSIONING auf false.
 *     Grund: Der Datenschutztext liegt auf Frontiers Azure-Speicher und ist Frontiers
 *     Text, nicht der von Block. Fuer den Store braucht Block einen eigenen; bis dahin
 *     faellt eine Serverabfrage beim Start weg, und der Startbildschirm geht IMMER
 *     durch zur Startseite, auch ohne Internet.
 *     Wieder einschalten: hier auf true setzen und in strings.xml gdpr_version_link
 *     auf die eigene Adresse legen.
 */
public class MainApplication extends Application {

    private static final boolean ENABLE_STRICT_MODE = false;

    private static final boolean ENABLE_GDPR_VERSIONING = false;

    private static Context mAppContext;
    private static boolean mIsInForeground = false;
    public static AppCompatActivity mActivity = null;

    private ActivityLifecycleHandler activityLifecycleHandler;

    private ApplicationComponent applicationComponent;
    private ConnectivityAssistantComponent connectivityAssistantComponent;
    private PresetsComponent presetsComponent;
    private OpenSourceSoftwareComponent openSourceSoftwareComponent;

    @Override
    protected void attachBaseContext(Context base) {
        setStrictMode(ENABLE_STRICT_MODE);

        super.attachBaseContext(base);

        MultiDex.install(this);
    }

    @Override
    public void onCreate() {

        super.onCreate();
        mAppContext = getApplicationContext();

        activityLifecycleHandler = new ActivityLifecycleHandler();
        registerActivityLifecycleCallbacks(activityLifecycleHandler);

        CommonPreferences.getInstance().init(getApplicationContext());
        UndokPreferences.getInstance().init(getApplicationContext());
        AccessPointUtil.init(getApplicationContext());

        TaskHelper.initRejectedExecutionHandler();

        initLogging();

        initTheme();

        bindWiFiToApplication();

        initNetRemoteLib();

        initThemeManager();

        initGDPRManager();

        initDagger();

        initSmartRadioManger();
    }

    protected void initThemeManager() {
        List<UndokThemes> themeList = new ArrayList<>();
        themeList.add(UndokThemes.DEFAULT);
        themeList.add(UndokThemes.DARK);

        ThemeDialogManager.getInstance().init(themeList);
    }

    private void setStrictMode(boolean enabled) {
        if (enabled) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                    .detectAll()
                    .penaltyLog()
                    .build());
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                    .detectAll()
                    .penaltyLog()
                    .build());
        }
    }

    private void initTheme() {
        int themeResId = ThemeUtil.getThemeResId();
        setTheme(themeResId);
    }

    private void bindWiFiToApplication() {
        if (AccessPointUtil.isConnectedToWiFi()) {
            AccessPointUtil.bindWifiNetworkToProcess();
        }
    }

    private void initNetRemoteLib() {
        int scannersFlag = NetRemote.SCANNER_SSDP | NetRemote.SCANNER_BONJOUR;
        boolean cacheRadios = true;
        boolean showAlsoMissingSpeakers = false;
        boolean enableProxySupport = BuildConfig.isInternalBuild;
        String httpsCertificates = getHttpsCertificates();

        NetRemoteManager.getInstance().initNetRemote(getApplicationContext(),
                getResources().getStringArray(R.array.vendor_id_array),
                getResources().getStringArray(R.array.firmware_blacklist),
                getResources().getStringArray(R.array.bonjour_service_type_array),
                scannersFlag, cacheRadios,
                showAlsoMissingSpeakers, enableProxySupport,
                httpsCertificates, AnalyticsSender.netRemoteAnalyticsCallback);

        NetRemoteManager.getInstance().setRadioPINManager(RadioPINManager.getInstance());
        RadioPINManager.getInstance().restorePINs(this);

        MultiroomGroupManager.getInstance().init(NetRemoteManager.getInstance());

        ConnectionStateUtil.getInstance().init();

        ConnectionManager.getInstance().restoreLastConnectedDevice();
        ConnectionManager.getInstance().setShouldAutoConnectToLastSpeaker(true);
    }

    private String getHttpsCertificates() {
        return getApplicationContext().getString(R.string.https_certificates);
    }

    private void initLogging() {
        FsLogger.initNewLogFile(getApplicationContext());
        setLoggingActive(CommonPreferences.getInstance().getLoggingEnabled());
        FsLogger.log("APP_VERSION", DokUiUtils.getAppVersion(mAppContext));
    }

    private void initGDPRManager() {
        GDPRVersionManager.setGDPREnabled(ENABLE_GDPR_VERSIONING);
    }

    static public void setLoggingActive(boolean enabled) {
        if (enabled) {
            FsLogger.setLogTraceFlag(TraceLevel.TRACE_ALL_BIT);
            FsLogger.startLogging();
        } else {
            FsLogger.stopLogging();
            FsLogger.setLogTraceFlag(TraceLevel.TRACE_DEFAULT);
        }

        FsLogger.log("APP_VERSION", DokUiUtils.getAppVersion(mAppContext));
    }

    static public Context getContext() {
        return mAppContext;
    }

    static public boolean isInForeground() {
        return mIsInForeground;
    }

    static public AppCompatActivity getCurrentActivity() {
        return mActivity;
    }

    public static void setAppIsInForeground(boolean state) {
        mIsInForeground = state;

        if (state) {
            NotificationManager.getInstance().setContext(mAppContext);
        }
    }

    private void initSmartRadioManger() {
        SmartRadioStringsManager.INSTANCE.registerListener();
    }

    private void initDagger() {
        applicationComponent = DaggerApplicationComponent.builder()
                .application(this)
                .build();
    }

    public ConnectivityAssistantComponent initConnectivityAssistantComponent() {
        if (connectivityAssistantComponent == null) {
            connectivityAssistantComponent = applicationComponent.getConnectivityAssistantFactory().create();
        }

        return connectivityAssistantComponent;
    }

    public void deinitConnectivityAssistantComponent() {
        connectivityAssistantComponent = null;
    }

    public PresetsComponent initPresetsComponent(IPresetsControlListener listener) {
        if (presetsComponent == null) {
            presetsComponent = applicationComponent.getPresetsComponentFactory().presetsModule(listener).build();
        }

        return presetsComponent;
    }

    public void deinitPresetsComponent() {
        presetsComponent = null;
    }

    public OpenSourceSoftwareComponent initOpenSourceComponent(IOnItemSelected listener, OpenSourceSoftwareActivity activity) {
        if (openSourceSoftwareComponent == null) {
            openSourceSoftwareComponent = applicationComponent.getOpenSourceSoftwareBuilder().openSourceModule(listener)
                    .setContext(activity)
                    .setViewModelOwner(activity)
                    .build();
        }

        return openSourceSoftwareComponent;
    }

    public void deinitOpenSourceSoftwareComponent() {
        openSourceSoftwareComponent = null;
    }
}
