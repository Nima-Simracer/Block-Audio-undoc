package com.frontier_silicon.fsirc.dok2.sources;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import java.util.List;
import java.util.Map;

public class SourcesExpandableArrayAdapter extends BaseExpandableListAdapter {

    private final int GROUP_ITEM = 0;
    private final int GROUP_ITEM_WITH_TINTED_ICON = 1;
    private final int GROUP_HEADER_ITEM = 2;
    private final int GROUP_CAST_ITEM = 3;
    private final int GROUP_CAST_ITEM_WITH_TINTED_ICON = 4;

    private Map<SourceItemModel, List<SourceItemModel>> mSourcesMap;
    private List<SourceItemModel> mSourcesList;

    private Context mContext;

    public SourcesExpandableArrayAdapter(Context context, List<SourceItemModel> sourcesList, Map<SourceItemModel, List<SourceItemModel>> sourcesMap) {
        mContext = context;
        mSourcesList = sourcesList;
        mSourcesMap = sourcesMap;
    }

    public int getSize(){
        return mSourcesList.size();
    }

    @Override
    public int getGroupCount() {
        return mSourcesList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return mSourcesMap.get(mSourcesList.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return mSourcesList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return mSourcesMap.get(mSourcesList.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }


    @Override
    public int getGroupType(int groupPosition) {
        SourceItemModel item = (SourceItemModel) getGroup(groupPosition);

        if (item.mKey != SourcesRadioUtil.INVALID_MODE_KEY) {
            NodeSysCapsValidModes.Mode mode = NodeSysCapsValidModes.ConvertIdToEnum(item.mModeId);
            if (mode.isAirable() || item.mModeId.equals(NodeSysCapsValidModes.Mode.Spotify.name()) ||
                    item.mModeId.equals(NodeSysCapsValidModes.Mode.DAB.name())) {
                return GROUP_ITEM;
            } else {
                return GROUP_ITEM_WITH_TINTED_ICON;
            }
        } else {
            if (item.mApp == SourceItemModel.CastApp.MoreApps) {
                return GROUP_CAST_ITEM_WITH_TINTED_ICON;
            } else if (item.mApp != SourceItemModel.CastApp.NONE) {
                return GROUP_CAST_ITEM;
            } else {
                return GROUP_HEADER_ITEM;
            }
        }
    }

    @Override
    public int getGroupTypeCount() {
        return 5;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        View v = convertView;
        LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        SourceItemModel sourceItemModel = (SourceItemModel) getGroup(groupPosition);
        int groupType = getGroupType(groupPosition);

        if (v == null) {
            v = inflateLayoutForGroupType(groupType);
        }

        if (groupType == GROUP_ITEM || groupType == GROUP_ITEM_WITH_TINTED_ICON) {
            boolean isTinted = groupType == GROUP_ITEM_WITH_TINTED_ICON;
            return bindDataToGroupItem(groupPosition, isExpanded, v, sourceItemModel, isTinted);

        } else if (groupType == GROUP_HEADER_ITEM) {
            return bindDataToGroupHeaderItem(v, sourceItemModel);

        } else if (groupType == GROUP_CAST_ITEM || groupType == GROUP_CAST_ITEM_WITH_TINTED_ICON) {
            boolean isTinted = groupType == GROUP_CAST_ITEM_WITH_TINTED_ICON;
            return bindDataToCastItem(v, sourceItemModel, isTinted);
        }

        v.setTag(sourceItemModel);

        return v;
    }

    private View inflateLayoutForGroupType(int groupType) {
        LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (groupType == GROUP_ITEM || groupType == GROUP_ITEM_WITH_TINTED_ICON) {
            return li.inflate(R.layout.source_expandable_group_header_list_item, null);

        } else if (groupType == GROUP_HEADER_ITEM) {
            return li.inflate(R.layout.group_header_list_item, null);

        } else if (groupType == GROUP_CAST_ITEM || groupType == GROUP_CAST_ITEM_WITH_TINTED_ICON) {
            return li.inflate(R.layout.source_app_list_item, null);
        }

        return null;
    }

    private View bindDataToGroupItem(int groupPosition, boolean isExpanded, View v, SourceItemModel sourceItemModel, boolean isTinted) {
        // standard selectable mode

        TextView tv = v.findViewById(R.id.text1);
        tv.setText(getText(sourceItemModel));

        String secondaryText = getSecondaryText(sourceItemModel, true, isExpanded, getChildrenCount(groupPosition));
        TextView secondaryTextView = v.findViewById(R.id.textSecondary);
        if (TextUtils.isEmpty(secondaryText)) {
            secondaryTextView.setVisibility(View.GONE);
        } else {
            secondaryTextView.setVisibility(View.VISIBLE);
            secondaryTextView.setText(secondaryText);
        }

        ImageView icon = v.findViewById(R.id.imageIcon);
        int iIconId = SourceIconsResourceIdFactory.getModeIconResId(NodeSysCapsValidModes.ConvertIdToEnum(sourceItemModel.mModeId));
        if (iIconId >= 0) {
            icon.setImageResource(iIconId);

            if (isTinted) {
                GuiUtils.setTintToDrawable(icon.getDrawable(), v.getContext(), R.attr.sources_icon_color);
            }

            icon.setVisibility(View.VISIBLE);
        } else {
            icon.setVisibility(View.GONE);
        }

        ImageView imgSelected = v.findViewById(R.id.imageViewSelected);
        if (sourceItemModel.mIsCurrentModeSelected && !isExpanded) {
            imgSelected.setVisibility(View.VISIBLE);
        } else {
            imgSelected.setVisibility(View.GONE);
        }

        tv.setTypeface(null, Typeface.NORMAL);

        ImageView expandableIndicatorImage = v.findViewById(R.id.imageGroupIndicator);

        if (getChildrenCount(groupPosition) > 0) {
            expandableIndicatorImage.setVisibility(View.VISIBLE);

            if (isExpanded) {
                expandableIndicatorImage.setImageResource(R.drawable.ic_expanditemarrow);
            } else {
                expandableIndicatorImage.setImageResource(R.drawable.ic_expanditemarrow_down);
            }
        } else {
            expandableIndicatorImage.setVisibility(View.GONE);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            v.setElevation(isExpanded ? mContext.getResources().getDimension(R.dimen.sources_list_header_elevation) : 0);
        }

        return v;
    }

    private View bindDataToGroupHeaderItem(View v, SourceItemModel sourceItemModel) {
        TextView tv = v.findViewById(R.id.text1);
        tv.setText(getText(sourceItemModel));

        return v;
    }

    private View bindDataToCastItem(View v, SourceItemModel sourceItemModel, boolean isTinted) {
        int iIconId = SourceIconsResourceIdFactory.getModeIconResId(sourceItemModel.mApp);

        ImageView appIcon = v.findViewById(R.id.appIcon);
        if (iIconId >= 0) {
            appIcon.setImageResource(iIconId);
            if (isTinted) {
                GuiUtils.setTintToDrawable(appIcon.getDrawable(), v.getContext(), R.attr.sources_icon_color);
            }
            appIcon.setVisibility(View.VISIBLE);
        } else {
            appIcon.setVisibility(View.GONE);
        }

        TextView tv = v.findViewById(R.id.text1);
        tv.setText(getText(sourceItemModel));

        return v;
    }



    @Override
    public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        View v = convertView;
        LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        SourceItemModel item = (SourceItemModel) getChild(groupPosition, childPosition);

        // selectable mode
        if (item.mKey != SourcesRadioUtil.INVALID_MODE_KEY) {

            if (v == null || v.getTag() == null || !(((SourceItemModel) v.getTag()).mKey != SourcesRadioUtil.INVALID_MODE_KEY)) {
                v = li.inflate(R.layout.source_list_item, null);
            }

            TextView tv = v.findViewById(R.id.text1);
            tv.setText(getChildText(item));

            TextView secondaryTextView = v.findViewById(R.id.textSecondary);
            secondaryTextView.setVisibility(View.GONE);

            ImageView icon = v.findViewById(R.id.imageIcon);
            int iIconId = SourceIconsResourceIdFactory.getModeIconResId(NodeSysCapsValidModes.ConvertIdToEnum(item.mModeId));
            if (iIconId >= 0) {
                icon.setImageResource(iIconId);
                icon.setVisibility(View.VISIBLE);
            } else {
                icon.setVisibility(View.GONE);
            }

            icon.setVisibility(View.GONE);

            ImageView imgSelected = v.findViewById(R.id.imageViewSelected);
            if (item.mIsCurrentModeSelected) {
                imgSelected.setVisibility(View.VISIBLE);
            } else {
                imgSelected.setVisibility(View.GONE);
            }

            tv.setTypeface(null, Typeface.NORMAL);
        } else {
            // mode group header
            if (v == null || v.getTag() == null || !(((SourceItemModel)v.getTag()).mKey == SourcesRadioUtil.INVALID_MODE_KEY) ) {
                v = li.inflate(R.layout.group_header_list_item, null);
            }

            TextView tv = v.findViewById(R.id.text1);
            tv.setText(getText(item));
        }

        v.setTag(item);

        return v;
    }

    private String getText(SourceItemModel modeItem) {
        if (modeItem.mModeId.equalsIgnoreCase(NodeSysCapsValidModes.Mode.DMR.name())) {
            return mContext.getResources().getString(R.string.fs_dok_mode_localmusic);
        } else {
            return modeItem.mName;
        }
    }

    private String getSecondaryText(SourceItemModel modeItem, boolean isGroupHeader, boolean isExpanded, int numChildren) {
        String text = "";

        if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {

            boolean secondaryTextVisible = false;

            if (isGroupHeader) {
                if (!isExpanded && (modeItem.mIsCurrentModeSelected || numChildren <= 0)) {
                    secondaryTextVisible = true;
                }
            } else {
                secondaryTextVisible = true;
            }

            if (secondaryTextVisible) {
                if (modeItem.mKey >= 0 && SourcesRadioUtil.isModeWithOwnInput(modeItem.mModeId)) {
                    if (modeItem.mRadio != null) {
                        text = mContext.getString(R.string.source_on, DokUiUtils.getFriendlyNameOrStereoSystemName(modeItem.mRadio));
                    } else {
                        Radio currRadio = NetRemoteManager.getInstance().getCurrentRadio();
                        if (currRadio != null) {
                            text = mContext.getString(R.string.source_on, DokUiUtils.getFriendlyNameOrStereoSystemName(currRadio));
                        }
                    }
                }
            }
        }

        return text;
    }

    private String getChildText(SourceItemModel modeItem) {
        if (modeItem.mModeId.equalsIgnoreCase(NodeSysCapsValidModes.Mode.DMR.name()))
            return mContext.getResources().getString(R.string.fs_dok_mode_localmusic) + " " + getSecondaryText(modeItem, false, false, 0) ;
        else
            return modeItem.mName + " " + getSecondaryText(modeItem, false, false, 0);
    }

    /**
     * Iterates over the collection of items and
     * removed the selection pick from any active modes
     */
    public void removeSelectionTick() {
        for (SourceItemModel currentMode : mSourcesList) {
            if (currentMode.mIsCurrentModeSelected) {
                currentMode.mIsCurrentModeSelected = false;
            }
        }
    }

    public void dispose() {
        mContext = null;
        mSourcesList.clear();
        mSourcesMap.clear();
    }
}
