package com.frontier_silicon.fsirc.dok2.nowPlaying.standby;

import android.view.View;

import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;

public class NowPlayingStandbyViewModel {

    public void onEnablePowerClicked(View v) {
        SpeakerDataManager.getInstance().enablePower(true);
    }
}
