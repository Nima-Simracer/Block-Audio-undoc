package com.frontier_silicon.fsirc.dok2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import com.frontier_silicon.fsirc.dok2.connection.ConnectionManager;
import com.frontier_silicon.fsirc.dok2.home.HomeActivity;
import com.frontier_silicon.fsirc.dok2.setup.welcome.WelcomeActivity;

/**
 * Created by lsuhov on 10/04/16.
 */
public class NavigationHelper {

    public enum AnimationType {
        Normal,
        /**
         * Right to left
         */
        SlideToLeft,
        /**
         * Left to right
         */
        SlideToRight,
        /**
         * From down to up
         */
        SlideUp,
        /**
         * From up to down
         */
        SlideDown
    }

    public static final String CONNECTION_LOST_ARG = "ConnectionLost";
    public static final String RADIO_UDN_ARG = "radioUDN";
    public static final String GROUP_ID = "groupId";
    public static final String EXTERNAL_SPOTIFY_LINKING = "EXTERNAL_SPOTIFY_LINKING";

//    public static void goToHome(Activity activity) {
//        if (activity == null || activity.getClass() == HomeActivity.class)
//            return;
//
//        Intent mainActivityIntent = new Intent(activity, HomeActivity.class);
//
//        activity.startActivity(mainActivityIntent);
//        activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
//        //activity.finish();
//    }


    public static void goToHomeAndClearActivityStack(Activity activity) {
        if (activity == null || activity.getClass() == HomeActivity.class)
            return;

        Intent mainActivityIntent = new Intent(activity, HomeActivity.class);
        mainActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        activity.startActivity(mainActivityIntent);
        activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }

    public static void goToSetupActivity(Activity currentActivity) {
        SpeakersDiscoveryManager.getInstance().stopDiscovery();
        ConnectionManager.getInstance().cleanup();

        goToActivity(currentActivity, WelcomeActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    public static void goToActivity(Activity currentActivity, Class<?> cls) {
        goToActivity(currentActivity, cls, NavigationHelper.AnimationType.SlideToLeft, false, null);
    }

    public static void goToActivity(Activity currentActivity, Class<?> cls, AnimationType animationType) {
        goToActivity(currentActivity, cls, animationType, false, null);
    }

    public static void goToActivity(Activity currentActivity, Class<?> cls, AnimationType animationType,
                                    boolean forgetCurrentActivity) {
        goToActivity(currentActivity, cls, animationType, forgetCurrentActivity, null);
    }

    public static void goToActivity(Activity currentActivity, Class<?> cls, Bundle bundle) {
        goToActivity(currentActivity, cls, NavigationHelper.AnimationType.SlideToLeft, false, bundle);
    }

    public static void goToActivity(Activity currentActivity, Class<?> cls, AnimationType animationType,
                                    boolean forgetCurrentActivity, Bundle bundle) {
        if (currentActivity == null || currentActivity.getClass() == cls) {
            return;
        }

        Intent mainActivityIntent = new Intent(currentActivity, cls);
        if (bundle != null) {
            mainActivityIntent.putExtras(bundle);
        }
        currentActivity.startActivity(mainActivityIntent);

        setTransition(currentActivity, animationType);

        if (forgetCurrentActivity) {
            currentActivity.finish();
        }
    }

    public static void goToActivityForResult(Activity currentActivity, Class<?> cls, AnimationType animationType,
                                              Bundle bundle, int requestCode) {
        if (currentActivity == null || currentActivity.getClass() == cls) {
            return;
        }

        Intent mainActivityIntent = new Intent(currentActivity, cls);
        if (bundle != null) {
            mainActivityIntent.putExtras(bundle);
        }

        setTransition(currentActivity, animationType);

        currentActivity.startActivityForResult(mainActivityIntent, requestCode);
    }

    public static void goToActivityForResult(Fragment fragment, Class<?> cls, AnimationType animationType,
                                             Bundle bundle, int requestCode) {
        if (fragment == null || fragment.getClass() == cls) {
            return;
        }

        Activity parent = fragment.getActivity();
        if (parent == null) {
            return;
        }

        Intent mainActivityIntent = new Intent(parent, cls);
        if (bundle != null) {
            mainActivityIntent.putExtras(bundle);
        }

        setTransition(parent, animationType);

        fragment.startActivityForResult(mainActivityIntent, requestCode);
    }

    public static void goToActivityClearingCurrentStack(Activity currentActivity, Class<?> cls, AnimationType animationType) {
        if (currentActivity == null || currentActivity.getClass() == cls) {
            return;
        }

        Intent intent = new Intent(currentActivity, cls);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        setTransition(currentActivity, animationType);

        currentActivity.startActivity(intent);
    }

    public static void goToExistingActivityAndClearBackStack(Activity currentActivity, Class<?> cls, AnimationType animationType) {
        if (currentActivity == null || currentActivity.getClass() == cls) {
            return;
        }


        Intent intent = new Intent(currentActivity, cls);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        setTransition(currentActivity, animationType);

        currentActivity.startActivity(intent);
    }

    public static void openLink(Activity currentActivity, String url, AnimationType animationType) {
        if (currentActivity == null) {
            return;
        }

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        currentActivity.startActivity(browserIntent);

        setTransition(currentActivity, animationType);
    }

    private static void setTransition(Activity currentActivity, AnimationType animationType) {
        if (currentActivity == null) {
            return;
        }

        switch (animationType) {

            case Normal:
                break;
            case SlideToLeft:
                currentActivity.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
                break;
            case SlideToRight:
                currentActivity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                break;
            case SlideUp:
                currentActivity.overridePendingTransition(R.anim.slide_in_up, R.anim.stay_animation);
                break;
            case SlideDown:
                currentActivity.overridePendingTransition(R.anim.slide_in_down, R.anim.stay_animation);
                break;
        }
    }
}
