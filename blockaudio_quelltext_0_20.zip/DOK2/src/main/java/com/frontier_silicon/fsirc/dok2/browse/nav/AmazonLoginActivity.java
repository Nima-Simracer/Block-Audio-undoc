package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavAmazonMpLoginComplete;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.loggerlib.FsLogger;

import static com.frontier_silicon.NetRemoteLib.Node.BaseNavAmazonMpLoginComplete.Ord.TRUE;

public class AmazonLoginActivity extends UndokActivityBase {

    boolean loginProcessStarted = false;
    boolean nodeWasSetted = false;
    WebView myWebView;
    String url = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.airable_amazon_login_activity);


        setupControls();
        setupAppBar();
        setTitle(R.string.amazon_login);

        Intent intent = getIntent();
        String message = intent.getStringExtra("AmazonLoginURL");
        loadAmazonLoginURl(message);

    }

    public void loadAmazonLoginURl(String url) {
        this.url = url;
        loadAmazonLoginURl();
    }

    protected void loadAmazonLoginURl() {
        // Configure the client to use when opening URLs
        if (myWebView != null && url != "") {
            myWebView.setWebViewClient(new MyAmazonLoginClient());
            myWebView.loadUrl(url);
        }
    }

    protected void setupControls() {
        myWebView = (WebView) findViewById(R.id.webview);
        // Configure related browser settings
        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    }


    // Manages the behavior when URLs are loaded
    private class MyAmazonLoginClient extends WebViewClient {

    @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (url.contains("airable.io/"))  {
                    if (loginProcessStarted && !nodeWasSetted) {
                        // set node
                        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
                        if (radio != null ) {
                            radio.setNode(new NodeNavAmazonMpLoginComplete(TRUE), false, new ISetNodeCallback() {
                                @Override
                                public void setNodeSuccess(NodeInfo node) {
                                    FsLogger.log("Amazon login notification successfully send to speaker");
                                    nodeWasSetted = true;
                                }

                                @Override
                                public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                                    FsLogger.log("Amazon login notification unsuccessfully send to speaker");
                                    nodeWasSetted = true;
                                }
                            });

                        }
                        NavBrowseManager.getInstance().resetNavToRoot();
                        finish();
                    }else{
                        loginProcessStarted = true;
                    }
            }
            else
                if ((url.contains("www.amazon.com") || (url.contains("na.account.amazon.com") && Build.VERSION.SDK_INT == Build.VERSION_CODES.M)) && !nodeWasSetted)
                    loginProcessStarted = true;
        }

        @TargetApi(Build.VERSION_CODES.N)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            view.loadUrl(request.getUrl().toString());
            return true;
        }
    }
}
