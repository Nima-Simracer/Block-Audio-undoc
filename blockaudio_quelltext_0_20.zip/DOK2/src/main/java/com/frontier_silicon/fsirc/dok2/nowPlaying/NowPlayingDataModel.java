package com.frontier_silicon.fsirc.dok2.nowPlaying;

import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import androidx.databinding.ObservableInt;
import androidx.databinding.ObservableLong;
import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.Node.BasePlayRating;
import com.frontier_silicon.NetRemoteLib.Node.BasePlayRepeat;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayCaps;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIpodDockStatus;

/**
 * Created by hcostescu on 10/05/17.
 */

public class NowPlayingDataModel {

    public ObservableField<String> playInfoName = new ObservableField<>();
    public ObservableField<String> playInfoText = new ObservableField<>();
    public ObservableField<String> artist = new ObservableField<>();
    public ObservableField<String> album = new ObservableField<>();
    public ObservableField<NodePlayCaps> playCaps = new ObservableField<>(new NodePlayCaps(0L));
    public ObservableField<NodePlayStatus> playStatus = new ObservableField<>();
    public ObservableLong duration = new ObservableLong();
    public ObservableField<BasePlayRepeat.Ord> repeatMode = new ObservableField<>(BasePlayRepeat.Ord.OFF);
    public ObservableBoolean isShuffle = new ObservableBoolean(false);
    public ObservableBoolean isShuffleError = new ObservableBoolean();
    public ObservableLong elapsedTime = new ObservableLong();
    public ObservableField<String> playError = new ObservableField<>();
    public ObservableField<String> castingApp = new ObservableField<>();
    public ObservableField<String> trackDescription = new ObservableField<>();
    public ObservableField<String> infoAlbumDescription = new ObservableField<>();
    public ObservableField<String> infoArtistDescription = new ObservableField<>();
    public ObservableField<String> playErrorMsg = new ObservableField<>();
    public ObservableField<String> playErrPopupMessage = new ObservableField<>("");
    public ObservableBoolean isElapsedTimeVisible = new ObservableBoolean(false);
    public ObservableField<NodeSysIpodDockStatus.Ord> iPodDockStatus = new ObservableField<>(NodeSysIpodDockStatus.Ord.NOT_DOCKED);
    public ObservableField<String> graphicUri = new ObservableField<>("");
    public ObservableInt fmPercentProgress = new ObservableInt();
    public ObservableBoolean dmrPlaying = new ObservableBoolean(false);
    public ObservableField<String> trackUri = new ObservableField<>("");
    public ObservableField<BasePlayRating.Ord> songRating = new ObservableField<>(BasePlayRating.Ord.NEUTRAL);
    public ObservableLong trackUpdated = new ObservableLong();
    public ObservableField<String> providerLogoUri = new ObservableField<>("");
    public ObservableField<String> providerName = new ObservableField<>("");
    public ObservableField<String> concurrencyString = new ObservableField<>("");
    public ObservableField<String> notificationMessage = new ObservableField<>("");

    public void resetToDefault(){

        playInfoName.set("");
        playInfoText.set("");
        artist.set("");
        album.set("");
        duration.set(0);
        repeatMode.set(BasePlayRepeat.Ord.OFF);
        isShuffle .set(false);
        isShuffleError.set(false);
        elapsedTime.set(0);
        playError.set("");
        castingApp.set("");
        trackDescription.set("");
        infoAlbumDescription.set("");
        infoArtistDescription.set("");
        playErrorMsg.set("");
        playErrPopupMessage.set("");
        isElapsedTimeVisible.set(false);
        iPodDockStatus.set(NodeSysIpodDockStatus.Ord.NOT_DOCKED);
        graphicUri.set("");
        fmPercentProgress.set(0);
        dmrPlaying.set(false);
        trackUri.set("");
        songRating.set(BasePlayRating.Ord.NEUTRAL);
        playCaps.set(new NodePlayCaps(0L));
        concurrencyString.set("");
        notificationMessage.set("");
        providerLogoUri.set("");
        providerName.set("");
    }

    public boolean isPlaying() {
        boolean isPlaying = false;
        if (playStatus.get() != null) {
            if (playStatus.get().getValueEnum() == NodePlayStatus.Ord.PLAYING){
                isPlaying = true;
            }
        }

        return isPlaying;
    }

    public boolean isPaused() {
        boolean isPaused = false;
        if (playStatus.get() != null) {
            isPaused = (playStatus.get().getValueEnum() == NodePlayStatus.Ord.PAUSED);
        }

        return isPaused;
    }

    public boolean isBuffering() {
        boolean isBuffering = false;
        if (playStatus.get() != null) {
            isBuffering = (playStatus.get().getValueEnum() == NodePlayStatus.Ord.BUFFERING ||
                    playStatus.get().getValueEnum() == NodePlayStatus.Ord.REBUFFERING);
        }

        return isBuffering;
    }

    public boolean isError() {
        boolean isError = false;
        if (playStatus.get() != null) {
            isError = (playStatus.get().getValueEnum() == NodePlayStatus.Ord.ERROR);
        }

        return isError;
    }

    public boolean isShuffleError() {
        boolean isError = false;
        if (playStatus.get() != null) {
            isError = isShuffleError.get();
        }

        return isError;
    }

    public boolean isIdle() {
        boolean isIdle = false;
        if (playStatus.get() != null) {
            isIdle = (playStatus.get().getValueEnum().equals(NodePlayStatus.Ord.IDLE));
        }

        return isIdle;
    }

    public boolean isStopped() {
        boolean isStopped = false;
        if (playStatus.get() != null) {
            isStopped = (playStatus.get().getValueEnum() == NodePlayStatus.Ord.STOPPED);
        }

        return isStopped;
    }

    public boolean isErrorPopup() {
        boolean isErrorPopup = false;
        if (playStatus.get() != null) {
            isErrorPopup = (playStatus.get().getValueEnum() == NodePlayStatus.Ord.ERROR_POPUP);
        }

        return isErrorPopup;
    }

    public boolean isPauseAvailable() {
        boolean isAvailable = false;

        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.Pause));
        }

        return isAvailable;
    }

    public boolean isStopAvailable() {
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = playCaps.get().DoesSupport(NodePlayCaps.Operation.Stop);
        }

        return isAvailable;
    }

    public boolean isNextAvailable(){
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.SkipNext));
        }
        return  isAvailable;
    }

    public boolean isPreviousAvailable(){
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.SkipPrevious));
        }
        return  isAvailable;
    }

    public boolean isShuffleAvailable() {
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.Shuffle));
        }

        return isAvailable;
    }

    public boolean isRepeatAvailable() {
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = playCaps.get().DoesSupport(NodePlayCaps.Operation.Repeat);
        }

        return isAvailable;
    }

    public boolean isSeekBarAvailable() {
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.Seek));
        }

        return isAvailable;
    }

    public boolean isThumbsUpAvailable() {
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.ThumbsUp));
        }

        return isAvailable;
    }

    public boolean isThumbsDownAvailable() {
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.ThumbsDown));
        }

        return isAvailable;
    }

    public boolean isSkipForwardAvailable() {
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.SkipForward));
        }

        return isAvailable;
    }

    public boolean isSkipBackwardAvailable() {
        boolean isAvailable = false;
        if (playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.SkipBackward));
        }

        return isAvailable;
    }

    public boolean isRepeatOneAvailable() {
        boolean isAvailable = false;
        if(playCaps.get() != null) {
            isAvailable = (playCaps.get().DoesSupport(NodePlayCaps.Operation.RepeatOne));
        }

        return isAvailable;
    }

    public String getAlbumSearchQuery() {
        if (!TextUtils.isEmpty(playInfoText.get())) {
            return playInfoText.get();
        } else {
            if (!TextUtils.isEmpty(album.get()))
                return getSearchQuery();
            else {
                if (TextUtils.isEmpty(artist.get()))
                    return "";
                else
                    return getSearchQuery();
            }
        }
    }

    public String getSearchQuery() {
        return artist + " " +  playInfoName.get() + " " + album;
    }

    public boolean isIPodDocked() {
        return iPodDockStatus.get() == NodeSysIpodDockStatus.Ord.DOCKED_ONLINE_READY;
    }
}
