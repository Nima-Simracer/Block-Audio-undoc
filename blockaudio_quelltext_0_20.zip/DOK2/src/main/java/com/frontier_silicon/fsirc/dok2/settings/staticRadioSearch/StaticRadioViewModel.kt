package com.frontier_silicon.fsirc.dok2.settings.staticRadioSearch

import android.content.Context
import androidx.lifecycle.ViewModel
import com.frontier_silicon.NetRemoteLib.Discovery.DeviceRecord
import com.frontier_silicon.NetRemoteLib.Discovery.deviceSerializer.DeviceDetailsSerializerManager
import com.frontier_silicon.components.NetRemoteManager
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender

open class StaticRadioViewModel: ViewModel() {

     fun searchRadioByIp(ipAddress: String) {
         AnalyticsSender.sendStartSearchRadioByIpEvent()
         NetRemoteManager.getInstance().netRemote.staticRadioDiscovery.startStaticRadioDiscovery(ipAddress)
    }

    fun cacheDeviceRecord(context: Context, record: DeviceRecord) {
        DeviceDetailsSerializerManager.getInstance().saveSearchedByIpRecord(context, record)
        NetRemoteManager.getInstance().netRemote.addSearchedByIPRecord(record)
    }
}