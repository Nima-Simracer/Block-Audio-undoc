package com.frontier_silicon.fsirc.dok2.settings;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;

import com.frontier_silicon.NetRemoteLib.NetRemoteAnalyticsCallback;
import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.fsirc.dok2.gdpr.GDPRVersionManager;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.loggerlib.FsLogger;

/**
 * Fassung 0.1 Block Audio (18.09.2026)
 *
 * WICHTIGSTE AENDERUNG DES GANZEN PAKETS.
 *
 * Im Original stand hier:
 *     private static FirebaseAnalytics mFirebaseAnalytics =
 *             FirebaseAnalytics.getInstance(MainApplication.getContext());
 *
 * Das ist ein STATISCHES Feld. Es wird in dem Augenblick ausgefuehrt, in dem die Klasse
 * zum ersten Mal angefasst wird — und das passiert in MainApplication.initNetRemote()
 * ueber AnalyticsSender.netRemoteAnalyticsCallback, also mitten im Start der App,
 * vor dem ersten Bild. Wirft Firebase dort eine Ausnahme, stirbt die App sofort und
 * ohne Meldung. Genau das Bild: geht kurz auf, geht wieder zu.
 *
 * Firebase ist deshalb komplett ersetzt durch einen Eintrag ins eigene Protokoll.
 * Alle Methoden heissen weiter gleich, damit der Rest der App unveraendert bleibt.
 * Wenn spaeter eine eigene Auswertung gewuenscht ist, muss nur ereignis() umgebogen
 * werden — an genau einer Stelle.
 */
public class AnalyticsSender {

    private static void ereignis(String name, Bundle daten) {
        try {
            if (daten == null) {
                FsLogger.log("EREIGNIS " + name);
            } else {
                FsLogger.log("EREIGNIS " + name + " " + daten.toString());
            }
        } catch (Throwable ignored) {
            // Protokoll darf die App niemals umbringen
        }
    }

    public static NetRemoteAnalyticsCallback netRemoteAnalyticsCallback = new NetRemoteAnalyticsCallback() {
        @Override
        public void sendDDXMLNotRespondingEvent(String error) {
            AnalyticsSender.sendDDXMLNotRespondingEvent(error);
        }

        @Override
        public void sendFSApiDataRetrievedSuccessfully() {
            AnalyticsSender.sendFSApiDataRetrievedSuccessfully();
        }

        @Override
        public void sendFSApiDataRetrievedUnsuccessfully(String error) {
            AnalyticsSender.sendFSApiDataRetrievedUnsuccessfully(error);
        }
    };

    public static void sendThemeAnalytics() {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }

        int themeIndex = CommonPreferences.getInstance().getCurrentThemeIndex();

        if (themeIndex > 1) {
            return;
        }

        String[] themeNames = new String[] {"Default", "Dark"};

        Bundle bundle = new Bundle();
        bundle.putString("Theme_Name", themeNames[themeIndex]);
        bundle.putInt("Theme_Index", themeIndex);

        ereignis("Theme_Usage", bundle);
    }

    public static void sendFontAnalytics(Context context) {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }

        Configuration configuration = context.getResources().getConfiguration();
        float scale = configuration.fontScale;

        Bundle bundle = new Bundle();
        bundle.putFloat("Font_Scale", scale);
        bundle.putString("Font_Scale_String", String.valueOf(scale));
        ereignis("Font", bundle);
    }

    public static void sendMusicSourceChangingAnalytics(String currentMode) {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }

        Bundle bundle = new Bundle();
        bundle.putString("Music_Source", currentMode);
        ereignis("Music_Source", bundle);
    }

    public static void sendNewAudioSystemTappingAnalytics() {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }
        ereignis("Setup_Audio_System", null);
    }

    public static void setupAudioSystemFinishedSuccessfully(String firmwareVersion) {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putString("Firmware_Version", firmwareVersion);
        ereignis("Setup_Audio_System_Finished_Successfully", bundle);
    }

    public static void sendIsVeniceXUnderSetupEvent(String firmwareVersion) {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putString("Firmware_Version", firmwareVersion);
        ereignis("VeniceX_Setup", bundle);
    }

    public static void sendVeniceXSetupSuccessfully(String firmwareVersion) {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putString("Firmware_Version", firmwareVersion);
        ereignis("VeniceX_Setup_Successfully_Done", bundle);
    }

    public static void sendGroupButtonTappingAnalytics() {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }
        ereignis("Audio_Systems_Group", null);
    }

    public static void sendIRStation(String stationName, long id) {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putString("Station_Name", stationName);
        bundle.putLong("Station_ID", id);
        ereignis("Selected_Radio_Station", bundle);
    }

    public static void sendStartSearchRadioByIpEvent() {
        ereignis("Start_Search_Radio_By_IP", null);
    }

    public static void sendFoundRadioByIpEvent() {
        ereignis("Found_Radio_By_IP", null);
    }

    public static void sendNOTFoundRadioByIpEvent() {
        ereignis("NOT_Found_Radio_By_IP", null);
    }

    public static void sendConnectivityAssistantStartedEvent() {
        ereignis("Connectivity_Assistant_Started", null);
    }

    public static void sendConnectivityAssistantSmartRadioFound() {
        ereignis("Connectivity_Assistant_Speaker_Found", null);
    }

    public static void sendConnectivityAssistantSmartRadioCanceled() {
        ereignis("Connectivity_Assistant_Canceled", null);
    }

    public static void sendDDXMLNotRespondingEvent(String error) {
        Bundle bundle = new Bundle();
        bundle.putString("Error", error);
        ereignis("DdXml_Not_Responding", bundle);
    }

    public static void sendFSApiDataRetrievedSuccessfully() {
        ereignis("Fs_Api_Data_Retrieved_Successfully", null);
    }

    public static void sendFSApiDataRetrievedUnsuccessfully(String error) {
        Bundle bundle = new Bundle();
        bundle.putString("Error", error);
        ereignis("Fs_Api_Data_Retrieved_UnSuccessfully", bundle);
    }

    public static void sendInstallEvent() {
        if (!GDPRVersionManager.firstCheckIsDone()) {
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putBoolean("INSTALL", true);
        ereignis("INSTALL", bundle);

        UndokPreferences.getInstance().setInstallEventSent();
    }

    public static void sendIsVeniceXDevice() {
        ereignis("Is_VeniceX_SmartRadio", null);
    }

    public static void sendIsNotVeniceXDevice() {
        ereignis("Is_NOT_VeniceX_SmartRadio", null);
    }

    public static void sendShareNowPlayingEvent() {
        ereignis("NOW_PLAYING_SHARE", null);
    }

    public static void sendSmartRadioNumberEvent(int smartRadioNumber) {
        Bundle bundle = new Bundle();
        bundle.putInt("SmartRadioNumber", smartRadioNumber);
        ereignis("Smart_Radio_Number", bundle);
    }

    public static void sendMoreThenOneVeniceXDevices(int smartRadioNumber) {
        Bundle bundle = new Bundle();
        bundle.putInt("VeniceXNumber", smartRadioNumber);
        ereignis("More_Than_One_VeniceX_Devices", bundle);
    }

    public static void sendOktivDownloadButtonPressed() {
        ereignis("Oktiv_DOWNLOAD_Button_Pressed", null);
    }

    public static void sendOktivCancelButtonPressed() {
        ereignis("Oktiv_CANCEL_Button_Pressed", null);
    }

    public static void sendOktivNeverShowAgainButtonPressed() {
        ereignis("Oktiv_NEVER_SHOW_AGAIN_Button_Pressed", null);
    }

    public static void sendNotificationUsageOnce() {
        ereignis("Notification_Usage", null);
    }
}
