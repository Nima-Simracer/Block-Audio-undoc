package com.frontier_silicon.fsirc.dok2.stereo.selectPrimary;

import android.app.Activity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.StereoSpeakerListItemBinding;
import com.frontier_silicon.fsirc.dok2.databinding.StereoSystemListItemBinding;
import com.frontier_silicon.fsirc.dok2.stereo.StereoSpeakerListItemViewModel;
import com.frontier_silicon.fsirc.dok2.stereo.StereoSpeakersDiffCallback;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 03/08/2017.
 */

public class SelectPrimarySpeakerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<StereoItemModel> mStereoItemModels = new ArrayList<>();
    private Activity mActivity;

    public SelectPrimarySpeakerAdapter(Activity activity) {
        mActivity = activity;
    }

    private class StereoSpeakerViewHolder extends RecyclerView.ViewHolder {
        StereoSpeakerListItemBinding mBinding;

        StereoSpeakerViewHolder(StereoSpeakerListItemBinding binding) {
            super(binding.getRoot());

            mBinding = binding;
        }
    }

    private class StereoSystemViewHolder extends RecyclerView.ViewHolder {
        StereoSystemListItemBinding mBinding;

        StereoSystemViewHolder(StereoSystemListItemBinding binding) {
            super(binding.getRoot());

            mBinding = binding;
        }
    }

    public void swapItems(List<StereoItemModel> stereoItemModels) {
        StereoSpeakersDiffCallback diffCallback = new StereoSpeakersDiffCallback(mStereoItemModels, stereoItemModels);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        mStereoItemModels.clear();
        mStereoItemModels.addAll(stereoItemModels);

        diffResult.dispatchUpdatesTo(this);
    }

    @Override
    public int getItemViewType(int position) {
        StereoItemModel stereoItemModel = mStereoItemModels.get(position);

        return stereoItemModel.itemType;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case StereoItemModel.SPEAKER: {
                StereoSpeakerListItemBinding binding = DataBindingUtil.inflate(
                        LayoutInflater.from(parent.getContext()),
                        R.layout.stereo_speaker_list_item,
                        parent, false);

                return new StereoSpeakerViewHolder(binding);
            }
            case StereoItemModel.STEREO_SYSTEM: {
                StereoSystemListItemBinding binding = DataBindingUtil.inflate(
                        LayoutInflater.from(parent.getContext()),
                        R.layout.stereo_system_list_item,
                        parent, false);

                return new StereoSystemViewHolder(binding);
            }
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
        StereoItemModel stereoItemModel = mStereoItemModels.get(position);

        switch (stereoItemModel.itemType) {
            case StereoItemModel.SPEAKER: {
                StereoSpeakerViewHolder stereoSpeakerViewHolder = (StereoSpeakerViewHolder)viewHolder;
                StereoSpeakerListItemBinding binding = stereoSpeakerViewHolder.mBinding;

                StereoSpeakerListItemViewModel viewModel = new PrimarySpeakerListItemViewModel(stereoItemModel, mActivity);
                binding.setViewModel(viewModel);

                break;
            }
            case StereoItemModel.STEREO_SYSTEM: {
                StereoSystemViewHolder stereoSystemViewHolder = (StereoSystemViewHolder)viewHolder;
                StereoSystemListItemBinding binding = stereoSystemViewHolder.mBinding;

                StereoSystemListItemViewModel viewModel = new StereoSystemListItemViewModel(stereoItemModel, mActivity);
                binding.setViewModel(viewModel);

                break;
            }
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder viewHolder) {

        if (viewHolder instanceof StereoSpeakerViewHolder) {
            StereoSpeakerViewHolder stereoSpeakerViewHolder = (StereoSpeakerViewHolder)viewHolder;
            StereoSpeakerListItemViewModel speakerViewModel = stereoSpeakerViewHolder.mBinding.getViewModel();

            if (speakerViewModel != null) {
                speakerViewModel.dispose();
                stereoSpeakerViewHolder.mBinding.setViewModel(null);
            }
        } else if (viewHolder instanceof StereoSystemViewHolder) {
            StereoSystemViewHolder stereoSystemViewHolder = (StereoSystemViewHolder)viewHolder;
            StereoSystemListItemViewModel coupleViewModel = stereoSystemViewHolder.mBinding.getViewModel();

            if (coupleViewModel != null) {
                coupleViewModel.dispose();
                stereoSystemViewHolder.mBinding.setViewModel(null);
            }
        }
    }

    @Override
    public int getItemCount() {
        return mStereoItemModels.size();
    }

    public void dispose() {
        mStereoItemModels.clear();
        mActivity = null;
    }
}
