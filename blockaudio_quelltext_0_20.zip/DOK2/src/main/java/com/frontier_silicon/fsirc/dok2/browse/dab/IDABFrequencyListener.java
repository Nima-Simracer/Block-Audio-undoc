package com.frontier_silicon.fsirc.dok2.browse.dab;

public interface IDABFrequencyListener {

	void onDABScanUpdated(boolean isScanning);
	
}
