package com.frontier_silicon.fsirc.dok2.settings.equalizer;

import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioEqPreset;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.RadioFromBundleExtractor;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;

public class EqualizerActivity extends UndokActivityBase implements IEqualizerListener,
        ICustomEditListener, ICustomEqualizerControlListener {

    private EqualizerArrayAdapter mAdapter;
    private ArrayList<EqualizerItemModel> mEqualizerItemsList;

    private EqualizerUtil mEqualizerUtil;

    private Radio mClientRadio;
    private INodeNotificationCallback mEqPresetNotifListener;
    private ProgressBar mProgressBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.equalizer_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.equalizer);

        Bundle bundle = getIntent().getExtras();
        mClientRadio = RadioFromBundleExtractor.extractRadio(bundle, EqualizerActivity.class);

        setupControls();

        initSpeakerConnectionLostWatcher();
        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
        addUdnToSpeakerLostWatcher(bundle.getString(NavigationHelper.RADIO_UDN_ARG));
    }

    @Override
    protected void onStart() {
        super.onStart();

        mProgressBar.setVisibility(View.VISIBLE);

        if (mEqualizerUtil == null) {
            mEqualizerUtil = new EqualizerUtil();
            mEqualizerUtil.addListener(this);
        }

        mEqualizerUtil.setClientRadio(mClientRadio);

        updateEqualizerList();
    }

    public void onResume() {
        super.onResume();

        registerNodeChangeNotifCallback();
    }

    public void onPause() {
        super.onPause();
        unregisterNodeChangeNotifCallback();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mClientRadio = null;
    }

    private void setupControls() {
        mProgressBar = findViewById(R.id.progressBar);
        mEqualizerItemsList = new ArrayList<>();

        mAdapter = new EqualizerArrayAdapter(this, R.layout.equalizer_list_item, R.id.text1, mEqualizerItemsList, this, this);
        ListView mListView = (ListView) findViewById(R.id.equalizersList);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                onListItemClick(position);
            }
        });
    }

    protected void onListItemClick(int position) {
        try {
            EqualizerItemModel eqItem = mAdapter.getItem(position);
            setEqualizer(eqItem);
        } catch (Exception e) {
        }
    }

    private void setEqualizer(EqualizerItemModel eqItem) {
        mEqualizerUtil.setEqualizerPreset(eqItem.mKeyId);

        selectEqualizerInList(eqItem.mKeyId);
    }

    private void selectEqualizerInList(long keyId) {
        for (EqualizerItemModel eqItem : mEqualizerItemsList) {
            if (eqItem.mKeyId == keyId) {
                eqItem.mIsSet = true;
            } else {
                eqItem.mIsSet = false;
            }
        }

        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    private void updateEqualizerList() {
        mEqualizerUtil.updateEqualizerPresetsList();
    }

    @Override
    public void onEqualizerPresetsUpdate(ArrayList<EqualizerItemModel> eqList) {
        if (eqList != null && mAdapter != null) {
            mEqualizerItemsList.clear();
            mEqualizerItemsList.addAll(eqList);
            mAdapter.notifyDataSetChanged();

            mProgressBar.setVisibility(View.GONE);
        } else if (eqList == null && mAdapter != null) {
            mEqualizerItemsList.clear();
            mAdapter.notifyDataSetChanged();

            mProgressBar.setVisibility(View.GONE);
        }
    }

    public void registerNodeChangeNotifCallback() {
        unregisterNodeChangeNotifCallback();

        if (NetRemoteManager.getInstance().checkConnection()) {
            mEqPresetNotifListener = new INodeNotificationCallback() {
                @Override
                public void onNodeUpdated(NodeInfo node) {
                    if (node instanceof NodeSysAudioEqPreset) {
                        onEqualizerPresetChanged();
                    }
                }
            };

            NetRemoteManager.getInstance().getCurrentRadio().addNotificationListener(mEqPresetNotifListener);
        }
    }

    public void unregisterNodeChangeNotifCallback() {
        if (NetRemoteManager.getInstance().checkConnection()) {
            if (mEqPresetNotifListener != null) {
                NetRemoteManager.getInstance().getCurrentRadio().removeNotificationListener(mEqPresetNotifListener);
            }
        }
    }

    protected void onEqualizerPresetChanged() {

        if (!DokUiUtils.isDestroyed(this)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    updateEqualizerList();
                }
            });
        }
    }

    @Override
    public void onListItemClick(EqualizerItemModel item) {
        setEqualizer(item);
    }

    @Override
    public void onValueChange(CustomEqualizerItemModel item) {
        FsLogger.log("CUSTOM EQ " + item.mName + " " + item.mValue);

        mEqualizerUtil.setCustomEqualizerBandValue(mClientRadio, item);
    }

    @Override
    public void onLoudnessValueChange(boolean isEnabled) {
        mEqualizerUtil.setEqualizerLoudness(mClientRadio, isEnabled);
    }
}
