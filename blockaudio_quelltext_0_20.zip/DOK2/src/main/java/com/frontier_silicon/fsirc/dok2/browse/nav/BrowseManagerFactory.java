package com.frontier_silicon.fsirc.dok2.browse.nav;

import com.frontier_silicon.fsirc.dok2.browse.nav.navAirable.NavMessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.navAirable.NavFormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.MessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable.ContextFormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable.ContextMessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.ContextBrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseManager;

/**
 * Created by lsuhov on 25/11/2016.
 */

public class BrowseManagerFactory {

    public static final int NavBrowse = 0;
    public static final int ContextBrowse = 1;

    public static BrowseManager getBrowseManager(int browseType) {
        if (browseType == NavBrowse) {
            return NavBrowseManager.getInstance();
        } else {
            return ContextBrowseManager.getInstance();
        }
    }

    public static FormManager getFormManager(int browseType) {
        if (browseType == NavBrowse) {
            return NavFormManager.getInstance();
        } else {
            return ContextFormManager.getInstance();
        }
    }

    public static MessageManager getMessageManager(int browseType) {
        if (browseType == NavBrowse) {
            return NavMessageManager.getInstance();
        } else {
            return ContextMessageManager.getInstance();
        }
    }
}
