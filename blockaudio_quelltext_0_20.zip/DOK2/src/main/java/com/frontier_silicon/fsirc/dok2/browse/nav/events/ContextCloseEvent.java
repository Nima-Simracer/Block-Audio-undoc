package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by lsuhov on 02/07/16.
 */

public class ContextCloseEvent {
    //by default, on dismiss the underlying NavList should be refreshed. If in a specific case we dont want
    private boolean mShouldRefreshUnderlying = true;

    public boolean getShouldRefreshUnderlying(){
        return this.mShouldRefreshUnderlying;
    }

    public ContextCloseEvent(boolean value){
        this.mShouldRefreshUnderlying = value;
    }
}
