package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant

import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.frontier_silicon.NetRemoteLib.Discovery.DeviceRecord
import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener
import com.frontier_silicon.NetRemoteLib.Discovery.staticRadioDiscovery.IStaticRadioDiscoveryListener
import com.frontier_silicon.NetRemoteLib.Radio.Radio
import com.frontier_silicon.components.NetRemoteManager
import com.frontier_silicon.components.common.DialogsHolder
import com.frontier_silicon.fsirc.dok2.NavigationHelper
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase
import com.frontier_silicon.fsirc.dok2.databinding.ConnectivityAssistantActivityBinding
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender
import com.frontier_silicon.fsirc.dok2.settings.SettingsType
import com.frontier_silicon.fsirc.dok2.settings.gdpr.SettingsWebViewActivity
import com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.fragmetns.CAFragmentFactory
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder
import com.google.android.material.tabs.TabLayoutMediator
import javax.inject.Inject

class ConnectivityAssistantActivity : UndokActivityBase(), LifecycleObserver, IStaticRadioDiscoveryListener, IRadioDiscoveryListener {

    private lateinit var binding: ConnectivityAssistantActivityBinding
    private lateinit var adapter: CAViewPagerAdapter
    private lateinit var viewModel: ConnectivityAssistantViewModel

    @Inject
    lateinit var fragmentFactory: CAFragmentFactory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycle.addObserver(this)
        binding = DataBindingUtil.setContentView(this, R.layout.connectivity_assistant_activity)
        viewModel = ViewModelProvider(this).get(ConnectivityAssistantViewModel::class.java)
        binding.lifecycleOwner = this
        binding.viewModel = viewModel

        inject()
        setupAppBar()
        setTitle(R.string.connectivity_assistant_title);
        initViewPager()
        initTabLayout()

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
    }

   private fun inject() {
        (application as MainApplication).initConnectivityAssistantComponent().inject(this)
    }

    private fun initViewPager() {
        adapter = CAViewPagerAdapter(fragmentFactory, supportFragmentManager, lifecycle)
        binding.viewPager.adapter = adapter
        binding.viewPager.isUserInputEnabled = false

        TabLayoutMediator(binding.assistantTabLayout, binding.viewPager) { tab, _ ->
            run {
                binding.viewPager.setCurrentItem(tab.position, true)
                tab.view.isClickable = false
            }
        }.attach()
    }

    private fun initObservers() {
        viewModel.startRadioSearch.observe(this, {
            if (it) {
                setSearchingState()
            }
        })
    }

    private fun initTabLayout() {
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
            }

            override fun onPageSelected(position: Int) {
                when (position) {
                    0 -> { setFirstPosition() }
                    1 -> { setSecondPosition() }
                    2 -> { setThirdPosition() }
                    3 -> { setForthPosition() }

                }
            }
            override fun onPageScrollStateChanged(state: Int) {
            }
        })
    }


    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    fun registerListener() {
        initObservers()
        registerSpeakersDiscoveryListener()
        if (binding.viewPager.currentItem == 0) {
            setFirstPosition()
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    fun removeObserver() {
        unregisterSpeakersDiscoveryListener()
    }

    fun onNext(v: View) {
        var nextPage = binding.viewPager.currentItem + 1

        if (nextPage < 4) {
            viewModel.rescan()
            binding.viewPager.currentItem = nextPage
        } else {
            viewModel.ipAddressToSearch.value?.let {
                setSearchingState()
                viewModel.searchRadioByIp(it)
            }
        }
    }

    fun onCancel(v: View) {
        AnalyticsSender.sendConnectivityAssistantSmartRadioCanceled()
        super.onBackPressed()
    }

    override fun onStaticRadioDiscovered(deviceRecord: DeviceRecord) {
        this.runOnUiThread {
            viewModel.cacheDeviceRecord(this, record = deviceRecord)
            AnalyticsSender.sendFoundRadioByIpEvent()
            dismissSearchingState()
        }
    }

    override fun onStaticRadioNotFound(deviceRecord: DeviceRecord) {
        this.runOnUiThread {
            AnalyticsSender.sendNOTFoundRadioByIpEvent()
            showFAQAlertDialog()
            dismissSearchingState()
        }
    }

    private fun showFAQAlertDialog() {
        val builder = ThemedAlertDialogBuilder.create(this)
        builder.setTitle(getString(R.string.FAQ))
                .setMessage(SmartRadioStringsManager.getSmartRadioString((R.string.no_devices_found), false))
                .setPositiveButton(R.string.open_faq) { dialog: DialogInterface?, id: Int -> openFAQ() }
                .setNegativeButton(android.R.string.cancel, null)

        val dialog = builder.create()
        DialogsHolder.addDialogToCollection("FAQ_DIALOG", dialog)
        dialog.show()
    }

    private fun openFAQ() {
        val bundle = Bundle()
        bundle.putString("SETTINGS_TYPE_KEY", SettingsType.FAQ.name)
        NavigationHelper.goToActivity(this, SettingsWebViewActivity::class.java, bundle)
        finish()
    }

    private fun setSearchingState() {
        viewModel.nextButtonState.value = false
        binding.progressBar.visibility = View.VISIBLE
    }

    private fun dismissSearchingState() {
        viewModel.nextButtonState.value = true
        binding.progressBar.visibility = View.INVISIBLE
    }


    private fun registerSpeakersDiscoveryListener() {
        NetRemoteManager.getInstance().addRadioDiscoveryListener(this)
        NetRemoteManager.getInstance().netRemote.staticRadioDiscovery.setListener(this)
    }

    private fun unregisterSpeakersDiscoveryListener() {
        NetRemoteManager.getInstance().removeRadioDiscoveryListener(this)
        NetRemoteManager.getInstance().netRemote.staticRadioDiscovery.removeListeners()
    }

    override fun onRadioFound(radio: Radio?) {
        this.runOnUiThread {
            AnalyticsSender.sendConnectivityAssistantSmartRadioFound()
            super.onBackPressed()
        }
    }

    override fun onRadioLost(radio: Radio?, rescanInProgress: Boolean) {
    }

    override fun onRadioUpdated(radio: Radio?) {
    }

    private fun setFirstPosition() {
        if (DokUiUtils.isLightTheme()) {
            binding.assistantTabLayout.getTabAt(0)?.setIcon(R.drawable.assistant_selected_dot_light)
            binding.assistantTabLayout.getTabAt(1)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(2)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(3)?.setIcon(R.drawable.assistant_default_dot_dark_black)

        } else {
            binding.assistantTabLayout.getTabAt(0)?.setIcon(R.drawable.assistant_selected_dot_dark_black)
            binding.assistantTabLayout.getTabAt(1)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(2)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(3)?.setIcon(R.drawable.assistant_default_dot_dark_black)
        }
    }

    private fun setSecondPosition() {
        if (DokUiUtils.isLightTheme()) {
            binding.assistantTabLayout.getTabAt(0)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(1)?.setIcon(R.drawable.assistant_selected_dot_light)
            binding.assistantTabLayout.getTabAt(2)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(3)?.setIcon(R.drawable.assistant_default_dot_dark_black)
        } else {
            binding.assistantTabLayout.getTabAt(0)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(1)?.setIcon(R.drawable.assistant_selected_dot_dark_black)
            binding.assistantTabLayout.getTabAt(2)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(3)?.setIcon(R.drawable.assistant_default_dot_dark_black)
        }
    }

    private fun setThirdPosition() {
        if (DokUiUtils.isLightTheme()) {
            binding.assistantTabLayout.getTabAt(0)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(1)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(2)?.setIcon(R.drawable.assistant_selected_dot_light)
            binding.assistantTabLayout.getTabAt(3)?.setIcon(R.drawable.assistant_default_dot_dark_black)
        } else {
            binding.assistantTabLayout.getTabAt(0)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(1)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(2)?.setIcon(R.drawable.assistant_selected_dot_dark_black)
            binding.assistantTabLayout.getTabAt(3)?.setIcon(R.drawable.assistant_default_dot_dark_black)
        }
    }

    private fun setForthPosition() {
        if (DokUiUtils.isLightTheme()) {
            binding.assistantTabLayout.getTabAt(0)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(1)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(2)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(3)?.setIcon(R.drawable.assistant_selected_dot_light)

        } else {
            binding.assistantTabLayout.getTabAt(0)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(1)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(2)?.setIcon(R.drawable.assistant_default_dot_dark_black)
            binding.assistantTabLayout.getTabAt(3)?.setIcon(R.drawable.assistant_selected_dot_dark_black)
        }
    }



    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    fun handleOnPause(){
        if(isFinishing){
            (application as MainApplication).deinitConnectivityAssistantComponent()
        }
    }

    /**
     * Release component if onDestroy is called when activity stack is cleared and this activity
     * is not on top of the stack.
     */
    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun handleOnDestroy(){
        if(isFinishing) {
            (application as MainApplication).deinitConnectivityAssistantComponent()
        }
    }

}