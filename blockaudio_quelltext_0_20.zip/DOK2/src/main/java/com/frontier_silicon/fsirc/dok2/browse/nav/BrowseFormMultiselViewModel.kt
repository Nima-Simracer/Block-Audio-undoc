package com.frontier_silicon.fsirc.dok2.browse.nav

import android.content.Context
import android.content.DialogInterface
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormCombobox
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormComboboxOption
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ComboboxItemsLoadedEvent
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder
import kotlin.math.pow


class BrowseFormMultiselViewModel(val position: Int, item: FormItem, var context: Context?) :
    BrowseFormItemBaseViewModel(position, item) {
     var multiselItems: List<FormComboboxOption?>  = ArrayList()
     var selectedList: Array<Boolean> = emptyArray()
     var allLanguages: Array<String> = emptyArray()


    init {
        EventBus.getDefault().register(this)
    }

    fun getComboboxItems(): List<FormComboboxOption?> {
        return (mFormItemBase as FormCombobox).formComboBoxOptions
    }

    fun onItemSelected(position: Int) {
        (mFormItemBase as FormCombobox).setSelectedOption(position)
    }

    @Subscribe
    fun onComboboxLoadedResult(event: ComboboxItemsLoadedEvent?) {
        multiselItems = getComboboxItems()
    }

    fun onMultiSelItemCLicked() {
        multiselItems = getComboboxItems()
        if (multiselItems.isEmpty()) {
            return
        }
        if (allLanguages.isEmpty() && selectedList.isEmpty()) {
            allLanguages = multiselItems?.size?.let { Array(it) { "" } }!!
            selectedList = Array(multiselItems.size){false}

            for (i in multiselItems.indices) {
                allLanguages[i] = multiselItems[i]?.name ?: ""
                selectedList[i] = multiselItems[i]?.isSelected ?: false

            }
        }
        val builder = ThemedAlertDialogBuilder.create(context)


        builder.setTitle(label.get())
        builder.setMultiChoiceItems(
            allLanguages, selectedList.toBooleanArray()
        ) { _, checkedItem, isChecked ->
            selectedList[checkedItem] = isChecked
        }

        builder.setPositiveButton(android.R.string.ok) { _, _ ->
            setSelectedOptions()
        }

//        builder.setNegativeButton(android.R.string.cancel) { dialog, _ ->
//            selectedList = Array(multiselItems.size){false}
//            dialog.dismiss()
//        }

        builder.show()
    }

    private fun setSelectedOptions() {
        if (mFormItemBase == null) {
            return
        }

        var selectedNumber: Double = 0.0
        for (i in selectedList.indices) {
            if (selectedList[i]) {
                selectedNumber += 2.toDouble().pow(i.toDouble())
            }
        }

        (mFormItemBase as FormCombobox).setMultiselSelectedOption(selectedNumber.toInt())
    }

    override fun dispose() {
        super.dispose()
        context = null

        EventBus.getDefault().unregister(this)
    }

}