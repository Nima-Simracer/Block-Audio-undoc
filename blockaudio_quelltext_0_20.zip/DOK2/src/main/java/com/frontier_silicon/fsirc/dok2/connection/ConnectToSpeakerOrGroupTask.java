package com.frontier_silicon.fsirc.dok2.connection;

import android.app.Activity;
import android.content.Context;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysPower;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.BaseShowProgressDialogTask;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.connection.AfterConnectionNodesSetter;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.browse.dmr.BrowseDMRFragment;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.volume.VolumeManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

public class ConnectToSpeakerOrGroupTask extends BaseShowProgressDialogTask<Boolean> {
	
	private Radio mRadio;
    private boolean mIsServer;
    private boolean mShowProgress = false;
    private boolean mFailSilently = false;
	private IConnectToSpeakerOrGroup mListener;
	
	public ConnectToSpeakerOrGroupTask(Context context, Radio radio, boolean isServer, boolean showProgress,
                                       boolean failSilently, IConnectToSpeakerOrGroup listener) {
		mContext = context;

		mRadio = radio;
        mIsServer = isServer;
        mShowProgress = showProgress;
        mFailSilently = failSilently;
		mListener = listener;
		mDialogKey = "connect_to_another_radio";
        TASK_TIMEOUT_MS = 60_000;

        if (isServer) {
            mLoadingMessage = mContext.getString(R.string.connecting_group_server);
        } else {
            mLoadingMessage = mContext.getString(R.string.connecting_to_another_radio, DokUiUtils.getFriendlyNameOrStereoSystemName(mRadio));
        }

		mDialogCancelable = false;
	}

    @Override
    protected void onPreExecute() {
        if (!mShowProgress) {
            return;
        }

        if (mContext != null && !DialogsHolder.isShowingOrActivityIsFinishing(mDialogKey, (Activity)mContext)) {
            showProgressDialog();

            initTimeoutTimer();
        }
    }

	@Override
	protected Boolean doInBackground(Integer... arg0) {
		if (mRadio != null) {
			boolean connected = MultiroomGroupManager.getInstance().connectToRadio(mRadio, mFailSilently);

            if (connected) {
                prepareForNewRadio();
            }

            return connected;
		} else {
			return false;
		}
	}

    private void prepareForNewRadio() {
        if (mIsServer) {
            AfterConnectionNodesSetter.setTransportOptimisationToAllClientsSync(mRadio);
        } else {
            AfterConnectionNodesSetter.enableNodesAfterConnection(mRadio);
        }

        if (!mFailSilently) {
            // force IR autoplay and keep network connected (19258)
            powerOnIfStandBy();
        }

        BrowseDMRFragment.mPermissionRequestShown = false;

        SpeakerDataManager.getInstance().bindToRadio(mRadio);
        VolumeManager.getInstance().bindToRadio(mRadio);

        NowPlayingManager.getInstance().bindToRadio(mRadio);
    }

    private void powerOnIfStandBy() {
        if (mRadio.isInStandby()) {
            mRadio.setNode(new NodeSysPower(NodeSysPower.Ord.ON), true);
        }
    }

	@Override
	protected void onPostExecute(Boolean result) {
		super.onPostExecute(result);
		
		if (result == null) {
			result = false;
		}
		
		if (mListener != null) {
			mListener.onConnectedToSpeakerOrGroup(result, mIsServer);
			mListener = null;
		}
	}

}
