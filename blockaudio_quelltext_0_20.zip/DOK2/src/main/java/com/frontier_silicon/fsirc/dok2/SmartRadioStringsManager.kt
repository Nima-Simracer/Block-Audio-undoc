package com.frontier_silicon.fsirc.dok2

import android.os.Build
import android.util.Log
import androidx.databinding.ObservableBoolean
import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener
import com.frontier_silicon.NetRemoteLib.Radio.Radio
import com.frontier_silicon.components.NetRemoteManager
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication

object SmartRadioStringsManager : IRadioDiscoveryListener {
    val SMART_RADIO: String = "SmartRadio"
    val SMART_RADIOS: String = "SmartRadios"

    val isAnySmartRadioAvailable: ObservableBoolean = ObservableBoolean(false)

    fun registerListener() {
        NetRemoteManager.getInstance().addRadioDiscoveryListener(this)

    }

    override fun onRadioFound(radio: Radio?) {
        for (radio in NetRemoteManager.getInstance().radios) {
            if (radio.deviceRecord.hasDAB) {
                isAnySmartRadioAvailable.set(true)
                return
            }
        }
        isAnySmartRadioAvailable.set(false)
    }

    override fun onRadioLost(radio: Radio?, rescanInProgress: Boolean) {
        for (radio in NetRemoteManager.getInstance().radios) {
            if (radio.deviceRecord.hasDAB) {
                isAnySmartRadioAvailable.set(true)
                return
            }
        }
        isAnySmartRadioAvailable.set(false)
    }

    override fun onRadioUpdated(radio: Radio?) {}


    fun getSmartRadioString(smartRadioString: String, isSingular: Boolean): String {
        return getReplacedString(smartRadioString, isSingular)
    }

    fun getSmartRadioString(string: Int, isSingular: Boolean): String {
        var resourceString = MainApplication.getContext().resources.getString(string)
       return getReplacedString(resourceString, isSingular)
    }

    fun getSmartRadioString(string: Int, isSingular: Boolean, capitalize: Boolean): String {
        var resourceString = MainApplication.getContext().resources.getString(string)
        return getReplacedString(resourceString, isSingular, capitalize)
    }

    fun getSmartRadioString(resourceString: String, isSingular: Boolean, capitalize: Boolean): String {
        return getReplacedString(resourceString, isSingular, capitalize)
    }

    private fun getReplacedString(resourceString: String, isSingular: Boolean, capitalize: Boolean = false): String {
        if (!resourceString.contains(SMART_RADIO) && isSingular) {
            return resourceString
        }

        if (!resourceString.contains(SMART_RADIOS) && !isSingular) {
            return resourceString
        }

        val valueToReplace = if (isSingular) {
            SMART_RADIO
        } else {
            SMART_RADIOS
        }

        return if (isAnySmartRadioAvailable.get()) {
            resourceString
        } else {
            var replacementString = getReplacementString(isSingular)
            if (capitalize) {
                replacementString = replacementString.capitalize()
            }

            resourceString.replace(valueToReplace, replacementString)
        }
    }

    private fun getReplacementString(isSingular: Boolean): String {
        val currentLanguage = getCurrentLocale()
        var replaceWith = "Audio System"

        when (currentLanguage) {
            "en" -> {
                replaceWith = if (isSingular) {
                    "audio system"
                } else {
                    "audio systems"
                }
            }
            "bg" -> {
                replaceWith = if (isSingular) {
                    "аудио система"
                } else {
                    "аудио системи"
                }
            }
            "cs" -> {
                replaceWith = if (isSingular) {
                     "audio systém"
                } else {
                     "audio systémy"
                }
            }
            "da" -> {
                replaceWith = if (isSingular) {
                    "lydsystem"
                } else {
                    "lydsystemer"
                }
            }
            "de" -> {
                replaceWith = if (isSingular) {
                    "Audiosystem"
                } else {
                    "Audiosysteme"
                }
            }
            "el" -> {
                replaceWith = if (isSingular) {
                    "ηχοσυστήματος"
                } else {
                    "ηχοσυστήματα"
                }
            }
            "es" -> {
                replaceWith = if (isSingular) {
                    "equipo de sonido"
                } else {
                    "equipos de sonido"
                }
            }
            "fr" -> {
                replaceWith = if (isSingular) {
                    "système audio"
                } else {
                    "systèmes audio"
                }
            }
            "it" -> {
                replaceWith = if (isSingular) {
                    "sistema audio"
                } else {
                    "sistemi audio"
                }
            }
            "nb" -> {
                replaceWith = if (isSingular) {
                    "lydsystem"
                } else {
                    "lydsystemer"
                }
            }
            "pl" -> {
                replaceWith = if (isSingular) {
                    "system audio"
                } else {
                    "audio systémy"
                }
            }
            "ro" -> {
                replaceWith = if (isSingular) {
                    "sistem audio"
                } else {
                    "sisteme audio"
                }
            }
            "sk" -> {
                replaceWith = if (isSingular) {
                    "audio systém"
                } else {
                    "audio systémov"
                }
            }
            "sv" -> {
                replaceWith = if (isSingular) {
                    "audiosystem"
                } else {
                    "ljudsystem"
                }
            }
        }

        return replaceWith
    }

    private fun getCurrentLocale(): String {
        var currentLocale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            MainApplication.getContext().resources.configuration.locales.get(0)
        } else {
            MainApplication.getContext().resources.configuration.locale
        }

        Log.d("LOCALE:", currentLocale.language)
        return currentLocale.language
    }

}