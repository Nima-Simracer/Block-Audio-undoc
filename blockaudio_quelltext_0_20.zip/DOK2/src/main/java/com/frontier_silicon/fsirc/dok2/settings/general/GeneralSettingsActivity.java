package com.frontier_silicon.fsirc.dok2.settings.general;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.view.MenuItem;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.widgets.DividerItemDecoration;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.SettingsGeneralActivityBinding;
import com.frontier_silicon.fsirc.dok2.home.HomeActivity;
import com.frontier_silicon.fsirc.dok2.settings.account.FSAuthManager;

/**
 * Created by lsuhov on 10/10/2017.
 */

public class GeneralSettingsActivity extends UndokActivityBase {

    private SettingsGeneralActivityBinding mBinding;
    private GeneralSettingsViewModel mViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.settings_general_activity);
        mViewModel = new GeneralSettingsViewModel(this);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.undok_settings);

        setupControls();
    }

    private void setupControls() {
        mBinding.recyclerView.setLayoutManager(new LinearLayoutManager(this));

        DividerItemDecoration itemDecoration = new DividerItemDecoration(this, LinearLayoutManager.VERTICAL);
        mBinding.recyclerView.addItemDecoration(itemDecoration);

        mBinding.recyclerView.setAdapter(mViewModel.getAdapter());
    }

    @Override
    protected void onResume() {
        mViewModel.onResume();

        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }

        DialogsHolder.dismissAllRegisteredDialogs();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }

        return true;
    }

    @Override
    public void onBackPressed() {
        if (FSAuthManager.getInstance().getWasAccountDeleted()) {
            NavigationHelper.goToActivity(this, HomeActivity.class, NavigationHelper.AnimationType.SlideToRight, true);
            FSAuthManager.getInstance().setWasAccountDeleted(false);
        } else {
           super.onBackPressed();
        }
    }
}
