package com.frontier_silicon.fsirc.dok2.settings.avs

import androidx.lifecycle.MutableLiveData
import com.frontier_silicon.NetRemoteLib.Node.NodeAvsAlarmVolume
import com.frontier_silicon.NetRemoteLib.Radio.Radio
import com.frontier_silicon.components.common.RadioNodeUtil
import com.frontier_silicon.loggerlib.FsLogger

class AvsSettingsViewModel {
    val currentVolume: MutableLiveData<Long> by lazy {
        MutableLiveData<Long>().also {
            getCurrentVolume()
        }
    }

    private var radio: Radio? = null


    fun setRadio(radio: Radio) {
        this.radio = radio
    }

    private fun getCurrentVolume() {
        if (radio == null) {
            return
        }

        RadioNodeUtil.getNodeFromRadioAsync(radio, NodeAvsAlarmVolume::class.java) { node ->
            val volume = node as NodeAvsAlarmVolume?
            if (volume != null) {
                currentVolume.value = volume.value
            }
        }
    }

     fun setSpeakerVolume(newVolume: Int) {
        if (newVolume.toLong() != currentVolume.value) {
            currentVolume.value = newVolume.toLong()

            // setting node
            if (radio == null) {
                return
            }

            FsLogger.log("AVS: volume set to :$newVolume")
            val avsVolume = NodeAvsAlarmVolume(currentVolume.value)
            radio!!.setNode(avsVolume, false)
        }
    }
}