package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

/**
 * Created by cvladu on 04/03/2018.
 */

public class RefreshFsdcaListEvent {

    public RefreshFsdcaListEvent(){}

}
