package com.frontier_silicon.fsirc.dok2.settings.equalizer;

public interface ICustomEditListener {

	void onListItemClick(EqualizerItemModel item);
	
}
