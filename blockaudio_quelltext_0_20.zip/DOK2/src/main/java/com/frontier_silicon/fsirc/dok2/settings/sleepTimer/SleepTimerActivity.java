package com.frontier_silicon.fsirc.dok2.settings.sleepTimer;

import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.View;
import android.widget.Button;

import android.widget.TextView;


import com.frontier_silicon.NetRemoteLib.Node.NodeSysSleep;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.RadioFromBundleExtractor;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.shawnlin.numberpicker.NumberPicker;

import java.util.Timer;
import java.util.TimerTask;

public class SleepTimerActivity extends UndokActivityBase {

    protected static final int SECONDS_IN_A_MINUTE = 60;
    private static final long UPDATE_TIME_INTERVAL_MS = 1000;

    private Timer mProgressTimer;
    private View mSetSleepTimerLayout;
    private View mResetSleepTimerLayout;
    private Button mSetButton;
    private Button mCancelButton;
    private TextView mTimeLeftText;
    private NumberPicker mNumberPicker;
    private Radio mClientRadio;
    private SleepTimerViewModel viewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_sleep_timer_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.sleep);

        Bundle bundle = getIntent().getExtras();
        mClientRadio = RadioFromBundleExtractor.extractRadio(bundle, SleepTimerActivity.class);

        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
        if (bundle != null) {
            addUdnToSpeakerLostWatcher(bundle.getString(NavigationHelper.RADIO_UDN_ARG));
        }

        viewModel = new ViewModelProvider(this).get(SleepTimerViewModel.class);
        viewModel.radio = mClientRadio;

        setupControls();
    }

    public void onResume() {
        super.onResume();
        registerObservers();
        updateButtons();
    }

    public void onPause() {
        super.onPause();

        stopProgressTimer();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mClientRadio = null;
    }

    protected void setupControls() {
        mSetSleepTimerLayout = findViewById(R.id.layoutSetSleepTimer);
        mResetSleepTimerLayout = findViewById(R.id.layoutResetSleepTimer);

        mNumberPicker = findViewById(R.id.numberPicker);
        setupNumberPickerSleepTimer(mNumberPicker);
        registerNumberPickerListener();

        mTimeLeftText = findViewById(R.id.textTimer);

        mSetButton = findViewById(R.id.buttonSetTimer);
        mSetButton.setOnClickListener(view -> enableSleep(true));

        mCancelButton = findViewById(R.id.buttonCancelTimer);
        mCancelButton.setOnClickListener(view -> enableSleep(false));
    }

    private void setupNumberPickerSleepTimer(final NumberPicker numberPicker) {
        final String[] sleepTimerValues = getResources().getStringArray(R.array.sleep_timer_values_array);
        numberPicker.setMinValue(0);
        numberPicker.setMaxValue(sleepTimerValues.length - 1);
        numberPicker.setDisplayedValues(sleepTimerValues);
        numberPicker.setValue(0);
    }

    private void updateButtons() {
        viewModel.checkIfSleepTimerActive();
        updateSetButtonVisibility();
    }

    private void updateSetButtonVisibility() {
        if (mNumberPicker.getValue() == 0) {
            mSetButton.setVisibility(View.INVISIBLE);
        }
    }

    private void registerNumberPickerListener() {
        mNumberPicker.setOnValueChangedListener((numberPicker, i, i1) -> {
            if (numberPicker.getValue() == 0) {
                mSetButton.setVisibility(View.INVISIBLE);
            } else {
                mSetButton.setVisibility(View.VISIBLE);
            }
        });
    }

    private void updateSleepTimerControls(boolean enabled) {
        if (enabled) {
            mSetSleepTimerLayout.setVisibility(View.GONE);
            mResetSleepTimerLayout.setVisibility(View.VISIBLE);

            startProgressTimer(UPDATE_TIME_INTERVAL_MS);
        } else {
            mResetSleepTimerLayout.setVisibility(View.GONE);
            mSetSleepTimerLayout.setVisibility(View.VISIBLE);

            stopProgressTimer();
        }
    }

    protected void enableSleep(boolean enable) {
        if (enable) {
            if (mNumberPicker != null) {
                enableSleepTimerFromNumberPicker();
            }

        } else {
            enableSleepTimer(0);
        }
    }

    private void enableSleepTimerFromNumberPicker() {
        int itemPos = mNumberPicker.getValue();
        setSleepTimerValueFromSpinnerPosition(itemPos);
    }

    private void setSleepTimerValueFromSpinnerPosition(int itemPos) {
        if (itemPos > 0) {
            final int[] sleepTimerIntValues = getResources().getIntArray(R.array.sleep_timer_integer_values_array);
            int sleepValueMinutes = sleepTimerIntValues[itemPos];
            long sleepAfterSeconds = sleepValueMinutes * SECONDS_IN_A_MINUTE;

            enableSleepTimer(sleepAfterSeconds);
        } else {
            enableSleepTimer(0);
        }
    }

    private void startProgressTimer(long timeIntervalMilisec) {
        stopProgressTimer();

        mProgressTimer = new Timer();
        mProgressTimer.schedule(new ProgressTimerTask(), 0, timeIntervalMilisec);
    }

    private void stopProgressTimer() {
        if (mProgressTimer != null) {
            mProgressTimer.cancel();
            mProgressTimer.purge();
            mProgressTimer = null;
        }
    }

    private class ProgressTimerTask extends TimerTask {
        @Override
        public void run() {
            final long timerSecondsLeft = viewModel.getSleepTimerSeconds();

            if (!DokUiUtils.isDestroyed(SleepTimerActivity.this)) {
                SleepTimerActivity.this.runOnUiThread(() -> {
                    if (DokUiUtils.isDestroyed(SleepTimerActivity.this)) {
                        return;
                    }

                    if (timerSecondsLeft > 0) {
                        mTimeLeftText.setText(getSecondsAsTimeString(timerSecondsLeft));
                    } else {
                        updateButtons();
                    }
                });
            }
        }
    }

    private String getSecondsAsTimeString(long totalSeconds) {

        return GuiUtils.getMilisecAsTimeStringRoundedUp(totalSeconds * 1000);
    }

    public void enableSleepTimer(long sleepAfterSeconds) {
        if (mClientRadio == null) {
            return;
        }

        RadioNodeUtil.setNodeToRadioAsync(mClientRadio, new NodeSysSleep(sleepAfterSeconds), success -> updateButtons());
    }

    private void registerObservers() {
        viewModel.getSleepTimer().observe(this, flag -> {

            updateSleepTimerControls(flag);

        });
    }
}
