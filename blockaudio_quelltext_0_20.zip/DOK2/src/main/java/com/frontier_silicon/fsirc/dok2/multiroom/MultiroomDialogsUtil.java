package com.frontier_silicon.fsirc.dok2.multiroom;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.DialogsOpener;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.sources.IAvailableSourcesListener;
import com.frontier_silicon.fsirc.dok2.sources.SourceItemModel;
import com.frontier_silicon.fsirc.dok2.sources.SourcesRadioUtil;
import com.frontier_silicon.fsirc.dok2.sources.StreamableModesArrayAdapter;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import java.util.ArrayList;
import java.util.List;

public class MultiroomDialogsUtil {

	public interface ISelectStreamableModeListener {
		void onSelectedStreamableMode(boolean streamableModeSelected);
	}

	static public void showMaxClientsErrorDlg(Activity activity) {
		String dialogKey = "max_clients_error";

        DialogsOpener.showMessageDialogWithOkButton(activity, dialogKey, -1, R.string.max_clients_dlg);
	}
	
	static public void showDifferentMRVersionsErrorDlg(Activity activity) {
		String dialogKey = "different_mr_version_error";

        DialogsOpener.showMessageDialogWithOkButton(activity, dialogKey, -1, R.string.diff_mr_ver_dlg);
	}

    static public void showCreateGroupError(Activity activity) {
        String dialogKey = "create_group_error";

        DialogsOpener.showMessageDialogWithOkButton(activity, dialogKey, -1, R.string.multiroom_create_group_error);
    }

    static public void showAddClientToGroupError(Activity activity) {
        String dialogKey = "add_client_to_group_error";

        DialogsOpener.showMessageDialogWithOkButton(activity, dialogKey, -1, R.string.multiroom_add_client_error);
    }

    static public void showDestroyGroupError(Activity activity) {
        String dialogKey = "destroy_group_error";

        DialogsOpener.showMessageDialogWithOkButton(activity, dialogKey, -1, R.string.multiroom_destroy_group_error);
    }

    static public void showUngroupDeviceError(Activity activity) {
        String dialogKey = "ungroup_device_error";

        DialogsOpener.showMessageDialogWithOkButton(activity, dialogKey, -1, R.string.multiroom_ungroup_client_error);
    }

	@SuppressLint("InflateParams")
	static public void showSelectStreamableModeDlg(Activity parentActivity, final Radio radio, final ISelectStreamableModeListener listener) {

		if (parentActivity != null && radio != null) {
			AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(parentActivity);
			builder.setMessage(parentActivity.getString(R.string.select_multiroom_mode));

			View dialogLayout = parentActivity.getLayoutInflater().inflate(R.layout.multiroom_streamable_modes_dialog, null);
			builder.setView(dialogLayout);

			builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					if (listener != null) {
						listener.onSelectedStreamableMode(false);
					}
				}
			});

			final Dialog dlg = builder.create();

			ListView modesListView = (ListView) dialogLayout.findViewById(R.id.listModes);
			modesListView.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					try {
						StreamableModesArrayAdapter adapter = (StreamableModesArrayAdapter) parent.getAdapter();
						if (adapter != null) {
							SourceItemModel selectedModeItem = adapter.getItem(position);
							SourcesRadioUtil.setModeAsync(radio, selectedModeItem.mKey, new RadioNodeUtil.INodeSetResultListener() {
								@Override
								public void onNodeSetResult(boolean success) {

									if (listener != null) {
										listener.onSelectedStreamableMode(success);
									}

									dlg.dismiss();
								}
							});
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});

			View emptyView = dialogLayout.findViewById(R.id.empty);
			modesListView.setEmptyView(emptyView);

			final List<SourceItemModel> modesList = new ArrayList<>();
			final StreamableModesArrayAdapter modeAdapter = new StreamableModesArrayAdapter(parentActivity, android.R.layout.simple_list_item_1, android.R.id.text1, modesList );
			modesListView.setAdapter(modeAdapter);

			SourcesRadioUtil.getStreamableModes(new IAvailableSourcesListener() {
				@Override
				public void onSourcesUpdate(final List<SourceItemModel> sourcesList) {
                    NetRemote.getMainThreadExecutor().execute(() -> {
                        modesList.clear();
                        modesList.addAll(sourcesList);
                        modeAdapter.notifyDataSetChanged();
                    });
				}
			}, radio);

			DialogsHolder.addDialogToCollection("select_streamable_mode_dialog", dlg);

			dlg.show();
		}
	}

}
