package com.frontier_silicon.fsirc.dok2.setup.connectionType.wifi;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import androidx.databinding.ObservableField;
import android.os.Build;
import androidx.appcompat.app.AlertDialog;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWlanScanList;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.setup.RadioNetworkConfig.EConnectionType;
import com.frontier_silicon.components.setup.RadioNetworkConfig.RadioNetworkConfigParams;
import com.frontier_silicon.components.setup.RadioNetworkConfig.RadioWiFiNetworkScanner;
import com.frontier_silicon.components.setup.RadioNetworkConfig.StaticIPAddressesParam;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SetupConfigureWifiActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.listOfAP.ListOfAccessPointActivity;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.manualAPSelection.ManualAccessPointSelectionActivity;
import com.frontier_silicon.fsirc.dok2.setup.finishing.FinishingSetupActivity;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by nbalazs on 08/03/2018.
 *
 */
public final class ConfigureWiFiActivityVM {

    public ObservableField<Boolean> isStaticWiFiLayoutVisible = new ObservableField<>(false);

    private Activity mActivity;
    private ProgressBar mScanningProgress;
    private TextView mScanningTextView;

    private SetupConfigureWifiActivityBinding mBinding;

    private NodeSysNetWlanScanList.ListItem mSelectedAP;
    private List<NodeSysNetWlanScanList.ListItem> mScanList = new ArrayList<>();

    private boolean mUseDHCP = true;
    private boolean mConnectWithWPS = false;
    private boolean mUseManualSetup = false;

    private IScanAvailableWifiNetworksListener mScanWiFiListener = null;
    private Date mTimeStampOfStartedScanListener;

    private StaticIPAddressesParam mStaticIPAdresses;

    private String mWiFiPasscode = "";

    private WiFiForRadioArrayAdapter mListAdapter;


    ConfigureWiFiActivityVM(Activity activity, SetupConfigureWifiActivityBinding binding) {
        mActivity = activity;
        mBinding = binding;

        init();
    }

    @SuppressLint("InflateParams")
    private void init() {
        View listFooterView = LayoutInflater.from(mActivity).inflate(R.layout.setup_list_footer_available_wifi, null);

        mBinding.listViewWiFiNetworks.addFooterView(listFooterView);

        mScanningTextView = listFooterView.findViewById(R.id.textViewScanningWiFi);
        mScanningProgress = listFooterView.findViewById(R.id.progressBarScanning);

        updateScanningControls();

        mListAdapter = new WiFiForRadioArrayAdapter(mActivity, android.R.layout.simple_list_item_1, mScanList);

        mBinding.listViewWiFiNetworks.setAdapter(mListAdapter);

        mBinding.listViewWiFiNetworks.setOnItemClickListener((parentView, view, position, id) -> {

            mSelectedAP = (NodeSysNetWlanScanList.ListItem) parentView.getItemAtPosition(position);

            if (mSelectedAP != null) {
                if (mSelectedAP.getPrivacy()) {
                    showWiFiPasscodeDialog(mSelectedAP);
                } else {
                    showWiFiConfirmDialog(mSelectedAP);
                }
            }
        });

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(mActivity, R.array.auth_types_array, R.layout.setup_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mBinding.spinnerAuthType.setAdapter(spinnerAdapter);
        mBinding.spinnerAuthType.setSelection(0);

        spinnerAdapter = ArrayAdapter.createFromResource(mActivity, R.array.enc_types_array, R.layout.setup_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mBinding.spinnerEncType.setAdapter(spinnerAdapter);
        mBinding.spinnerEncType.setSelection(0);

        isStaticWiFiLayoutVisible.set(false);

        mBinding.checkBoxDhcp.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isStaticWiFiLayoutVisible.set(!isChecked);
        });

        mBinding.buttonCommitConfig.setOnClickListener((v) -> readyToConfigNetwork());
    }

    void onActivityResumed() {
        GuiUtils.hideKeyboard(mBinding.getRoot(), mActivity);

        clearListViewIfNeeded();

        addWiFiNetworksToAdapter();

        showManualWiFiConfig(mUseManualSetup);

        addWiFiNetworksToAdapter();

        showManualWiFiConfig(mUseManualSetup);

        updateScanningControls();
    }

    public final void onPreviousClicked() {
        mActivity.onBackPressed();
    }

    final void showManualWiFiConfig(boolean showManualConfig) {
        mUseManualSetup = showManualConfig;

        if (showManualConfig) {
            mBinding.layoutAvailableWiFi.setVisibility(View.GONE);
            mBinding.layoutManualWiFi.setVisibility(View.VISIBLE);
        } else {
            mBinding.layoutAvailableWiFi.setVisibility(View.VISIBLE);
            mBinding.layoutManualWiFi.setVisibility(View.GONE);
        }
    }

    final boolean isManualWifiConfigShowing() {
        return mUseManualSetup;
    }

    final void onRefreshTriggered() {
        rescanWiFi();
    }

    private void rescanWiFi() {
        if (mListAdapter != null) {
            mListAdapter.clear();
            mListAdapter.notifyDataSetChanged();
            SetupManager.getInstance().removeScannedListOfWiFis();

            addWiFiNetworksToAdapter();
        }
    }

    private void clearListViewIfNeeded() {
        if (SetupManager.getInstance().mShouldClearListOfWiFis) {
            if (mListAdapter != null) {
                mListAdapter.clear();
                mListAdapter.notifyDataSetChanged();
            }
            SetupManager.getInstance().mShouldClearListOfWiFis = false;
        }
    }

    private void addWiFiNetworksToAdapter() {
        if (SetupManager.getInstance().isConnectedToRadio()) {
            if (!scanListenerIsValid()) {

                mSelectedAP = null;
                mScanWiFiListener = new ScanAvailableWiFiNetworksCallback();
                mTimeStampOfStartedScanListener = new Date();

                updateScanningControls();
                mScanningProgress.setMax(RadioWiFiNetworkScanner.MAX_SECONDS_TO_SCAN_AND_RETRIEVE);

                SetupManager.getInstance().scanAvailableWiFiNetworks(mScanWiFiListener);
            } else {
                // It's possible that user goes to previous page, and quickly returns back
                SetupManager.getInstance().scanAvailableWiFiNetworks(mScanWiFiListener);
            }
        } else {
            goToConnectToHeadlessPageIfNeeded();
        }
    }

    private void goToConnectToHeadlessPageIfNeeded() {
        Class nextActivity;
        if (PermissionsUtil.requestLocationPermission(mActivity, false) && Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            nextActivity = ListOfAccessPointActivity.class;
        } else {
            nextActivity = ManualAccessPointSelectionActivity.class;
        }
        mActivity.startActivity(new Intent(mActivity, nextActivity));
    }

    private void readyToConfigNetwork() {
        RadioNetworkConfigParams configParams = new RadioNetworkConfigParams();

        if (mConnectWithWPS) {
            configParams.mConnectionType = EConnectionType.WPS;
        } else {
            configParams.mConnectionType = EConnectionType.WiFi;

            if (mUseManualSetup) {
                configParams.mSSID = mBinding.editTextSSID.getText().toString();
                configParams.mWiFiPasscode = mBinding.editTextPassword.getText().toString();
                configParams.mAuthType = mBinding.spinnerAuthType.getSelectedItemPosition();
                configParams.mEncryptionType = mBinding.spinnerEncType.getSelectedItemPosition();

                extractStaticIPs();
            } else {
                if (mSelectedAP == null) {
                    FsLogger.log("mSelectedAP was null when the user tried to commit wifi settings");
                    Toast.makeText(mActivity, R.string.select_wifi_again, Toast.LENGTH_SHORT).show();
                    return;
                }

                configParams.mSelectedAPKeyId = mSelectedAP.getKey();
                configParams.mWiFiPasscode = mWiFiPasscode;
                configParams.mSSID = RadioNodeUtil.getHumanReadableSSID(mSelectedAP.getSSID());
            }

            if (!mUseDHCP) {
                configParams.mUseDhcp = false;
                configParams.mStaticIPAdresses = mStaticIPAdresses;
            }
        }

        SetupManager.getInstance().setNetworkConfigParams(configParams);

        notifyOnConfigReadyToCommit();
    }

    private class ScanAvailableWiFiNetworksCallback implements IScanAvailableWifiNetworksListener {

        public void onReceiveWiFiNetworks(List<NodeSysNetWlanScanList.ListItem> mAPList) {

            GuiUtils.replaceContentsOfList(mScanList, mAPList);

            mListAdapter.notifyDataSetChanged();
            mScanWiFiListener = null;
            updateScanningControls();
        }

        @Override
        public void onProgress(final int progress) {
            mActivity.runOnUiThread(() -> mScanningProgress.setProgress(progress));
        }
    }

    private void notifyOnConfigReadyToCommit() {
        SetupManager.getInstance().setIsWiFiSetup(true);
        SetupManager.getInstance().setIsEthernetSetup(false);

        NavigationHelper.goToActivity(mActivity, FinishingSetupActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    private void extractStaticIPs() {
        final EditText editTextIP = mBinding.manualWifiStaticIPsLayout.findViewById(R.id.editTextIP);
        final EditText editTextGatewayIP = mBinding.manualWifiStaticIPsLayout.findViewById(R.id.editTextGatewayIP);
        final EditText editTextSubnetMask = mBinding.manualWifiStaticIPsLayout.findViewById(R.id.editTextSubnetMask);
        final EditText editTextPrimaryDNS = mBinding.manualWifiStaticIPsLayout.findViewById(R.id.editTextPrimaryDNS);
        final EditText editTextSecondaryDNS = mBinding.manualWifiStaticIPsLayout.findViewById(R.id.editTextSecondaryDNS);

        String ip = editTextIP.getText().toString();
        String gateway = editTextGatewayIP.getText().toString();
        String subnet = editTextSubnetMask.getText().toString();
        String dns1 = editTextPrimaryDNS.getText().toString();
        String dns2 = editTextSecondaryDNS.getText().toString();

        boolean isMissingMandatoryIP = (TextUtils.isEmpty(ip) || TextUtils.isEmpty(gateway) || TextUtils.isEmpty(subnet));

        if (!isMissingMandatoryIP) {
            mStaticIPAdresses = new StaticIPAddressesParam();
            mStaticIPAdresses.mIPAdress = ip;
            mStaticIPAdresses.mGatewayAdress = gateway;
            mStaticIPAdresses.mSubnetMask = subnet;
            mStaticIPAdresses.mPrimaryDNSAdress = dns1;
            mStaticIPAdresses.mSecondaryDNSAdress = dns2;
        }

        mUseDHCP = isMissingMandatoryIP;
    }

    private void updateScanningControls() {
        boolean mScanListenerIsValid = scanListenerIsValid();

        mScanningProgress.setVisibility(mScanListenerIsValid ? View.VISIBLE : View.GONE);
        mScanningTextView.setVisibility(mScanListenerIsValid ? View.VISIBLE : View.GONE);
    }

    private boolean scanListenerIsValid() {
        if (mScanWiFiListener == null)
            return false;

        if (mTimeStampOfStartedScanListener != null) {
            Date currentTimeStamp = new Date();
            long timeDifference = currentTimeStamp.getTime() - mTimeStampOfStartedScanListener.getTime();
            if ((timeDifference / 1000.0) > RadioWiFiNetworkScanner.MAX_SECONDS_TO_SCAN_AND_RETRIEVE)
                return false;
        }
        return true;
    }

    private void showWiFiPasscodeDialog(NodeSysNetWlanScanList.ListItem scanAP) {
        String dialogKey = "wifi_password_dialog";

        if (mSelectedAP == null || DialogsHolder.isShowing(dialogKey)) {
            return;
        }

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mActivity);

        @SuppressLint("InflateParams") final View dialogLayout = mActivity.getLayoutInflater().inflate(R.layout.setup_wifi_password_dialog, null);
        builder.setView(dialogLayout);

        TextView messageTextView = dialogLayout.findViewById(R.id.enterPasswordForWiFiTextView);
        messageTextView.setText(mActivity.getResources().getString(R.string.wifi_pass_msg, RadioNodeUtil.getHumanReadableSSID(scanAP.getSSID())));

        final EditText passEditText = dialogLayout.findViewById(R.id.editTextPassw);
        passEditText.setSingleLine(true);
        passEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);


        final CheckBox passVisibleCheckbox = dialogLayout.findViewById(R.id.checkBoxShowPassword);
        passVisibleCheckbox.setChecked(false);
        passVisibleCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked)
                passEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            else
                passEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

            //move cursor to end
            int textEndPos = passEditText.getText().length();
            passEditText.setSelection(textEndPos, textEndPos);
        });

        final View staticIpLayout = dialogLayout.findViewById(R.id.wifiFromListStaticIPsLayout);
        staticIpLayout.setVisibility(View.GONE);

        final CheckBox useDhcpCheckbox = dialogLayout.findViewById(R.id.checkBoxDhcp);
        useDhcpCheckbox.setChecked(true);
        useDhcpCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (!isChecked) {
                GuiUtils.hideKeyboard(passEditText, mActivity);
            } else {
                passEditText.requestFocus();
                GuiUtils.showKeyboardForGivenEditText(passEditText, mActivity);
            }

            staticIpLayout.setVisibility(isChecked ? View.GONE : View.VISIBLE);
        });

        builder.setPositiveButton(android.R.string.ok, (dialog, which) -> {

            // validate 8 char min password
            mWiFiPasscode = passEditText.getText().toString();

            if (mWiFiPasscode.length() >= 8) {
                extractStaticIPs();
                getPasswordFromEditBoxAndStartConfig(passEditText);
                GuiUtils.hideKeyboard(passEditText, mActivity);
            } else {
                // pass validation failed, show error message

                Toast.makeText(mActivity, mActivity.getResources().getString(R.string.wifi_password_less_8_chars), Toast.LENGTH_SHORT).show();
            }
        });

//        if (scanAP.getWpsCapability()) {
//            builder.setNeutralButton(R.string.wps, (dialog, which) -> {
//                mConnectWithWPS = true;
//                readyToConfigNetwork();
//                GuiUtils.hideKeyboard(passEditText, mActivity);
//            });
//        }

        builder.setNegativeButton(android.R.string.cancel, (dialog, which) -> GuiUtils.hideKeyboard(passEditText, mActivity));

        final Dialog dlg = builder.create();
        final Window window = dlg.getWindow();
        if (window != null) {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        DialogsHolder.addDialogToCollection(dialogKey, dlg);

        passEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() < 8) {
                    ((AlertDialog) dlg).getButton(AlertDialog.BUTTON_POSITIVE)
                            .setEnabled(false);
                } else {
                    ((AlertDialog) dlg).getButton(AlertDialog.BUTTON_POSITIVE)
                            .setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        dlg.show();

        GuiUtils.showKeyboardForGivenEditText(passEditText, mActivity);

        // put dialog ok btn to disabled
        ((AlertDialog) dlg).getButton(AlertDialog.BUTTON_POSITIVE)
                .setEnabled(false);
        passEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                GuiUtils.hideKeyboard(passEditText, mActivity);

                dlg.dismiss();
                extractStaticIPs();
                getPasswordFromEditBoxAndStartConfig(passEditText);

                return true;
            }

            return false;
        });
    }

    private void getPasswordFromEditBoxAndStartConfig(EditText editText) {
        mWiFiPasscode = editText.getText().toString();

        readyToConfigNetwork();
    }

    private void showWiFiConfirmDialog(NodeSysNetWlanScanList.ListItem scanAP) {
        String dialogKey = "wifi_confirm_dialog";

        if (scanAP == null || DialogsHolder.isShowing(dialogKey)) {
            return;
        }

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mActivity);

        @SuppressLint("InflateParams") final View dialogLayout = mActivity.getLayoutInflater().inflate(R.layout.setup_wifi_without_password_dialog, null);
        builder.setView(dialogLayout);

        TextView messageTextView = dialogLayout.findViewById(R.id.connectToOpenWiFiTextView);
        messageTextView.setText(mActivity.getResources().getString(R.string.open_wifi_confirm_msg, RadioNodeUtil.getHumanReadableSSID(scanAP.getSSID())));

        final View staticIpLayout = dialogLayout.findViewById(R.id.wifiFromListStaticIPsLayout);
        staticIpLayout.setVisibility(View.GONE);

        final CheckBox useDhcpCheckbox = dialogLayout.findViewById(R.id.checkBoxDhcp);
        useDhcpCheckbox.setChecked(true);
        useDhcpCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> staticIpLayout.setVisibility(isChecked ? View.GONE : View.VISIBLE));

        builder.setPositiveButton(android.R.string.ok, (dialog, which) -> {
            extractStaticIPs();
            readyToConfigNetwork();
            GuiUtils.hideKeyboard(dialogLayout, mActivity);
        });

        builder.setNegativeButton(android.R.string.cancel, null);

        final Dialog dlg = builder.create();
        final Window window = dlg.getWindow();
        if (window != null) {
            dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        DialogsHolder.addDialogToCollection(dialogKey, dlg);

        dlg.show();
    }
}
