package com.frontier_silicon.fsirc.dok2.settings;

/**
 * Created by hcostescu on 06/03/18.
 */

public interface IFWVersionResult {
    void onFWVersionResultComplete(String fwVersion);
}
