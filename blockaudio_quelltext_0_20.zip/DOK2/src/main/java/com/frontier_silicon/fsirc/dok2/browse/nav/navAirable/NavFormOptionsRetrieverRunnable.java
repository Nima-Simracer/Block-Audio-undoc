package com.frontier_silicon.fsirc.dok2.browse.nav.navAirable;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.common.UnifiedFormOptionsListItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormOptionsRetrieverRunnable;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;

public class NavFormOptionsRetrieverRunnable extends FormOptionsRetrieverRunnable {

    public NavFormOptionsRetrieverRunnable(Radio radio, INavFormOptionRetrieverListener listener) {
        super(radio, listener);
    }

    @Override
    public void run() {
        FsLogger.log("form retriever runnable started ", LogLevel.Info);
        ArrayList<UnifiedFormOptionsListItem> formOptionNode = null;
        formOptionNode = RadioNavigationUtil.getNavOptionList(mRadio);

        if (formOptionNode != null) {
            sendNavListToListener(formOptionNode);
        }else{
            sendNavListToListener(null);
        }
        dispose();
    }
}
