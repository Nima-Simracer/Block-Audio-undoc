package com.frontier_silicon.fsirc.dok2.home;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.graphics.drawable.BitmapDrawable;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;

import com.frontier_silicon.NetRemoteLib.Node.BaseMultiroomGroupState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomGroupModel;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.multiroom.MultiroomRescanUtil;
import com.frontier_silicon.fsirc.dok2.multiroom.MultiroomDialogsUtil;
import com.frontier_silicon.fsirc.dok2.multiroom.MultiroomEditGroupManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.SpeakerImageDownloader;

import java.util.List;

/**
 * Created by lsuhov on 05/05/2017.
 */

public class HomeSpeakerViewModel extends HomeBaseItemViewModel {

    public ObservableField<BitmapDrawable> speakerImage = new ObservableField<>();
    public ObservableBoolean isMultiroomSpeaker = new ObservableBoolean(false);
    public ObservableBoolean isSingleGroupSpeaker = new ObservableBoolean(false);
    public ObservableBoolean isSingleMode = new ObservableBoolean(true);
    public ObservableBoolean isStereoSystem = new ObservableBoolean(false);
    public ObservableBoolean groupIsAvailable = new ObservableBoolean(true);
    public ObservableBoolean isAvsBadgeIconVisible = new ObservableBoolean(false);

    private final int[] SG_RETRY_TIMEOUTS = {5000, 5000, 1500, 500};
    private final int SG_RETRY_COUNT = 3;
    private int mSgRetryTimeoutIndex = 0;
    private long SG_SPINNER_TIMER_ID;
    private CompoundButton mSgCompoundButton;
    private boolean mOriginalSgState;

    public HomeSpeakerViewModel(MultiroomItemModel multiroomItemModel, Activity activity) {
        super(multiroomItemModel, activity);

        init();
    }

    protected void init() {
        if (mMultiroomItemModel.getRadio() == null) {
            dispose();
            return;
        }

        SG_SPINNER_TIMER_ID = DelayedPostsManager.getInstance().registerNewCallbackID();

        super.init();

        updateAvailabilityChecking();
        updateSpeakerAvailability();
        updateSpeakerImage();
        updateSpeakerType();
        updateSingleMultiState();
        updateStereoState();
        updateAlexaImage();
    }

    private void updateStereoState() {
        MultiroomDeviceModel deviceModel = mMultiroomItemModel.getDeviceModel();
        isStereoSystem.set(deviceModel.isStereoSystem());
    }

    private void updateSingleMultiState() {
        MultiroomDeviceModel deviceModel = mMultiroomItemModel.getDeviceModel();
        isSingleMode.set(deviceModel.mGroupRole == BaseMultiroomGroupState.Ord.NO_GROUP);
    }

    private void updateSpeakerType() {
        isMultiroomSpeaker.set(mMultiroomItemModel.getType() == MultiroomItemModel.MultiroomSpeaker);
        isSingleGroupSpeaker.set(mMultiroomItemModel.getType() == MultiroomItemModel.SingleGroupSpeaker);
    }

    private void updateSpeakerImage() {
        SpeakerImageDownloader downloader = new SpeakerImageDownloader(mRadio, mActivity,
                bitmapDrawable -> speakerImage.set(bitmapDrawable));
        downloader.download();
    }

    private void updateSpeakerAvailability() {
        isAvailable.set(mRadio.isAvailable() && !mMultiroomItemModel.getDeviceModel().mIsIncompleteStereoSystem);
    }

    private void updateAvailabilityChecking() {

        isCheckingAvailability.set(mRadio.isCheckingAvailability());
    }

    private void updateAlexaImage() {
        if (mMultiroomItemModel == null) {
            return;
        }

        Radio radio = mMultiroomItemModel.getRadio();

        if (radio != null) {
            if (radio.hasAVS()) {
                isAvsBadgeIconVisible.set(true);
            }
        }
    }

    public void onEditGroupClicked(View view) {
        MultiroomEditGroupManager.getInstance().showEditGroupDialog(mMultiroomItemModel);
    }

    public void onSGSwitchChecked(CompoundButton compoundButton, boolean isChecked) {
        if (isSingleMode.get() != isChecked) {
            return;
        }

        if (isChecked && maxClientsReachedOnSGGroup()) {
            showMaxClientsReachedDialog();
            compoundButton.setChecked(false);
            return;
        }

        if (isChecked && speakerHasDifferentMultiroomVersionThanGroup()) {
            showSpeakerHasDifferentMultiroomVersionThanGroupDialog();
            compoundButton.setChecked(false);
            return;
        }

        isSingleMode.set(!isChecked);

        lockSgCompoundButton(compoundButton, !isChecked);

        initSgSpinnerTimer();
        scheduleSgSpinnerTimer();

        MultiroomGroupManager.getInstance().sendSingleGroupCommand(mRadio, isChecked);
    }

    private void showSpeakerHasDifferentMultiroomVersionThanGroupDialog() {
        MultiroomDialogsUtil.showDifferentMRVersionsErrorDlg(mActivity);
    }

    private boolean speakerHasDifferentMultiroomVersionThanGroup() {
        MultiroomGroupManager groupManager = MultiroomGroupManager.getInstance();
        String multiroomVersionOfCurrentSpeaker = mMultiroomItemModel.getDeviceModel().mRadio.getMultiroomVersion();
        String multiroomVersionOfSpeakerFromGroup = "";

        for (MultiroomGroupModel groupModel : groupManager.getGroupsFromDeviceMap()) {
            if (groupManager.isUngroupedDevicesGroup(groupModel.mGroupId) ||
                    groupManager.isSecondaryStereoGroup(groupModel.mGroupId)) {
                continue;
            }

            List<MultiroomDeviceModel> deviceModels = groupManager.getAllDevicesForGroup(groupModel);
            if (deviceModels.size() > 0 && deviceModels.get(0).mRadio.isSG()) {
                multiroomVersionOfSpeakerFromGroup = deviceModels.get(0).mRadio.getMultiroomVersion();
                break;
            }
        }

        return !TextUtils.isEmpty(multiroomVersionOfCurrentSpeaker) &&
                !TextUtils.isEmpty(multiroomVersionOfSpeakerFromGroup) &&
                !multiroomVersionOfCurrentSpeaker.equals(multiroomVersionOfSpeakerFromGroup);
    }

    private boolean maxClientsReachedOnSGGroup() {
        MultiroomGroupManager groupManager = MultiroomGroupManager.getInstance();
        int currentSize = 0;

        for (MultiroomGroupModel groupModel : groupManager.getGroupsFromDeviceMap()) {
            if (groupManager.isUngroupedDevicesGroup(groupModel.mGroupId) ||
                    groupManager.isSecondaryStereoGroup(groupModel.mGroupId)) {
                continue;
            }

            List<MultiroomDeviceModel> deviceModels = groupManager.getAllDevicesForGroup(groupModel);
            if (deviceModels.size() > 0 && deviceModels.get(0).mRadio.isSG()) {
                currentSize = deviceModels.size();
                break;
            }
        }

        return currentSize >= SpeakerDataManager.getInstance().getSpeakerDataModel().maxNumberOfMultiroomClients.get() + 1;
    }

    private void showMaxClientsReachedDialog() {
        MultiroomDialogsUtil.showMaxClientsErrorDlg(mActivity);
    }

    private void initSgSpinnerTimer() {
        DelayedPostsManager.getInstance().cancelCallback(SG_SPINNER_TIMER_ID);
        mSgRetryTimeoutIndex = SG_RETRY_COUNT;
    }

    private void scheduleSgSpinnerTimer() {
        DelayedPostsManager.getInstance().postDelayed(new Runnable() {
            @Override
            public void run() {
                mSgRetryTimeoutIndex--;
                MultiroomRescanUtil.getInstance().rescanMultiroomDevicesAndGroups();

                if (mSgRetryTimeoutIndex >= 0) {
                    scheduleSgSpinnerTimer();
                } else {
                    unlockSgCompoundButton();
                }
            }
        }, SG_SPINNER_TIMER_ID, SG_RETRY_TIMEOUTS[mSgRetryTimeoutIndex]);
    }

    private void lockSgCompoundButton(CompoundButton compoundButton, boolean originalCheckedValue) {
        mSgCompoundButton = compoundButton;
        mOriginalSgState = originalCheckedValue;

        isCheckingAvailability.set(true);
    }

    private void unlockSgCompoundButton() {
        isCheckingAvailability.set(false);

        if (mSgCompoundButton != null) {
            mSgCompoundButton.setChecked(mOriginalSgState);
        }
    }

    public void dispose() {
        isCheckingAvailability.set(false);
        mSgCompoundButton = null;

        DelayedPostsManager.getInstance().removeCallbackId(mSgRetryTimeoutIndex);

        super.dispose();
    }
}
