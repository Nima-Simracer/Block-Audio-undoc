package com.frontier_silicon.fsirc.dok2.setup;

public interface IStateOfCheckingHeadlessSetupListener {
	void onStateOfCheckingHeadlessSetupChanged(EStateOfCheckingHeadlessSetup state);
	void onProgress(int progress);
}
