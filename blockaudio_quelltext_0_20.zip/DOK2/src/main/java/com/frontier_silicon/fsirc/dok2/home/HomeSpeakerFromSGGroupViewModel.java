package com.frontier_silicon.fsirc.dok2.home;

import android.app.Activity;

import com.frontier_silicon.components.multiroom.MultiroomItemModel;

/**
 * Created by lsuhov on 06/09/2017.
 */

public class HomeSpeakerFromSGGroupViewModel extends HomeSpeakerViewModel {

    public HomeSpeakerFromSGGroupViewModel(MultiroomItemModel multiroomItemModel, boolean groupIsAvailable, Activity activity) {
        super(multiroomItemModel, activity);

        this.groupIsAvailable.set(groupIsAvailable);
    }
}
