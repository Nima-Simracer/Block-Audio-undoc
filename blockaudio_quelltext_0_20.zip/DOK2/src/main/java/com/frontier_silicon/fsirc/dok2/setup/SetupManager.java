package com.frontier_silicon.fsirc.dok2.setup;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.net.wifi.ScanResult;
import android.os.AsyncTask;
import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;
import com.frontier_silicon.NetRemoteLib.Discovery.deviceDetailsRetriever.DDXMLParser;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeAvsHastoken;
import com.frontier_silicon.NetRemoteLib.Node.NodeCastTos;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsUtcSettingsList;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoVersion;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWlanRegion;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWlanScanList;
import com.frontier_silicon.NetRemoteLib.Radio.ConnectionErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.IConnectionCallback;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.common.IButtonsResponseWithTextListener;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.setup.RadioNetworkConfig.GetEthernetIsSupportedTask;
import com.frontier_silicon.components.setup.RadioNetworkConfig.IGetEthernetIsSupportedListener;
import com.frontier_silicon.components.setup.RadioNetworkConfig.RadioNetworkConfigParams;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.connection.RadioPINManager;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.settings.language.ILanguageSupported;
import com.frontier_silicon.fsirc.dok2.settings.language.ILanguageUpdate;
import com.frontier_silicon.fsirc.dok2.settings.language.LanguageItemModel;
import com.frontier_silicon.fsirc.dok2.settings.language.LanguageUtil;
import com.frontier_silicon.fsirc.dok2.setup.AccessPointConfig.AccessPointModel;
import com.frontier_silicon.fsirc.dok2.setup.connectionType.wifi.IScanAvailableWifiNetworksListener;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.DateTimeParams;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.GetDateTimeIsSupportedTask;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.IDateTimeCapsListener;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;


public class SetupManager {

	private static SetupManager mInstance = null;

	private NetRemote mNetRemote = null;
	private Radio mCurrentRadio = null;

	private ArrayList<IConnectionCallback> mRadioConnectionListeners;

	private Date mTimeOfLastApScan = null;

	private boolean mIsConnectingToHeadlessAP = false;
	private String mConnectingToSSID = "";
	private boolean mIsConnectingToRadio = false;
	private String mSSIDOfCurrentRadioConnection = "";
	private  String mFirmwareVersion = "";

	private String mRadioFriendlyName = "";
	private Boolean mDateTimeIsSupported = null;
	private Boolean mEthernetIsSupported = null;
	private Boolean mLanguageIsSupported = null;

	private List<LanguageItemModel> mLanguagesList = null;
	private NodeSysCapsClockSourceList mClockSourceList = null;
	private List<NodeSysCapsUtcSettingsList.ListItem> mUtcTimeZoneList = null;
	private DateTimeParams mDateTimeParams = null;


	private int mRegionId = NodeSysNetWlanRegion.Ord.EUROPE.ordinal();
	private RadioNetworkConfigParams mConfigParams;

	private int mWiFiNetworkId = -1;

	private static final boolean ENABLE_LOGGING_TO_FILE = true;
	private ScanAvailableWiFiNetworksTask mScanWiFiTask = null;
	private List<NodeSysNetWlanScanList.ListItem> mScannedWiFis = null;

	private GetRadioFriendlyNameTask mFriendlyNameTask = null;
	private GetDateTimeIsSupportedTask mDateTimeIsSuportedTask = null;

	private Thread mCommitingNetworkConfigThread;
	private SetupDeviceRunnable mSetupDeviceRunnable;
	private volatile EStateOfCheckingHeadlessSetup mStateOfSettingUpHeadlessSetup = EStateOfCheckingHeadlessSetup.None;
	public boolean mShouldClearListOfWiFis = false;
	private GetEthernetIsSupportedTask mGetEthernetIsSupportedTask;
	private String[] mFirmwareBlacklist;

	private boolean mCastSupported = false;
	private boolean mBluetoothSupported = false;
	private boolean mSpotifySupported = false;
	private boolean m3PdaSupported = false;
    private boolean mAVSSupported = false;
	private boolean mIsFsdcaSpeakerInSetup = false;
	private boolean mIsDispose = false;
	private Radio mRadioForNextSetupSteps;
	private boolean isAVSSupported;
	private boolean mSkipSearchingWasPressed = false;

	private boolean isWifiSetup = false;

	private boolean isEthernetSetup = false;

	public static SetupManager getInstance() {
		if (mInstance == null)
			mInstance = new SetupManager();

		return mInstance;
	}

	private SetupManager() {
		mRadioConnectionListeners = new ArrayList<>();
	}

	public void Init(Activity activity) {
		mWiFiNetworkId = AccessPointUtil.getCurrentWiFiNetworkId();
		mIsDispose = false;

		if (ENABLE_LOGGING_TO_FILE)
			FsLogger.initNewLogFile(activity.getApplicationContext());
	}

	private void initNetRemote() {
		if (mNetRemote != null && mCurrentRadio != null)
			return;

        if (mNetRemote == null) {
            mNetRemote = NetRemoteManager.getInstance().getNetRemote();

            mFirmwareBlacklist = mNetRemote.getFirmwareBlacklist();
        }

        String ipAddress = AccessPointUtil.getIpAddressOfTheAccessPoint(MainApplication.getCurrentActivity());

        if (mCurrentRadio == null) {
            mCurrentRadio = mNetRemote.createStaticRadioHTTP(ipAddress,
                    "", "Headless Radio", true);

            String savedPin = RadioPINManager.getInstance().getPIN(mCurrentRadio.getSN());
            if (TextUtils.isEmpty(savedPin))
                savedPin = NetRemoteManager.RADIO_DEFAULT_PIN;

            mCurrentRadio.setPIN(savedPin);
        }
	}

	public NetRemote getNetRemote() {
		return mNetRemote;
	}

	public void cleanNetRemote() {
		closeRadioConnection();

		if (mNetRemote != null) {
			mNetRemote = null;
		}
	}

	public Radio getCurrentRadio() {
		return mCurrentRadio;
	}

	public boolean isVeniceXDevice() {
		boolean isVeniceXDevice = false;
		if (mFirmwareVersion != null) {
			isVeniceXDevice =  mFirmwareVersion.toLowerCase().contains("venicex") ||
					mFirmwareVersion.toLowerCase().contains("fs2340") ||
					mFirmwareVersion.toLowerCase().contains("fs4444");
		}
		return isVeniceXDevice;
	}

	public String getFirmwareVersion() {
		return mFirmwareVersion;
	}
	public void registerForRadioConnectionEvents(IConnectionCallback connectionCallback) {
		mRadioConnectionListeners.add(connectionCallback);
	}

	public void removeFromRadioConnectionEvents(IConnectionCallback connectionCallback) {
		mRadioConnectionListeners.remove(connectionCallback);
	}

	public void connectToCurrentRadio() {
		initNetRemote();

		if (mCurrentRadio == null)
			return;

		resetConnectedToHeadlessAP();

		mIsConnectingToRadio = true;
		mSkipSearchingWasPressed = false;
		mSSIDOfCurrentRadioConnection = AccessPointUtil.getSSIDOfCurrentConnection();
		FsLogger.log("Connecting to NetRemote - " + mSSIDOfCurrentRadioConnection);

		mCurrentRadio.connect(false, new IConnectionCallback() {

			@Override
			public void onConnectionSuccess(Radio radio) {

				FsLogger.log("SetupManager:connectToCurrentRadio onConnectionSuccess " + radio.getDetailDescription());

				retrieveAllDataAfterConnectionSuccess(radio);
			}

			@Override
			public void onConnectionError(Radio radio, ConnectionErrorResponse error) {
				mIsConnectingToRadio = false;
				removeScannedListOfWiFis();

				FsLogger.log("SetupManager:connectToCurrentRadio onConnectionError " + radio.getDetailDescription() + " error: " + error.toString(), LogLevel.Error);

				notifyListenersOnFailedConnection(radio, error);

				mShouldClearListOfWiFis = true;

				if (NetRemoteManager.isPinError(error)) {
					RadioPINManager.getInstance().showIncorrectPINDialog(MainApplication.getCurrentActivity(), mCurrentRadio, new IButtonsResponseWithTextListener() {

						@Override
						public void onOkClicked(String response) {
							mCurrentRadio.setPIN(response);
							connectToCurrentRadio();
						}

						@Override
						public void onCancelClicked() {
							AccessPointUtil.disconnectCurrentWifi();
						}
					});
				}
			}

			@Override
			public void onDisconnected(Radio radio, ConnectionErrorResponse error) {
				mIsConnectingToRadio = false;
				removeScannedListOfWiFis();
				closeRadio();

				FsLogger.log("SetupManager:connectToCurrentRadio onDisconnected " + radio.getDetailDescription() + " error: " + error.toString(), LogLevel.Error);

				for (IConnectionCallback connectionCallback : mRadioConnectionListeners) {
					connectionCallback.onDisconnected(radio, error);
				}

				mShouldClearListOfWiFis = true;
			}
		});
	}

	private void retrieveAllDataAfterConnectionSuccess(final Radio radio) {

        RadioNodeUtil.getNodesFromRadioAsync(radio, new Class[]{NodeSysInfoVersion.class, NodeAvsHastoken.class}, true, new RadioNodeUtil.INodesResultListener() {
            @Override
            public void onNodesResult(Map<Class, NodeInfo> nodes) {

                NodeSysInfoVersion nodeSysInfoVersion = (NodeSysInfoVersion) nodes.get(NodeSysInfoVersion.class);

                if (nodeSysInfoVersion == null || TextUtils.isEmpty(nodeSysInfoVersion.getValue())) {
                    FsLogger.log("-> SetupManager:NodeSysInfoVersion null");

                    testCastSupport(radio);
                    getModesList(radio);
                } else {

                     mFirmwareVersion = nodeSysInfoVersion.getValue().toLowerCase();

                     if (isVeniceXDevice()) {
						 AnalyticsSender.sendIsVeniceXUnderSetupEvent(mFirmwareVersion);
					 }

                    if (DDXMLParser.isFirmwareInBlacklist(mFirmwareVersion, mFirmwareBlacklist)) {
                        FsLogger.log("SetupManager:connectToCurrentRadio firmware " + nodeSysInfoVersion.toString() + ". Closing connection");

                        closeRadio();

                        notifyListenersOnFailedConnection(radio,
                                new ConnectionErrorResponse(false, ConnectionErrorResponse.ErrorCode.Error, null));

                    } else {
                        testCastSupport(radio);
                        getModesList(radio);
                    }
                }

                // testing avs support
                NodeAvsHastoken nodeAvsHastoken = (NodeAvsHastoken) nodes.get(NodeAvsHastoken.class);

                isAVSSupported = (nodeAvsHastoken != null);
            }
        });

    }

    private void testCastSupport(final Radio radio) {
        // We need to know whether this radio can support cast before moving on, we have to do this now
        // as otherwise we won't know which fragment path to follow
        radio.getNode(NodeCastTos.class, false, new IGetNodeCallback() {
            @Override
            public void getNodeResult(NodeInfo node) {
                // Supported
                mCastSupported = true;
                retrieveNextNodesOnConnection(radio);
            }

            @Override
            public void getNodeError(Class nodeType, NodeErrorResponse error) {
                // Not supported
                mCastSupported = false;
                retrieveNextNodesOnConnection(radio);
            }
        });
    }

    private void retrieveNextNodesOnConnection(final Radio radio) {
        getEthernetIsSupportedAsync(isSupported -> {
            setEthernetIsSupported(isSupported);

            getDateTimeIsSupportedAsync(new IDateTimeCapsListener() {
                @Override
                public void onDateTimeSupportUpdate(boolean dateTimeIsSupported) {
                    FsLogger.log("SetupManager:getDateTimeIsSupportedAsync dateTimeIsSupported: " + dateTimeIsSupported);

                    setDateAndTimeSetupIsSupported(dateTimeIsSupported);

                    getRadioFriendlyNameAsync(friendlyName -> {

                        removeScannedListOfWiFis();
                        scanAvailableWiFiNetworks(null);

                        mIsConnectingToRadio = false;

                        FsLogger.log("SetupManager:getRadioFriendlyNameAsync friendlyName: " + friendlyName);

                        notifyListenersOnSuccessfullConnection(radio);
                    });
                }

                @Override
                public void onDateTimeCapsUpdate(NodeSysCapsClockSourceList clockSourceList, List<NodeSysCapsUtcSettingsList.ListItem> utcTimeZoneList) {
                    setClockSourceList(clockSourceList);
                    setUtcTimeZoneList(utcTimeZoneList);
                }
            });

            getLanguageFromSpeaker();
        });
    }

    private void getModesList(final Radio radio) {
        mBluetoothSupported	= false;
        mSpotifySupported = false;
        m3PdaSupported = false;
		mIsFsdcaSpeakerInSetup = false;

        NodeSysCapsValidModes validModes = radio.getValidModesSync();
        if (validModes != null) {
            for (NodeSysCapsValidModes.ListItem item : validModes.getEntries()) {

                if (item.getId().endsWith(NodeSysCapsValidModes.Mode.AVS.name())) {
                    mAVSSupported = true;
                }
                if (item.getId().equals(NodeSysCapsValidModes.Mode.Bluetooth.name()))
                    mBluetoothSupported = true;
                if (item.getId().equals(NodeSysCapsValidModes.Mode.Spotify.name()))
                    mSpotifySupported = true;
                if (item.getId().equals("3PDA") || item.getId().equals("Alexa Speaker") ) {
					m3PdaSupported = true;
					mIsFsdcaSpeakerInSetup = true;
				}
            }
        }
    }

	private void notifyListenersOnSuccessfullConnection(Radio radio) {
		for (IConnectionCallback connectionCallback : mRadioConnectionListeners) {
			connectionCallback.onConnectionSuccess(radio);
		}
	}

	private void notifyListenersOnFailedConnection(Radio radio, ConnectionErrorResponse error) {
		for (IConnectionCallback connectionCallback : mRadioConnectionListeners) {
			connectionCallback.onConnectionError(radio, error);
		}
	}

	public boolean isConnectedToRadio() {
		return mCurrentRadio != null && mCurrentRadio.isConnectionOk();
	}

	public boolean isConnectingToGivenRadio(ScanResult scanResult) {
		if (!mIsConnectingToRadio)
			return false;

		return isConnectingToGivenAP(scanResult) || isConnectedToGivenAP(scanResult) && scanResult.SSID.contentEquals(mSSIDOfCurrentRadioConnection);

	}

	public boolean isConnectedToGivenRadio(ScanResult scanResult) {
		if (!isConnectedToRadio())
			return false;

		if (!scanResult.SSID.contentEquals(mSSIDOfCurrentRadioConnection))
			return false;

		return isConnectedToGivenAP(scanResult);
	}

	public boolean isPhoneStillConnectedToRadioAccessPoint() {
		String currentSSID = AccessPointUtil.getSSIDOfCurrentConnection();
		return currentSSID.contentEquals(mSSIDOfCurrentRadioConnection);
	}

	public boolean isConnectedToAnotherRadioConnection(String ssid) {
		//in case there is no radio connection we ignore
		if (!isConnectedToRadio())
			return false;
		return !ssid.contentEquals(mSSIDOfCurrentRadioConnection);
	}

	public boolean isConnectedToADifferentWiFiThanRadiosConnection() {
		String currentSSID = AccessPointUtil.getSSIDOfCurrentConnection();

		return isConnectedToAnotherRadioConnection(currentSSID);
	}

	public boolean isConnectingToRadio() {
		return mIsConnectingToRadio;
	}

	public boolean canConnectToAP(ScanResult scanResult) {

		return scanResult != null && !isConnectedToGivenRadio(scanResult);
	}

	public List<AccessPointModel> getCurrentAccessPoints(Context context) {
		List<ScanResult> scanResults = AccessPointUtil.getScanResults();

		List<AccessPointModel> suggestedDevices = new ArrayList<>();

        if (scanResults != null) {
            for (ScanResult scanResult : scanResults) {
                AccessPointModel apModel = new AccessPointModel(scanResult);

                if (macAddressIsFS(scanResult.BSSID, context)
                        && !isOnSuggestedDevicesBlackList(scanResult.SSID, context) && !TextUtils.isEmpty(scanResult.SSID)) {
                    suggestedDevices.add(apModel);
                }
            }
            sortList(suggestedDevices);
        }

		return suggestedDevices;
	}

	private void sortList(List<AccessPointModel> list) {
		Collections.sort(list, (accessPointModel, t1) -> t1.getSignalStrength() - accessPointModel.getSignalStrength());
	}

	private boolean macAddressIsFS(String macAddress, Context context) {
		if (macAddress == null)
			return false;

		macAddress = macAddress.toLowerCase();

        String[] macPartsForSuggestedDevices = getMACPartsForSuggestedDevices(context);

		for (String huiName : macPartsForSuggestedDevices) {
			huiName = huiName.toLowerCase();
			if (macAddress.startsWith(huiName))
				return true;
		}

		return false;
	}

	private boolean isOnSuggestedDevicesBlackList(String name, Context context) {
		if (name == null)
			return false;

		name = name.toLowerCase();

        String[] prefixBLackList = getPrefixBlackListForSuggestedDevices(context);

		for (String prefix : prefixBLackList) {
			prefix = prefix.toLowerCase();
			if(name.startsWith(prefix)) {
				return true;
			}

		}

		return false;
	}

	private String[] mMacPartsForSuggestedDevices = null;
	private String[] getMACPartsForSuggestedDevices(Context context) {
        if (mMacPartsForSuggestedDevices == null) {
            Resources resources = context.getResources();

            mMacPartsForSuggestedDevices = resources.getStringArray(R.array.suggested_devices_mac_parts_array);
        }

        return mMacPartsForSuggestedDevices;
	}

	private String[] mPrefixBlacklistForSuggestedDevices = null;
	private String[] getPrefixBlackListForSuggestedDevices(Context context) {
        if (mPrefixBlacklistForSuggestedDevices == null) {
            Resources resources = context.getResources();

            return resources.getStringArray(R.array.prefix_black_list_array);
        }

        return mPrefixBlacklistForSuggestedDevices;
	}

	public boolean shoudStartNewAccessPointsScan() {
		if (mTimeOfLastApScan == null)
			return true;

		Date currentTimeStamp = new Date();
		long timeDifference = currentTimeStamp.getTime() - mTimeOfLastApScan.getTime();

		return (timeDifference / 1000.0) > FsComponentsConfig.SECONDS_TO_WAIT_BEFORE_MAKING_NEW_AP_SCAN_WHEN_REQUESTED;
	}

	public boolean startWiFiAccessPointScan() {
		mTimeOfLastApScan = new Date();
		return AccessPointUtil.startAccesPointsScan();
	}

	public void connectToAccessPoint(final ScanResult accessPoint) {
		closeRadioConnection();

		mIsConnectingToHeadlessAP = true;
		mIsConnectingToRadio = true;
		mConnectingToSSID = accessPoint.SSID;

        (new Thread(() -> AccessPointUtil.connectToAccessPoint(accessPoint))).start();
	}

	public boolean isConnectedToAnyAP() {
		return AccessPointUtil.isConnectedToWiFi();
	}

	public void resetConnectedToHeadlessAP() {
		mIsConnectingToHeadlessAP = false;
		mConnectingToSSID = "";
		mRadioFriendlyName = "";
	}

	public boolean isConnectedToGivenAP(ScanResult scanResult) {
		return AccessPointUtil.isConnectedToGivenAP(scanResult);
	}

	public boolean isConnectingToGivenAP(ScanResult scanResult) {
		if (!mIsConnectingToHeadlessAP)
			return false;

		return scanResult.SSID.contentEquals(mConnectingToSSID);
	}

	public boolean isConnectingToHeadlessAP() {
		return mIsConnectingToHeadlessAP;
	}

	public String getSSIDOfConnectingAP() {
		return mConnectingToSSID;
	}

	public boolean isConnectedToHeadlessAP() {
		if (!isConnectedToAnyAP())
			return false;

		String currentBSSID = AccessPointUtil.getBSSIDOfCurrentConnection();
        String currentSSID = AccessPointUtil.getSSIDOfCurrentConnection();

		return macAddressIsFS(currentBSSID, MainApplication.getCurrentActivity()) && !isOnSuggestedDevicesBlackList(currentSSID, MainApplication.getCurrentActivity());
	}

	public void setEthernetIsSupported(boolean isSupported) {
		mEthernetIsSupported = isSupported;
	}

	public boolean getEthernetIsSupported() {
		return mEthernetIsSupported != null && mEthernetIsSupported;
	}

	public void setRadioForNextSetupSteps(Radio radio) {
		mRadioForNextSetupSteps = radio;
	}

	public Radio getRadioForNextSetupSteps() {
		return mRadioForNextSetupSteps;
	}

	public interface IGetFriendlyNameAsync {
		void onFriendlyNameRetrieved(String friendlyName);
	}

	public void getRadioFriendlyNameAsync(IGetFriendlyNameAsync getFriendlyNameInterface) {
		if (getFriendlyNameInterface == null)
			return;

		if (!TextUtils.isEmpty(mRadioFriendlyName)) {
			getFriendlyNameInterface.onFriendlyNameRetrieved(mRadioFriendlyName);
		} else {
			if (mFriendlyNameTask == null) {
				mFriendlyNameTask = new GetRadioFriendlyNameTask(getFriendlyNameInterface);
				TaskHelper.execute(mFriendlyNameTask);
			} else
				mFriendlyNameTask.setInterfaceListener(getFriendlyNameInterface);
		}
	}

	public void getDateTimeIsSupportedAsync(IDateTimeCapsListener dateTimeCapsListener) {
		if (dateTimeCapsListener == null)
			return;

		if (mDateTimeIsSupported != null) {
			dateTimeCapsListener.onDateTimeSupportUpdate(mDateTimeIsSupported);
		} else {
			if (mDateTimeIsSuportedTask == null) {
				mDateTimeIsSuportedTask = new GetDateTimeIsSupportedTask(getCurrentRadio(), dateTimeCapsListener);
				TaskHelper.execute(mDateTimeIsSuportedTask);
			} else {
				mDateTimeIsSuportedTask.setInterfaceListener(dateTimeCapsListener);
			}
		}
	}

	public void getEthernetIsSupportedAsync(IGetEthernetIsSupportedListener listener) {
		if (listener == null)
			return;

		if (mEthernetIsSupported != null) {
			listener.onEthernetSupported(mEthernetIsSupported);
		} else {
			if (mGetEthernetIsSupportedTask == null || mGetEthernetIsSupportedTask.getStatus() == AsyncTask.Status.FINISHED) {
				mGetEthernetIsSupportedTask = new GetEthernetIsSupportedTask(getCurrentRadio(), listener);
				TaskHelper.execute(mGetEthernetIsSupportedTask);
			} else {
				mGetEthernetIsSupportedTask.setInterfaceListener(listener);
			}
		}
	}

	public void scanAvailableWiFiNetworks(IScanAvailableWifiNetworksListener scanWifiNetworksListener) {
		if (scanWifiNetworksListener != null && mScannedWiFis != null) {
			// we consider that we just entered page SetupPage.SetWirelessAP and we should return the results
			//from the scan ordered in page SetupPage.SelectName.
			scanWifiNetworksListener.onReceiveWiFiNetworks(mScannedWiFis);
			return;
		}

		if (mScanWiFiTask == null) {
			mScanWiFiTask = new ScanAvailableWiFiNetworksTask(scanWifiNetworksListener);
			TaskHelper.execute(mScanWiFiTask);
		} else {
			// In two cases it could enter here:
			// - on the first enter in page SetupPage.SetWirelessAP, the scan ordered from page SetupPage.SelectName
			// didn't finish yet
			// - user presses repeatedly refresh button(this should not happen because we
			// check in higher level code).
			mScanWiFiTask.setScanWiFiListener(scanWifiNetworksListener);
		}
	}

	public void setupDevice(IStateOfCheckingHeadlessSetupListener stateListener) {
		if (stateListener != null) {
			stateListener.onStateOfCheckingHeadlessSetupChanged(mStateOfSettingUpHeadlessSetup);

			if (isFinishedState(mStateOfSettingUpHeadlessSetup))
				return;
		}

		if (!setupDeviceThreadIsRunning()) {
			if (mSetupDeviceRunnable != null)
				mSetupDeviceRunnable.dispose();

			mSetupDeviceRunnable = new SetupDeviceRunnable(stateListener);
			mCommitingNetworkConfigThread = new Thread(mSetupDeviceRunnable);
			mCommitingNetworkConfigThread.start();
		} else
			mSetupDeviceRunnable.setListener(stateListener);
	}

	public boolean setupDeviceThreadIsRunning() {
		return mCommitingNetworkConfigThread != null && mCommitingNetworkConfigThread.isAlive() &&
				!mCommitingNetworkConfigThread.isInterrupted();
	}

	public void skipSearchingForConfiguredDevice() {
		if (mSetupDeviceRunnable != null)
			mSetupDeviceRunnable.setShouldStopTheTimer(true);
			mSkipSearchingWasPressed = true;
	}

	private boolean isFinishedState(EStateOfCheckingHeadlessSetup stateOfSettingUpHeadlessSetup) {
		return stateOfSettingUpHeadlessSetup == EStateOfCheckingHeadlessSetup.CouldntConnectToWiFi ||
				stateOfSettingUpHeadlessSetup == EStateOfCheckingHeadlessSetup.CouldntFindDeviceWithSSDP ||
				stateOfSettingUpHeadlessSetup == EStateOfCheckingHeadlessSetup.NodesWereNotSetCorrectly ||
				stateOfSettingUpHeadlessSetup == EStateOfCheckingHeadlessSetup.SuccesfullSetup ||
				stateOfSettingUpHeadlessSetup == EStateOfCheckingHeadlessSetup.WaitOnConnectingWithWPS;
	}

	public EStateOfCheckingHeadlessSetup getStateOfSetup() {
		return mStateOfSettingUpHeadlessSetup;
	}

	public void setStateOfSetup(EStateOfCheckingHeadlessSetup stateOfSetup) {
		mStateOfSettingUpHeadlessSetup = stateOfSetup;
	}

	public void resetStateOfSetup() {
		mStateOfSettingUpHeadlessSetup = EStateOfCheckingHeadlessSetup.None;
		if (mSetupDeviceRunnable != null) {
			mSetupDeviceRunnable.setShouldStopTheTimer(false);
			mSetupDeviceRunnable.cleanTimer();
		}
	}

	public void setFriendlyName(String friendlyName) {
		mRadioFriendlyName = friendlyName;
	}

	public String getFriendlyName() {
		return mRadioFriendlyName;
	}

	public void setNetworkConfigParams(RadioNetworkConfigParams configParams) {
		mConfigParams = configParams;
		mConfigParams.mRegionId = mRegionId;
	}

	public RadioNetworkConfigParams getConfigParams() {
		return mConfigParams;
	}

	public int getRegionId() {
		return mRegionId;
	}

	public void setRegionId(int regionId) {
		mRegionId = regionId;
	}

	public boolean reconnectToInitialWiFiNetwork() {
		return mWiFiNetworkId != -1 && AccessPointUtil.connectToNetworkId(mWiFiNetworkId);
	}

	public void removeInitialWiFiNetwork() {
	    mWiFiNetworkId = -1;
    }

	public int getWiFiNetworkIdOfPreviousConnectedWiFi() {
        return mWiFiNetworkId;
    }

	public void setScannedListOfWiFis(List<NodeSysNetWlanScanList.ListItem> scanList) {
		mScannedWiFis = scanList;
	}

	public void removeScannedListOfWiFis() {
		mScannedWiFis = null;
	}

	public Boolean getDateAndTimeSetupIsSupported() {

		return mDateTimeIsSupported;
	}

	public void setDateAndTimeSetupIsSupported(boolean isSupported) {
        if (!isAVSSupported) {
            mDateTimeIsSupported = isSupported;
        } else {
            mDateTimeIsSupported = false;
        }
	}

	// region Select Language Methods


	public void getLanguageIsSupportedAsync(ILanguageUpdate languageUpdateListener, ILanguageSupported languageSupportedListener) {
		LanguageUtil languageUtil = new LanguageUtil(getCurrentRadio());
		languageUtil.getLanguageList(languageUpdateListener, languageSupportedListener);
	}

	public void setLanguageList(List<LanguageItemModel> lList) {
		if (lList != null && !lList.isEmpty()) {
			mLanguagesList = new ArrayList<>();
			mLanguagesList.addAll(lList);
		}
	}

	public void getLanguageFromSpeaker() {
		getLanguageIsSupportedAsync(this::setLanguageList, this::setLanguageIsSupported);
}

	public List<LanguageItemModel> getLanguageList()
	{ return mLanguagesList;}

	public Boolean getLanguageIsSupported() {
		return mLanguageIsSupported;
	}

	public void setLanguageIsSupported(Boolean isLanguageSupported) {
        mLanguageIsSupported = isLanguageSupported;
    }

	// endregion

    public void setClockSourceList(NodeSysCapsClockSourceList clockSourceList) {
        mClockSourceList = clockSourceList;
    }

    public NodeSysCapsClockSourceList getClockSourceList() {
        return mClockSourceList;
    }

    public DateTimeParams getDateTimeParams() {
        return mDateTimeParams;
    }

    public void setDateTimeParams(DateTimeParams dateTimeParams) {
        mDateTimeParams = dateTimeParams;
		mDateTimeParams.setSelectedTimeZone("");
    }

    public void setUtcTimeZoneList(List<NodeSysCapsUtcSettingsList.ListItem> utcTimeZoneList) {
        mUtcTimeZoneList = utcTimeZoneList;
    }

    public List<NodeSysCapsUtcSettingsList.ListItem> getUtcTimeZoneList() {
        return mUtcTimeZoneList;
    }

	public void removeFriendlyNameTask() {
		if (mFriendlyNameTask != null) {
			mFriendlyNameTask.cancel(true);
			mFriendlyNameTask = null;
		}
	}

    public void removeDateAndTimeIsSupportedTask() {
        if (mDateTimeIsSuportedTask != null) {
            mDateTimeIsSuportedTask.cancel(true);
            mDateTimeIsSuportedTask = null;
        }
    }

	public void removeScanWiFiTask() {
		if (mScanWiFiTask != null) {
			mScanWiFiTask.cancel(true);
			mScanWiFiTask = null;
		}
	}

    public void removeEthernetIsSupportedTask() {
        if (mGetEthernetIsSupportedTask != null) {
            mGetEthernetIsSupportedTask.cancel(true);
            mGetEthernetIsSupportedTask = null;
        }
    }

	public void closeRadioConnection() {
        removeFriendlyNameTask();
		removeDateAndTimeIsSupportedTask();
		removeScanWiFiTask();
        removeEthernetIsSupportedTask();

		closeRadio();

        mDateTimeIsSupported = null;
        mEthernetIsSupported = null;
		mShouldClearListOfWiFis = true;
        mClockSourceList = null;
        mDateTimeParams = null;
        mUtcTimeZoneList = null;
		removeScannedListOfWiFis();
	}

    private void closeRadio() {
        if (mCurrentRadio != null) {
            mCurrentRadio.close();
            mCurrentRadio = null;
        }
    }

    public boolean isDisposed() {
        return mIsDispose;
    }

    public void dispose() {
        cleanNetRemote();
        mIsFsdcaSpeakerInSetup = false;
        mIsDispose = true;
    }

    public boolean getIsFsdcaSpeakerInSetup() {
		return mIsFsdcaSpeakerInSetup;
	}

	public boolean getIsCastSupported() {
        return mCastSupported;
    }

    public boolean getIsBluetoothSupported() {
		return  mBluetoothSupported;
	}

	public boolean getIsSpotifySupported() {
		return  mSpotifySupported;
	}

	public boolean getIs3PdaSupported() {
		return m3PdaSupported;
	}

	public boolean getIsAvsSupported(){
	    return mAVSSupported;
    }

    public boolean getSkipChckingWasPressed() {
		return mSkipSearchingWasPressed;
	}

	public void setIsWiFiSetup(boolean isWiFiSetup) {
		this.isWifiSetup = isWiFiSetup;
	}

	public boolean getIsWifiSetup() {
		return  isWifiSetup;
	}

	public void setIsEthernetSetup(boolean isEthernetSetup) {
		this.isEthernetSetup = isEthernetSetup;
	}

	public boolean getIsEthernetSetup() {
		return  isEthernetSetup;
	}
}
