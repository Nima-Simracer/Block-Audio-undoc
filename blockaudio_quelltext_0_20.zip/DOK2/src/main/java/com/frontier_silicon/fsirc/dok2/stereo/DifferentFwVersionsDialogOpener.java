package com.frontier_silicon.fsirc.dok2.stereo;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

/**
 * Created by lsuhov on 22/11/2017.
 */

public class DifferentFwVersionsDialogOpener {

    private final String canShowDifferentFwMessageAgainKey = "canShowDifferentFwMessageAgainKey";

    public boolean canShowDifferentVersionsWarning() {
        return CommonPreferences.getInstance().getBoolean(canShowDifferentFwMessageAgainKey, true);
    }

    public void setCanShowDifferentVersionsWarning(boolean value) {
        CommonPreferences.getInstance().putBoolean(canShowDifferentFwMessageAgainKey, value);
    }

    public void showDifferentFwMessageForStereoSystem(String systemName, Context context, final IDifferentFwVersionResultListener listener) {
        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(context);

        Activity activity = (Activity)context;
        final View dialogLayout = activity.getLayoutInflater().inflate(R.layout.stereo_different_fw_version_dialog, null);
        builder.setView(dialogLayout);

        TextView textView = dialogLayout.findViewById(R.id.text);
        String text = context.getString(R.string.different_fw_in_multichannel_system, systemName);
        textView.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(text, false));

        SwitchCompat switchCompat = dialogLayout.findViewById(R.id.switchDontShowAgain);
        switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setCanShowDifferentVersionsWarning(!isChecked);
            }
        });

        builder.setNegativeButton(R.string.continue_anyway, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                listener.continueOperation();
            }
        });

        builder.setPositiveButton(R.string.update, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                listener.goToUpdateSection();;
            }
        });

        Dialog dialog = builder.create();
        dialog.show();
    }
}
