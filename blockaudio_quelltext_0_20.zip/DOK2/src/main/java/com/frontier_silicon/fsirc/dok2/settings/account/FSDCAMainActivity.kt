package com.frontier_silicon.fsirc.dok2.settings.account

import androidx.databinding.DataBindingUtil
import android.os.Bundle
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase
import com.frontier_silicon.fsirc.dok2.databinding.FsdcaMainActivityBinding

class FSDCAMainActivity : UndokActivityBase() {
    private var mBinding: FsdcaMainActivityBinding? = null
    private var mViewModel: FSDCAMainViewModel? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DataBindingUtil.setContentView(this, R.layout.fsdca_main_activity)
        mViewModel = FSDCAMainViewModel(mBinding, this)
        mBinding?.viewModel = mViewModel
        setupAppBar()
        enableUpNavigation()
        setTitle(R.string.account_management)
    }

    override fun onResume() {
        super.onResume()
        mViewModel!!.loadUserDataFromServer()
        if (mViewModel != null) {
            mViewModel!!.onResume()
        }
    }

    override fun onPause() {
        super.onPause()
        if (mViewModel != null) {
            mViewModel!!.onPause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mViewModel != null) {
            mViewModel!!.dispose()
        }
    }
}