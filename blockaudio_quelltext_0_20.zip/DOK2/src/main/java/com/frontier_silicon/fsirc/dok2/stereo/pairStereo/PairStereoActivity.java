package com.frontier_silicon.fsirc.dok2.stereo.pairStereo;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;

import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.StereoPairActivityBinding;
import com.frontier_silicon.fsirc.dok2.databinding.StereoPairSpeakerBinding;
import com.frontier_silicon.fsirc.dok2.stereo.StereoBundleHelper;

/**
 * Created by lsuhov on 10/08/2017.
 */

public class PairStereoActivity extends UndokActivityBase {

    StereoPairActivityBinding mBinding;
    PairStereoViewModel mViewModel;
    StereoSpeakerForPairingViewModel mPrimarySpeakerViewModel;
    StereoSpeakerForPairingViewModel mSecondarySpeakerViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.stereo_pair_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.stereo_setup);

        Bundle bundle = getIntent().getExtras();
        StereoItemModel primaryStereoItemModel = StereoBundleHelper.getPrimaryStereoItemModel(bundle);
        StereoItemModel secondaryStereoItemModel = StereoBundleHelper.getSecondaryStereoItemModel(bundle);

        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
        addUdnToSpeakerLostWatcher(bundle.getString(StereoBundleHelper.PRIMARY_SPEAKER_UDN));
        addUdnToSpeakerLostWatcher(bundle.getString(StereoBundleHelper.SECONDARY_SPEAKER_UDN));

        if (!StereoBundleHelper.isStereoItemModelSpeakerValid(primaryStereoItemModel) ||
                !StereoBundleHelper.isStereoItemModelSpeakerValid(secondaryStereoItemModel)) {
            onBackPressed();
            return;
        }

        mPrimarySpeakerViewModel = inflateStereoSpeakerLayout(primaryStereoItemModel, true);
        inflateDivider();
        mSecondarySpeakerViewModel = inflateStereoSpeakerLayout(secondaryStereoItemModel, false);

        mViewModel = new PairStereoViewModel(mPrimarySpeakerViewModel, mSecondarySpeakerViewModel, mBinding, this);
        mBinding.setViewModel(mViewModel);
        mBinding.differentFirmwareTextView.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.different_fw_in_secondary, false));
    }

    private void inflateDivider() {
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.divider, mBinding.speakersLayout, false);

        mBinding.speakersLayout.addView(view);
    }

    private StereoSpeakerForPairingViewModel inflateStereoSpeakerLayout(StereoItemModel stereoItemModel,
                                                                        boolean isPrimary) {

        StereoPairSpeakerBinding speakerBinding = DataBindingUtil.inflate(getLayoutInflater(),
                R.layout.stereo_pair_speaker, mBinding.speakersLayout, false);

        StereoSpeakerForPairingViewModel speakerViewModel = new StereoSpeakerForPairingViewModel(stereoItemModel,
                isPrimary, speakerBinding, this);

        speakerBinding.setViewModel(speakerViewModel);

        mBinding.speakersLayout.addView(speakerBinding.getRoot());

        return speakerViewModel;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }

        if (mPrimarySpeakerViewModel != null) {
            mPrimarySpeakerViewModel.dispose();
            mPrimarySpeakerViewModel = null;
        }

        if (mSecondarySpeakerViewModel != null) {
            mSecondarySpeakerViewModel.dispose();
            mSecondarySpeakerViewModel = null;
        }

        if (mBinding != null) {
            mBinding.speakersLayout.removeAllViews();
            mBinding = null;
        }
    }
}
