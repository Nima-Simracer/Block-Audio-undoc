package com.frontier_silicon.fsirc.dok2.stereo.editSystem;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;

import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.StereoEditPairActivityBinding;
import com.frontier_silicon.fsirc.dok2.databinding.StereoEditPairSpeakerBinding;
import com.frontier_silicon.fsirc.dok2.stereo.StereoBundleHelper;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 17/08/2017.
 */

public class EditStereoSystemActivity extends UndokActivityBase {

    private StereoEditPairActivityBinding mBinding;
    private EditStereoSystemViewModel mViewModel;
    private List<StereoSpeakerForEditingViewModel> mSpeakerViewModels = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.stereo_edit_pair_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.stereo_setup);

        setupControls();
    }

    private void setupControls() {
        StereoItemModel systemStereoItemModel = StereoBundleHelper.getSystemStereoItemModel(getIntent().getExtras());
        if (systemStereoItemModel == null || systemStereoItemModel.deviceModels == null) {
            FsLogger.log("Failed on retrieving a valid system stereoItemModel", LogLevel.Error);
            return;
        }

        setTitle(getString(R.string.edit_stereo_system, systemStereoItemModel.toString()));

        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);

        int numberOfSpeakersInMultichannel = systemStereoItemModel.deviceModels.size();

        MultiroomDeviceModel primaryDeviceModel = null;
        if (numberOfSpeakersInMultichannel > 0) {
            primaryDeviceModel = systemStereoItemModel.deviceModels.get(0);
            addUdnToSpeakerLostWatcher(primaryDeviceModel.mRadio.getUDN());
        }
        if (numberOfSpeakersInMultichannel > 1) {
            MultiroomDeviceModel secondaryDeviceModel = systemStereoItemModel.deviceModels.get(1);
            addUdnToSpeakerLostWatcher(secondaryDeviceModel.mRadio.getUDN());
        }


        for (int i = 0; i < numberOfSpeakersInMultichannel; i++) {
            MultiroomDeviceModel deviceModel = systemStereoItemModel.deviceModels.get(i);
            inflateStereoSpeakerLayout(deviceModel, primaryDeviceModel);

            if (i < numberOfSpeakersInMultichannel - 1) {
                inflateDivider();
            }
        }

        mViewModel = new EditStereoSystemViewModel(primaryDeviceModel, this);
        mBinding.setViewModel(mViewModel);
    }

    private void inflateStereoSpeakerLayout(MultiroomDeviceModel deviceModel, MultiroomDeviceModel primaryDeviceModel) {
        StereoEditPairSpeakerBinding speakerBinding = DataBindingUtil.inflate(getLayoutInflater(),
                R.layout.stereo_edit_pair_speaker, mBinding.speakersLayout, false);

        StereoSpeakerForEditingViewModel viewModel = new StereoSpeakerForEditingViewModel(deviceModel,
                primaryDeviceModel, speakerBinding, this);

        speakerBinding.setViewModel(viewModel);

        mBinding.speakersLayout.addView(speakerBinding.getRoot());

        mSpeakerViewModels.add(viewModel);
    }

    private void inflateDivider() {
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.divider, mBinding.speakersLayout, false);

        mBinding.speakersLayout.addView(view);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mSpeakerViewModels.size() > 0) {
            for (StereoSpeakerForEditingViewModel viewModel : mSpeakerViewModels) {
                viewModel.dispose();
            }
            mSpeakerViewModels.clear();
        }

        mBinding = null;

        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }
    }
}
