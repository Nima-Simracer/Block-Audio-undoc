package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by lsuhov on 02/07/16.
 */

public class NavRefreshEvent {

    //the ID to which we successfully navigated before this event was triggered
    //it is only updated with valid value in normal nav, from context and message nav the value is -1
    private long mNavId;

    public NavRefreshEvent(long id){
        this.mNavId = id;
    }

    public long getNavId(){
        return this.mNavId;
    }
}
