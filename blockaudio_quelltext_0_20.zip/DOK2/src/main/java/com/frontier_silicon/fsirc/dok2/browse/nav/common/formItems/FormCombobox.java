package com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems;

import com.frontier_silicon.NetRemoteLib.Node.NodeListItem.FormItemType;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by adanaila on 10/7/2016.
 */

/** Try to use the same logic for Multisel */

public class FormCombobox extends FormItem {
    private List<FormComboboxOption> options;
    private FormComboboxOption selectedOption;
    private int selectedOptionsForMultisel = -1;

    public FormCombobox(Long keyP, FormItemType typeP, String idP, String labelP, String descriptionP, List<FormComboboxOption> optionsP)
    {
        super(keyP, typeP, idP, labelP, descriptionP);
        this.options = optionsP;
        this.selectedOption = null;
    }

    public List<String> getOptions() {
        List<String> result = new ArrayList<>();
        if(this.options != null)
        for ( FormComboboxOption fco : this.options) {
            result.add(fco.getName());
        }
        return result;
    }

    public List<FormComboboxOption> getFormComboBoxOptions() {
        return  options;
    }

    public void setOptions(List<FormComboboxOption> value) {this.options = value;}

    public void setSelectedOption(int position){
        this.selectedOption = this.options.get(position);
    }
    public void setMultiselSelectedOption(int selectedOptions){
        this.selectedOptionsForMultisel = selectedOptions;
    }


    public String getSelectedOptionKey(){
        //Default it returns the first option that is selectable
        if(this.selectedOption != null)
            return this.getId() + this.selectedOption.optionSelected();
        else if (selectedOptionsForMultisel != -1) {
            return  this.getId() + "=" + selectedOptionsForMultisel;
        }
            return this.getId() + "=0";
    }
}