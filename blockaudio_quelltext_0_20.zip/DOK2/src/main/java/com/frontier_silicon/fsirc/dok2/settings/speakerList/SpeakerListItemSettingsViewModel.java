package com.frontier_silicon.fsirc.dok2.settings.speakerList;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.settings.groupedSpeakers.GroupedSpeakersSettingsActivity;
import com.frontier_silicon.fsirc.dok2.settings.speaker.SpeakerSettingsActivity;
import com.frontier_silicon.fsirc.dok2.util.SpeakerImageDownloader;

/**
 * Created by lsuhov on 12/10/2017.
 */

public class SpeakerListItemSettingsViewModel {

    public ObservableField<String> name = new ObservableField<>();
    public ObservableBoolean isSpeaker = new ObservableBoolean();
    public ObservableBoolean isStereoSystem = new ObservableBoolean();
    public ObservableBoolean isMultiroomGroup = new ObservableBoolean();
    public ObservableField<BitmapDrawable> speakerImage = new ObservableField<>();

    private MultiroomItemModel mMultiroomItemModel;
    private Activity mActivity;

    public SpeakerListItemSettingsViewModel(MultiroomItemModel multiroomItemModel, Activity activity) {
        mMultiroomItemModel = multiroomItemModel;
        mActivity = activity;

        init();
    }

    private void init() {
        updateSpeakerOrGroupName();
        updateType();
        updateSpeakerImage();
    }

    private void updateSpeakerImage() {
        MultiroomDeviceModel deviceModel = mMultiroomItemModel.getDeviceModel();
        if (deviceModel == null || deviceModel.isStereoSystem()) {
            return;
        }

        SpeakerImageDownloader downloader = new SpeakerImageDownloader(deviceModel.mRadio, mActivity,
                bitmapDrawable -> speakerImage.set(bitmapDrawable));
        downloader.download();
    }

    private void updateType() {
        MultiroomDeviceModel deviceModel = mMultiroomItemModel.getDeviceModel();

        isMultiroomGroup.set(mMultiroomItemModel.getIsGroupHeader());
        isStereoSystem.set(deviceModel != null && deviceModel.isStereoSystem());
        isSpeaker.set(deviceModel != null && !deviceModel.isStereoSystem());
    }

    private void updateSpeakerOrGroupName() {
        name.set(mMultiroomItemModel.toString());
    }

    public void onListItemClicked(View v) {
        if (mMultiroomItemModel.getIsGroupHeader()) {

            Bundle bundle = new Bundle();
            bundle.putString(NavigationHelper.GROUP_ID, mMultiroomItemModel.getGroupId());

            NavigationHelper.goToActivity(mActivity, GroupedSpeakersSettingsActivity.class, bundle);
        } else {

            Radio radio = mMultiroomItemModel.getRadio();
            if (radio == null) {
                return;
            }

            Bundle bundle = new Bundle();
            bundle.putString(NavigationHelper.RADIO_UDN_ARG, radio.getUDN());

            NavigationHelper.goToActivity(mActivity, SpeakerSettingsActivity.class, bundle);
        }
    }

    public void dispose() {
        mActivity = null;
        mMultiroomItemModel = null;
    }
}
