package com.frontier_silicon.fsirc.dok2.upnpUtils;

import android.util.Log;

import com.coderus.localmediaplayback.service.ClingRemoteService;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import org.fourthline.cling.android.AndroidUpnpService;
import org.fourthline.cling.model.ValidationException;
import org.fourthline.cling.model.meta.Device;
import org.fourthline.cling.model.meta.DeviceDetails;
import org.fourthline.cling.model.meta.DeviceIdentity;
import org.fourthline.cling.model.meta.Icon;
import org.fourthline.cling.model.meta.ManufacturerDetails;
import org.fourthline.cling.model.meta.RemoteDevice;
import org.fourthline.cling.model.meta.RemoteDeviceIdentity;
import org.fourthline.cling.model.meta.RemoteService;
import org.fourthline.cling.model.meta.Service;
import org.fourthline.cling.model.types.DeviceType;
import org.fourthline.cling.model.types.ServiceType;
import org.fourthline.cling.model.types.UDAServiceId;
import org.fourthline.cling.model.types.UDN;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.net.UnknownHostException;

/**
 * Helper classes returning Cling device and
 * services from <code>NetRemoteManager</code> classes
 */
public class ClingHelper {
  private static ServiceType mServiceType;
  private static UDAServiceId mServiceId;
  private static URI mDescriptor;
  private static URI mControl;
  private static URI mEventSubscription;
  private static DeviceType mDeviceType = new DeviceType("schemas-upnp-org", "MediaRenderer");



  /**
   * Returns a instance of <code>ClingRemoteService</code> containing the actions
   * and state variables required by the control point in the local media
   * playback library
   *
   * @return A Cling Service with core actions
   * @throws URISyntaxException
   * @throws ValidationException
   */
  public static Service createDeviceAVTransportService() throws URISyntaxException, ValidationException {
    ServiceType serviceType = new ServiceType("schemas-upnp-org", "AVTransport");
    UDAServiceId serviceId = new UDAServiceId("AVTransport");
    URI descriptor = new URI(null, "AVTransport/scpd.xml", null);
    URI control = new URI(null, "AVTransport/control", null);
    URI eventSubscription = new URI(null, "AVTransport/event", null);

    return new ClingRemoteService(serviceType, serviceId, descriptor, control, eventSubscription, ClingRemoteService.createActions(), ClingRemoteService.createStateVariables());
  }

  public static Service createDeviceConnectionManagerService() throws URISyntaxException, ValidationException {

    if (mServiceType == null) {
      mServiceType = new ServiceType("schemas-upnp-org", "ConnectionManager");
      mServiceId = new UDAServiceId("ConnectionManager");
      mDescriptor = new URI(null, "ConnectionManager/scpd.xml", null);
      mControl = new URI(null, "ConnectionManager/control", null);
      mEventSubscription = new URI(null, "ConnectionManager/event", null);
    }

    return new ClingRemoteService(mServiceType, mServiceId, mDescriptor, mControl, mEventSubscription, ClingRemoteService.createActions(), ClingRemoteService.createStateVariables());
  }

  public static Service createDeviceRenderingControlService() throws URISyntaxException, ValidationException {

    if (mServiceType == null) {
      mServiceType = new ServiceType("schemas-upnp-org", "RenderingControl");
      mServiceId = new UDAServiceId("RenderingControl");
      mDescriptor = new URI(null, "RenderingControl/scpd.xml", null);
      mControl = new URI(null, "RenderingControl/control", null);
      mEventSubscription = new URI(null, "RenderingControl/event", null);
    }

    return new ClingRemoteService(mServiceType, mServiceId, mDescriptor, mControl, mEventSubscription, ClingRemoteService.createActions(), ClingRemoteService.createStateVariables());
  }

  /**
   * Alternative to <code>createClingDevice(Radio targetRadio, RemoteService[] remoteServices)</code>
   * containing a single service created by <code>createDeviceAVTransportService()</code>.
   *
   * @param targetRadio The Radio for which a Cling device should be constructed
   * @return A Cling device object
   * @throws URISyntaxException
   * @throws ValidationException
   * @throws MalformedURLException
   * @throws UnknownHostException
   */
  public static Device createClingDevice(Radio targetRadio) throws URISyntaxException, ValidationException, MalformedURLException, UnknownHostException {
    RemoteService[] remoteServices = new RemoteService[]{
            (RemoteService) createDeviceAVTransportService(),
            //(RemoteService) createDeviceConnectionManagerService(),
            //(RemoteService) createDeviceRenderingControlService()
    };

    return createClingDevice(targetRadio, remoteServices);
  }

  /**
   * Create an instance of cling <code>RemoteDevice</code> from a <code>NetRemoteManager</code>
   * <code>Radio</code>. The cling device object include key information such as device IP address and UDN and other
   * identifying information returned from the <code>Radio object</code>
   *
   * @param targetRadio    The Radio for which a Cling device should be constructed
   * @param remoteServices A List of services available from the
   * @return A cling device object with the same identifying characteristics as the given radio
   * @throws MalformedURLException
   * @throws UnknownHostException
   * @throws URISyntaxException
   * @throws ValidationException
   */
  public static Device createClingDevice(Radio targetRadio, RemoteService[] remoteServices) throws MalformedURLException, UnknownHostException, URISyntaxException, ValidationException {
    InetAddress inet4Address = Inet4Address.getByName(targetRadio.getIpAddress());
    URL descriptor = new URL("http", targetRadio.getIpAddress(), 8080, "/dd.xml", new URLStreamHandler() {
      @Override
      protected URLConnection openConnection(URL url) throws IOException {
        return null;
      }
    });

    UDN clingUniqueDeviceName = new UDN(targetRadio.getUDN());
    RemoteDeviceIdentity deviceIdentity = new RemoteDeviceIdentity(clingUniqueDeviceName, 0, descriptor, null, inet4Address);
    ManufacturerDetails manufacturerDetails = new ManufacturerDetails("Frontier Silicon Ltd", new URI("http://www.frontier-silicon.com"));
    DeviceDetails deviceDetails = new DeviceDetails(targetRadio.getFriendlyName(), manufacturerDetails);

    return new RemoteDevice(deviceIdentity, mDeviceType, deviceDetails, new Icon[0], remoteServices);
  }
}
