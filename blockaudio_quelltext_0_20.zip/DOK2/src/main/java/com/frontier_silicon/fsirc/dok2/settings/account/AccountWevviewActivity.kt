package com.frontier_silicon.fsirc.dok2.settings.account

import androidx.databinding.DataBindingUtil
import android.os.Bundle
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase
import com.frontier_silicon.fsirc.dok2.databinding.FsdcaAccountWebviewActivityBinding

class AccountWebviewActivity : UndokActivityBase() {
    private var mBinding: FsdcaAccountWebviewActivityBinding? = null
    private var mViewModel: AccountWebviewViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DataBindingUtil.setContentView(this, R.layout.fsdca_account_webview_activity)
        mViewModel = AccountWebviewViewModel(mBinding, this)
        mBinding!!.viewModel = mViewModel
        mViewModel!!.init()

        setupAppBar()
        enableUpNavigation()
        setTitle(R.string.account_management)

    }


    override fun onDestroy() {
        super.onDestroy()
        mViewModel!!.dispose()
    }
}
