package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.fragmetns

import androidx.fragment.app.Fragment

class CAFragmentFactory {
     val SMART_RADIO_FRAGMENT = 0
     val ROUTER_SETTINGS_FRAGMENT = 1
     val VPN_SETTINGS_FRAGMENT = 2
     val SEARCH_BY_IP_FRAGMENT = 3

    fun getFragment(position: Int): Fragment {
        return when (position) {
            SMART_RADIO_FRAGMENT -> {
                CASmartRadioSettingsFragment()
            }
            ROUTER_SETTINGS_FRAGMENT -> {
                CARouterSettingsFragment()
            }

            VPN_SETTINGS_FRAGMENT -> {
            CAVpnSettingsFragment()
            }
            SEARCH_BY_IP_FRAGMENT -> {
                CASearchByIpFragment()
            }

            else -> {
                CASmartRadioSettingsFragment()
            }

        }
    }
}