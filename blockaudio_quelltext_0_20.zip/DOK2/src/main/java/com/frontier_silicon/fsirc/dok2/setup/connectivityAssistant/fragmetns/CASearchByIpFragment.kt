package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.fragmetns

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.databinding.CaSearchByIpFragmentBinding
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication
import com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.ConnectivityAssistantViewModel

class CASearchByIpFragment: Fragment() {
    private lateinit var binding: CaSearchByIpFragmentBinding
    private lateinit var viewModel: ConnectivityAssistantViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        binding = DataBindingUtil.inflate(inflater, R.layout.ca_search_by_ip_fragment, container, false)
        viewModel = ViewModelProvider(requireActivity()).get(ConnectivityAssistantViewModel::class.java)

        addSearchButtonTextWacher()
        initSearchFromKeyboard()
        binding.ipAddressToSearch.setHint(SmartRadioStringsManager.getSmartRadioString(R.string.static_radio_ip_address, true))
        binding.searchByIpTextView.setHint(SmartRadioStringsManager.getSmartRadioString(R.string.ca_search_by_ip, true))

        return binding.root
    }


    private fun addSearchButtonTextWacher() {
        binding.ipAddressToSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val speakerIp = binding.ipAddressToSearch.text
                viewModel.nextButtonName.value = MainApplication.getContext().getString(R.string.dmr_search)
                viewModel.nextButtonState.value = shouldEnableSearchButton(speakerIp = speakerIp.toString())
                if (speakerIp?.isEmpty() == true) {
                    binding.editTextLayout.error = getString(R.string.static_radio_empty_ip_address)
                } else if (!Patterns.IP_ADDRESS.matcher(speakerIp).matches()) {
                    binding.editTextLayout.error = getString(R.string.static_radio_ip_address_not_maching)
                } else {
                    binding.editTextLayout.isErrorEnabled = false
                }

                viewModel.ipAddressToSearch.value = speakerIp.toString()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })
    }


   private fun initSearchFromKeyboard() {
        binding.ipAddressToSearch.setOnKeyListener(View.OnKeyListener { v, keyCode, event -> // If the event is a key-down event on the "enter" button
            if (event.action == KeyEvent.ACTION_DOWN &&
                    keyCode == KeyEvent.KEYCODE_ENTER) {
                        val ipAddress = binding.ipAddressToSearch.text.toString()
                if (shouldEnableSearchButton(ipAddress)) {
                    viewModel.searchRadioByIp(ipAddress)
                    viewModel.startRadioSearch.value = true
                }
                return@OnKeyListener true
            }
            false
        })
    }

    override fun onResume() {
        super.onResume()
        viewModel.nextButtonName.value = MainApplication.getContext().getString(R.string.dmr_search)
        viewModel.nextButtonState.value = false
    }

    private fun shouldEnableSearchButton(speakerIp: String): Boolean {
        return speakerIp.isNotEmpty() && Patterns.IP_ADDRESS.matcher(speakerIp).matches()
    }

}