package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.fragmetns

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.databinding.CaVpnSettingsFragmentBinding


class CAVpnSettingsFragment: Fragment() {
    private lateinit var binding: CaVpnSettingsFragmentBinding


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.ca_vpn_settings_fragment, container, false)

        return binding.root
    }
}
