package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.messageItems.MessageItem;

/**
 * Created by lsuhov on 24/10/2016.
 */

public class BrowseMessageBaseViewModel {
    private final String AMAZON_HINT = "amzn.";
    private int mPosition;
    private MessageItem mMessageBase;
    private TextView mTextView;

    public BrowseMessageBaseViewModel(int position, MessageItem item, TextView textView) {
        mPosition = position;
        mMessageBase = item;
        mTextView = textView;

        init();
    }

    protected void init() {
        if (mMessageBase.getName().contains(AMAZON_HINT)) {
            createRedirectLinkForUrl(mMessageBase.getName());
        } else {
            mTextView.setText(mMessageBase.getName());
        }
    }

    private void createRedirectLinkForUrl(String message) {
        if (mTextView != null) {
            int startIndex = message.indexOf(AMAZON_HINT);
            int endIndex = message.length();
            char[] link = new char[endIndex - startIndex];
            message.getChars(startIndex, endIndex, link, 0);
            String linkToShow = String.valueOf(link);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(message);
            spannableStringBuilder.setSpan(new ClickableSpan() {
                @Override
                public void onClick(View widget) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://"+linkToShow));
                    MainApplication.getCurrentActivity().startActivity(intent);
                }
            },startIndex, endIndex,  Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannableStringBuilder.setSpan(new StyleSpan(Typeface.BOLD), startIndex, endIndex, 0);
            mTextView.setMovementMethod(LinkMovementMethod.getInstance());
            mTextView.setText(spannableStringBuilder, TextView.BufferType.SPANNABLE);
        }
    }
        public void dispose() {
        mMessageBase = null;
    }
}
