package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseFormButtonViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.AirableItemSelectionManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseFormItemButtonBinding;

/**
 * Created by lsuhov on 07/11/2016.
 */

public class BrowseFormItemButtonDelegate extends AirableSelectableItemDelegate {

    private int mBrowseType;

    public BrowseFormItemButtonDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseFormItemButtonBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_form_item_button,
                parent, false);
        AirableItemSelectionManager.getInstance().addSelectableItem(binding.formButton);
        this.createEditorListeners(binding.formButton);

        return new BrowseFormItemButtonViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        FormManager formManager = BrowseManagerFactory.getFormManager(mBrowseType);
        FormItem formItem = formManager.getItemByPosition(position);

        BrowseFormItemButtonViewHolder buttonViewHolder = (BrowseFormItemButtonViewHolder) holder;
        BrowseFormButtonViewModel viewModel = new BrowseFormButtonViewModel(position, formItem, formManager);
        buttonViewHolder.mBinding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseFormItemButtonViewHolder formButtonViewHolder = (BrowseFormItemButtonViewHolder) holder;
        BrowseFormButtonViewModel viewModel = formButtonViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            formButtonViewHolder.mBinding.setViewModel(null);
        }
    }

    protected static class BrowseFormItemButtonViewHolder extends ListItemViewHolder {
        public BrowseFormItemButtonBinding mBinding;

        BrowseFormItemButtonViewHolder(BrowseFormItemButtonBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
