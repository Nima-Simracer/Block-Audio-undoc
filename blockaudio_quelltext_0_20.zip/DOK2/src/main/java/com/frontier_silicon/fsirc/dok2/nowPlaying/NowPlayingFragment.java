package com.frontier_silicon.fsirc.dok2.nowPlaying;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import androidx.databinding.DataBindingUtil;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Parcelable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.coderus.localmediaplayback.ControlPoint;
import com.coderus.localmediaplayback.LocalMediaDMR;
import com.coderus.localmediaplayback.Manager;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes.Mode;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.LayoutDecider;
import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.databinding.NowPlayingFragmentBinding;
import com.frontier_silicon.fsirc.dok2.notifications.LocalMediaNotification;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.upnpUtils.ClingHelper;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.volume.volumeControl.VolumeCtrlFragment;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import org.fourthline.cling.model.ValidationException;
import org.fourthline.cling.model.meta.RemoteDevice;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;


public class NowPlayingFragment extends BaseFragment implements IChildFragment, IPageSwitchListener,
        IMultiroomGroupingListener, IConnectionStateListener {

    public static final String FRAGMENT_TAG = "TAG_NOW_PLAYING_FRAGMENT";
    public static final String LOG_TAG = FRAGMENT_TAG + ": ";

    private static final int WAIT_SHARE_BTN_CLICK_TIME_MS = 1000;

    protected SeekBar mPlayPosSeekBar;

    protected NowPlayingViewModel mNowPlayingViewModel;

    private SeekBar mFrequencySeekBar;

    private long mLastShareBtnClickTime = 0;

    private NowPlayingFragmentBinding mBinding;

    private TextView mPresetIndex;

    private RemoteDevice mClingDevice;
    private Manager mLocalMediaService;
    private boolean mLocalMediaBound;

    private String pendingAction = "";

    private final BroadcastReceiver playerEventStateReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            ControlPoint.EventState eventState = (ControlPoint.EventState) intent.getSerializableExtra("play_state");
            FsLogger.log("LocalMedia: Received eventState: " + eventState);

            String udn = intent.getStringExtra("udn");
            if (!((mClingDevice != null) && (mClingDevice.getIdentity().getUdn().getIdentifierString().equals(udn)))) {
                return;
            }

            if (mNowPlayingViewModel != null) {

                switch (eventState) {
                    case EXTRA_WILL_START:
                        mNowPlayingViewModel.isDMRPlaybackStarted = false;
                        NowPlayingManager.getInstance().setDMRPlaying(true);
                        break;
                    case EXTRA_DID_STARTED:
                        mNowPlayingViewModel.updateBufferingView(true);

                        mNowPlayingViewModel.isDMRPlaybackStarted = true;
                        if (mNowPlayingViewModel.isPaused()) {
                            NowPlayingManager.getInstance().play();
                        }
                        checkPlaybackInfo(4);
                        break;
                    case EXTRA_DID_FINISHED:
                        mNowPlayingViewModel.isDMRPlaybackStarted = false;
                        boolean isLastItem = intent.getBooleanExtra("is_last", false);
                        if (isLastItem) {
                            // playlist finished, clear interface
                            LocalMediaNotification notification = LocalMediaNotification.getInstance();
                            if (notification != null) {
                                notification.stopForeground().remove();
                            }
                        }
                        break;
                    case PLAYING:
                        mNowPlayingViewModel.updateBufferingView(false);
                        NowPlayingManager.getInstance().setDMRPlaying(true);
                        NowPlayingManager.getInstance().updateAllPlaybackInfo(true, false);

                        break;
                    case STOPPED:
                        mNowPlayingViewModel.updateBufferingView(false);
                        NowPlayingManager.getInstance().setDMRPlaying(false);

                        break;
                    case BUFFERING:
                        mNowPlayingViewModel.updateBufferingView(true);
                        break;
                    case PAUSED:
                        FsLogger.log("LocalMedia: Received eventState: PAUSED");
                        break;
                }
            }
        }
    };

    private void checkPlaybackInfo(final int steps) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mNowPlayingViewModel == null) {
                    return;
                }

                if ((steps > 0) && (mNowPlayingViewModel.isDMRPlaybackStarted))
                    if (!mNowPlayingViewModel.isProgressBarVisible.get() || !mNowPlayingViewModel.isPlayPauseButtonSupported() /*|| (mProgressTimer == null)*/) {
                        FsLogger.log("LocalMedia: reload PlaybackInfo ");
                        NowPlayingManager.getInstance().updateAllPlaybackInfo(true, false);

                        checkPlaybackInfo(steps - 1);
                    }
            }
        }, 5000);
    }

    private ServiceConnection mLocalMediaPlaybackConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            FsLogger.log(LOG_TAG + "LocalMedia: playback service connected to now playing fragment");
            try {
                Manager.ManagerBinder binder = (Manager.ManagerBinder) service;
                mLocalMediaService = binder.getService();

                if (mClingDevice == null) {
                    initClingDevice();
                }

                mLocalMediaService.setLifecycleListener(event -> {
                    if (event == Manager.ServiceLifeEvent.REQUEST_CLIENT_UNDBIND) {
                        try {
                            Activity activity = getActivity();
                            if (activity == null) {
                                return;
                            }
                            activity.getApplicationContext().unbindService(mLocalMediaPlaybackConnection);
                        } catch (IllegalArgumentException e) {
                        }
                    }
                });

                mLocalMediaService.init();
                // cmd receiver

                Activity activity = getActivity();
                if (activity != null) {
                    IntentFilter receiverFilter = new IntentFilter();
                    receiverFilter.addAction(LocalMediaDMR.LOCAL_MUSIC_PLAY_STATE);

                    try {
                        activity.unregisterReceiver(playerEventStateReceiver);
                    } catch (IllegalArgumentException e) {

                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        activity.registerReceiver(playerEventStateReceiver, receiverFilter, Context.RECEIVER_NOT_EXPORTED);
                    } else {
                        activity.registerReceiver(playerEventStateReceiver, receiverFilter);
                    }
                }

                mLocalMediaBound = true;
                if (pendingAction.equals("next")) {
                    onNextBtn();
                } else if (pendingAction.equals("prev")) {
                    onPreviousBtn();
                }

                //checkIfLocalMusicIsPlaying();
            } catch (NoClassDefFoundError e) {
                mLocalMediaBound = false;
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            FsLogger.log(LOG_TAG + "Local media playback service disconnected from now playing fragment");
            mLocalMediaBound = false;
        }
    };

    public void checkIfLocalMusicIsPlaying() {
        DelayedPostsManager.getInstance().postDelayed(() -> {
            if ((mClingDevice != null) && (mLocalMediaService != null)) {
                if (mLocalMediaService.isPlaying(mClingDevice)) {
                    NowPlayingManager.getInstance().setDMRPlaying(true);
                }
            }
        }, 3000);
    }

    private void bindServices() {
        if (!mLocalMediaBound && MainApplication.isInForeground()) {

            Activity parentActivity = getActivity();

            if (parentActivity != null) {
                Intent i = new Intent(parentActivity, Manager.class);

                parentActivity.startService(i);
                boolean result = parentActivity.getApplicationContext().bindService(i,
                        mLocalMediaPlaybackConnection,
                        Context.BIND_AUTO_CREATE
                );

                if (!result) {
                    FsLogger.log(LOG_TAG + "Failed to initialise binding to Local Media Playback service failed",
                            LogLevel.Error);
                }
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.now_playing_fragment, container, false);

        mNowPlayingViewModel = new NowPlayingViewModel();
        mNowPlayingViewModel.init(this.getActivity(), mBinding);

        mBinding.setNowPlayingVM(mNowPlayingViewModel);
        if (LayoutDecider.isTabletAndLandscape(getActivity())) {
            setConstraintsForLandscape();
        }

        return mBinding.getRoot();
    }

    private void setConstraintsForLandscape() {
        ViewGroup.MarginLayoutParams albumArtParams = (ViewGroup.MarginLayoutParams) mBinding.layoutAlbumArt.getLayoutParams();
        ViewGroup.MarginLayoutParams currentSOurceParams = (ViewGroup.MarginLayoutParams) mBinding.imageCurrentSource.getLayoutParams();
        albumArtParams.topMargin = DokUiUtils.dpToPx(20, getActivity());
        albumArtParams.bottomMargin = DokUiUtils.dpToPx(10, getActivity());
        ;

        currentSOurceParams.topMargin = DokUiUtils.dpToPx(-30, getActivity());
        ;
    }

    @Override
    public boolean isBackButtonHandledByFragment(boolean upButton) {
        return false;
    }

    public void onStart() {
        super.onStart();

        setupControls();

        if (mIsRestoreInstance) {
            mIsRestoreInstance = false;
        }
        onFragmentActivated();

        NowPlayingManager.getInstance().setManagerUpdatesListener(new NowPlayingManager.OnUpdate() {
            @Override
            public void onPlaybackUpdate() {

                // Crashlytics #2349 - the app crashes on Android 8+ if the app is in background and
                // we try to start a service
                if (mNowPlayingViewModel == null || !MainApplication.isInForeground() ||
                        DokUiUtils.isDestroyed(getActivity()) || getView() == null) {
                    return;
                }
            }
        });
    }

    public void onStop() {
        NowPlayingManager.getInstance().setManagerUpdatesListener(null);

        super.onStop();
    }

    @Override
    public void onDestroyView() {
        if (mBinding != null) {
            if (mBinding.hasPendingBindings()) {
                mBinding.executePendingBindings();
            }
            mBinding.unbind();
            mBinding.getNowPlayingVM().dispose();
            mNowPlayingViewModel = null;
        }
        super.onDestroyView();
    }

    public void onPause() {
        super.onPause();

        fragmentUninitialize();
    }

    public void onResume() {
        super.onResume();

        fragmentInitialize();
    }

    private void setupControls() {

        mBinding.buttonPrev.setOnClickListener(v -> onPreviousBtn());

        mBinding.buttonNext.setOnClickListener(v -> onNextBtn());

        mBinding.buttonShare.setOnClickListener(view -> onShareBtnClick());

        mPlayPosSeekBar = getView().findViewById(R.id.seekBarPlayPosition);
        mPlayPosSeekBar.setPadding(12, 0, 12, 0);
        mPlayPosSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                seekPlaybackToPos(seekBar.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                if (fromUser) {
                    long seekPos = NowPlayingManager.getInstance().getPositionMilisec(progress, mNowPlayingViewModel.getDuration());

                    mNowPlayingViewModel.trackElapsedText.set(GuiUtils.getMilisecAsTimeStringRoundedDown(seekPos));
                }
            }
        });

        mFrequencySeekBar = getView().findViewById(R.id.seekBarFM);
        mFrequencySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar view) {
                NowPlayingManager.getInstance().setManualFrequency(view.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar view) {
            }

            @Override
            public void onProgressChanged(SeekBar view, int progress, boolean fromUser) {
                if (fromUser) {
                    NowPlayingManager.getInstance().onManualFrequencyChanged(progress);
                }
            }
        });

        mPresetIndex = getView().findViewById(R.id.presetActiveTextView);

        addVolumeControl();

        setThemeColorToControls();
    }


    private void addVolumeControl() {
        if (LayoutDecider.isLandscape(getActivity())) {
            Fragment volumeFragment = new VolumeCtrlFragment();
            getChildFragmentManager().beginTransaction().replace(R.id.layoutEmbeddedVolumeCtrl, volumeFragment).commit();
        }
    }

    @Override
    public void onBackButton() {
    }

    @Override
    public synchronized void onFragmentActivated() {
        GuiUtils.hideKeyboard(getActivity());

        mClingDevice = null;

        Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();
        if (currentMode == Mode.DMR) {

            initClingDevice();
            if (!mLocalMediaBound) {
                bindServices();
            }
        } else {
            NowPlayingManager.getInstance().setDMRPlaying(false);
        }

        if (!super.onFragmentActivatedBase())
            return;

        mNowPlayingViewModel.mIsStopping = false;
        FsLogger.log(LOG_TAG + "onFragmentActivated mode: " + currentMode);
    }

    @Override
    public synchronized void onFragmentDeactivated() {
        if (mLocalMediaBound) {
            Activity parent = getActivity();

            if (parent != null) {
                try {
                    parent.getApplicationContext().unbindService(mLocalMediaPlaybackConnection);
                } catch (IllegalArgumentException e) {
                    // service already closed by system
                }
                parent.unregisterReceiver(playerEventStateReceiver);

                mLocalMediaBound = false;
            }
        }

        if (!super.onFragmentDeactivatedBase()) {
            return;
        }
    }

    private void fragmentInitialize() {
        mNowPlayingViewModel.mIsStopping = false;
        mNowPlayingViewModel.setScrollingEnableState();

        registerConnectionStateListener();

        registerMultiroomGroupNotifListener();
    }

    private void fragmentUninitialize() {

        unregisterConnectionStateListener();

        unregisterMultiroomGroupNotifListener();

        mNowPlayingViewModel.mIsStopping = true;
    }

    private void registerMultiroomGroupNotifListener() {
        unregisterMultiroomGroupNotifListener();
        MultiroomGroupManager.getInstance().addListener(this);
    }

    private void unregisterMultiroomGroupNotifListener() {
        MultiroomGroupManager.getInstance().removeListener(this);
    }

    private void unregisterConnectionStateListener() {
        ConnectionStateUtil.getInstance().removeListener(this);
    }

    private void registerConnectionStateListener() {
        unregisterConnectionStateListener();

        ConnectionStateUtil.getInstance().addListener(this, true);
    }

    @Override
    public void onGroupingUpdate() {
        Activity parentActivity = getActivity();
        if (parentActivity != null) {
            parentActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //???updateButtons();
                }
            });
        }
    }

    @Override
    public void onStateUpdate(final ConnectionState newState) {
        Activity parentActivity = getActivity();
        if (parentActivity != null) {
            parentActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mNowPlayingViewModel == null || mNowPlayingViewModel.mIsStopping) {
                        return;
                    }

                    FsLogger.log("LocalMedia: ConnectionState: " + newState);
                    switch (newState) {

                        case NO_WIFI_OR_ETHERNET:
                        case CONNECTED_RADIO_AP_MODE:
                        case NOT_CONNECTED_TO_RADIO:
                        case INVALID_SESSION:
                        case DISCONNECTED:
                        case DISCONNECTED_PIN_ERROR:
                            mClingDevice = null;
                            break;

                        case SEARCHING_RADIOS_NO_SPEAKER_FOUND_YET:
                        case SEARCHING_RADIOS_SPEAKER_FOUND:
                        case NO_RADIOS_FOUND:
                            break;

                        case CONNECTED_TO_RADIO:
                            initClingDevice();

                            NowPlayingManager.getInstance().updateAllPlaybackInfo(true, false);
                            break;

                        default:
                            break;
                    }
                }
            });
        }

    }

    private void setThemeColorToControls() {
        int topColor = GuiUtils.getColorFromAttribute(getContext(), R.attr.nowplaying_icons_color);
        int bottomColor = GuiUtils.getColorFromAttribute(getContext(), R.attr.icon_color);

        mBinding.buttonPrev.setColorFilter(bottomColor);
        mBinding.buttonNext.setColorFilter(bottomColor);
        mBinding.buttonScanForward.setColorFilter(bottomColor);
        mBinding.buttonScanBack.setColorFilter(bottomColor);
        mBinding.playButton.setColorFilter(bottomColor);
        mBinding.pauseButton.setColorFilter(bottomColor);
        mBinding.stopButton.setColorFilter(bottomColor);
        mBinding.buttonThumbsUp.setColorFilter(bottomColor);
        mBinding.buttonThumbsDown.setColorFilter(bottomColor);
        mBinding.buttonSkipForward.setColorFilter(bottomColor);
        mBinding.buttonSkipBackward.setColorFilter(bottomColor);
        mBinding.buttonRepeat.setColorFilter(topColor);

        GuiUtils.setTintToToggleButton(mBinding.toggleShuffle, topColor);

        GuiUtils.setTintToDrawable(mPresetIndex.getBackground(), getContext(), R.attr.sources_icon_color);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            GuiUtils.setTintToDrawable(mFrequencySeekBar.getThumb(), getContext(), R.attr.fmbar_thumb_color);
        }
    }

    protected void seekPlaybackToPos(int progress) {
        if (NetRemoteManager.getInstance().checkConnection()) {
            long seekPos = NowPlayingManager.getInstance().getPositionMilisec(progress, mNowPlayingViewModel.getDuration());
            NowPlayingManager.getInstance().seek(seekPos);
            mNowPlayingViewModel.setPosition(seekPos);
        }
    }

    protected void onPreviousBtn() {
        if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.DMR) {
            FsLogger.log(LOG_TAG + "Attempting to play previous local media track");

            if (!mLocalMediaBound) {
                pendingAction = "prev";
                bindServices();
                return;
            }

            if (mClingDevice == null) {
                initClingDevice();
            }

            if ((mClingDevice != null) && (mLocalMediaService != null)) {
                if (mLocalMediaService.hasPrev(mClingDevice)) {
                    mLocalMediaService.playPreviousForDevice(mClingDevice);
                } else {
                    Toast.makeText(getActivity(), R.string.dmr_no_prev_track, Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            NowPlayingManager.getInstance().previous();
        }
    }

    protected void onNextBtn() {
        if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.DMR) {
            FsLogger.log(LOG_TAG + "Attempting to play next local media track");

            if (!mLocalMediaBound) {
                pendingAction = "next";
                bindServices();
                return;
            }

            if (mClingDevice == null) {
                initClingDevice();
                FsLogger.log("LocalMedia: init on next cling device");
            }

            if ((mClingDevice != null) && (mLocalMediaService != null)) {
                if (mLocalMediaService.hasNext(mClingDevice)) {
                    mLocalMediaService.playNextForDevice(mClingDevice);
                } else {
                    Toast.makeText(getActivity(), R.string.dmr_no_next_track, Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            NowPlayingManager.getInstance().next();
        }
    }

    @Override
    public String getStaticTag() {
        return FRAGMENT_TAG;
    }

    private void initClingDevice() {
        mClingDevice = null;

        Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();
        if (currentMode != Mode.DMR) {
            return;
        }

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio != null) {
            try {
                mClingDevice = (RemoteDevice) ClingHelper.createClingDevice(radio);
                ClingHelper.createDeviceAVTransportService();

                FsLogger.log("LocalMedia: initClingDevice " + mClingDevice);
            } catch (URISyntaxException e) {
                FsLogger.log(LOG_TAG + "Error constructing URI with manufacture details for Cling device", LogLevel.Error);
            } catch (ValidationException e) {
                FsLogger.log(LOG_TAG + "Error constructing Cling device object with given parameters", LogLevel.Error);
            } catch (MalformedURLException e) {
                FsLogger.log(LOG_TAG + "Error creating Cling device with with URL descriptor", LogLevel.Error);
            } catch (UnknownHostException e) {
                FsLogger.log(LOG_TAG + "Error creating Cling device with InetAddress address", LogLevel.Error);
            }
        }
    }

    private void onShareBtnClick() {
        if (System.currentTimeMillis() - mLastShareBtnClickTime > WAIT_SHARE_BTN_CLICK_TIME_MS) {
            AnalyticsSender.sendShareNowPlayingEvent();
            mLastShareBtnClickTime = System.currentTimeMillis();
            Activity parentActivity = getActivity();
            if (parentActivity != null) {
                shareCurrentlyPlaying();
            }
        }
    }

    public void shareCurrentlyPlaying() {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.playing_via_undok));
        sendIntent.putExtra(Intent.EXTRA_TEXT, getShareMessage());
        sendIntent.setType("text/plain");
        
        Intent shareIntent = Intent.createChooser(sendIntent, null);
        startActivity(shareIntent);
    }

    private String getShareMessage() {
        return getString(R.string.listening_to_hashtag) + " " + mNowPlayingViewModel.playInfoName.get() + " - " +
                mNowPlayingViewModel.secondLineInfoText.get() + " " + getString(R.string.undok_hashtag);
    }

}