package com.frontier_silicon.fsirc.dok2.connectedSpeaker;

public interface IParentActivity {

	void switchFragment(String fragmentTag);
}
