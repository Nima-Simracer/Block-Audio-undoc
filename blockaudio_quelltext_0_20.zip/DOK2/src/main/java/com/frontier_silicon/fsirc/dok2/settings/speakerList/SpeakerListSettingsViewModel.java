package com.frontier_silicon.fsirc.dok2.settings.speakerList;

import android.app.Activity;

import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import java.util.List;

/**
 * Created by lsuhov on 12/10/2017.
 */

public class SpeakerListSettingsViewModel implements IMultiroomGroupingListener {

    private Activity mActivity;
    private SpeakerListSettingsAdapter mAdapter;

    public SpeakerListSettingsViewModel(Activity activity) {
        mActivity = activity;

        init();
    }

    public void init() {
        mAdapter = new SpeakerListSettingsAdapter(mActivity);
    }

    public void onResume() {
        MultiroomGroupManager.getInstance().addListener(this);

        updateListOfSpeakers();
    }

    public void onPause() {
        MultiroomGroupManager.getInstance().removeListener(this);
    }

    public SpeakerListSettingsAdapter getAdapter() {
        return mAdapter;
    }


    @Override
    public void onGroupingUpdate() {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        mActivity.runOnUiThread(() -> {
            if (DokUiUtils.isDestroyed(mActivity)) {
                return;
            }

            updateListOfSpeakers();
        });
    }

    private void updateListOfSpeakers() {
        List<MultiroomItemModel> multiroomItemModelList = MultiroomGroupManager.getInstance().getFlatGroupDeviceList();

        mAdapter.swapItems(multiroomItemModelList);
    }

    public void dispose() {
        mActivity = null;

        mAdapter.dispose();
        mAdapter = null;
    }
}
