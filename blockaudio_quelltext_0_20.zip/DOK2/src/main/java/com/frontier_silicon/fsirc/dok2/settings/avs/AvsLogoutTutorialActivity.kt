package com.frontier_silicon.fsirc.dok2.settings.avs

import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.StyleSpan
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView

import com.frontier_silicon.components.common.ExternalAppsOpener
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase

class AvsLogoutTutorialActivity : UndokActivityBase() {
    private var txtFooter: TextView? = null
    private var screenDescription: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.avs_logout_activity)

        setupAppBar()
        setTitle(R.string.avs_logout_title)

        txtFooter = findViewById(R.id.avs_footer)
        screenDescription = findViewById(R.id.screen_description)
        setText(screenDescription!!, R.string.logout_avs_tutorial)
        setText(txtFooter!!, R.string.footer_avs_login_finish)
    }

    private fun setText(textView: TextView, stringToShowId: Int) {
        val alexaApp = getString(R.string.logout_alexa_app)

        var stringToShow = getString(stringToShowId, alexaApp)
        stringToShow = SmartRadioStringsManager.getSmartRadioString(stringToShow, true)
        val startIndex = stringToShow.indexOf(alexaApp)
        val endIndex = startIndex + alexaApp.length

        val spannableStringBuilder = SpannableStringBuilder(stringToShow)
        spannableStringBuilder.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                ExternalAppsOpener.openAlexaApp(this@AvsLogoutTutorialActivity)
            }
        }, startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)


        spannableStringBuilder.setSpan(StyleSpan(Typeface.BOLD), startIndex, endIndex, 0)

        textView.movementMethod = LinkMovementMethod.getInstance()
        textView.setText(spannableStringBuilder, TextView.BufferType.SPANNABLE)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(Menu.NONE, ACTION_DONE, Menu.NONE, R.string.avs_login_finish_done).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            ACTION_DONE -> {
                finish()
                return true
            }

            else -> return false
        }
    }

    companion object {
        private val ACTION_DONE = 1
    }
}
