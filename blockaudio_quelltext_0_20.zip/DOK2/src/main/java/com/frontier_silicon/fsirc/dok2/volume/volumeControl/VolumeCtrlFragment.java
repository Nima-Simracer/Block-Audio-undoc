package com.frontier_silicon.fsirc.dok2.volume.volumeControl;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.VolumeCtrlFragmentBinding;
import com.frontier_silicon.fsirc.dok2.volume.VolumeManager;

public class VolumeCtrlFragment extends Fragment  {

    public static final String FRAGMENT_TAG = "TAG_VOLUME_CTRL_FRAGMENT";
    VolumeCtrlFragmentBinding mBinding;
    private VolumeCtrlViewModel mVolumeCtrlViewModel;
    private VolumeManager mVolumeManager;

    public VolumeCtrlFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        initVolumeManager();

        mBinding = DataBindingUtil.inflate(inflater, R.layout.volume_ctrl_fragment, container, false);

        mVolumeCtrlViewModel = new VolumeCtrlViewModel(mBinding, getActivity());

        mBinding.setVolumeCtrVM(mVolumeCtrlViewModel);

        return mBinding.getRoot();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        setupControls();
    }

    private void initVolumeManager() {
        if (mVolumeManager == null) {
            mVolumeManager = VolumeManager.getInstance();
        }
    }

    public void onResume() {
        super.onResume();

        mVolumeCtrlViewModel.addListeners();
        mVolumeCtrlViewModel.updateAll();
    }

    public void onPause() {
        super.onPause();

        mVolumeCtrlViewModel.removeListeners();
    }

    private void setupControls() {
        mBinding.seekBarVolume.setOnSeekBarChangeListener(mVolumeCtrlViewModel);
    }

    @Override
    public void onDestroyView() {

        if (mVolumeCtrlViewModel != null) {
            mVolumeCtrlViewModel.dispose();
        }

        mBinding = null;
        mVolumeManager = null;
        mVolumeCtrlViewModel = null;

        super.onDestroyView();
    }
}
