package com.frontier_silicon.fsirc.dok2.settings;

import android.content.Context;
import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.Node.NodeAvsHastoken;
import com.frontier_silicon.NetRemoteLib.Node.NodeDefs;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomDeviceTransportOptimisation;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidLang;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysFactoryReset;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysSleep;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.EqualizerUtil;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;


public class SettingsUtil {

	public static final String testLang = "Testlang";

    public SettingsUtil() {

	}

	private boolean isSleepSupported(Radio radio) {

        NodeSysSleep sleepNode = (NodeSysSleep) radio.nodeSyncGetter(NodeSysSleep.class).get();

		return sleepNode != null;
	}

	private boolean isFactoryResetSupported(Radio radio) {

        boolean isSupported = radio.nodeSyncSetter(new NodeSysFactoryReset(NodeSysFactoryReset.Ord.NONE)).set();

		return isSupported;
	}

	private boolean mIsLanguageSupported;
	private boolean isLanguageSupported(Radio radio)
	{
		mIsLanguageSupported = false;

        radio.getListNode(NodeSysCapsValidLang.class, "-1", NodeDefs.MaxItemsForList, true, new IGetNodeCallback() {
            @Override
            public void getNodeResult(NodeInfo node) {
                NodeSysCapsValidLang lListNode = (NodeSysCapsValidLang) node;

                if (lListNode != null) {
                    if (lListNode.Size() == 2 && (lListNode.getItem(0).getLangLabel().contentEquals(testLang) ||
                            lListNode.getItem(1).getLangLabel().contentEquals(testLang))) {
                        mIsLanguageSupported = false;
                    } else {
                        mIsLanguageSupported = true;
                    }
                }
            }

            @Override
            public void getNodeError(Class nodeType, NodeErrorResponse error) {
                mIsLanguageSupported = false;
            }
        });
		return mIsLanguageSupported;
	}

	public void getGroupSettings(String groupId, ISettingsControlListener listener, Context context) {
        SettingsUpdateTask updateSettingsTask = new SettingsUpdateTask(groupId, listener, context);
        TaskHelper.execute(updateSettingsTask);
	}
	
	private ArrayList<SettingsItemModel> getGroupSettingsImpl(String groupId, Context context) {
		ArrayList<SettingsItemModel> settingsItemsList = new ArrayList<>();

		if (context == null) {
            return settingsItemsList;
        }

        MultiroomDeviceModel serverDeviceModel = MultiroomGroupManager.getInstance().getServerDeviceFromGroupId(groupId);
        if (serverDeviceModel == null) {
            return settingsItemsList;
        }

        Radio serverRadio = serverDeviceModel.mRadio;
        if (serverRadio == null) {
            return settingsItemsList;
        }

        addTransportOptimisationIfSupported(serverRadio, context, settingsItemsList);

        if (isSleepSupported(serverRadio)) {
            settingsItemsList.add(new SettingsItemModel(SettingsType.SLEEP, context.getString(R.string.sleep), true));
        }

        settingsItemsList.add(new SettingsItemModel(SettingsType.DIVIDER,
                SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.manage_devices, false),
                false));

        addAllDevicesAsSettingsListItems(groupId, settingsItemsList);

		return settingsItemsList;
	}

    private void addTransportOptimisationIfSupported(Radio radio, Context context, ArrayList<SettingsItemModel> settingsItemsList) {

        NodeMultiroomDeviceTransportOptimisation nodeOptimisation = (NodeMultiroomDeviceTransportOptimisation) radio.
                nodeSyncGetter(NodeMultiroomDeviceTransportOptimisation.class).get();

        if (nodeOptimisation == null)
            return;

        boolean transportOptimisation = nodeOptimisation.getValue() != 0;
        settingsItemsList.add(new SettingsItemModel(SettingsType.TRANSPORT_OPTIMISATION,
                context.getString(R.string.network_optimisation), null, false, true, transportOptimisation));
    }

	private void addBluetoothSettings(Context context, List<SettingsItemModel> settingsItemsList) {
		settingsItemsList.add(new SettingsItemModel(SettingsType.BLUETOOTH,
				context.getString(R.string.bluetooth_settings), null, true, false, false));
	}

    private void addAllDevicesAsSettingsListItems(String groupId, ArrayList<SettingsItemModel> settingsItemsList) {

        List<MultiroomDeviceModel> deviceList = MultiroomGroupManager.getInstance().getAllDevicesForGroupId(groupId);

        if (deviceList.size() > 0) {
            Collections.sort(deviceList, new Comparator<MultiroomDeviceModel>() {
                @Override
                public int compare(MultiroomDeviceModel lhs, MultiroomDeviceModel rhs) {
                    if (lhs.mRadio != null && lhs.mRadio != null) {
                        return lhs.toString().compareToIgnoreCase(rhs.toString());
                    } else {
                        return 0;
                    }
                }
            });

            for (MultiroomDeviceModel deviceModel : deviceList) {
                if (deviceModel.mRadio != null) {
                    settingsItemsList.add(new SettingsItemModel(SettingsType.AUDIO_DEVICE,
                            deviceModel.toString(), deviceModel.mRadio.getUDN(), true));
                }
            }
        }

	}

	public void getDeviceSettings(Radio radio, ISettingsControlListener listener, Context context) {
		SettingsUpdateTask updateSettingsTask = new SettingsUpdateTask(radio, listener, context);
		TaskHelper.execute(updateSettingsTask);
	}

	private ArrayList<SettingsItemModel> getDeviceSettings(Radio radio, Context context) {

		final ArrayList<SettingsItemModel> settingsItemsList = new ArrayList<>();

		if (context != null) {

			if (isLanguageSupported(radio)) {
                settingsItemsList.add(new SettingsItemModel(SettingsType.LANGUAGE, context.getString(R.string.undok_language), true));
            }

            MultiroomGroupManager groupManager = MultiroomGroupManager.getInstance();
            MultiroomDeviceModel deviceModel = groupManager.getDeviceByUdn(radio.getUDN());
            boolean isSingleDevice = deviceModel != null && (groupManager.isUngroupedDevicesGroup(deviceModel.mGroupId) ||
                            groupManager.isSecondaryStereoGroup(deviceModel.mGroupId));

			if (isSingleDevice && isSleepSupported(radio)) {
                settingsItemsList.add(new SettingsItemModel(SettingsType.SLEEP, context.getString(R.string.sleep), true));
			}

			if (EqualizerUtil.isEqualizerSupported(radio)) {
				settingsItemsList.add(new SettingsItemModel(SettingsType.EQUALIZER, context.getString(R.string.equalizer), true));
			}

			if (isDateTimeSupported(radio)) {
				settingsItemsList.add(new SettingsItemModel(SettingsType.CLOCK, context.getString(R.string.date_time_settings), true));
			}

            if (isFactoryResetSupported(radio)) {
                settingsItemsList.add(new SettingsItemModel(SettingsType.FACTORY_RESET, context.getString(R.string.factory_reset), false));
            }

            boolean isAudioQualityEnabled = checkIfAudioQualitySettingsIsPresent(radio);

			if (isAudioQualityEnabled || shouldDisplayAudioQualitySetting()){
				settingsItemsList.add(new SettingsItemModel(SettingsType.AIRABLE_SOUND_QUALITY,
						context.getString(R.string.airable_quality), true));
			}

            if (radio.hasAVS()) {
                RadioNodeUtil.getNodesFromRadio(radio, new Class[]{NodeAvsHastoken.class}, true, true, new RadioNodeUtil.INodesResultListener() {
                    @Override
                    public void onNodesResult(Map<Class, NodeInfo> nodes) {
                        NodeAvsHastoken nodeAvsHastoken = (NodeAvsHastoken) nodes.get(NodeAvsHastoken.class);
                        if (nodeAvsHastoken == null) {
                            return;
                        }

                        FsLogger.log("AVS: " + nodeAvsHastoken.getValueEnum());

                        if (nodeAvsHastoken.getValueEnum() == NodeAvsHastoken.Ord.FALSE) {
                            settingsItemsList.add(new SettingsItemModel(SettingsType.AVS_LOGIN, context.getString(R.string.settings_avs_login), true));
                        } else {
                            settingsItemsList.add(new SettingsItemModel(SettingsType.AVS_ALARMS, context.getString(R.string.settings_avs), true));
                            settingsItemsList.add(new SettingsItemModel(SettingsType.AVS_LOGOUT, context.getString(R.string.settings_avs_logout), true));
                        }
                    }
                });

            }
        }

		return settingsItemsList;
	}

	private boolean shouldDisplayAudioQualitySetting() {
	    Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
	    if ( currentRadio != null && currentRadio.getFirmwareVersion() != null && !currentRadio.getFirmwareVersion().isEmpty()) {
	        return (currentRadio.isVeniceXDevice());
        }

	    return false;
    }

    private boolean mIsDateTimeSupported = false;
    public boolean isDateTimeSupported(Radio radio) {
        mIsDateTimeSupported = false;

        if (radio != null) {
            radio.getListNode(NodeSysCapsClockSourceList.class, true, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    mIsDateTimeSupported = (node != null);
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {}
            });
        }

        return mIsDateTimeSupported;
    }

    private boolean checkIfAudioQualitySettingsIsPresent(Radio radio) {
        NodeSysCapsValidModes validModes = radio.getValidModesSync();
        if (validModes == null) {
            return false;
        }

        return  validModes.hasAirableModes() || validModes.hasSpotify();
    }

	private class SettingsUpdateTask extends AsyncTask<Void, Integer, Boolean> {

		ArrayList<SettingsItemModel> mSettingsItemsList = new ArrayList<>(); //Crashlytics fix #2590
		private ISettingsControlListener mListener;
		private Context mContext;
		private Radio mRadio;
		private boolean mIsGroupSettings;
        private String mGroupId;
		
		public SettingsUpdateTask(Radio radio, ISettingsControlListener listener, Context context) {
			mListener = listener;
			mContext = context;
			mRadio = radio;
			mIsGroupSettings = false;
		}

        public SettingsUpdateTask(String groupId, ISettingsControlListener listener, Context context) {
            mListener = listener;
            mContext = context;
            mGroupId = groupId;
            mIsGroupSettings = true;
        }
		
		@Override
		protected Boolean doInBackground(Void... arg0) {

			if (mIsGroupSettings) {
				mSettingsItemsList = getGroupSettingsImpl(mGroupId, mContext);
			} else {
                if (mRadio == null) {
                    return true;
                }

				mSettingsItemsList = getDeviceSettings(mRadio, mContext);

			}

			return true;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			if (mListener != null) {
				mListener.onSettingsUpdated(mSettingsItemsList);
			}

			dispose();
		}

        private void dispose() {
            mListener = null;
            mSettingsItemsList = null;
            mContext = null;
            mRadio = null;
        }
    }

	public static boolean isRadioAvailable(SettingsItemModel item) {
		boolean isAvailable = true;

		if (item.mType == SettingsType.AUDIO_DEVICE) {
			Radio radio = NetRemoteManager.getInstance().getRadio(item.mRadioUDN);
			if (radio != null) {
				isAvailable = (!radio.isCheckingAvailability() && radio.isAvailable());
			}
		}

		return isAvailable;
	}
}
