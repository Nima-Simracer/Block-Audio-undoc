package com.frontier_silicon.fsirc.dok2.connection;

import android.app.Activity;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.ConnectionErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.IConnectionCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.IButtonsResponseWithTextListener;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

public class RadioConnectivityHandler implements IConnectionCallback, IRadioDiscoveryListener {

    private boolean mShouldAutoConnectToLastSpeaker = false;
    private boolean mDiplayPinSecondAttempt = false;
    private final Object autoConnectLock = new Object();

    public void init() {

        NetRemoteManager.getInstance().addConnectionListener(this);
        NetRemoteManager.getInstance().addRadioDiscoveryListener(this);
    }

    void setShouldAutoConnectToLastSpeaker(boolean autoConnect) {
        mShouldAutoConnectToLastSpeaker = autoConnect;
    }

    void cleanup() {

        NetRemoteManager.getInstance().removeConnectionListener(this);
        NetRemoteManager.getInstance().removeRadioDiscoveryListener(this);
    }

    @Override
	public void onConnectionSuccess(Radio radio) {
        mShouldAutoConnectToLastSpeaker = false;
    }

	@Override
	public void onConnectionError(Radio radio, ConnectionErrorResponse error) {
		FsLogger.log("RadioConnectivityHandler: conn error " + radio + " " + error);

		if (NetRemoteManager.isPinError(error)) {
		    if (mShouldAutoConnectToLastSpeaker) {
		        displayWrongPinAlert();
            }
			showPINDialog(radio);
		}
	}

	@Override
	public void onDisconnected(Radio radio, ConnectionErrorResponse error) {}

	private void showPINDialog(final Radio radio) {
        final Activity parentActivity = MainApplication.getCurrentActivity();
        if (DokUiUtils.isDestroyed(parentActivity)) {
            FsLogger.log("showPINDialog was cancelled because  parentActivity is null", LogLevel.Error);
            return;
        }

		RadioPINManager.getInstance().showIncorrectPINDialog(parentActivity, radio, new IButtonsResponseWithTextListener() {
			@Override
			public void onOkClicked(String response) {
                if (radio == null || DokUiUtils.isDestroyed(parentActivity))
                    return;

                ConnectionManager.getInstance().tryConnectToSelectedRadio(radio);
                mShouldAutoConnectToLastSpeaker = true;
			}

			@Override
			public void onCancelClicked() {
				NetRemoteManager.getInstance().setCurrentRadio(null);
                mShouldAutoConnectToLastSpeaker = false;
			}
		});
	}

    @Override
    public void onRadioFound(Radio radio) {
        radio.setPIN(NetRemoteManager.getInstance().getPIN(radio));
    }

    @Override
    public void onRadioLost(Radio radio, boolean rescanInProgress) {}

    @Override
    public void onRadioUpdated(Radio radio) {
        autoConnectAtStart();
    }

	private void autoConnectAtStart() {
        synchronized (autoConnectLock) {
            // This function is called from different threads
            if (!mShouldAutoConnectToLastSpeaker) {
                return;
            }

            Radio lastConnectedRadio = ConnectionManager.getInstance().getLastConnectedDevice();

            // connect to previously connected radio
            if (lastConnectedRadio != null && lastConnectedRadio.isAvailable()) {
                ConnectionManager.getInstance().connectToLastConnectedDevice();

                mShouldAutoConnectToLastSpeaker = false;
            }
        }
    }

    private void displayWrongPinAlert() {
        NetRemote.getMainThreadExecutor().execute(() -> {
            Toast.makeText(MainApplication.getCurrentActivity(), R.string.wrong_pin, Toast.LENGTH_LONG).show();
        });

    }
}
