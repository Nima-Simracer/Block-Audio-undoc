package com.frontier_silicon.fsirc.dok2.settings.equalizer;

import java.util.List;

import com.frontier_silicon.fsirc.dok2.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class EqualizerArrayAdapter extends ArrayAdapter<EqualizerItemModel> {

	private Context mContext;

	private final ICustomEqualizerControlListener mCustomEqValueListener;
	private final ICustomEditListener mListener;

	public EqualizerArrayAdapter(Context context, int resource, int textViewResourceId, List<EqualizerItemModel> objects, ICustomEditListener listener, ICustomEqualizerControlListener customEqValueListener) {
		super(context, resource, textViewResourceId, objects);
		
		mContext = context;
		mListener = listener;
		mCustomEqValueListener = customEqValueListener;
	}	
	
    @SuppressLint("InflateParams")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
    	View v = convertView;
		LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		final EqualizerItemModel item = getItem(position);
		
		if (v == null)
			v = li.inflate(R.layout.equalizer_list_item, null);
			
		String text = item.mName;
		
		TextView tv = (TextView) v.findViewById(R.id.text1);
		tv.setText(text);
		
		ImageView imageSelected = (ImageView) v.findViewById(R.id.imageViewSelected);
		if (item.mIsSet) {
			imageSelected.setVisibility(View.VISIBLE);
		} else {
			imageSelected.setVisibility(View.INVISIBLE);
		}
		
		ImageView imageEdit = (ImageView) v.findViewById(R.id.imageViewEdit);
		imageEdit.setVisibility(View.GONE);

		LinearLayout customEQBandsLayout = (LinearLayout) v.findViewById(R.id.layoutCustomEQBands);
		if (item.mIsCustomEq && item.mIsSet) {
			customEQBandsLayout.setVisibility(View.VISIBLE);
			setupCustomEQBands(customEQBandsLayout, item);
		} else {
			customEQBandsLayout.setVisibility(View.GONE);
		}

		View layoutEqualizerItem = v.findViewById(R.id.layoutEqualizerItem);
		layoutEqualizerItem.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				if (mListener != null) {
					mListener.onListItemClick(item);
				}
			}
		});
		
		return v;
	}

	private void setupCustomEQBands(LinearLayout rootView, final EqualizerItemModel itemModel) {
		for (final CustomEqualizerItemModel customEQBandItem : itemModel.mEqualizerItemsList) {

			View customEqBandView = rootView.findViewWithTag(customEQBandItem.mName);
			if (customEqBandView == null) {
				LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				customEqBandView = li.inflate(R.layout.equalizer_band_list_item, null);

				customEqBandView.setTag(customEQBandItem.mName);

				rootView.addView(customEqBandView);
			}

			TextView tv = (TextView) customEqBandView.findViewById(R.id.text1);
			tv.setText(customEQBandItem.mName);
			final SeekBar equalizerSeek = (SeekBar) customEqBandView.findViewById(R.id.seekBar);
			equalizerSeek.setProgress(customEQBandItem.getPercentValue());

			equalizerSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {
					notifyDataSetChanged();

					notifyListenerValueChanged(customEQBandItem);
				}

				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					if (fromUser) {
						customEQBandItem.setValueFromPercent(progress);
					}
				}
			});

		}

		if (itemModel.mIsLoudnessAvailable) {
			View eqLoudnessView = rootView.findViewWithTag(itemModel.mName);
			if (eqLoudnessView == null) {
				LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				eqLoudnessView = li.inflate(R.layout.equalizer_loudness_list_item, null);
				eqLoudnessView.setTag(itemModel.mName);

				rootView.addView(eqLoudnessView);
			}

			CheckBox loudnessCheckBox = (CheckBox) eqLoudnessView.findViewById(R.id.checkBoxLoudness);
			loudnessCheckBox.setOnCheckedChangeListener(null);
			loudnessCheckBox.setChecked(itemModel.mIsLoudnessEnabled);

			loudnessCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					itemModel.mIsLoudnessEnabled = isChecked;

					notifyDataSetChanged();

					notifyListenerLoudnessValueChanged(isChecked);
				}
			});
		}
	}

	private void notifyListenerLoudnessValueChanged(boolean isChecked) {
		if (mCustomEqValueListener != null) {
			mCustomEqValueListener.onLoudnessValueChange(isChecked);
		}
	}

	private void notifyListenerValueChanged(CustomEqualizerItemModel customEqItem) {
		if (mCustomEqValueListener != null) {
			mCustomEqValueListener.onValueChange(customEqItem);
		}
	}

}
