package com.frontier_silicon.fsirc.dok2.stereo;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;

import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

/**
 * Created by lsuhov on 06/08/2017.
 */

public abstract class StereoSpeakerListItemViewModel {

    public ObservableField<String> name = new ObservableField<>();
    public ObservableField<BitmapDrawable> speakerImage = new ObservableField<>();

    protected StereoItemModel mStereoItemModel;
    protected Activity mActivity;

    public StereoSpeakerListItemViewModel(StereoItemModel stereoItemModel, Activity activity) {
        mStereoItemModel = stereoItemModel;
        mActivity = activity;

        if(stereoItemModel.deviceModel == null) {
            FsLogger.log("StereoItemModel seems to be a couple instead of speaker", LogLevel.Error);
            return;
        }

        init();
    }

    private void init() {
        updateName();

        updateSpeakerImage();
    }

    private void updateName() {
        name.set(mStereoItemModel.deviceModel.mRadio.getFriendlyName());
    }

    private void updateSpeakerImage() {

        DokUiUtils.setImageIntoObservableDrawable(speakerImage, mStereoItemModel.deviceModel.mRadio, mActivity);
    }

    public void onPlayAlertToneClicked(View v) {
        StereoManager.getInstance().playAlertTone(mStereoItemModel.deviceModel.mRadio);
    }

    public abstract void onListItemClicked(View v);

    public void dispose() {
        mStereoItemModel = null;
        mActivity = null;
    }
}
