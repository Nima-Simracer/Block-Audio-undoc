package com.frontier_silicon.fsirc.dok2.settings.account

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.frontier_silicon.fsirc.dok2.NavigationHelper
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase
import com.frontier_silicon.fsirc.dok2.settings.general.GeneralSettingsActivity
import com.frontier_silicon.fsirc.dok2.setup.SetupManager
import com.frontier_silicon.fsirc.dok2.setup.fsdca.SetupFSDCAAssociationActivity

class FSDCALoginActivity : UndokActivityBase(), IFSDCAConnectionStatus {
    private var loginButton: Button? = null
    private val mAuthManager = FSAuthManager.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fsdca_login_activity)


        setupAppBar()
        enableUpNavigation()
        setTitle(R.string.account_management)

        setup()
        setredirectUrlForOAuth()
    }

    override fun onResume() {
        super.onResume()
        mAuthManager.setConnectionListener(this)
    }


    private fun setup() {
        loginButton = findViewById(R.id.btn_login)
        findViewById<TextView>(R.id.loginMessageTextView).setText(SmartRadioStringsManager.getSmartRadioString(R.string.fsdca_login, true))

        loginButton!!.setOnClickListener { v -> mAuthManager.authenticate(this@FSDCALoginActivity) }
    }

    private fun setredirectUrlForOAuth() {
        mAuthManager.setLoginUiFilterIntent(intent)
    }

    override fun onPause() {
        super.onPause()
        mAuthManager.setConnectionListener(null)
    }

    override fun onConnected() {
        if (SetupManager.getInstance().isFsdcaSpeakerInSetup) {
            val bundle = Bundle()
            bundle.putBoolean(START_ASSOCIATION_AUTOMATICALLY, true)
            NavigationHelper.goToActivity(this@FSDCALoginActivity, SetupFSDCAAssociationActivity::class.java, NavigationHelper.AnimationType.SlideToRight, true, bundle)
        } else {
            NavigationHelper.goToActivity(this@FSDCALoginActivity, FSDCAMainActivity::class.java, NavigationHelper.AnimationType.SlideToLeft, true)
        }
    }

    override fun onFailedConnecting() {
        Toast.makeText(this@FSDCALoginActivity, getString(R.string.fsdca_error), Toast.LENGTH_SHORT).show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
        }

        return true
    }

    override fun onBackPressed() {
        if (FSAuthManager.getInstance().wasAccountDeleted) {
            NavigationHelper.goToActivity(this, GeneralSettingsActivity::class.java, NavigationHelper.AnimationType.SlideToRight, true)
        } else {
            super.onBackPressed()
        }
    }

    companion object {
        private val START_ASSOCIATION_AUTOMATICALLY = "START_ASSOCIATION_AUTOMATICALLY"
    }
}