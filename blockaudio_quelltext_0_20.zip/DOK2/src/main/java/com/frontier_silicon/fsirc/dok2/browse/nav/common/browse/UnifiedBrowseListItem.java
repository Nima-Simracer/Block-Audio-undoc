package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

import com.frontier_silicon.NetRemoteLib.Node.BaseNavContextList;
import com.frontier_silicon.NetRemoteLib.Node.BaseNavList;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;

/**
 * Created by adanaila on 18/11/2016.
 */

public class UnifiedBrowseListItem {
    private String mName;
    private NodeListItem.FieldType mType;
    private NodeListItem.FieldSubType mSubtype;
    private Long mKey;
    private String mArtwork;
    private String mArtist;
    private NodeListItem.FieldContextMenu mContextMenu;

    public UnifiedBrowseListItem(BaseNavList.ListItem nli){
        this.mArtwork = nli.getGraphicUri();
        this.mContextMenu = nli.getContextMenu();
        this.mKey = nli.getKey();
        this.mName = nli.getName();
        this.mType = nli.getType();
        this.mSubtype = nli.getSubType();
        this.mArtist = nli.getArtist();
    }

    public UnifiedBrowseListItem(BaseNavContextList.ListItem nli){
        this.mKey = nli.getKey();
        this.mName = nli.getName();
        this.mType = nli.getType();
        this.mSubtype = nli.getSubType();
    }

    public String getName() { return this.mName; }
    public NodeListItem.FieldType getType() { return this.mType; }
    public NodeListItem.FieldSubType getSubType() { return this.mSubtype; }
    public String getGraphicUri() { return this.mArtwork; }
    public String getArtist() { return this.mArtist; }
    public NodeListItem.FieldContextMenu getContextMenu() { return this.mContextMenu; }
    public Long getKey() { return this.mKey; }

    @Override
    public boolean equals(Object object) {
        if (object instanceof UnifiedBrowseListItem) {
            UnifiedBrowseListItem ubli = (UnifiedBrowseListItem) object;
            return this.mName.equals(ubli.mName) &&
                    this.mType == ubli.mType &&
                    this.mSubtype == ubli.mSubtype &&
                    this.mArtwork.equals(ubli.mArtwork) &&
                    this.mArtist.equals(ubli.mArtist) &&
                    this.mKey == ubli.mKey;
        } else {
            return false;
        }
    }
}
