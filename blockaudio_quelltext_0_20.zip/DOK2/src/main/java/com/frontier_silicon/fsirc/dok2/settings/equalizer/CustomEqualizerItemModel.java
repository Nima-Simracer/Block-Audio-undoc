package com.frontier_silicon.fsirc.dok2.settings.equalizer;

public class CustomEqualizerItemModel {

	public String mName;
	public long mValue;
	public long mMinValue;
	public long mMaxValue;
	public long mKeyId;
	
	public CustomEqualizerItemModel(String name, long value, long minValue, long maxValue, long keyId) {
		mName = name;
		mValue = value;
		mMinValue = minValue;
		mMaxValue = maxValue;
		mKeyId = keyId;
	}
	
	public void setValueFromPercent(int percent) {
		float p = (float)percent/100.0f;		
		mValue = (long) ((p * (mMaxValue - mMinValue)) + mMinValue);
	}
	
	public int getPercentValue() {
		float percent = 100.0f * ((float)(mValue - mMinValue) / (float)(mMaxValue - mMinValue));
		return (int)percent;
	}
	
	public void setValue(long value) {
		if (value <= mMaxValue && value >= mMinValue) {
			mValue = value;
		}		
	}
	
}
