package com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems;

import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;

/**
 * Created by adanaila on 10/10/2016.
 */

public class FormComboboxOption {
    private Long key;
    public String name;
    private NodeListItem.FormOptionState state;

    public FormComboboxOption(Long keyP, String nameP, NodeListItem.FormOptionState state)
    {
        this.key = keyP;
        this.name = nameP;
        this.state = state;
    }

    public String getName(){
        return this.name;
    }

    public boolean isSelected() {
        return state == NodeListItem.FormOptionState.Selected;
    }

    @Override
    public boolean equals(Object obj)
    {
        if(obj instanceof FormComboboxOption)
            if(((FormComboboxOption) obj).getName().equals(this.getName()))
                return true;
        return false;
    }

    public String optionSelected()
    {
        //need to add here the text for full generation of this option selected in FormData
        return "=" + key;
    }
}
