package com.frontier_silicon.fsirc.dok2.stereo;

/**
 * Created by lsuhov on 23/11/2017.
 */

public interface IDifferentFwVersionResultListener {
    void continueOperation();
    void goToUpdateSection();
}
