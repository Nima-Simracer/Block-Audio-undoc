package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.widgets.DividerItemDecoration;
import com.frontier_silicon.fsirc.dok2.widgets.LinearLayoutManagerWrapper;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable.ContextFormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable.ContextMessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable.ContextNavUpRunnable;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.ContextBrowseManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseContextMenuDialogBinding;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

/**
 * Created by lsuhov on 23/11/2016.
 */

public class ContextMenuDialogFragment extends DialogFragment {

    private BrowseContextMenuDialogBinding mBinding;
    private ContextMenuDialogViewModel mViewModel;
    private LinearLayoutManager mLayoutManager;
    private  TextView title;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Activity activity = getActivity();
        title = new TextView(getContext());
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setTextSize(17);
        title.setPadding(10,10,10,10);
        if (DokUiUtils.isLightTheme()) {
            title.setTextColor(activity.getResources().getColor(R.color.text_color));
        } else {
            title.setTextColor(activity.getResources().getColor(R.color.dark_black_text_color));
        }

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity).setOnKeyListener((dialog, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK &&
                    event.getAction() == KeyEvent.ACTION_DOWN &&
                    event.getRepeatCount() == 0 &&
                    !event.isCanceled()) {
                //get nav.depth for context navigation, go up one lvl if we are deeper then 0 lvl.
                int itemsType = ContextBrowseManager.getInstance().getPageTypeBasedOnItems();
                if((itemsType != -1)
                        && BrowseItemType.MessageItem == itemsType){
                    ContextBrowseManager.getInstance().CloseContextDialog(true);
                    return true;
                }
                ContextNavUpRunnable contextNavUpRunnable = new ContextNavUpRunnable(result -> {
                    switch (result) {
                        case Success:{
                            ContextFormManager.getInstance().clearItemsLoaded();
                            ContextBrowseManager.getInstance().refreshCurrentList(-1);
                            break;
                        }
                        case RootReached:{
                            ContextBrowseManager.getInstance().CloseContextDialog(false);
                        }
                    }
                });
                new Thread(contextNavUpRunnable).start();
                return true;
            }
            return false;
        });

        BrowseItemModel model = ContextMessageManager.getInstance().getSelectedNavItem();
        int position = ContextMessageManager.getInstance().getSelectedNavItemPosition();
        NodeSysCapsValidModes.Mode mode = SpeakerDataManager.getInstance().getCurrentMode();
        if(model != null && mode != NodeSysCapsValidModes.Mode.AIRABLE_CALM &&
                mode !=  NodeSysCapsValidModes.Mode.AIRABLE_KLASSIK) {
            title.setText(model.getName());
            builder.setCustomTitle(title);
        } else {
            title.setVisibility(View.GONE);
        }

        mBinding = DataBindingUtil.inflate(activity.getLayoutInflater(), R.layout.browse_context_menu_dialog, null, false);
        builder.setView(mBinding.getRoot());

        mViewModel = new ContextMenuDialogViewModel(activity, position, model);
        mBinding.setViewModel(mViewModel);

        setupControls();

        return builder.create();
    }

    private void setupControls() {
        mLayoutManager = new LinearLayoutManagerWrapper(getContext());

        DividerItemDecoration itemDecoration = new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL);

        mBinding.browseItemsList.setHasFixedSize(true);
        mBinding.browseItemsList.setLayoutManager(mLayoutManager);
        mBinding.browseItemsList.addItemDecoration(itemDecoration);

        mBinding.browseItemsList.setAdapter(mViewModel.getAdapter());

        mBinding.cancelButton.setOnClickListener(v -> {
            ContextBrowseManager.getInstance().CloseContextDialog(true);
        });
    }

    @Override
    public void onStart() {
        super.onStart();

        getDialog().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);

        mViewModel.onStart(getDialog());
        getDialog().setCanceledOnTouchOutside(false);
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        if(mViewModel!= null
            &&mViewModel.getShouldRefreshUnderlying())
            ContextMessageManager.getInstance().refreshUnderlyingNavList();
        dispose();
        super.onDismiss(dialog);
    }

    private void dispose() {
        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }

        if (mBinding != null) {
            mBinding.setViewModel(null);
            mBinding = null;
        }

        //mBrowseItemModel = null;
    }
}
