package com.frontier_silicon.fsirc.dok2.settings.speaker;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;

public class AboutSpeakerModel {

	public enum WiFiStrength {
		NONE(0),
		POOR(25),
		GOOD(50),
		EXCELLENT(75);
		
		private int mValue;
		
		WiFiStrength(int value) {
			this.mValue = value;
		}
		
		public int getValue() {
			return mValue;
		}
	}
	
	public Radio mDeviceRadio;
	public MultiroomItemModel mDevice;
	public String mVersion;
	public String mWifiNetworkName;
	public WiFiStrength mWifiNetworkStrength;
	public String mModelName;
	public String mIPAddress;
	public String mMACAddress;
	public int mWifiNetworkStrengthPercent;
	public boolean mWiredInterfaceConnected = false;
	
	public AboutSpeakerModel() {
	}
	
	public AboutSpeakerModel(AboutSpeakerModel item) {
		mDevice = item.mDevice;
		mDeviceRadio = item.mDeviceRadio;
		mVersion = item.mVersion;
		mWifiNetworkName = item.mWifiNetworkName;
		mWifiNetworkStrength = item.mWifiNetworkStrength;
		mIPAddress = item.mIPAddress;
		mMACAddress = item.mMACAddress;
		mWifiNetworkStrengthPercent = item.mWifiNetworkStrengthPercent;
		mWiredInterfaceConnected = item.mWiredInterfaceConnected;
		if (item.mDeviceRadio != null) {
            mModelName = item.mDeviceRadio.getModelName();
        }
	}
	
}
