package com.frontier_silicon.fsirc.dok2.setup.accessPoint.listOfAP;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.databinding.DataBindingUtil;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;
import com.frontier_silicon.NetRemoteLib.Radio.ConnectionErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.IConnectionCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupLocationGrantedActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.AccessPointConfig.AccessPointModel;
import com.frontier_silicon.fsirc.dok2.setup.AccessPointsArrayAdapter;
import com.frontier_silicon.fsirc.dok2.setup.ConnectToSetupAPHelper;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.IConnectToSetupAPListener;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.speakerName.NameYourSpeakerActivity;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by nbalazs on 01/03/2018.
 */

public class ListOfAccessPointActivity extends SetupActivityBase implements IConnectionCallback, IConnectToSetupAPListener {
    private SetupLocationGrantedActivityBinding mBinding;

    private List<AccessPointModel> mAccessPointsList = new ArrayList<>();
    private ProgressBar mScanningProgressBar;
    private TextView mScanningTextView;
    private AccessPointsArrayAdapter mAdapter;
    private SetupManager mSetupManager;
    private ConnectToSetupAPHelper mConnectHelper;
    private boolean mWiFiListenersAreRegistered = false;

    private WifiScanReceiver mWiFiScanReceiver;
    private int mCurrentTimeProgressOfRescan = -1;
    private Timer mProgressTimer;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.setup_location_granted_activity);

        setupControls();

        configureToolbarWithExitButton(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_title_select_wifi, true));

        mWiFiScanReceiver = new WifiScanReceiver();

        mSetupManager = SetupManager.getInstance();

        mConnectHelper = ConnectToSetupAPHelper.getInstance();

        mConnectHelper.attachActivity(this, this);
    }

    private void setupControls() {
        // check if timertask fired after fragment removed or not
        Button backButton = findViewById(R.id.previousButton);
        backButton.setOnClickListener((v) -> onBackPressed());

        Button nextButton = findViewById(R.id.nextButton);
        nextButton.setOnClickListener((v) -> NavigationHelper.goToActivity(this, NameYourSpeakerActivity.class, NavigationHelper.AnimationType.SlideToLeft));

        ListView mListView = findViewById(R.id.acessPointListView);

        @SuppressLint("InflateParams") View listFooterView = LayoutInflater.from(this).inflate(R.layout.setup_list_footer_available_wifi, null);
        mListView.addFooterView(listFooterView);
        mListView.setOnItemClickListener((parent, view, position, id) -> {
            AccessPointModel apModel = (AccessPointModel) parent.getItemAtPosition(position);

            if (apModel == null) {
                return;
            }

            if (SetupManager.getInstance().isConnectedToGivenAP(apModel.getScanResult())) {
                NavigationHelper.goToActivity(this, NameYourSpeakerActivity.class, NavigationHelper.AnimationType.SlideToLeft);
            }

            setNextButtonVisible(false);

            mConnectHelper.tryConnectToAP(apModel);
        });

        mAdapter = new AccessPointsArrayAdapter(this, R.layout.setup_list_item_connect_to_headless, mAccessPointsList);
        mListView.setAdapter(mAdapter);

        mScanningProgressBar = listFooterView.findViewById(R.id.progressBarScanning);
        mScanningTextView = listFooterView.findViewById(R.id.textViewScanningWiFi);

        updateScanningControls();
    }

    private void updateScanningControls() {
        boolean mScanning = mProgressTimer != null;

        mScanningProgressBar.setVisibility(mScanning ? View.VISIBLE : View.GONE);
        mScanningTextView.setVisibility(mScanning ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onStart() {
        mSetupManager = SetupManager.getInstance();

        mSetupManager.registerForRadioConnectionEvents(this);

        if (mSetupManager.getFriendlyName() != null && mSetupManager.getFriendlyName().length() > 0) {
            setNextButtonVisible(true);
        }

        super.onStart();
    }

    @Override
    protected void onResume() {
        registerNetworkListeners();

        mConnectHelper.attachActivity(this, this);

        checkWiFiEnabled();

        mConnectHelper.checkConnectionToAPAndRadio();

        decideHowToRetrieveAccessPoints();

        super.onResume();
    }

    @Override
    protected void onPause() {
        unregisterNetworkListeners();

        mConnectHelper.detachActivity();

        super.onPause();
    }

    @Override
    public void onStop() {
        mSetupManager.removeFromRadioConnectionEvents(this);
        mConnectHelper.unregisterNetworkListeners();

        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_refresh, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_rescan) {
            rescanWiFiAccessPoints();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void getAvailableWiFiAccessPoints() {
        if (mSetupManager.isDisposed())
            return;

        List<AccessPointModel> devicesList = mSetupManager.getCurrentAccessPoints(this);

        updateLayoutIfNeeded(devicesList.size());

        GuiUtils.replaceContentsOfList(mAccessPointsList, devicesList);

        cleanScanTimer();

        updateScanningControls();

        mConnectHelper.checkConnectionToAPAndRadio();

        mAdapter.notifyDataSetChanged();
    }

    private void updateLayoutIfNeeded(int deviceListSize) {
        mBinding.textTopInfo.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.connect_to_radio_description, true));
        if (deviceListSize == 0) {
            String noWifiMessage = getResources().getString(R.string.no_wifi_message);
            mBinding.textTopInfo.setText(!AccessPointUtil.isWifiEnabled() ? noWifiMessage : SmartRadioStringsManager.INSTANCE.getSmartRadioString( R.string.no_suggested_device_found, true));
        } else {
            mBinding.textTopInfo.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.connect_to_radio_description, true));
        }
    }

    protected void rescanWiFiAccessPoints() {
        if (!AccessPointUtil.isWifiEnabled()) {
            showNoWiFiDialog();
        } else if (!AccessPointUtil.checkLocationIfAndroid6OrMore(this)) {
            PermissionsUtil.showLocationDialog(this);
        } else {
            cleanScanTimer();

            if (mProgressTimer == null) {
                mScanningProgressBar.setMax(FsComponentsConfig.MAX_SECONDS_TO_GET_NEW_LIST_OF_AP_FROM_PHONE);

                mProgressTimer = new Timer();
                mProgressTimer.schedule(new ScanWiFiTimerTask(), 0, 1000);

                updateScanningControls();

                mAdapter.clear();
                mSetupManager.startWiFiAccessPointScan();
            }
        }

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void refreshList() {
        ListOfAccessPointActivity.this.runOnUiThread(() -> mAdapter.notifyDataSetChanged());
    }

    @Override
    public void onConnectToApFailed() {
        showCannotConnectDialog();
        mSetupManager.resetConnectedToHeadlessAP();
        refreshList();
    }

    private void checkWiFiEnabled() {
        boolean enabled = AccessPointUtil.isWifiEnabled();

        if (!enabled) {
            showNoWiFiDialog();
        }
    }

    private void showNoWiFiDialog() {
        String dialogKey = "hui_no_wifi_dialog";
        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, this)) {
            return;
        }

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(this);

        builder.setTitle(R.string.no_wifi);
        builder.setMessage(R.string.offer_enable_wifi);
        builder.setPositiveButton(android.R.string.yes, (dialog, which) -> {
            WifiManager wifiManager = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifiManager != null) {
                wifiManager.setWifiEnabled(true);
            }
        });
        builder.setNegativeButton(getString(R.string.go_to_settings), (dialog, which) -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);

        dlg.show();
    }


    private void decideHowToRetrieveAccessPoints() {
        if (mSetupManager.shoudStartNewAccessPointsScan())
            rescanWiFiAccessPoints();
        else {
            if (!AccessPointUtil.checkLocationIfAndroid6OrMore(this)) {
                PermissionsUtil.showLocationDialog(this);
            }
            getAvailableWiFiAccessPoints();
            mSetupManager.startWiFiAccessPointScan();
        }
    }

    private class ScanWiFiTimerTask extends TimerTask {

        @Override
        public void run() {
            if (mSetupManager.isDisposed()) {
                cleanScanTimer();
                return;
            }

            runOnUiThread(() -> {
                if (mCurrentTimeProgressOfRescan < FsComponentsConfig.MAX_SECONDS_TO_GET_NEW_LIST_OF_AP_FROM_PHONE) {
                    mCurrentTimeProgressOfRescan++;
                    mScanningProgressBar.setProgress(mCurrentTimeProgressOfRescan);
                } else {
                    cleanScanTimer();
                    getAvailableWiFiAccessPoints();
                }
            });
        }
    }

    private void cleanScanTimer() {
        if (mProgressTimer != null) {
            mProgressTimer.cancel();
            mProgressTimer.purge();
        }
        mProgressTimer = null;
        mCurrentTimeProgressOfRescan = -1;
    }

    public void onNewWiFiAccessPointsAvailable() {
        getAvailableWiFiAccessPoints();
    }

    private void showCannotConnectDialog() {
        String dialogKey = "hui_cannot_connect";
        Activity parentActivity = this;

        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, parentActivity))
            return;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(parentActivity);
        builder.setTitle(R.string.cannot_connect_title);
        builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.cannot_connect_description, true));
        builder.setPositiveButton(android.R.string.ok, null);

        AlertDialog dialog = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dialog);

        dialog.show();
    }

    @Override
    public void onConnectionSuccess(Radio radio) {
        NavigationHelper.goToActivity(this, NameYourSpeakerActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    @Override
    public void onConnectionError(Radio radio, ConnectionErrorResponse error) {
        mConnectHelper.mManuallyConnectingToRadio = false;
        refreshList();

        CharSequence text = this.getString(R.string.error_connecting_to_radio);

        GuiUtils.showToast(text, this.getApplicationContext());

        setNextButtonVisible(false);
    }

    @Override
    public void onDisconnected(Radio radio, ConnectionErrorResponse error) {
        refreshList();
        setNextButtonVisible(false);
    }

    private class WifiScanReceiver extends BroadcastReceiver {
        public void onReceive(Context c, Intent intent) {
            onNewWiFiAccessPointsAvailable();
        }
    }

    private void registerNetworkListeners() {
        if (!mWiFiListenersAreRegistered) {
            this.registerReceiver(mWiFiScanReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
            mWiFiListenersAreRegistered = true;
        }
    }

    private void unregisterNetworkListeners() {
        if (mWiFiListenersAreRegistered) {
            this.unregisterReceiver(mWiFiScanReceiver);
            mWiFiListenersAreRegistered = false;
        }
    }

    private void setNextButtonVisible(boolean isVisible) {
        ListOfAccessPointActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                findViewById(R.id.nextButton).setVisibility(isVisible ? View.VISIBLE : View.GONE);
            }
        });
    }
}
