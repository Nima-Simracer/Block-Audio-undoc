package com.frontier_silicon.fsirc.dok2.update;

public interface ICheckForUpdateListener {
    enum ErrorType {
        PinNotProvided,
        Unknown
    }

	void onCurrentVersionRetrieved(String version);
	void onCheckingUpdate();
	void onAvailableUpdate(String updateVersion, String updateChanges, long isMandatory);
	void onNoAvailableUpdate();
	void onCheckFailed(ErrorType errorType);
}
