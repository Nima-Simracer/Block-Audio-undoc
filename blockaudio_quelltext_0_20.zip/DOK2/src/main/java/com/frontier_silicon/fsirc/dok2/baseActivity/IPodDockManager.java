package com.frontier_silicon.fsirc.dok2.baseActivity;

import android.app.Activity;
import android.content.DialogInterface;
import androidx.databinding.Observable;
import androidx.appcompat.app.AlertDialog;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIpodDockStatus;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

/**
 * Created by lsuhov on 01/05/2017.
 */

public class IPodDockManager {

    private static IPodDockManager mInstance;
    private Activity mActivity = null;
    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;

    private IPodDockManager() {
    }

    public static IPodDockManager getInstance() {
        if (mInstance == null) {
            mInstance = new IPodDockManager();
        }

        return mInstance;
    }

    public void onResume(Activity activity) {
        mActivity = activity;

        registerListener();
    }

    public void onPause() {
        mActivity = null;

        unregisterListener();
    }

    private void registerListener() {
        if (mPropertyChangedCallback == null) {
            mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable observable, int i) {
                    onIPodDockChange();
                }
            };
        }

        SpeakerDataManager.getInstance().getSpeakerDataModel().ipodDockStatus.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void unregisterListener() {
        SpeakerDataManager.getInstance().getSpeakerDataModel().ipodDockStatus.removeOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void onIPodDockChange() {
        NodeSysIpodDockStatus.Ord ipodDockStatus = SpeakerDataManager.getInstance().getSpeakerDataModel().ipodDockStatus.get();
        if (ipodDockStatus == NodeSysIpodDockStatus.Ord.DOCKED_ONLINE_READY) {
            showIPodDockedDlg();
        }
    }

    private void showIPodDockedDlg() {
        if (mActivity == null) {
            return;
        }

        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String dialogKey = "ipod_docked_dlg";
                if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, mActivity))
                    return;

                AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mActivity);

                builder.setTitle(mActivity.getString(R.string.ipod_docked_title_dlg));
                builder.setMessage(mActivity.getString(R.string.ipod_docked_msg_dlg));

                builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
                        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
                            currentRadio.setMode(NodeSysCapsValidModes.Mode.iPod, false);
                        }
                    }
                });
                builder.setNegativeButton(android.R.string.cancel, null);

                AlertDialog dlg = builder.create();
                DialogsHolder.addDialogToCollection(dialogKey, dlg);
                dlg.show();
            }
        });
    }
}
