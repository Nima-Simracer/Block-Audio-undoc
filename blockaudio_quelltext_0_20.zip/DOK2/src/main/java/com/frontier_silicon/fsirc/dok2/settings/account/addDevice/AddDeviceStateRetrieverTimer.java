package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeFsdcaState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNodeUtil;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by cvladu on 20/03/2018.
 */

public class AddDeviceStateRetrieverTimer {
    private static final int FSDCACHECK_PERIOD = 700;
    private UpdateFSDCAStateTimerTask mTimerTask;
    private Timer mTimer;

    public void startFsdcaStateRetriverTimer(Radio radio, IAddDeviceState listener) {
        mTimerTask = new UpdateFSDCAStateTimerTask(radio, listener);
        mTimer = new Timer();
        mTimer.schedule(mTimerTask, 400, FSDCACHECK_PERIOD);
    }

    public void stopFsdcaTimer() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer.purge();
            mTimer = null;
        }

        if (mTimerTask != null) {
            mTimerTask.cancel();
            mTimerTask.dispose();
            mTimerTask = null;
        }
    }

    class UpdateFSDCAStateTimerTask extends TimerTask {
        boolean isCanceled = false;
        private Radio mRadio;
        private IAddDeviceState mListener;

        public UpdateFSDCAStateTimerTask(Radio radio, IAddDeviceState listener) {
            mRadio = radio;
            mListener = listener;
        }

        @Override
        public void run() {
            if (isCanceled) {
                return;
            }
            updateFsdcaState(mRadio, mListener);
        }

        public void dispose() {
            isCanceled = true;
            mRadio = null;
            mListener = null;
        }
    }

    public void updateFsdcaState(final Radio radio, final IAddDeviceState listener) {
        if (radio == null) {
            return;
        }

        RadioNodeUtil.getNodeFromRadioAsync(radio, NodeFsdcaState.class, node -> {
            if (node != null) {
                notifyFsdcaListeners((NodeFsdcaState) node, listener);
            }
        });
    }

    private void notifyFsdcaListeners(NodeFsdcaState node, IAddDeviceState listener) {
        NetRemote.getMainThreadExecutor().execute(()-> {
            if (listener != null) {
                listener.onFSDCAState(node);
            }
        });
    }
}
