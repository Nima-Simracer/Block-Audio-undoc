package com.frontier_silicon.fsirc.dok2.settings.language;

import java.util.ArrayList;

/**
 * Created by hcostescu on 11/21/2016.
 */

public interface ILanguageUpdate {
     void onLanguageUpdate(ArrayList<LanguageItemModel> lList);
}
