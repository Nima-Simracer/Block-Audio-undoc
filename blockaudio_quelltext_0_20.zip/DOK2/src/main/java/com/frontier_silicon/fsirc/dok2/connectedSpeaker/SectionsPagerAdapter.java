package com.frontier_silicon.fsirc.dok2.connectedSpeaker;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import android.view.ViewGroup;

import java.util.HashMap;

abstract public class SectionsPagerAdapter extends FragmentPagerAdapter {

    public static final int BROWSE_IR_FRAGMENT_TAB_ID = 5;
    public static final int BROWSE_SPOTIFY_FRAGMENT_TAB_ID = 6;
    public static final int BROWSE_DAB_FRAGMENT_TAB_ID = 7;
    public static final int BROWSE_BLUETOOTH_FRAGMENT_TAB_ID = 8;
    public static final int BROWSE_DMR_FRAGMENT_TAB_ID = 9;
    public static final int BROWSE_NOT_AVAILABLE_TAB_ID = 10;

    public static final int NOW_PLAYING_FRAGMENT_TAB_ID = 11;
    public static final int NOW_PLAYING_CAST_TAB_ID = 12;
    public static final int NOW_PLAYING_STANDBY_TAB_ID = 13;

    public static final int BROWSE_AVS_TAB_ID = 14;


    protected static final int INVALID_TAB_ID = -1;

    protected Context mContext;
    protected HashMap<Integer, Fragment> mFragmentsMap;

    protected FragmentManager mFragmentMgr;

    public SectionsPagerAdapter(Context context, FragmentManager fm) {
        super(fm);

        mContext = context;
        mFragmentsMap = new HashMap<>();
        mFragmentMgr = fm;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        Fragment fragment = (Fragment) super.instantiateItem(container, position);

        mFragmentsMap.put(position, fragment);
        return fragment;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        super.destroyItem(container, position, object);

        mFragmentsMap.remove(position);
    }

    public Fragment getFragment(int position) {
        return mFragmentsMap.get(position);
    }

    abstract public int getPosition(String fragmentTag);

    abstract public int getDefaultTabId();

    abstract public int getBrowseTabPosition();

    public void notifyTabContentShouldChange(int position) {
    }

    abstract public int getTabId(int position);

    public void dispose() {
        mContext = null;
        mFragmentMgr = null;
        mFragmentsMap.clear();
    }
}
