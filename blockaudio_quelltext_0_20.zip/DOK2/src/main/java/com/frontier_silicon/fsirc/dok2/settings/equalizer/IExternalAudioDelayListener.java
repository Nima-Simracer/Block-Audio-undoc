package com.frontier_silicon.fsirc.dok2.settings.equalizer;

public interface IExternalAudioDelayListener {
    void onExternalAudioDelayUpdate(boolean isSupported, long audioDelayValue, long maxAudioDelayValue);
}
