package com.frontier_silicon.fsirc.dok2.update;

public interface IUpdateFirmwareListener {
	void onProgress(long progress);
	void onFinish();
	void onFailed();
}
