package com.frontier_silicon.fsirc.dok2.setup.connectionType.wps;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SetupConfigureWpsActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;


/**
 * Created by nbalazs on 08/03/2018.
 *
 */

public class ConfigureWPSActivity extends SetupActivityBase {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetupConfigureWpsActivityBinding mBinding = DataBindingUtil.setContentView(this, R.layout.setup_configure_wps_activity);

        mBinding.setViewModel(new ConfigureWPSActivityVM(this));

        configureToolbarWithExitButton(R.string.setup_wps_title);
    }

    @Override
    protected void onStart() {
        super.onStart();
        enableRadioConnectionCallbackAndWiFiMonitor();
    }

}
