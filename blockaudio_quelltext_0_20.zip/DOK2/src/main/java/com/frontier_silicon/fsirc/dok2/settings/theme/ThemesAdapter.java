package com.frontier_silicon.fsirc.dok2.settings.theme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.fsirc.dok2.R;

import java.util.List;

/**
 * Created by lsuhov on 25/02/16.
 */
public class ThemesAdapter extends ArrayAdapter<ThemeModelItem> {

    public ThemesAdapter(Context context, int resource, List<ThemeModelItem> objects) {
        super(context, resource, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Context context = getContext();
        if (context == null)
            return null;

        ThemeModelItem themeModelItem = getItem(position);
        int index = CommonPreferences.getInstance().getCurrentThemeIndex();

        LayoutInflater li = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View v = li.inflate(R.layout.theme_list_item, null);
        TextView textView = (TextView) v.findViewById(R.id.text1);
        textView.setText(themeModelItem.mThemeName);

        ImageView imageView = (ImageView) v.findViewById(R.id.themeIcon);
        imageView.setImageResource(themeModelItem.mDrawableResource);

        if (index == position) {
            View selectedMarkView = v.findViewById(R.id.imageViewSelected);
            selectedMarkView.setVisibility(View.VISIBLE);
        }

        return v;
    }
}
