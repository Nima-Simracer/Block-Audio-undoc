package com.frontier_silicon.fsirc.dok2.update;

import android.content.Context;
import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import android.graphics.drawable.Drawable;
import androidx.core.content.ContextCompat;

import com.frontier_silicon.NetRemoteLib.Node.BaseSysIsuState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.fsirc.dok2.BR;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;

/**
 * Created by lsuhov on 22/01/16.
 */
public class IsuViewModel extends BaseObservable {

    private Context mContext;
    private IsuItemModel mIsuItemModel;
    private Radio mRadio;

    public IsuViewModel(Context context, Radio radio, IsuItemModel isuModel) {

        mContext = context;
        mIsuItemModel = isuModel;
        mRadio = radio;

        setListener(radio);
    }

    @Bindable
    public String getRadioFriendlyName() {
        if (mRadio != null) {
            return mRadio.getFriendlyName();
        } else {
            return "";
        }
    }

    @Bindable
    public boolean getIsProgressBarVisible() {
        return mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.CHECK_IN_PROGRESS ||
                mIsuItemModel.mIsUpdating;
    }

    @Bindable
    public String getUpdateInfoText() {
        String updateInfo = "";

        if (mIsuItemModel.mUpdateFailed) {
            updateInfo = mContext.getString(R.string.error_isu_failed);
        }
        else if (mIsuItemModel.mIsUpdating) {
            if (mIsuItemModel.mIsRestarting)
                updateInfo = mContext.getString(R.string.updating_firmware_restart);
            else if (mIsuItemModel.mProgress == 0) {
                updateInfo = SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.updating_firmware_short_version, true);
            } else {
                updateInfo = mContext.getString(R.string.updating_firmware_progress) + " : " + mIsuItemModel.mProgress + "%";
            }
        }
        else if (mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.CHECK_IN_PROGRESS) {
            updateInfo = mContext.getString(R.string.checking_for_update);
        }
        else if (mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.UPDATE_AVAILABLE) {
            if (mIsuItemModel.mIsMandatory == 1) {
                updateInfo = mContext.getString(R.string.important_update, mIsuItemModel.mUpdateVersion);
            } else {
                updateInfo = mContext.getString(R.string.recommended_update, mIsuItemModel.mUpdateVersion);
            }
        }
        else if (mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.UPDATE_NOT_AVAILABLE) {
            updateInfo = mContext.getString(R.string.no_available_update);
        }
        else if (mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.CHECK_FAILED) {
            if (mIsuItemModel.mErrorType == ICheckForUpdateListener.ErrorType.PinNotProvided) {
                updateInfo = SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.pin_not_provided, true);
            } else {
                updateInfo = mContext.getString(R.string.failed_on_checking_updates);
            }
        }

        return updateInfo;
    }

    @Bindable
    public String getCurrentFirmwareVersion() {
        if (mIsuItemModel.mIsUpdating) {
            return "";
        } else {
            return mIsuItemModel.mCurrentVersion;
        }
    }

    @Bindable
    public boolean getIsUpdateAvailable() {
        return mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.UPDATE_AVAILABLE;
    }

    @Bindable
    public int getUpdateInfoTextColor() {
        int attrValue;
        if (mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.UPDATE_AVAILABLE) {
            attrValue = R.attr.isu_update_text_color;
        } else {
            attrValue = R.attr.listitem_text_color;
        }
        return GuiUtils.getColorFromAttribute(mContext, attrValue);
    }

    @Bindable
    public String getUpdateDescription() {
        if (mIsuItemModel == null) {
            return "";
        }

        if (mIsuItemModel.mIsUpdating) {
            return "";
        } else {
            return mIsuItemModel.mUpdateDescription;
        }
    }

    @Bindable
    public Drawable getUpdateImageResource() {
        int resourceId = R.drawable.ic_radioup2date;

        if (mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.UPDATE_AVAILABLE) {
            if (mIsuItemModel.mIsMandatory == 1) {
                resourceId = R.drawable.ic_criticalupdate;
            } else {
                resourceId = R.drawable.ic_recommendedupdate;
            }
        } else if (mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.UPDATE_NOT_AVAILABLE) {
            resourceId = R.drawable.ic_radioup2date;
        } else if (mIsuItemModel.mUpdateState == BaseSysIsuState.Ord.CHECK_FAILED) {
            resourceId = R.drawable.ic_updateerror;
        }

        return ContextCompat.getDrawable(mContext, resourceId);
    }

    private void setListener(final Radio radio) {

        AllDevicesIsuManager.getInstance().addListenersForItemModelAndUpdateStateAccordingly(radio,
                new ICheckForUpdateListener() {

                    @Override
                    public void onCheckingUpdate() {

                        notifyPropertyChanged(BR.isProgressBarVisible);
                        notifyPropertyChanged(BR.updateInfoText);
                    }

                    @Override
                    public void onCurrentVersionRetrieved(final String version) {
                        notifyPropertyChanged(BR.currentFirmwareVersion);
                    }

                    @Override
                    public void onAvailableUpdate(final String updateVersion, final String updateChanges, final long isMandatory) {

                        notifyPropertyChanged(BR.isProgressBarVisible);
                        notifyPropertyChanged(BR.updateInfoText);
                        notifyPropertyChanged(BR.isUpdateAvailable);
                        notifyPropertyChanged(BR.updateInfoTextColor);
                        notifyPropertyChanged(BR.updateDescription);
                        notifyPropertyChanged(BR.updateImageResource);

                    }

                    @Override
                    public void onNoAvailableUpdate() {

                        notifyPropertyChanged(BR.isProgressBarVisible);
                        notifyPropertyChanged(BR.updateInfoText);
                        notifyPropertyChanged(BR.updateImageResource);
                    }

                    @Override
                    public void onCheckFailed(final ErrorType errorType) {

                        notifyPropertyChanged(BR.isProgressBarVisible);
                        notifyPropertyChanged(BR.updateInfoText);
                        notifyPropertyChanged(BR.updateImageResource);
                    }

                }, new IUpdateFirmwareListener() {

                    @Override
                    public void onProgress(long long1) {

                        mIsuItemModel.mProgress = long1;

                        notifyPropertyChanged(BR.isProgressBarVisible);
                        notifyPropertyChanged(BR.currentFirmwareVersion);
                        notifyPropertyChanged(BR.updateDescription);
                        notifyPropertyChanged(BR.updateInfoText);

                        if (mIsuItemModel.mIsRestarting && (mIsuItemModel.mProgress == 0)) {
                            // Radio is back after restart
                            mIsuItemModel.mIsUpdating = false;
                            mIsuItemModel.mIsRestarting = false;
                            mIsuItemModel.mUpdateState = BaseSysIsuState.Ord.UPDATE_NOT_AVAILABLE;
                            notifyPropertyChanged(BR.updateImageResource);
                        }

                        if (mIsuItemModel.mProgress == 100 && !radio.isVenice()) {
                            mIsuItemModel.mIsRestarting = true;
                        }

                    }

                    @Override
                    public void onFinish() {

                        notifyPropertyChanged(BR.isProgressBarVisible);
                    }

                    @Override
                    public void onFailed() {

                        notifyPropertyChanged(BR.isProgressBarVisible);
                        notifyPropertyChanged(BR.updateInfoText);
                        notifyPropertyChanged(BR.currentFirmwareVersion);
                        notifyPropertyChanged(BR.updateDescription);

                    }
                });
    }

    /*updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AllDevicesIsuManager.getInstance().updateFirmware(multiroomItemModel);
                hideView(updateButton);
            }
        });*/
}
