package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;

import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.fsirc.dok2.widgets.DividerItemDecoration;
import com.frontier_silicon.fsirc.dok2.widgets.LinearLayoutManagerWrapper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.HideErrorMessageEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavResultEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ResetFormManagerEvent;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseIrFragmentBinding;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class BrowseNavFragment extends BaseFragment implements IChildFragment,
        IPageSwitchListener {

    public static final String FRAGMENT_TAG = "TAG_BROWSE_IR_FRAGMENT";

    protected BrowseIrFragmentBinding mBinding;
    protected LinearLayoutManager mLayoutManager;
    protected BrowseNavViewModel mBrowseNavViewModel;
    private Boolean wasScrolling = false;

    public BrowseNavFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mBinding = DataBindingUtil.inflate(inflater, R.layout.browse_ir_fragment, container, false);

        return mBinding.getRoot();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        setHasOptionsMenu(true);

        mBrowseNavViewModel = new BrowseNavViewModel(this, mBinding, getActivity());
        mBinding.setViewModel(mBrowseNavViewModel);

        setupControls();

        if (mIsRestoreInstance) {
            mIsRestoreInstance = false;
            onFragmentActivated();
        }

    }

    public void onResume() {
        super.onResume();

        mBrowseNavViewModel.setIsStopping(false);

        mBrowseNavViewModel.fragmentActivated();

        if (mBinding.editTextSearchRadio != null) {
            mBinding.editTextSearchRadio.clearFocus();
            mBinding.layoutSearch.clearFocus();
        }
    }

    public void onPause() {
        super.onPause();

        mBrowseNavViewModel.fragmentDeactivated();
        mBrowseNavViewModel.setIsStopping(true);
    }

    @Override
    public void onDestroyView() {

        mBinding.setViewModel(null);

        if (mBrowseNavViewModel != null) {
            mBrowseNavViewModel.dispose();
            mBrowseNavViewModel = null;
        }

        super.onDestroyView();
    }

    protected void setupControls() {

        mLayoutManager = new LinearLayoutManagerWrapper(getContext());

        DividerItemDecoration itemDecoration = new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL);

        mBinding.browseItemsList.setLayoutManager(mLayoutManager);
        mBinding.browseItemsList.addItemDecoration(itemDecoration);

        mBinding.browseItemsList.setAdapter(mBrowseNavViewModel.getAdapter());


        mBinding.editTextSearchRadio.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                String searchText = ((EditText) v).getText().toString().trim();
                return mBrowseNavViewModel.search(searchText);
            }

            return false;
        });

        mBinding.buttonSearch.setOnClickListener(v -> {
            String searchText = mBinding.editTextSearchRadio.getText().toString().trim();
            mBrowseNavViewModel.search(searchText);
        });


        mBinding.goBottomButton.setOnClickListener(view -> {
            int position = mBrowseNavViewModel.getAdapter().getItemCount();
            mLayoutManager.scrollToPosition(position - 1);
        });

        mBinding.goTopButton.setOnClickListener(view -> {
            mLayoutManager.scrollToPosition(0);
        });

        addRecyclerViewScrollListener();
        mBinding.goBottomButton.setVisibility(View.GONE);
        mBinding.goTopButton.setVisibility(View.GONE);
    }

    public void addRecyclerViewScrollListener() {
        mBinding.browseItemsList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                    wasScrolling = true;
                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                int totalItems = mBrowseNavViewModel.getAdapter().getItemCount();
                if (mLayoutManager.findLastVisibleItemPosition() == totalItems - 1 && totalItems <= 15) {
                    mBinding.goBottomButton.setVisibility(View.GONE);
                    mBinding.goTopButton.setVisibility(View.GONE);
                    mBinding.linearContainer.invalidate();
                } else if (mLayoutManager.findFirstVisibleItemPosition() == 0 && wasScrolling) {
                    mBinding.goBottomButton.setVisibility(View.VISIBLE);
                    mBinding.goTopButton.setVisibility(View.GONE);
                    mBinding.linearContainer.invalidate();
                } else if (mLayoutManager.findLastVisibleItemPosition() == totalItems - 1 && wasScrolling) {
                    mBinding.goBottomButton.setVisibility(View.GONE);
                    mBinding.goTopButton.setVisibility(View.VISIBLE);
                    mBinding.linearContainer.invalidate();
                } else if (mLayoutManager.findFirstVisibleItemPosition() > 0 &&  mLayoutManager.findLastVisibleItemPosition() < totalItems && wasScrolling) {
                    mBinding.goBottomButton.setVisibility(View.VISIBLE);
                    mBinding.goTopButton.setVisibility(View.VISIBLE);
                    mBinding.linearContainer.invalidate();
                }
            }
        });
    }

    @Override
    public void onBackButton() {
        mBinding.browseItemsList.stopScroll();
        //this needs to be called in case of empty search on Airable sources, then a navigation back
        EventBus.getDefault().post(new ResetFormManagerEvent());
        mBrowseNavViewModel.onBackButton();
    }

    @Override
    public boolean isBackButtonHandledByFragment(boolean upButton) {
        return mBrowseNavViewModel.isBackButtonHandledByFragment(upButton);
    }

    @Override
    public String getStaticTag() {
        return FRAGMENT_TAG;
    }

    @Override
    public synchronized void onFragmentActivated() {
        if (!super.onFragmentActivatedBase())
            return;

        FirebaseCrashlytics.getInstance().log("BrowseNavFragment activated");

        EventBus.getDefault().register(this);
        mBrowseNavViewModel.fragmentActivated();
    }

    @Override
    public synchronized void onFragmentDeactivated() {
        if (!super.onFragmentDeactivatedBase())
            return;

        FirebaseCrashlytics.getInstance().log("BrowseNavFragment deactivated");

        mBrowseNavViewModel.fragmentDeactivated();
        EventBus.getDefault().post(new HideErrorMessageEvent());
        EventBus.getDefault().unregister(this);
    }

    @Subscribe
    public void onNavigationResult(final NavResultEvent event) {

        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                if (getActivity() != null && mBrowseNavViewModel != null &&
                        event.result != EIRNavigationResult.AlreadyLoaded) {

                    FirebaseCrashlytics.getInstance().log("BrowseNavFragment scroll to 0");
                    mLayoutManager.scrollToPosition(0);
                    wasScrolling = false;
                    int totalItems = mBrowseNavViewModel.getAdapter().getItemCount();

                    if (mLayoutManager.findLastVisibleItemPosition() == totalItems - 1 && totalItems <= 15) {
                        mBinding.goBottomButton.setVisibility(View.GONE);
                        mBinding.goTopButton.setVisibility(View.GONE);
                    } else if (mLayoutManager.findLastVisibleItemPosition() < totalItems - 1 && totalItems > 15) {
                        mBinding.goBottomButton.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
    }
}
