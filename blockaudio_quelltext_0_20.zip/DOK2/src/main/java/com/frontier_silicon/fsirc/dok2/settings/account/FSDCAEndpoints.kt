package com.frontier_silicon.fsirc.dok2.settings.account

import com.frontier_silicon.fsirc.dok2.BuildConfig
import java.util.*

class FSDCAEndpoints {
    companion object Routes {
        var REDIRECT_URL = "undok2://auth_response"
        var PLAY_STORE_CLIENT_ID = "12bcf1c8-7b1f-487b-bd82-6a701260f7c9"
        var AMAZON_STORE_CLIENT_ID = "aed726c4-a511-477b-b02b-e2526829e9ed"
        var GET_DEVICES = "https://auth-fsdca.frontier-nuvola.net/devices"
        var ENDPOINT = "https://auth-ui-fsdca.frontier-nuvola.net"
        var HOST_UI = "auth-ui-fsdca.frontier-nuvola.net"
        var HOST = "auth-fsdca.frontier-nuvola.net"
    }
        private val LOGIN_URL_PART1 = "$ENDPOINT/login?lng="
        private val LOGIN_URL_PART2 = "&response_type=code&client_id=" + getCLientId() + "&scope=user&redirect_uri=" + REDIRECT_URL
        private val MY_ACCOUNT = "$ENDPOINT/undok/account?lng="
        private val MY_DEVICES = "$ENDPOINT/undok/devices?lng="
        private val FAQ = "$ENDPOINT/undok/faq?lng="


    private fun getLocale(): String {
        val language = getLocaleLanguage()
        val country = getLocaleCountry()
        return "$language-$country"
    }

    private fun getLocaleLanguage(): String {
        var language = Locale.getDefault().isO3Language
        language = language.substring(0, 2)
        return language
    }

    private fun getLocaleCountry(): String {
        var country = Locale.getDefault().isO3Country
        country = country.substring(0, 2)
        return country
    }

    fun getLoginURL(): String? {
        return LOGIN_URL_PART1 + getLocale() + LOGIN_URL_PART2
    }

    fun getMyAccountUrl(): String? {
        return MY_ACCOUNT + getLocale()
    }

    fun getMyDevicesUrl(): String? {
        return MY_DEVICES + getLocale()
    }

    fun getFAQUrl(): String? {
        return FAQ + getLocale()
    }

    fun getCLientId(): String {
        return if (BuildConfig.putOnAmazonStore) {
            AMAZON_STORE_CLIENT_ID
        } else PLAY_STORE_CLIENT_ID
    }
}