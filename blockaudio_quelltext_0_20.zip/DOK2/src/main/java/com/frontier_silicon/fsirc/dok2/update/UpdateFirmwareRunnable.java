package com.frontier_silicon.fsirc.dok2.update;

import com.frontier_silicon.loggerlib.LogLevel;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuControl;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.components.common.RadioNodeUtil;

public class UpdateFirmwareRunnable implements Runnable {
	private Radio mRadio = null;
    private IsuItemModel mIsuItemModel;
	
	public UpdateFirmwareRunnable(Radio radio, IsuItemModel isuItemModel) {
		mRadio = radio;
        mIsuItemModel = isuItemModel;
	}

	@Override
	public void run() {
        Radio radio = mRadio;

		startISUUpdate(radio);

		IsuBackgroundManager.getInstance().updateIsuInfoOfRadio(radio, false, false);
	}

	private void startISUUpdate(final Radio radio) {
        mIsuItemModel.mUpdateFailed = false;

		RadioNodeUtil.setNodeToRadioAsync(radio, new NodeSysIsuControl(NodeSysIsuControl.Ord.UPDATE_FIRMWARE), new RadioNodeUtil.INodeSetResultListener() {
			@Override
			public void onNodeSetResult(boolean success) {
				FsLogger.log(">>> UpdateFirmwareRunnable: start ISU update " + radio + " " + success, LogLevel.Warning);

				if (success) {
                    setIsuInitiatedInModel();
				} else {
                    onFailed();
                }

                dispose();
			}
		});
	}

    private void setIsuInitiatedInModel() {
        synchronized (mIsuItemModel.mLock) {
            mIsuItemModel.mCurrentVersionWasRetrieved = false;
            mIsuItemModel.mCurrentVersion = "";
            mIsuItemModel.mUpdateVersion = "";
            mIsuItemModel.mUpdateDescription = "";
            mIsuItemModel.mUpdateState = null;
            mIsuItemModel.mIsUpdating = true;
            mIsuItemModel.mProgress = 0;
            mIsuItemModel.mIsRestarting = false;
            mIsuItemModel.mUpdateFailed = false;

            if (mIsuItemModel.mUpdateListener != null) {
                mIsuItemModel.mUpdateListener.onProgress(0);
            }
        }
    }

    private void onFailed() {
        synchronized (mIsuItemModel.mLock) {
            mIsuItemModel.mIsUpdating = false;
            mIsuItemModel.mUpdateFailed = true;
            if (mIsuItemModel.mUpdateListener != null)
                mIsuItemModel.mUpdateListener.onFailed();
        }
    }

    private void dispose() {
        mRadio = null;
        mIsuItemModel = null;
    }
}
