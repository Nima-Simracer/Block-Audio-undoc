package com.frontier_silicon.fsirc.dok2.connectedSpeaker;

import androidx.fragment.app.Fragment;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.BrowseAvsFragment;
import com.frontier_silicon.fsirc.dok2.browse.fsdca3PDA.Browse3PdaFragment;
import com.frontier_silicon.fsirc.dok2.browse.BrowseNotAvailableFragment;
import com.frontier_silicon.fsirc.dok2.browse.BrowseSpotifyFragment;
import com.frontier_silicon.fsirc.dok2.browse.bluetooth.BrowseBluetoothFragment;
import com.frontier_silicon.fsirc.dok2.browse.dab.BrowseDABFragment;
import com.frontier_silicon.fsirc.dok2.browse.dmr.BrowseDMRFragment;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseNavFragment;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingFragment;
import com.frontier_silicon.fsirc.dok2.nowPlaying.googleCast.NowPlayingGoogleCastFragment;
import com.frontier_silicon.fsirc.dok2.nowPlaying.standby.NowPlayingStandbyFragment;
import com.frontier_silicon.fsirc.dok2.presets.PresetsFragment;
import com.frontier_silicon.fsirc.dok2.sources.SourcesFragment;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class FragmentFactory {

    public static final String NOW_PLAYING_TAG = "TAG_NOW_PLAYING";
    public static final String BROWSE_TAG = "TAG_BROWSE_FRAGMENT";

    private static FragmentFactory mInstance;

	private final String LOG_TAG = getClass().getSimpleName() + ": ";
	private List<Radio> mDMRModeRadio = new CopyOnWriteArrayList<>();

    private FragmentFactory() {}

    public static FragmentFactory getInstance() {
        if (mInstance == null) {
            mInstance = new FragmentFactory();
        }

        return mInstance;
    }


	public Fragment getFragment(String fragmentTag) {

		if (NOW_PLAYING_TAG.contentEquals(fragmentTag)) {
			return getNowPlayingFragment();
		}

		if (BROWSE_TAG.contentEquals(fragmentTag)) {
			return getBrowseFragmentForCurrentMode();
		}

		if (SourcesFragment.FRAGMENT_TAG.contentEquals(fragmentTag)) {
			return new SourcesFragment();
		}

		if (PresetsFragment.FRAGMENT_TAG.contentEquals(fragmentTag)) {
			return new PresetsFragment();
		}

        return null;
	}

	private Fragment getBrowseFragmentForCurrentMode() {
		Fragment fragment;

		Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();

		if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
			if (currentRadio.isInStandby()) {
				fragment = new BrowseNotAvailableFragment();
			} else if (isDMRRequestedRadio(currentRadio)) {
				fragment = new BrowseDMRFragment();

			} else {
				NodeSysCapsValidModes.Mode currMode = SpeakerDataManager.getInstance().getCurrentMode();
				boolean isNavigationAllowed= SpeakerDataManager.getInstance().isNavigationSupportedForCurrentMode();
				if (currMode == NodeSysCapsValidModes.Mode.FSDCA_3PDA) {
					fragment = new Browse3PdaFragment();
				} else if (currMode == NodeSysCapsValidModes.Mode.Spotify) {
					fragment = new BrowseSpotifyFragment();
				} else if (currMode == NodeSysCapsValidModes.Mode.DAB) {
					fragment = new BrowseDABFragment();
				} else if (currMode == NodeSysCapsValidModes.Mode.Bluetooth) {
					fragment = new BrowseBluetoothFragment();
				} else if (currMode == NodeSysCapsValidModes.Mode.DMR) {
                    fragment = new BrowseDMRFragment();
                } else if (currMode == NodeSysCapsValidModes.Mode.AVS
                        || (currMode == NodeSysCapsValidModes.Mode.None && currentRadio.hasAVS())) {
					fragment = new BrowseAvsFragment();
				} else if (currMode == NodeSysCapsValidModes.Mode.AuxIn
						|| currMode == NodeSysCapsValidModes.Mode.None
						|| currMode == NodeSysCapsValidModes.Mode.FM
						|| currMode == NodeSysCapsValidModes.Mode.AirPlay
						|| currMode == NodeSysCapsValidModes.Mode.Cast) {
					fragment = new BrowseNotAvailableFragment();
				} else if (isNavigationAllowed) {
					fragment = new BrowseNavFragment();
				} else {
					fragment = new BrowseNotAvailableFragment();
				}
			}

		} else {
			fragment = new BrowseNavFragment();
		}

		return fragment;
	}

    private Fragment getNowPlayingFragment() {
        Fragment fragment;

        if (SpeakerDataManager.getInstance().isInStandby()) {
            fragment = new NowPlayingStandbyFragment();
        } else if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.Cast) {
            fragment = new NowPlayingGoogleCastFragment();
        } else {
            fragment = new NowPlayingFragment();
        }
        return fragment;
    }

	public long getNowPlayingFragmentTabId() {
		long tabId;

		if (SpeakerDataManager.getInstance().isInStandby()) {
		    tabId = SectionsPagerAdapter.NOW_PLAYING_STANDBY_TAB_ID;
        } else if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.Cast) {
			tabId = SectionsPagerAdapter.NOW_PLAYING_CAST_TAB_ID;
		} else {
			tabId = SectionsPagerAdapter.NOW_PLAYING_FRAGMENT_TAB_ID;
		}
		return tabId;
	}

	public long getNowPlayingTabIdForFragmentTag(String fragmentTag) {
        long tabId = SectionsPagerAdapter.NOW_PLAYING_FRAGMENT_TAB_ID;

        if (NowPlayingFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.NOW_PLAYING_FRAGMENT_TAB_ID;
        } else if (NowPlayingStandbyFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.NOW_PLAYING_STANDBY_TAB_ID;
        } else if (NowPlayingGoogleCastFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.NOW_PLAYING_CAST_TAB_ID;
        }

        return tabId;
    }

    public boolean isNowPlayingFragment(Fragment fragment) {
        return fragment instanceof NowPlayingFragment || fragment instanceof NowPlayingGoogleCastFragment ||
                fragment instanceof NowPlayingStandbyFragment;
    }

	public long getBrowseFragmentTabIdForCurrentMode() {
		long tabId;

		Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
		if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
			if (currentRadio.isInStandby()) {
				tabId = SectionsPagerAdapter.BROWSE_NOT_AVAILABLE_TAB_ID;
			} else if (mDMRModeRadio.size() > 0 && isDMRRequestedRadio(currentRadio)) {
				tabId = SectionsPagerAdapter.BROWSE_DMR_FRAGMENT_TAB_ID;
			} else {
				NodeSysCapsValidModes.Mode currMode = SpeakerDataManager.getInstance().getCurrentMode();
				boolean isNavigationAllowed= SpeakerDataManager.getInstance().isNavigationSupportedForCurrentMode();

				if (currMode == NodeSysCapsValidModes.Mode.Spotify) {
					tabId = SectionsPagerAdapter.BROWSE_SPOTIFY_FRAGMENT_TAB_ID;
				} else if (currMode == NodeSysCapsValidModes.Mode.DAB) {
					tabId = SectionsPagerAdapter.BROWSE_DAB_FRAGMENT_TAB_ID;
				} else if (currMode == NodeSysCapsValidModes.Mode.Bluetooth) {
					tabId = SectionsPagerAdapter.BROWSE_BLUETOOTH_FRAGMENT_TAB_ID;
				} else if (currMode == NodeSysCapsValidModes.Mode.DMR) {
					tabId = SectionsPagerAdapter.BROWSE_DMR_FRAGMENT_TAB_ID;
                } else if (currMode == NodeSysCapsValidModes.Mode.AVS
                        || (currMode == NodeSysCapsValidModes.Mode.None && currentRadio.hasAVS())) {
                    tabId = SectionsPagerAdapter.BROWSE_AVS_TAB_ID;
				} else if (currMode == NodeSysCapsValidModes.Mode.AuxIn
						|| currMode == NodeSysCapsValidModes.Mode.FM
						|| currMode == NodeSysCapsValidModes.Mode.None
						|| currMode == NodeSysCapsValidModes.Mode.AirPlay
						|| currMode == NodeSysCapsValidModes.Mode.Cast) {
					tabId = SectionsPagerAdapter.BROWSE_NOT_AVAILABLE_TAB_ID;
				} else if (isNavigationAllowed) {
					tabId = SectionsPagerAdapter.BROWSE_IR_FRAGMENT_TAB_ID;
				} else {
					tabId = SectionsPagerAdapter.BROWSE_NOT_AVAILABLE_TAB_ID;
				}
			}

		} else {
			tabId = -1;
		}

		return tabId;
	}

	public long getBrowseFragmentTabIdFromFragmentTag(String fragmentTag) {
        long tabId = SectionsPagerAdapter.BROWSE_IR_FRAGMENT_TAB_ID;

        if (BrowseNavFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.BROWSE_IR_FRAGMENT_TAB_ID;

        } else if (BrowseSpotifyFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.BROWSE_SPOTIFY_FRAGMENT_TAB_ID;

        } else if (BrowseDABFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.BROWSE_DAB_FRAGMENT_TAB_ID;

        } else if (BrowseDMRFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.BROWSE_DMR_FRAGMENT_TAB_ID;

        } else if (BrowseBluetoothFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.BROWSE_BLUETOOTH_FRAGMENT_TAB_ID;

        } else if (BrowseNotAvailableFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.BROWSE_NOT_AVAILABLE_TAB_ID;

        } else if (BrowseAvsFragment.FRAGMENT_TAG.equals(fragmentTag)) {
            tabId = SectionsPagerAdapter.BROWSE_AVS_TAB_ID;
        }

        return tabId;
    }

	/**
	 * Add a radio object to the factories
	 * list of known devices
	 *
	 * @param dmrRadio
   */
	public void addDMRRadio(Radio dmrRadio) {
		if ((dmrRadio != null) && (!isDMRRequestedRadio(dmrRadio))){
			mDMRModeRadio.add(dmrRadio);
		}
	}

	public void removeDRMRadio(Radio targetRadio){
		if (targetRadio != null) {
			String targetUDN = targetRadio.getUDN();

			int poz = isDMRRequestedRadio(targetUDN);

			if (poz >= 0) {
				mDMRModeRadio.remove(poz);
			}
		}
	}

	/**
	 * Compares a target radio to the factories lists of known
	 * radio objects by comparing their UDN.
	 *
	 * @param targetRadio The connected radio at the time of the fragment request
	 * @return <code>true</code> when the radio is contains in the list otherwise false
   */
	private boolean isDMRRequestedRadio(Radio targetRadio) {

		if (targetRadio != null) {
			String targetUDN = targetRadio.getUDN();

			if (isDMRRequestedRadio(targetUDN) >= 0) {
				return true;
			}
		} else {
			FsLogger.log(LOG_TAG + "The radio passed to isDMRRequestRadio check was null", LogLevel.Error);
		}

		return false;
	}

	private int isDMRRequestedRadio(String targetUDN) {

		if (targetUDN != null) {
			for (int i = 0; i < mDMRModeRadio.size(); i++) {
				Radio storedRadio = mDMRModeRadio.get(i);
				if ((storedRadio != null) && (storedRadio.getUDN() != null)) {
					if (storedRadio.getUDN().equalsIgnoreCase(targetUDN)) {
						return i;
					}
				}
			}
		}

		return -1;
	}
}
