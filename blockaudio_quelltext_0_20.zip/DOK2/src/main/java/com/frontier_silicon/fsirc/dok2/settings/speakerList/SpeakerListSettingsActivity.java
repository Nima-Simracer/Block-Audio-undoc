package com.frontier_silicon.fsirc.dok2.settings.speakerList;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.view.View;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.SettingsSpeakerListActivityBinding;

/**
 * Created by lsuhov on 12/10/2017.
 */

public class SpeakerListSettingsActivity extends UndokActivityBase {

    private SettingsSpeakerListActivityBinding mBinding;
    private SpeakerListSettingsViewModel mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.settings_speaker_list_activity);
        mViewModel = new SpeakerListSettingsViewModel(this);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.settings);

        setupControls();
        mBinding.emptyState.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.no_devices_found, false));
    }

    private void setupControls() {
        mBinding.listOfSpeakers.setLayoutManager(new LinearLayoutManager(this));
        mBinding.listOfSpeakers.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        mViewModel.getAdapter().setEmptyStateListener(new SpeakerListSettingsAdapter.EmptyState() {
            @Override
            public void onEmptyState(boolean isEmptyState) {
                if (isEmptyState) {
                    mBinding.emptyState.setVisibility(View.VISIBLE);
                } else {
                    mBinding.emptyState.setVisibility(View.GONE);
                }
            }
        });
        mBinding.listOfSpeakers.setAdapter(mViewModel.getAdapter());
    }

    @Override
    protected void onResume() {
        super.onResume();

        mViewModel.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

        mViewModel.onPause();
    }

    @Override
    protected void onDestroy() {
        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }

        super.onDestroy();
    }
}
