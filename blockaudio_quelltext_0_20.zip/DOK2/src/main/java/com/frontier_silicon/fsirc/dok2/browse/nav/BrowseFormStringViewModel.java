package com.frontier_silicon.fsirc.dok2.browse.nav;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormValueItem;

/**
 * Created by adanaila on 10/31/2016.
 */

public class BrowseFormStringViewModel extends BrowseFormItemBaseViewModel {

    public BrowseFormStringViewModel(int position, FormItem item) {
        super(position, item);
    }

    public void onValueChanged(String value) {
        ((FormValueItem)this.mFormItemBase).setValue(value.trim());
    }
}
