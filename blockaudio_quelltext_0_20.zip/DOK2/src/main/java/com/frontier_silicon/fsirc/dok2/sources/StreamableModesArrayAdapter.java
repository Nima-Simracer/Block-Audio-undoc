package com.frontier_silicon.fsirc.dok2.sources;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class StreamableModesArrayAdapter extends ArrayAdapter<SourceItemModel> {

	private Context mContext;
	private int mLayoutResId;
	private int mTextViewResId;

	public StreamableModesArrayAdapter(Context context, int resource, int textViewResourceId, List<SourceItemModel> objects) {
		super(context, resource, textViewResourceId, objects);
		
		mContext = context;
		mLayoutResId = resource;
		mTextViewResId = textViewResourceId;
	}	
	
    @SuppressLint("InflateParams")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
    	View v = convertView;
		LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		final SourceItemModel item = getItem(position);
		
		if (v == null)
			v = li.inflate(mLayoutResId, null);
			
		String text = item.mName;
		
		TextView tv = (TextView) v.findViewById(mTextViewResId);
		tv.setText(text);
		
		return v;
	}

    
}
