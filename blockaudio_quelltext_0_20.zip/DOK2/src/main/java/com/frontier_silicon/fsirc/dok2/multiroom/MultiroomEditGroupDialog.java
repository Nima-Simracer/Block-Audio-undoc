package com.frontier_silicon.fsirc.dok2.multiroom;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomCapsMaxClients;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.ErrorSanitizerMessageType;
import com.frontier_silicon.components.common.FriendlyNameSanitizer;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.common.IDialogButtonsResponse;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.IMultiroomOperationListener;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.multiroom.MultiroomOperation;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.widgets.SameSelectionSpinner;
import com.frontier_silicon.fsirc.dok2.connection.RadioConnectionDialogsUtil;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.frontier_silicon.fsirc.dok2.R.id.editTextGroupName;

//TODO: transform this class to extend AppCompatDialogFragment
public class MultiroomEditGroupDialog implements IMultiroomEditGroupListener {

    public static final String DIALOG_KEY = "edit_group_dlg";

    private static final int NUM_MIN_SPEAKERS_IN_GROUP = 2;
    private IMultiroomOperationListener mListener;
    private MultiroomItemModel mMultiroomItemModel;

    private Activity mParentActivity;

    private List<MultiroomEditGroupItemModel> mAllRadios;
    private ArrayAdapter<MultiroomEditGroupItemModel> mAdapter;
    private Button mOkButton;

    private boolean mHaveMaxNumberClients;
    private long mMaxNumberClients;
    private boolean mIsGroupNameEmpty = false;
    private boolean mGroupExists;

    public MultiroomEditGroupDialog(Activity parentActivity, IMultiroomOperationListener listener) {
        mParentActivity = parentActivity;
        mListener = listener;
        mHaveMaxNumberClients = false;
        mMaxNumberClients = 0;
    }

    public void createDialog(final MultiroomItemModel multiroomItemModel,
                             String newGroupName, List<MultiroomOperation> operationList) {
        mMultiroomItemModel = multiroomItemModel;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mParentActivity);

        View dialogLayout = mParentActivity.getLayoutInflater().inflate(R.layout.edit_group_dialog, null);

        builder.setView(dialogLayout);

        ListView radiosListView = (ListView) dialogLayout.findViewById(R.id.listRadios);

        String currentGroupId;

        if (multiroomItemModel.getIsGroupHeader()) {
            currentGroupId = multiroomItemModel.getGroupId();
            mGroupExists = true;
        } else {
            currentGroupId = MultiroomGroupManager.TEMP_GROUP_ID;
            mGroupExists = false;
        }

        String groupsMultiroomVersion = getSelectedGroupMultiroomVersion(multiroomItemModel);

        mAllRadios = getRadiosList(multiroomItemModel, currentGroupId, groupsMultiroomVersion);

        // remove master speaker from list of radios (already visible in the dialog header)
        List<MultiroomEditGroupItemModel> allVisibleRadios = getVisibleRadiosList(mAllRadios);

        if (operationList != null) {
            updateMultiroomEditModelsWithCachedOperationData(allVisibleRadios, operationList);
        }

        mAdapter = new MultiroomEditGroupArrayAdapter(mParentActivity, R.layout.edit_group_list_item, allVisibleRadios, this);

        radiosListView.setAdapter(mAdapter);

        final View renameGroupLayout = dialogLayout.findViewById(R.id.layoutNewGroup);
        initRenameGroupLayout(renameGroupLayout, mParentActivity, multiroomItemModel, newGroupName);

        setHeaderViews(dialogLayout, multiroomItemModel);

        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                AnalyticsSender.sendGroupButtonTappingAnalytics();
                
                if (!multiroomItemModel.getIsGroupHeader()) {
                    createNewGroup(mAllRadios, renameGroupLayout, multiroomItemModel, mListener);
                } else {
                    editMultiroomGroup(mAllRadios, renameGroupLayout, multiroomItemModel);
                }
            }
        });

        builder.setNegativeButton(mParentActivity.getString(R.string.cancel), null);

        if (mGroupExists) {
            builder.setNeutralButton(R.string.delete_group, null);
        }

        final AlertDialog dlg = builder.create();

        DialogsHolder.addDialogToCollection(DIALOG_KEY, dlg);
        dlg.show();

        // needs to be set after show()
        mOkButton = dlg.getButton(DialogInterface.BUTTON_POSITIVE);

        // for new groups enable after selecting +2 devices (minimum 1 client)
        if (!mGroupExists) {
            mOkButton.setEnabled((NUM_MIN_SPEAKERS_IN_GROUP - 1) < 0);
        } else {
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDeleteGroupDialog(dlg);
                }
            });
        }

        // Asynchronously request the max number clients limit
        Radio radio = getMasterRadio(multiroomItemModel);

        if (radio != null) {
            radio.getNode(NodeMultiroomCapsMaxClients.class, false, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    NodeMultiroomCapsMaxClients maxClientsNode = (NodeMultiroomCapsMaxClients) node;
                    mMaxNumberClients = maxClientsNode.getValue();
                    mHaveMaxNumberClients = true;
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    // Error - don't know the max number of clients, we'll have to make do without
                }
            });
        }
    }

    private void updateMultiroomEditModelsWithCachedOperationData(List<MultiroomEditGroupItemModel> multiroomEditGroupItemModels,
                                                                  List<MultiroomOperation> operationList) {
        for (MultiroomOperation operation : operationList) {
            String id = operation.mMultiroomDeviceUDN;
            for (MultiroomEditGroupItemModel multiroomEditGroupItemModel : multiroomEditGroupItemModels) {
                if (id.contentEquals(multiroomEditGroupItemModel.getDeviceModel().mRadio.getUDN())) {

                    if (operation.mOperationType == MultiroomOperation.MultiroomGroupEditOperation.ADD_REMOVE_SPEAKER_TO_FROM_GROUP &&
                            operation.mGroupId.contentEquals(MultiroomGroupManager.NO_GROUP_ID)) {
                        multiroomEditGroupItemModel.setChecked(false);
                    } else if (operation.mOperationType == MultiroomOperation.MultiroomGroupEditOperation.ADD_REMOVE_SPEAKER_TO_FROM_GROUP) {
                        multiroomEditGroupItemModel.setChecked(true);
                    }
                }
            }
        }
    }

    private Radio getMasterRadio(MultiroomItemModel itemModel) {
        Radio radio;

        if (itemModel.getIsGroupHeader()) {
            MultiroomDeviceModel serverDevice = MultiroomGroupManager.getInstance().getServerDeviceFromGroupId(itemModel.getGroupId());
            if (serverDevice != null) {
                radio = serverDevice.mRadio;
            } else {
                radio = itemModel.getRadio();
            }
        } else {
            radio = itemModel.getRadio();
        }

        return radio;
    }

    private boolean createNewGroup(List<MultiroomEditGroupItemModel> allRadios,
                                   View newGroupLayout, final MultiroomItemModel multiroomItemModel,
                                   IMultiroomOperationListener listener) {

        EditText editText = (EditText) newGroupLayout.findViewById(editTextGroupName);

        if (editText != null) {
            final String newGroupName = editText.getText().toString();

            MultiroomCreateGroupTask createGroupTask = new MultiroomCreateGroupTask(mParentActivity, allRadios, newGroupName, multiroomItemModel, listener);
            TaskHelper.execute(createGroupTask);
        } else {
            return false;
        }

        return true;
    }

    private boolean editMultiroomGroup(List<MultiroomEditGroupItemModel> allRadios, View renameGroupLayout, MultiroomItemModel multiroomItemModel) {
        boolean resultOk = true;
        EditText editText = (EditText) renameGroupLayout.findViewById(editTextGroupName);
        String newGroupName = editText.getText().toString();
        String oldGroupName = multiroomItemModel.getGroupName();
        boolean renameGroup = (!oldGroupName.equals(newGroupName));

        MultiroomEditGroupTask editGroupTask = new MultiroomEditGroupTask(mParentActivity, allRadios, renameGroup, newGroupName, multiroomItemModel, mListener);
        TaskHelper.execute(editGroupTask);

        return resultOk;
    }


    private MultiroomEditGroupItemModel mRemovedItem = null;

    private List<MultiroomEditGroupItemModel> getRadiosList(MultiroomItemModel multiroomItemModel, String currentGroupId,
                                                            String groupsMultiroomVersion) {
        List<MultiroomEditGroupItemModel> radiosList = new ArrayList<>();

        List<MultiroomItemModel> devicesList = MultiroomGroupManager.getInstance().getFlatGroupDeviceList();

        for (MultiroomItemModel itemModel : devicesList) {
            if (!itemModel.getIsGroupHeader()) {   // ungrouped radios
                if (itemModel.getRadio() != null) {
                    if (itemModel.getRadio().isMultiroomCapable()) {

                        boolean isMasterRadio = false;

                        boolean isSelected = itemModel.getGroupId().equals(currentGroupId);
                        if (!mGroupExists) {
                            isSelected = multiroomItemModel.getRadio().getUDN().equals(itemModel.getRadio().getUDN());

                            isMasterRadio = isSelected;
                        }

                        MultiroomEditGroupItemModel item = new MultiroomEditGroupItemModel(itemModel.getDeviceModel(),
                                currentGroupId, groupsMultiroomVersion, mGroupExists, isSelected);
                        radiosList.add(item);

                        if (isMasterRadio) {
                            mRemovedItem = item;
                        }
                    }
                }
            } else {
                // groups
                List<MultiroomDeviceModel> groupDevices = MultiroomGroupManager.getInstance().getAllDevicesForGroupId(itemModel.getGroupId());
                for (MultiroomDeviceModel device : groupDevices) {
                    if (device.mRadio != null) {
                        boolean isSelected = device.mGroupId.equals(currentGroupId);

                        boolean isMasterRadio = false;
                        if (isSelected) {
                            isMasterRadio = device.isServer();
                        }

                        MultiroomEditGroupItemModel item = new MultiroomEditGroupItemModel(device, currentGroupId,
                                groupsMultiroomVersion, mGroupExists, isSelected);
                        radiosList.add(item);

                        if (isMasterRadio) {
                            mRemovedItem = item;
                        }
                    }
                }
            }
        }

        // sort radios alphabetically
        Collections.sort(radiosList, new Comparator<MultiroomEditGroupItemModel>() {
            @Override
            public int compare(MultiroomEditGroupItemModel lhs, MultiroomEditGroupItemModel rhs) {
                return lhs.toString().compareToIgnoreCase(rhs.toString());
            }
        });

        return radiosList;
    }

    private List<MultiroomEditGroupItemModel> getVisibleRadiosList(List<MultiroomEditGroupItemModel> allRadios) {
        ArrayList<MultiroomEditGroupItemModel> allVisibleRadios = new ArrayList<>();
        allVisibleRadios.addAll(allRadios);
        if (mRemovedItem != null) {
            allVisibleRadios.remove(mRemovedItem);
        }

        return allVisibleRadios;
    }

    private String getSelectedGroupMultiroomVersion(MultiroomItemModel deviceItem) {
        String multiroomVersion = "";

        if (deviceItem.getIsGroupHeader()) {
            // get MR ver. from first found radio in the selected group
            List<MultiroomDeviceModel> groupDevices = MultiroomGroupManager.getInstance().getAllDevicesForGroupId(deviceItem.getGroupId());
            for (MultiroomDeviceModel device : groupDevices) {
                if (device.mRadio != null) {
                    multiroomVersion = device.mRadio.getMultiroomVersion();
                    break;
                }
            }
        } else {
            if (deviceItem.getRadio() != null) {
                multiroomVersion = deviceItem.getRadio().getMultiroomVersion();
            }
        }

        return multiroomVersion;
    }

    private void initRenameGroupLayout(View renameGroupLayout, final Context context, final MultiroomItemModel multiroomItemModel, final String newGroupName) {
        final EditText editText = (EditText) renameGroupLayout.findViewById(editTextGroupName);
        final TextView groupName = (TextView) renameGroupLayout.findViewById(R.id.groupName);
        final TextView errorMessage = (TextView) renameGroupLayout.findViewById(R.id.errorMessage);
        final SameSelectionSpinner suggestedNamesSpinner = (SameSelectionSpinner) renameGroupLayout.findViewById(R.id.spinnerGroupNames);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(context, R.array.group_names_array, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        suggestedNamesSpinner.setAdapter(spinnerAdapter);
        suggestedNamesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View view, int position, long id) {
                CharSequence name = (CharSequence) parentView.getItemAtPosition(position);
                editText.setText(name);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });

        final Button renameDoneButton = (Button) renameGroupLayout.findViewById(R.id.buttonRenameDone);
        final Button renameButton = (Button) renameGroupLayout.findViewById(R.id.buttonRename);

        renameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                renameDoneButton.setVisibility(View.VISIBLE);
                renameButton.setVisibility(View.GONE);

                suggestedNamesSpinner.setVisibility(View.VISIBLE);

                editText.setEnabled(true);
                editText.requestFocus();
            }
        });

        renameDoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                renameDoneButton.setVisibility(View.GONE);
                renameButton.setVisibility(View.VISIBLE);

                suggestedNamesSpinner.setVisibility(View.GONE);

                editText.setEnabled(false);
                editText.clearFocus();
            }
        });

        final String initialGroupName = getInitialGroupName(context, multiroomItemModel, newGroupName);
        editText.setText(initialGroupName);

        FriendlyNameSanitizer nameSanitizer = new FriendlyNameSanitizer(FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME);
        nameSanitizer.appendSanitizerToEditText(editText, context, new FriendlyNameSanitizer.IFriendlyNameSanitizerListener() {
            boolean firstEdit = true;

            @Override
            public void onSubmitFriendlyName(String friendlyName) {
                /*if (!TextUtils.isEmpty(friendlyName))
                    setNewTempGroupName(context, friendlyName);*/
            }

            @Override
            public void onNewFriendlyName(String friendlyName) {
                errorMessage.setVisibility(View.GONE);
                groupName.setVisibility(View.VISIBLE);
                renameDoneButton.setEnabled(true);
                mIsGroupNameEmpty = false;
                updateOkButtonState();
                if (firstEdit) {    // prevents auto-fill by the suggested name spinner (first time only)
                    firstEdit = false;
                    editText.setText(initialGroupName);
                    editText.selectAll();
                }
            }

            @Override
            public void onBadFriendlyName(ErrorSanitizerMessageType errorMessageType) {
               handleMessageErrorType(mParentActivity, errorMessageType, groupName, errorMessage);
                if (errorMessageType == ErrorSanitizerMessageType.EmptyName) {
                    renameDoneButton.setEnabled(false);
                    mIsGroupNameEmpty = true;
                }
                updateOkButtonState();
            }
        });
    }

    private  void handleMessageErrorType(Activity activity, ErrorSanitizerMessageType messageType, TextView groupName, TextView errorMessage) {
        switch (messageType) {
            case EmptyName:
                textVisibility(groupName, errorMessage);
                errorMessage.setText(activity.getString(R.string.empty_friendly_name_not_allowed));
                break;
            case BiggerThanSupportedLimit:
                textVisibility(groupName, errorMessage);
                errorMessage.setText(activity.getString(R.string.length_limit_of_friendly_name_was_exceeded, FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME));
                break;
            case CharacterNotAllowed:
                textVisibility(groupName, errorMessage);
                errorMessage.setText(activity.getString(R.string.invalid_chars_were_entered_message));
                break;
            case WhiteSpaceAtBeginning:
                textVisibility(groupName, errorMessage);
                errorMessage.setText(activity.getString(R.string.whitespace_not_allowed));
                break;
            case MultipleWhiteSpaces:
                textVisibility(groupName, errorMessage);
                errorMessage.setText(activity.getString(R.string.multiple_whitespaces_not_allowed));
                break;
        }
    }

    private void textVisibility(TextView groupName, TextView errorMessage) {
        groupName.setVisibility(View.GONE);
        errorMessage.setVisibility(View.VISIBLE);
    }

    private String getInitialGroupName(Context context, MultiroomItemModel multiroomItemModel, String newGroupName) {
        String initialGroupName;

        if (multiroomItemModel.getIsGroupHeader()) {
            initialGroupName = multiroomItemModel.getGroupName();
        } else {
            if (TextUtils.isEmpty(newGroupName)) {
                initialGroupName = generateNewGroupName(context);
            } else {
                initialGroupName = newGroupName;
            }
        }

        return initialGroupName;
    }

    private String generateNewGroupName(Context context) {
        int groupIdx = 1;
        String newGroupName = context.getString(R.string.new_group_default_name, "" + groupIdx);

        while (MultiroomGroupManager.getInstance().isGroupNameDuplicated(newGroupName)) {
            groupIdx++;
            newGroupName = context.getString(R.string.new_group_default_name, "" + groupIdx);
        }

        return newGroupName;
    }

    private void setHeaderViews(View dialogLayout, MultiroomItemModel multiroomItemModel) {

        Radio radio = getMasterRadio(multiroomItemModel);

        if (radio != null) {

            final TextView playSourceText = dialogLayout.findViewById(R.id.textPlayingSource);

            radio.getCurrentModeAsListItem(false, currentMode ->
                    setPlayingSource(playSourceText, currentMode));

            TextView masterRadioText = dialogLayout.findViewById(R.id.textGroupMaster);
            masterRadioText.setText(DokUiUtils.getFriendlyNameOrStereoSystemName(radio));
        }
    }

    private void setPlayingSource(TextView secondLineText, NodeSysCapsValidModes.ListItem currentMode) {

        if (currentMode == null ||
                currentMode.getId().equals(NodeSysCapsValidModes.Mode.None.name()) ||
                currentMode.getId().equals(NodeSysCapsValidModes.Mode.UnknownMode.name()) ||
                currentMode.getId().equals(NodeSysCapsValidModes.Mode.Audsync.name())) {

            secondLineText.setVisibility(View.GONE);
            return;

        } else {
            secondLineText.setVisibility(View.VISIBLE);
        }

        if (currentMode.getId().equals(NodeSysCapsValidModes.Mode.DMR.name())) {
            String s = mParentActivity.getString(R.string.fs_dok_mode_localmusic);
            secondLineText.setText(mParentActivity.getString(R.string.playing_smth, s));

        } else {
            secondLineText.setText(mParentActivity.getString(R.string.playing_smth, currentMode.getLabel()));
        }
    }

    @Override
    public void onDeviceSelectionChanged(MultiroomEditGroupItemModel deviceItem, boolean isSelected) {
        if (deviceItem.isAvailableOnTheNetwork()) {
            if (isSelected && !deviceItem.isSameMultiroomVersion()) {
                showDifferentMultiroomVerDlg(deviceItem);
            } else {
                updateOkButtonState();
                if (maximumGroupSizeExceeded()) {
                    // Can't add this one
                    deviceItem.setChecked(false);
                    mAdapter.notifyDataSetChanged();
                }
            }
        } else {
            showRadioNotAvailableDlg(deviceItem.getDeviceModel().mRadio);
        }
    }

    private void updateOkButtonState() {
        int numSpeakersInGroup = 0;
        for (MultiroomEditGroupItemModel item : mAllRadios) {
            if (item.isChecked()) {
                numSpeakersInGroup++;
            }
        }

        boolean enableOkButton = !mIsGroupNameEmpty;
        if (!mGroupExists) {
            enableOkButton &= numSpeakersInGroup >= NUM_MIN_SPEAKERS_IN_GROUP;
        }

        if (maximumGroupSizeExceeded()) {
            enableOkButton = false;
            maxiumGroupSizeExceededAlert();
        }

        if (mOkButton != null) {
            mOkButton.setEnabled(enableOkButton);
        }
    }

    private void maxiumGroupSizeExceededAlert() {
        AlertDialog.Builder alertDialogBuilder = ThemedAlertDialogBuilder.create(mParentActivity);
        alertDialogBuilder.setTitle(R.string.multiroom_group_too_large_dlg_title);
        alertDialogBuilder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.multiroom_group_too_large_dlg_text, false));
        alertDialogBuilder.setPositiveButton(android.R.string.ok, null);

        alertDialogBuilder.show();
    }

    private boolean maximumGroupSizeExceeded() {
        int numSpeakersInGroup = 0;
        for (MultiroomEditGroupItemModel item : mAllRadios) {
            if (item.isChecked()) {
                numSpeakersInGroup++;
            }
        }

        if (mHaveMaxNumberClients && ((numSpeakersInGroup - 1) > mMaxNumberClients))
            return true;

        return false;
    }


    private void showDifferentMultiroomVerDlg(MultiroomEditGroupItemModel deviceItem) {
        try {
            MultiroomDialogsUtil.showDifferentMRVersionsErrorDlg(mParentActivity);

            deviceItem.setChecked(false);
            mAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showRadioNotAvailableDlg(Radio radio) {
        try {
            RadioConnectionDialogsUtil.showRadioNotAvailableOnTheNetworkDlg(mParentActivity, radio, new IDialogButtonsResponse() {
                @Override
                public void onPositiveClicked() {
                }

                @Override
                public void onNegativeClicked() {
                    DialogsHolder.dismissDialog(DIALOG_KEY);
                }

                @Override
                public void onNeutralClicked() {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showDeleteGroupDialog(final AlertDialog parentDialog) {
        if (mParentActivity != null) {
            String dialogKey = "delete_group";
            if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, mParentActivity))
                return;

            AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mParentActivity);

            if (MultiroomGroupManager.getInstance().isTempGroup(mMultiroomItemModel.getGroupId())) {
                builder.setMessage(mParentActivity.getString(R.string.multiroom_group_delete_msg));
                builder.setTitle(mParentActivity.getString(R.string.multiroom_group_delete_title, mMultiroomItemModel.getGroupName()));
            } else {
                builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.multiroom_group_ungroup_msg, false));
                builder.setTitle(mParentActivity.getString(R.string.multiroom_group_ungroup_title, mMultiroomItemModel.getGroupName()));
            }

            builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    MultiroomOperationsQueueExecutorTask executorTask = new MultiroomOperationsQueueExecutorTask(mParentActivity,
                            MultiroomEditGroupUtil.getDestroyGroupOperationsList(mMultiroomItemModel), mListener);
                    TaskHelper.execute(executorTask);

                    parentDialog.dismiss();
                }
            });

            builder.setNegativeButton(android.R.string.cancel, null);

            AlertDialog dlg = builder.create();
            DialogsHolder.addDialogToCollection(dialogKey, dlg);
            dlg.show();
        }
    }
}
