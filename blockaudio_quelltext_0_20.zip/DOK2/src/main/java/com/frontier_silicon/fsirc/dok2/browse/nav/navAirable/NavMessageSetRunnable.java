package com.frontier_silicon.fsirc.dok2.browse.nav.navAirable;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

public class NavMessageSetRunnable implements Runnable {

    public interface INavMessageDataSendListener {
        void onNavMessageSend(boolean params);
    }

    private static final boolean ENABLE_SYNC_OPS = true;
    private Radio mRadio;
    private INavMessageDataSendListener mListener;
    private long mId;

    public NavMessageSetRunnable(Radio radio, long id, INavMessageDataSendListener listener) {
        mRadio = radio;
        mListener = listener;
        this.mId = id;
    }

    @Override
    public void run() {
        FsLogger.log("message data set runnable started ", LogLevel.Info);

        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {
            sendResultToListener(RadioNavigationUtil.getInstance().navigateNavItem(mRadio, mId));
        }
        dispose();
    }

    private void sendResultToListener(boolean result) {
        if (mListener != null) {
            mListener.onNavMessageSend(result);
        }
    }

    private void dispose() {
        mRadio = null;
        mListener = null;
    }
}
