package com.frontier_silicon.fsirc.dok2.multiroom;

import android.app.Activity;

import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.IMultiroomOperationListener;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.multiroom.MultiroomOperationResult;
import com.frontier_silicon.components.multiroom.MultiroomRescanUtil;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Created by lsuhov on 11/05/2017.
 */

public class MultiroomEditGroupManager implements IMultiroomOperationListener{

    private static MultiroomEditGroupManager mInstance;

    private Activity mActivity;

    private MultiroomEditGroupManager() {}

    public static MultiroomEditGroupManager getInstance() {
        if (mInstance == null) {
            mInstance = new MultiroomEditGroupManager();
        }

        return mInstance;
    }

    public void setActivity(Activity activity) {
        mActivity = activity;
    }

    public void showEditGroupDialog(MultiroomItemModel multiroomItemModel) {
        if (multiroomItemModel == null) {
            FsLogger.log("showPreEditGroupDialog: multiroomItemModel is null");
            return;
        }

        if (mActivity == null) {
            FsLogger.log("showPreEditGroupDialog: mActivity is null");
            return;
        }

        MultiroomPreEditGroupTask preEditGroupTask = new MultiroomPreEditGroupTask(mActivity, multiroomItemModel, this);
        TaskHelper.execute(preEditGroupTask);
    }

    @Override
    public void onOperationComplete(final MultiroomOperationResult result) {

        if (result != null && !DokUiUtils.isDestroyed(mActivity)) {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (DokUiUtils.isDestroyed(mActivity)) {
                        return;
                    }

                    switch (result.mOperationResult) {
                        case SUCCESS:
                            break;
                        case ADD_CLIENT_ERR:
                            MultiroomDialogsUtil.showAddClientToGroupError(mActivity);
                            break;
                        case CREATE_GROUP_ERR:
                            MultiroomDialogsUtil.showCreateGroupError(mActivity);
                            break;
                        case DESTROY_GROUP_ERR:
                            MultiroomDialogsUtil.showDestroyGroupError(mActivity);
                            break;
                        case UNGROUP_DEVICE_ERR:
                            MultiroomDialogsUtil.showUngroupDeviceError(mActivity);
                            break;
                        case ADD_CLIENT_MAX_CLIENT_ERR:
                            MultiroomDialogsUtil.showMaxClientsErrorDlg(mActivity);
                            break;
                        case DIFFERENT_MR_VERSION_ERR:
                            MultiroomDialogsUtil.showDifferentMRVersionsErrorDlg(mActivity);
                            break;
                        case STREAMABLE_MODE_NEEDED_ERR:
                            MultiroomDialogsUtil.showSelectStreamableModeDlg(mActivity, result.mDevice.mRadio, new MultiroomDialogsUtil.ISelectStreamableModeListener() {
                                @Override
                                public void onSelectedStreamableMode(boolean streamableModeSelected) {
                                    if (!streamableModeSelected) {
                                        MultiroomRescanUtil.getInstance().rescanMultiroomDevicesAndGroups();
                                    }
                                }
                            });
                            break;
                        default:
                            break;
                    }
                }
            });
        }
    }
}
