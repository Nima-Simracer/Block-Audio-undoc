package com.frontier_silicon.fsirc.dok2.browse.dmr;

import android.net.Uri;

import java.util.List;

/**
 * Interface that should be implemented by a media controller. Including core methods suc has
 * generate play lists or altering view elements to reflect media catalogue state
 */
public interface MediaHandler {
  /**
   * Play a list of media items to the current UPnP DMR.
   *
   * @param mediaList The list of content items to be played
   */
  void invokePlayMediaList(List<Uri> mediaList, int playFromPosition);

  /**
   * Updates the layout view elements to display the 'Browse not supported' message.
   *
   * @param isNavigationSupported
   */
  void updateNavigationSupported(final boolean isNavigationSupported);

  /**
   * Updates the layout view elements to display the 'No results found' message.
   *
   * @param size The number of items returned by a query
   */
  void setupEmptyListView(int size);

  /**
   * Requests that the media controller fragment hides the text label
   * that displays the user selection.
   */
  void hideSelectionLabel();
}