package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseNavTrackNotAvailableViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseListItemNotAvailableTrackBinding;

/**
 * Created by hcostescu on 28/11/16.
 */
public class BrowseItemTrackNotAvailable extends RecyclerViewListItemDelegate {
    private int mBrowseType;

    public BrowseItemTrackNotAvailable(int browseType) {
        mBrowseType = browseType;
    }

   @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseListItemNotAvailableTrackBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_list_item_not_available_track,
                parent, false);

        return new BrowseItemTrackNotAvailableViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(mBrowseType);

        BrowseItemModel browseItemModel = browseManager.tryGetBrowseItemModel(position);

        BrowseItemTrackNotAvailableViewHolder labelViewHolder = (BrowseItemTrackNotAvailableViewHolder) holder;
        BrowseListItemNotAvailableTrackBinding binding = labelViewHolder.mBinding;

        BrowseNavTrackNotAvailableViewModel viewModel = new BrowseNavTrackNotAvailableViewModel(position, browseItemModel);
        binding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseItemTrackNotAvailableViewHolder labelViewHolder = (BrowseItemTrackNotAvailableViewHolder) holder;
        BrowseNavTrackNotAvailableViewModel viewModel = labelViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            labelViewHolder.mBinding.setViewModel(null);
        }
    }

    private static class BrowseItemTrackNotAvailableViewHolder extends ListItemViewHolder {
        BrowseListItemNotAvailableTrackBinding mBinding;

        BrowseItemTrackNotAvailableViewHolder(BrowseListItemNotAvailableTrackBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}