package com.frontier_silicon.fsirc.dok2.sources;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.databinding.SourcesFragmentBinding;

public class SourcesFragment extends BaseFragment implements IChildFragment,
        IPageSwitchListener {

	public static final String FRAGMENT_TAG = "TAG_MODE_FRAGMENT";

    private SourcesFragmentBinding mBinding;
    private SourcesViewModel mViewModel;

	public SourcesFragment() {

	    //TODO lsuhov: this should be the default behaviour of all fragments from ConnectedSpeakerActivity
	    this.forceResumeOnActivated = false;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		mBinding = DataBindingUtil.inflate(inflater, R.layout.sources_fragment, container, false);

		mViewModel = new SourcesViewModel(getLifecycle());
		mBinding.setViewModel(mViewModel);

		return mBinding.getRoot();
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		setupControls();

        if (mIsRestoreInstance) {
            mIsRestoreInstance = false;
            onFragmentActivated();
        }
	}

	@Override
	public synchronized void onFragmentActivated() {
		if (!super.onFragmentActivatedBase())
			return;

		collapseListViewIfCurrentConnectionIsNotGroup();
	}

	@Override
	public synchronized void onFragmentDeactivated() {
		if (!super.onFragmentDeactivatedBase()) {
			return;

		}
	}

    private void setupControls() {

        mBinding.sourcesList.setAdapter(mViewModel.getAdapter());

        mBinding.sourcesList.setOnGroupClickListener((expandableListView, view, groupPos, id) ->
                mViewModel.onGroupClicked(groupPos));

        mBinding.sourcesList.setOnChildClickListener((parent, v, groupPosition, childPosition, id) ->
                mViewModel.onChildClicked(groupPosition, childPosition));

        mBinding.sourcesList.setGroupIndicator(null);
	}

	@Override
	public void onBackButton() { }

	@Override
	public boolean isBackButtonHandledByFragment(boolean upButton) {
		return false;
	}


	@Override
	public String getStaticTag() {
		return FRAGMENT_TAG;
	}

	private void collapseListViewIfCurrentConnectionIsNotGroup() {
		String groupName = MultiroomGroupManager.getInstance().getCurrentGroupName();
		if (TextUtils.isEmpty(groupName)) {

			int count = mViewModel.getAdapter().getGroupCount();
			for (int i = 0; i < count; i++) {
				mBinding.sourcesList.collapseGroup(i);
			}
		}
	}


}
