package com.frontier_silicon.fsirc.dok2.connectedSpeaker;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import android.text.TextUtils;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.sources.SourcesFragment;

/**
 * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class SectionsPagerAdapterPortrait extends SectionsPagerAdapter {

    private static final int SOURCE_FRAGMENT_TAB_POS = 0;
    private static final int NOW_PLAYING_FRAGMENT_TAB_POS = 1;
    private static final int BROWSE_FRAGMENT_TAB_POS = 2;

    private static final int NUM_TABS = 3;
    private static final int DEFAULT_TAB_ID = 1;

    private String mChangedFragmentTag = null;

    public SectionsPagerAdapterPortrait(Context context, FragmentManager fm) {
        super(context, fm);
    }

    @Override
    public int getBrowseTabPosition(){
        return BROWSE_FRAGMENT_TAB_POS;
    }

    @Override
    public Fragment getItem(int position) {
        Fragment newFragment = null;

        switch (position) {
            case SOURCE_FRAGMENT_TAB_POS:
                newFragment = FragmentFactory.getInstance().getFragment(SourcesFragment.FRAGMENT_TAG);
                break;

            case NOW_PLAYING_FRAGMENT_TAB_POS:
                newFragment = FragmentFactory.getInstance().getFragment(FragmentFactory.NOW_PLAYING_TAG);
                break;

            case BROWSE_FRAGMENT_TAB_POS:
                newFragment = FragmentFactory.getInstance().getFragment(FragmentFactory.BROWSE_TAG);
                break;
        }

        mFragmentsMap.put(position, newFragment);

        return newFragment;
    }

    @Override
    public int getCount() {
        return NUM_TABS;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return mContext.getString(R.string.mode);
            case 1:
                return mContext.getString(R.string.now_playing);
            case 2:
                return mContext.getString(R.string.browse);
        }
        return null;
    }

    @Override
    public int getTabId(int position) {
        switch (position) {
            case 0:
                return (R.id.sourceId);
            case 1:
                return (R.id.nowPlayingId);
            case 2:
                return (R.id.browseId);
        }

        return 0;
    }

    @Override
    public int getPosition(String fragmentTag) {
        int position = INVALID_TAB_ID;

        if (!TextUtils.isEmpty(fragmentTag)) {
            if (SourcesFragment.FRAGMENT_TAG.equals(fragmentTag)) {
                position = SOURCE_FRAGMENT_TAB_POS;
            } else if (FragmentFactory.NOW_PLAYING_TAG.equals(fragmentTag)) {
                position = NOW_PLAYING_FRAGMENT_TAB_POS;
            } else if (FragmentFactory.BROWSE_TAG.equals(fragmentTag)) {
                position = BROWSE_FRAGMENT_TAB_POS;
            }
        }

        return position;
    }

    @Override
    public int getItemPosition(Object object) {
        if (mChangedFragmentTag != null) {
            try {
                IChildFragment fragment = (IChildFragment) object;
                if (fragment.getStaticTag().equals(mChangedFragmentTag)) {
                    mChangedFragmentTag = null;
                    return FragmentPagerAdapter.POSITION_NONE;
                }
            } catch (Exception e) {
            }
        }

        return FragmentPagerAdapter.POSITION_UNCHANGED;
    }

    @Override
    public void notifyTabContentShouldChange(int position) {
        try {
            IChildFragment fragment = (IChildFragment) getFragment(position);
            mChangedFragmentTag = fragment.getStaticTag();
            notifyDataSetChanged();
        } catch (Exception e) {
        }
    }

    @Override
    public int getDefaultTabId() {
        return DEFAULT_TAB_ID;
    }

    @Override
    public long getItemId(int position) {
        long itemId = position;

        if (position == SOURCE_FRAGMENT_TAB_POS ) {
            itemId = position;
        } else if (position == NOW_PLAYING_FRAGMENT_TAB_POS) {
            IChildFragment fragment = (IChildFragment) getFragment(position);
            if (fragment != null) {
                itemId = FragmentFactory.getInstance().getNowPlayingTabIdForFragmentTag(fragment.getStaticTag());

            } else {
                itemId = FragmentFactory.getInstance().getNowPlayingFragmentTabId();
            }
        } else {
            IChildFragment fragment = (IChildFragment) getFragment(position);
            if (fragment != null) {
                itemId = FragmentFactory.getInstance().getBrowseFragmentTabIdFromFragmentTag(fragment.getStaticTag());
            } else {
                itemId = FragmentFactory.getInstance().getBrowseFragmentTabIdForCurrentMode();
                if (itemId < 0) {
                    itemId = BROWSE_IR_FRAGMENT_TAB_ID;
                }
            }
        }

        return itemId;
    }

}
