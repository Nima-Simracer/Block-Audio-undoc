package com.frontier_silicon.fsirc.dok2.settings.avs.locales

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.frontier_silicon.NetRemoteLib.Node.BaseAvsValidLocales
import com.frontier_silicon.NetRemoteLib.Node.NodeAvsLocale
import com.frontier_silicon.NetRemoteLib.Node.NodeAvsValidLocales
import com.frontier_silicon.NetRemoteLib.Radio.Radio
import com.frontier_silicon.components.common.RadioNodeUtil
import com.frontier_silicon.loggerlib.FsLogger

class AvsLocaleViewModel: ViewModel() {
     val locales: MutableLiveData<List<BaseAvsValidLocales.ListItem>> by lazy {
        MutableLiveData<List<BaseAvsValidLocales.ListItem>>().also {
            getAvsLocales()
        }
    }

     val currentLocale: MutableLiveData<NodeAvsLocale> by lazy {
        MutableLiveData<NodeAvsLocale>().also {
            getAvsLocale()
        }
    }

    private var radio: Radio? = null

    fun setRadio(radio: Radio) {
        this.radio = radio
    }

    private fun getAvsLocales() {
        if (radio == null) {
            return
        }

        // get locale list
        RadioNodeUtil.getNodeFromRadioAsync(radio, NodeAvsValidLocales::class.java) { node ->
            val avsLocales = node as NodeAvsValidLocales?
            if (avsLocales != null) {
                locales.value = avsLocales.entries
            }
        }
    }

    private fun getAvsLocale() {
        if (radio == null) {
            return
        }
        // current speaker locale
        RadioNodeUtil.getNodeFromRadioAsync(radio, NodeAvsLocale::class.java) { node ->
            val avsCurrentLocale = node as NodeAvsLocale?

            if (avsCurrentLocale != null) {
                FsLogger.log("Current language: " + avsCurrentLocale.value!!)
                currentLocale.value = avsCurrentLocale
            }
        }
    }
}