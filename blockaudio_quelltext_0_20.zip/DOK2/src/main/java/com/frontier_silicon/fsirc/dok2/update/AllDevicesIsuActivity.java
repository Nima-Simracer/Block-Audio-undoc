package com.frontier_silicon.fsirc.dok2.update;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.SortedList;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener;
import com.frontier_silicon.NetRemoteLib.Node.BaseSysIsuSoftwareUpdateProgress;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.widgets.DividerItemDecoration;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import java.util.Iterator;
import java.util.List;

public class AllDevicesIsuActivity extends UndokActivityBase implements IRadioDiscoveryListener {

    private static final int DELAY_CHECK_PROGRESS_MS = 5000;
    private static final int UPDATE_TIMEOUT_MS = 300_000;

    private AllDevicesIsuManager mAllDevicesIsuManager = AllDevicesIsuManager.getInstance();
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private AllDevicesIsuAdapter mAdapter;
    private Button mUpdateButton;
    private ProgressBar mGroupProgressBar;
    /* 0.19 Audioblock: der Kasten aus Drehkreis UND Beschriftung. Vorher wurde
       nur der nackte Kreis ein- und ausgeblendet — ohne Text war nicht zu
       erkennen, ob noch etwas laeuft oder ob es haengt. */
    private View mLayoutIsuLaeuft;
    private IAllDevicesIsuListener mAllDevicesIsuListener;
    private TextView mUpdateSummaryTextView;

    private Handler mUpdateProgressHandler = new Handler();
    private int mUpdateProgressTimerMs;

    @Override
    public void onCreate(Bundle icicle) {

        super.onCreate(icicle);

        setContentView(R.layout.isu_all_devices_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.update);

        setupControls();
    }

    private void setupControls() {
        mRecyclerView = (RecyclerView)findViewById(R.id.isu_list);
        mUpdateSummaryTextView = findViewById(R.id.updateSummaryTextView);
        mUpdateSummaryTextView.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.update_summary, true));

        mLayoutManager = new LinearLayoutManager(this);
        DividerItemDecoration itemDecoration = new DividerItemDecoration(this, LinearLayoutManager.VERTICAL);

        mAdapter = new AllDevicesIsuAdapter(this);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.addItemDecoration(itemDecoration);

        mUpdateButton = (Button)findViewById(R.id.buttonUpdate);
        mGroupProgressBar = (ProgressBar)findViewById(R.id.progressBarGroupedIsu);
        mLayoutIsuLaeuft = findViewById(R.id.layoutIsuLaeuft);

        mUpdateButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                showUpdateWarningDialog();
            }
        });

        mAllDevicesIsuListener = new IAllDevicesIsuListener() {

            @Override
            public void updatesAreAvailable(final boolean allDevicesHaveUpdates) {

                if (!DokUiUtils.isDestroyed(AllDevicesIsuActivity.this)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            onUpdatesAreAvailable(allDevicesHaveUpdates);
                        }
                    });
                }
            }

            @Override
            public void failed() {
                if (!DokUiUtils.isDestroyed(AllDevicesIsuActivity.this)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showUpdateButtonIfNeeded();
                        }
                    });
                }
            }

            @Override
            public void noUpdatesAvailable() {

                if (!DokUiUtils.isDestroyed(AllDevicesIsuActivity.this)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showUpdateButtonIfNeeded();
                        }
                    });
                }
            }

            @Override
            public void isuFinished() {

                if (!DokUiUtils.isDestroyed(AllDevicesIsuActivity.this)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showUpdateButtonIfNeeded();
                            hideProgressBar();

                            // Refresh screen after updates finished
                            checkForUpdates();

                        }
                    });
                }
            }
        };
        mAllDevicesIsuManager = AllDevicesIsuManager.getInstance();
        mAllDevicesIsuManager.setIAllDevicesIsuListener(mAllDevicesIsuListener);
    }

    @Override
    public void onResume() {
        mAllDevicesIsuManager = AllDevicesIsuManager.getInstance();

        NetRemoteManager.getInstance().addRadioDiscoveryListener(this);

        updateAdapter();

        if (!mAllDevicesIsuManager.isUpdating()) {
            checkForUpdates();
            showUpdateButtonIfNeeded();
        } else {
            startOrAttachToIsu();
        }

        super.onResume();
    }

    @Override
    public void onPause() {

        NetRemoteManager.getInstance().removeRadioDiscoveryListener(this);

        super.onPause();
    }

    @Override
    public void onDestroy() {
        mAllDevicesIsuManager.removeIAllDevicesIsuListener();
        mAllDevicesIsuListener = null;

        if (mAdapter != null && mAdapter.mSortedRadios != null) {
            mAdapter.mSortedRadios.clear();
        }

        super.onDestroy();
    }

    private void updateAdapter() {
        updateMultiroomList();

        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    private void updateMultiroomList() {

        List<Radio> radios = NetRemoteManager.getInstance().getRadios();
        AllDevicesIsuManager.getInstance().setAllDevices(radios);

        mAdapter.mSortedRadios.beginBatchedUpdates();
        mAdapter.mSortedRadios.clear();
        mAdapter.mSortedRadios.addAll(radios);
        mAdapter.mSortedRadios.endBatchedUpdates();
    }

    private void showUpdateWarningDialog() {
        String dialogKey = "update_warning";
        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, this))
            return;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(this);

        builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.update_summary, true));

        builder.setPositiveButton(R.string.update, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                startOrAttachToIsu();
            }
        });
        builder.setNegativeButton(android.R.string.cancel, null);

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);
        dlg.show();
    }

    private void checkForUpdates() {
        hideAllItemsFromFooter();

        mAllDevicesIsuManager.checkForUpdates(mAllDevicesIsuListener);
    }

    private void startOrAttachToIsu() {
        hideAllItemsFromFooter();
        mGroupProgressBar.setVisibility(View.VISIBLE);
        if (mLayoutIsuLaeuft != null) {
            mLayoutIsuLaeuft.setVisibility(View.VISIBLE);
        }

        mAllDevicesIsuManager.startIsu(mAllDevicesIsuListener);

        if (mUpdateProgressHandler != null) {
            mUpdateProgressTimerMs = 0;
            mUpdateProgressHandler.postDelayed(mCheckUpdateProgressTask, DELAY_CHECK_PROGRESS_MS);
        }
    }

    private void onUpdatesAreAvailable(boolean allDevicesHaveUpdates) {
        hideAllItemsFromFooter();

        mUpdateButton.setVisibility(View.VISIBLE);
    }

    private void showUpdateButtonIfNeeded() {

        mUpdateButton.setVisibility(mAllDevicesIsuManager.atLeastOneRadioHasAvailableUpdate() ? View.VISIBLE : View.GONE);
    }

    private void hideAllItemsFromFooter() {
        mUpdateButton.setVisibility(View.GONE);
        hideProgressBar();
    }

    private void hideProgressBar() {
        mGroupProgressBar.setVisibility(View.GONE);
        if (mLayoutIsuLaeuft != null) {
            mLayoutIsuLaeuft.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_refresh, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem menuItem = menu.findItem(R.id.action_rescan);
        DokUiUtils.setTintToActionMenu(this, menuItem);

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_rescan) {
            checkForUpdates();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Called when a new radio is discovered.
     *
     * @param radio The radio
     */
    @Override
    public void onRadioFound(final Radio radio) {
        mAllDevicesIsuManager.addDevice(radio);

        if (!DokUiUtils.isDestroyed(this)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mAdapter.mSortedRadios.add(radio);
                }
            });
        }
    }

    /**
     * Called when previously visible radio is no longer visible on the network. Note that this is different
     * to when a radio is still visible, but the session ID has become invalidated (in that situation the
     * Radio.IConnectionCallback.onDisconnected callback is used).
     *
     * @param radio The radio
     */
    @Override
    public void onRadioLost(final Radio radio, boolean rescanInProgress) {
        System.out.println("Radio lost");

        if (mAllDevicesIsuManager.isUpdating() || updateMonitorActive()) {
            // We are going to have to expect to lose contact temporarily if we are updating
            return;
        }

        mAllDevicesIsuManager.removeDevice(radio);

        if (!DokUiUtils.isDestroyed(this)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mAdapter.mSortedRadios.remove(radio);
                }
            });
        }
    }

    /**
     * Called when an existing radio has updated information, for example a friendly name change.
     *
     * @param radio The radio
     */
    @Override
    public void onRadioUpdated(Radio radio) {
        final int position = mAdapter.mSortedRadios.indexOf(radio);
        if (position == SortedList.INVALID_POSITION) {
            return;
        }

        if (!DokUiUtils.isDestroyed(this)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mAdapter.notifyItemChanged(position);
                }
            });
        }
    }


    private boolean updateMonitorActive() {
        return  mUpdateProgressTimerMs <= UPDATE_TIMEOUT_MS;
    }


    private Runnable mCheckUpdateProgressTask = new Runnable() {

        // The update progress value is not notifying so we have to poll and then
        // drive the result into the update manager

        @Override
        public void run() {

            if (DokUiUtils.isDestroyed(AllDevicesIsuActivity.this))
                return;

            mUpdateProgressTimerMs += DELAY_CHECK_PROGRESS_MS;

            if (!updateMonitorActive())
                return;

            List<Radio> radios = NetRemoteManager.getInstance().getRadios();

            if ((radios != null) && (radios.size() > 0)) {

                Iterator<Radio> radioIter = radios.iterator();

                while (radioIter.hasNext()) {

                    final Radio radio = radioIter.next();

                    radio.getNode(BaseSysIsuSoftwareUpdateProgress.class, false, new IGetNodeCallback() {
                                @Override
                                public void getNodeResult(NodeInfo node) {
                                    BaseSysIsuSoftwareUpdateProgress status = (BaseSysIsuSoftwareUpdateProgress) node;
                                    mAllDevicesIsuManager.setIsuProgress(radio.getSN(), status.getValue());
                                }

                                @Override
                                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                                    // If we get an error, the radio doesn't have this implemented or is offline
                                }
                            });
                }
            }

            if (mUpdateProgressHandler != null)
                mUpdateProgressHandler.postDelayed(mCheckUpdateProgressTask, DELAY_CHECK_PROGRESS_MS);
        }
    };
}
