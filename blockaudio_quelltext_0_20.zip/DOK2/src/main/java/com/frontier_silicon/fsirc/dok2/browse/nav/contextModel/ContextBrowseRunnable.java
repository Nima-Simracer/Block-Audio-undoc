package com.frontier_silicon.fsirc.dok2.browse.nav.contextModel;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;

/**
 * Created by lsuhov on 02/07/16.
 */

public class ContextBrowseRunnable implements Runnable {

    private long mKey;
    private Radio mRadio;
    private IContextListener mListener;
    private boolean mActivateContext;

    public ContextBrowseRunnable(long key, boolean activate, Radio radio, IContextListener listener) {
        mKey = key;
        mRadio = radio;
        mListener = listener;
        this.mActivateContext = activate;
    }

    @Override
    public void run() {
        if (mRadio == null) {
            return;
        }

        boolean result;
        if(this.mActivateContext)
            result = RadioNavigationUtil.getInstance().activateContextItem(mRadio, mKey);
        else
            result = RadioNavigationUtil.getInstance().navigateContextItem(mRadio, mKey);

        if (!result) {
            notifyError();
        }

        ContextBrowseManager.getInstance().retrieveFirstPageSync(mRadio);

        EIRNavigationResult retrieveTotalNumberResult = ContextBrowseManager.getInstance().retrieveTotalNumberOfItemsFromCurrentListSync(mRadio);

        if (mListener != null) {
            mListener.onNavigationCompleted(retrieveTotalNumberResult);
        }

        dispose();
    }

    private void dispose() {
        mRadio = null;
        mListener = null;
    }

    private void notifyError() {
        if (mListener != null) {
            mListener.onNavigationCompleted(EIRNavigationResult.NavigationFailed);
        }
    }
}
