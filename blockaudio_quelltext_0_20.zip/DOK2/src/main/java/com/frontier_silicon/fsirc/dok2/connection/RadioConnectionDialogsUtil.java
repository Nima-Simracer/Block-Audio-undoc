package com.frontier_silicon.fsirc.dok2.connection;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.loggerlib.LogLevel;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.DialogsOpener;
import com.frontier_silicon.components.common.IDialogButtonsResponse;
import com.frontier_silicon.loggerlib.FsLogger;

public class RadioConnectionDialogsUtil {

    static public void showRadioNotAvailableOnTheNetworkDlg(final Activity activity, final Radio radio, final IDialogButtonsResponse buttonsResponseListener) {
        if (radio != null) {
            showRadioNotAvailableOnTheNetworkDlg(activity, DokUiUtils.getFriendlyNameOrStereoSystemName(radio), new IDialogButtonsResponse() {
                @Override
                public void onPositiveClicked() {
                    if (buttonsResponseListener != null) {
                        buttonsResponseListener.onPositiveClicked();
                    }
                }

                @Override
                public void onNegativeClicked() {
                }

                @Override
                public void onNeutralClicked() {
                    String helpDialogKey = "radio_not_available_help_dlg";
                    DialogsOpener.showMessageDialogWithOkButton(activity, helpDialogKey, R.string.radio_not_available_title, R.string.radio_not_available_help);

                    if (buttonsResponseListener != null) {
                        buttonsResponseListener.onNeutralClicked();
                    }
                }
            });
        } else {
            FsLogger.log("RadioConnectionDialogsUtil: showRadioNotAvailableOnTheNetworkDlg null radio", LogLevel.Error);
        }
    }

    static void showRadioNotAvailableOnTheNetworkDlg(Activity activity, String radioName, final IDialogButtonsResponse buttonsResponseListener) {
        final String dialogKey = "radio_not_available_error";

        if (DialogsHolder.isShowing(dialogKey))
            return;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity);

        builder.setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.radio_not_available_title, true));
        builder.setMessage(activity.getString(R.string.radio_not_available_msg, radioName));

        builder.setCancelable(true)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        DialogsHolder.dismissDialog(dialogKey);

                        if (buttonsResponseListener != null) {
                            buttonsResponseListener.onPositiveClicked();
                        }
                    }
                })
                .setNeutralButton(R.string.help, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        DialogsHolder.dismissDialog(dialogKey);

                        if (buttonsResponseListener != null) {
                            buttonsResponseListener.onNeutralClicked();
                        }
                    }
                });

        Dialog dialog = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dialog);

        dialog.show();
    }
}
