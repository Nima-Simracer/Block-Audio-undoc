package com.frontier_silicon.fsirc.dok2.browse.bluetooth;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseBluetoothFragmentBinding;

public class BrowseBluetoothFragment extends BaseFragment implements IChildFragment, IPageSwitchListener {

	public static final String FRAGMENT_TAG = "TAG_BROWSE_BT_FRAGMENT";

	public BrowseBluetoothFragment() {
        this.forceResumeOnActivated = false;
    }

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        BrowseBluetoothFragmentBinding binding = DataBindingUtil.inflate(inflater, R.layout.browse_bluetooth_fragment, container, false);

		binding.setViewModel(new BrowseBluetoothViewModel(getLifecycle()));

		return binding.getRoot();
	}

	@Override
	public void onBackButton() { }

	@Override
	public boolean isBackButtonHandledByFragment(boolean upButton) {
    	return false;
	}

	@Override
	public String getStaticTag() {
		return FRAGMENT_TAG;
	}

	@Override
    public synchronized void onFragmentActivated() {
        super.onFragmentActivatedBase();
    }

    @Override
    public synchronized void onFragmentDeactivated() {
        super.onFragmentDeactivatedBase();
    }
}
