package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseNavItemViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseListItemLabelBinding;

/**
 * Created by lsuhov on 06/11/2016.
 */

public class BrowseItemLabelDelegate extends RecyclerViewListItemDelegate {

    private int mBrowseType;

    public BrowseItemLabelDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseListItemLabelBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_list_item_label,
                parent, false);

        return new BrowseItemLabelViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(mBrowseType);

        BrowseItemModel browseItemModel = browseManager.tryGetBrowseItemModel(position);

        BrowseItemLabelViewHolder labelViewHolder = (BrowseItemLabelViewHolder) holder;
        BrowseListItemLabelBinding binding = labelViewHolder.mBinding;

        BrowseNavItemViewModel viewModel = new BrowseNavItemViewModel(position, browseItemModel);
        binding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseItemLabelViewHolder labelViewHolder = (BrowseItemLabelViewHolder) holder;
        BrowseNavItemViewModel viewModel = labelViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            labelViewHolder.mBinding.setViewModel(null);
        }
    }

    private static class BrowseItemLabelViewHolder extends ListItemViewHolder {
        BrowseListItemLabelBinding mBinding;

        BrowseItemLabelViewHolder(BrowseListItemLabelBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
