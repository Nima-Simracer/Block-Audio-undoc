package com.frontier_silicon.fsirc.dok2.setup.connectionType.wifi;

import java.util.List;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWlanScanList;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.R;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class WiFiForRadioArrayAdapter extends ArrayAdapter<NodeSysNetWlanScanList.ListItem> {
    private Context mContext = null;

    public WiFiForRadioArrayAdapter(Context context, int resource, List<NodeSysNetWlanScanList.ListItem> objects) {
        super(context, resource, objects);

        mContext = context;
    }

    @SuppressLint("InflateParams")
    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        NodeSysNetWlanScanList.ListItem scanItem = getItem(position);

        if (v == null)
            v = li != null ? li.inflate(R.layout.setup_list_item_select_wifi, null) : null;

        String text = RadioNodeUtil.getHumanReadableSSID(scanItem != null ? scanItem.getSSID() : null);
        if (scanItem != null && scanItem.getWpsCapability())
            text += " " + mContext.getString(R.string.wps_part);

        TextView tv = v != null ? v.findViewById(R.id.text1) : null;
        if (tv != null) {
            tv.setText(text);
        }

        View imageView = v != null ? v.findViewById(R.id.privacyImageView) : null;
        if (imageView != null) {
            imageView.setVisibility((scanItem != null && scanItem.getPrivacy()) ? View.VISIBLE : View.GONE);
        }

        return v;
    }
}
