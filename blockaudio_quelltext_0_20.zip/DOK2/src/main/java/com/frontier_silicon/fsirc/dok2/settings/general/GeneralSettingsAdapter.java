package com.frontier_silicon.fsirc.dok2.settings.general;

import android.app.Activity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SettingsBindableListItemBinding;
import com.frontier_silicon.fsirc.dok2.home.HomeSpeakersModelDiffCallback;
import com.frontier_silicon.fsirc.dok2.settings.SettingsItemModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 11/10/2017.
 */

public class GeneralSettingsAdapter extends RecyclerView.Adapter<SettingsViewHolder> {

    private List<SettingsItemModel> mSettingsItemModels = new ArrayList<>();
    private Activity mActivity;

    GeneralSettingsAdapter(Activity activity) {
        mActivity = activity;
    }

    public void setNewListOfSettings(List<SettingsItemModel> settingsItemModels) {

        GeneralSettingsDiffUtil diffCallback = new GeneralSettingsDiffUtil(mSettingsItemModels, settingsItemModels);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        mSettingsItemModels.clear();
        mSettingsItemModels.addAll(settingsItemModels);

        diffResult.dispatchUpdatesTo(this);
    }

    @Override
    public SettingsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        SettingsBindableListItemBinding itemBinding = DataBindingUtil.inflate(
                layoutInflater, R.layout.settings_bindable_list_item,
                parent, false);

        return new SettingsViewHolder(itemBinding);
    }

    @Override
    public void onBindViewHolder(SettingsViewHolder viewHolder, int position) {
        SettingsBindableListItemBinding binding = viewHolder.mBinding;
        SettingsItemModel itemModel = mSettingsItemModels.get(position);

        GeneralItemSettingViewModel viewModel = new GeneralItemSettingViewModel(itemModel, mActivity);
        binding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(SettingsViewHolder holder) {
        GeneralItemSettingViewModel viewModel = holder.mBinding.getViewModel();

        if (viewModel != null) {
            viewModel.dispose();
            holder.mBinding.setViewModel(null);
        }

        super.onViewRecycled(holder);
    }

    @Override
    public int getItemCount() {
        return mSettingsItemModels.size();
    }

    public void dispose() {
        mSettingsItemModels.clear();
        mActivity = null;
    }
}
