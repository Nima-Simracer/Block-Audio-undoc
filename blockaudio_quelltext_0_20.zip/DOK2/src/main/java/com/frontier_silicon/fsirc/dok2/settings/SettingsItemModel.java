package com.frontier_silicon.fsirc.dok2.settings;

import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;

public class SettingsItemModel {

	public SettingsType mType;
	public String mName;
	public boolean mShowChevron = true;
	public String mRadioUDN = null;
    public boolean mIsCheckable = false;
    public boolean mCheckValue = false;
	public boolean mShouldScroll = false;


	public SettingsItemModel(SettingsType settingType, String name, boolean showChevron) {
		this(settingType, name, null, showChevron);
	}

	public SettingsItemModel(SettingsType settingType, String name, String radioUDN, boolean showChevron) {
		mType = settingType;
		mName = name;
		mRadioUDN = radioUDN;
		mShowChevron = showChevron;
		mShouldScroll = UndokPreferences.getInstance().getScrollingEnabled();
	}

    public SettingsItemModel(SettingsType settingType, String name, String radioUDN, boolean showChevron,
                             boolean isCheckable, boolean checkValue) {
        this(settingType, name, radioUDN, showChevron);

        mIsCheckable = isCheckable;
        mCheckValue = checkValue;
    }
}
