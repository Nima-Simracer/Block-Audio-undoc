package com.frontier_silicon.fsirc.dok2.setup.clock;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import androidx.databinding.Observable;
import androidx.databinding.ObservableField;

import com.frontier_silicon.NetRemoteLib.Node.BaseSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.BaseSysClockMode;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsUtcSettingsList;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.DateTimeParams;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.connectionType.SelectConnectionTypeActivity;
import com.frontier_silicon.fsirc.dok2.setup.language.ConfigureLanguageActivity;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/**
 * Created by nbalazs on 20/03/2018.
 *
 */
public class ConfigureClockActivityVM {

    private Activity mActivity;

    private DateTimeParams mDateTimeParams;

    final SpinnerData mHourSpinnerData;
    final SpinnerData mClockSpinnerData;
    final SpinnerData mTimeZoneSpinnerData;

    public ObservableField<String> timeTextString = new ObservableField<>();
    public ObservableField<String> dateTextString = new ObservableField<>();
    public ObservableField<Boolean> daylightSaving = new ObservableField<>();

    public ObservableField<Boolean> isFmDabClockLayoutVisible = new ObservableField<>(false);
    public ObservableField<Boolean> isNetworkClockLayoutVisible = new ObservableField<>(false);
    public ObservableField<Boolean> isManualClockLayoutVisible = new ObservableField<>(true);

    private Observable.OnPropertyChangedCallback mHourSpinnerChangedCallback;
    private Observable.OnPropertyChangedCallback mTimeZoneSpinnerChangedCallback;
    private Observable.OnPropertyChangedCallback mClockSpinnerChangedCallback;

    private Observable.OnPropertyChangedCallback mDaylightSavingChangedCallback;

    ConfigureClockActivityVM(Activity activity, String[] hourFormats, String[] clocks, String[] timeZones) {
        mActivity = activity;
        mDateTimeParams = new DateTimeParams(mActivity);
        mHourSpinnerData = new SpinnerData(hourFormats);
        mClockSpinnerData = new SpinnerData(clocks);
        mTimeZoneSpinnerData = new SpinnerData(timeZones);

        mDateTimeParams = SetupManager.getInstance().getDateTimeParams();
        if (mDateTimeParams == null) {
            mDateTimeParams = new DateTimeParams(mActivity);
        }

        updateHourFormatSelectionFromParams();
        updateClockSourceSelectionFromParams();
        updateTimeZoneSelectionFromParams();
        updateDaylightSavingFromParams();
    }

    public final void onNextPressed() {
        SetupManager.getInstance().setDateTimeParams(mDateTimeParams);

        if (SetupManager.getInstance().getLanguageIsSupported()) {
            NavigationHelper.goToActivity(mActivity, ConfigureLanguageActivity.class, NavigationHelper.AnimationType.SlideToLeft);
        } else {
            NavigationHelper.goToActivity(mActivity, SelectConnectionTypeActivity.class, NavigationHelper.AnimationType.SlideToLeft);
        }
    }

    public final void onBackPressed() {
        mActivity.onBackPressed();
    }

    private void updateTimeZoneSelectionFromParams() {
        if (mDateTimeParams.getUTCOffsetNode() == null) {
            if (mDateTimeParams.mUtcOffsetSeconds != null) {
                setTimeZoneForDateTimeParams();
                return;
            } else {
                setTimeZoneFromPhone();
                return;
            }
        }

        Long indexOfUtcItem = mDateTimeParams.getUTCOffsetNode().getKey();
        mTimeZoneSpinnerData.setSelectedValuePosition(indexOfUtcItem.intValue());
    }

    private void setTimeZoneForDateTimeParams() {
        List<NodeSysCapsUtcSettingsList.ListItem> nodeUtcList = SetupManager.getInstance().getUtcTimeZoneList();
        if (nodeUtcList == null)
            return;

        for (int i = 0; i < nodeUtcList.size(); i++) {
            NodeSysCapsUtcSettingsList.ListItem timeZoneItem = nodeUtcList.get(i);
            if (mDateTimeParams.getSelectedTimeZone().compareTo("") == 0){
                if (mDateTimeParams.mUtcOffsetSeconds.equals(timeZoneItem.getTime())) {
                    mTimeZoneSpinnerData.setSelectedValuePosition(timeZoneItem.getKey().intValue());
                }
            }
            else {
                if (mDateTimeParams.mUtcOffsetSeconds.equals(timeZoneItem.getTime()) && timeZoneItem.getRegion().equals(mDateTimeParams.getSelectedTimeZone())) {
                    mTimeZoneSpinnerData.setSelectedValuePosition(timeZoneItem.getKey().intValue());
                    return;
                }
            }
        }
    }

    private void setTimeZoneFromPhone() {
        TimeZone phoneTimeZone = mDateTimeParams.mPhoneTimeZone;
        List<NodeSysCapsUtcSettingsList.ListItem> nodeUtcList = SetupManager.getInstance().getUtcTimeZoneList();
        if (nodeUtcList == null)
            return;

        int phoneTimeZoneOffset = phoneTimeZone.getRawOffset() / 1000;

        for (int i = 0; i < nodeUtcList.size(); i++) {
            NodeSysCapsUtcSettingsList.ListItem timeZoneItem = nodeUtcList.get(i);
            if (phoneTimeZoneOffset == timeZoneItem.getTime()) {
                mTimeZoneSpinnerData.setSelectedValuePosition(timeZoneItem.getKey().intValue());
                return;
            }
        }
    }

    private void updateDaylightSavingFromParams() {
        daylightSaving.set(mDateTimeParams.mDaylightSaving);
    }

    private void updateHourFormatSelectionFromParams() {
        if (mDateTimeParams.mHourFormat == BaseSysClockMode.Ord._12_HOUR) {
            mHourSpinnerData.setSelectedValuePosition(0);
        } else {
            mHourSpinnerData.setSelectedValuePosition(1);
        }
    }

    private void updateClockSourceSelectionFromParams() {
        List<NodeSysCapsClockSourceList.ListItem> listItems = SetupManager.getInstance().getClockSourceList().getEntries();
        for (int i = 0; i < listItems.size(); i++) {
            NodeSysCapsClockSourceList.ListItem nodeListItem = listItems.get(i);
            if (nodeListItem.getSource() == mDateTimeParams.mClockSource) {
                mClockSpinnerData.setSelectedValuePosition(i);
                break;
            }
        }
    }

    void onActivityResumed() {
        mHourSpinnerChangedCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                if (mDateTimeParams == null) {
                    return;
                }
                mDateTimeParams.mHourFormat = BaseSysClockMode.Ord.values()[mHourSpinnerData.getSelectedValuePosition()];
                timeTextString.set(getTimeDisplayString(mDateTimeParams.mHour, mDateTimeParams.mMinute, mDateTimeParams.mHourFormat));
            }
        };
        mHourSpinnerData.addOnPropertyChangedCallback(mHourSpinnerChangedCallback);

        mTimeZoneSpinnerChangedCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                if (mDateTimeParams == null)
                    return;

                NodeSysCapsUtcSettingsList.ListItem utcOffset = getUtcOffsetFromSpinner();
                if (utcOffset != null) {
                    mDateTimeParams.setUTCOffsetNode(utcOffset);
                    mDateTimeParams.setSelectedTimeZone(utcOffset.getRegion());
                }
            }
        };
        mTimeZoneSpinnerData.addOnPropertyChangedCallback(mTimeZoneSpinnerChangedCallback);

        mClockSpinnerChangedCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                NodeSysCapsClockSourceList clockSourceList = SetupManager.getInstance().getClockSourceList();
                List<NodeSysCapsClockSourceList.ListItem> nodeListItems = clockSourceList.getEntries();
                NodeSysCapsClockSourceList.ListItem listItemModel = nodeListItems.get(mClockSpinnerData.getSelectedValuePosition());
                NodeListItem.FieldSource clockSource = listItemModel.getSource();
                onSelectedClockSourceChanged(clockSource);
            }
        };
        mClockSpinnerData.addOnPropertyChangedCallback(mClockSpinnerChangedCallback);

        mDaylightSavingChangedCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                if (mDateTimeParams == null)
                    return;

                mDateTimeParams.mDaylightSaving = daylightSaving.get();
            }
        };

        daylightSaving.addOnPropertyChangedCallback(mDaylightSavingChangedCallback);
    }

    void onActivityPaused() {
        SetupManager.getInstance().setDateTimeParams(mDateTimeParams);

        mHourSpinnerData.removeOnPropertyChangedCallback(mHourSpinnerChangedCallback);
        mTimeZoneSpinnerData.removeOnPropertyChangedCallback(mTimeZoneSpinnerChangedCallback);
        mClockSpinnerData.removeOnPropertyChangedCallback(mClockSpinnerChangedCallback);
        daylightSaving.removeOnPropertyChangedCallback(mDaylightSavingChangedCallback);
    }

    private void onSelectedClockSourceChanged(NodeListItem.FieldSource clockSource) {
        hideAllClockSourceLayouts();

        switch (clockSource) {
            case FM:
            case DAB:
                isFmDabClockLayoutVisible.set(true);
                break;
            case SNTP:
                isNetworkClockLayoutVisible.set(true);
                break;
            case Manual:
                isManualClockLayoutVisible.set(true);
                onManualClockSourceSelected();
                break;
        }

        if (mDateTimeParams == null) {
            return;
        }
        mDateTimeParams.mClockSource = clockSource;
    }

    private void onManualClockSourceSelected() {
        dateTextString.set(getDateDisplayString(mDateTimeParams.mDateYear, mDateTimeParams.mDateMonth, mDateTimeParams.mDateDay));
        if (mDateTimeParams == null)
            return;

        mDateTimeParams.mHourFormat = BaseSysClockMode.Ord.values()[mHourSpinnerData.getSelectedValuePosition()];

        timeTextString.set(getTimeDisplayString(mDateTimeParams.mHour, mDateTimeParams.mMinute, mDateTimeParams.mHourFormat));
    }

    private void hideAllClockSourceLayouts() {
        isFmDabClockLayoutVisible.set(false);
        isNetworkClockLayoutVisible.set(false);
        isManualClockLayoutVisible.set(false);
    }

    private NodeSysCapsUtcSettingsList.ListItem getUtcOffsetFromSpinner() {
        List<NodeSysCapsUtcSettingsList.ListItem> utcList = SetupManager.getInstance().getUtcTimeZoneList();
        if (utcList == null)
            return null;

        return utcList.get(mTimeZoneSpinnerData.getSelectedValuePosition());
    }

    public final void openDateChooserDialog() {
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int monthOfYear = c.get(Calendar.MONTH);
        int dayOfMonth = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(mActivity, (datePicker, year1, month, day) -> {
            if (mDateTimeParams == null) {
                return;
            }
            mDateTimeParams.mDateYear = year1;
            mDateTimeParams.mDateMonth = month + 1;
            mDateTimeParams.mDateDay = day;

            dateTextString.set(getDateDisplayString(mDateTimeParams.mDateYear, mDateTimeParams.mDateMonth, mDateTimeParams.mDateDay));

        }, year, monthOfYear, dayOfMonth);

        datePickerDialog.show();
    }

    private String getDateDisplayString(int year, int month, int day) {
        String dayStr = "" + day;
        if (day < 10) {
            dayStr = "0" + day;
        }

        String monthStr = "" + month;
        if (month < 10) {
            monthStr = "0" + month;
        }

        return dayStr + "-" + monthStr + "-" + year;
    }

    public void openTimeChooserDialog() {
        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        boolean is24hMode = (mDateTimeParams.mHourFormat == BaseSysClockMode.Ord._24_HOUR);

        TimePickerDialog datePickerDialog = new TimePickerDialog(mActivity, (timePicker, hour1, minute1) -> {
            if (mDateTimeParams == null) {
                return;
            }
            mDateTimeParams.mHour = hour1;
            mDateTimeParams.mMinute = minute1;

            timeTextString.set(getTimeDisplayString(mDateTimeParams.mHour, mDateTimeParams.mMinute, mDateTimeParams.mHourFormat));

        }, hour, minute, is24hMode);

        datePickerDialog.show();
    }

    private String getTimeDisplayString(int hour, int minute, BaseSysClockMode.Ord hourFormat) {

        String minuteStr = "" + minute;
        if (minute < 10) {
            minuteStr = "0" + minute;
        }

        String ampmStr = "";
        if (hourFormat == BaseSysClockMode.Ord._12_HOUR) {
            if (hour < 12) {
                ampmStr = "AM";
                if (hour == 0) {
                    hour = 12;
                }
            } else {
                ampmStr = "PM";
                if (hour > 12) {
                    hour = hour - 12;
                }
            }
        }

        return hour + ":" + minuteStr + " " + ampmStr;
    }

    static List<String> getClockSourceStringList(Activity activity, List<NodeSysCapsClockSourceList.ListItem> nodeListItems) {
        List<String> lstSources = new ArrayList<>();
        for (int i = 0; i < nodeListItems.size(); i++) {

            int stringId = -1;

            BaseSysCapsClockSourceList.ListItem listItem = nodeListItems.get(i);
            if (listItem.getSource() == null) {
                continue;
            }

            switch (listItem.getSource()) {
                case DAB:
                    stringId = R.string.dab_update;
                    break;
                case FM:
                    stringId = R.string.fm_update;
                    break;
                case Manual:
                    stringId = R.string.no_update;
                    break;
                case SNTP:
                    stringId = R.string.network_update;
                    break;
                default:
                    FsLogger.log("Clock Source not available");
            }

            lstSources.add(activity.getString(stringId));
        }

        return lstSources;
    }
}
