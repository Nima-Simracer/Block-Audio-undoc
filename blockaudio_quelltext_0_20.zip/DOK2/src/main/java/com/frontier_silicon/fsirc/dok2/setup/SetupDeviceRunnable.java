package com.frontier_silicon.fsirc.dok2.setup;

import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;
import com.frontier_silicon.NetRemoteLib.Discovery.IDiscoveryService;
import com.frontier_silicon.NetRemoteLib.Discovery.scanner.IScanOnDemandListener;
import com.frontier_silicon.NetRemoteLib.Discovery.ping.PingUtil;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCfgIrAutoPlayFlag;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoFriendlyName;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.setup.RadioNetworkConfig.EConnectionType;
import com.frontier_silicon.components.setup.RadioNetworkConfig.RadioNetworkConfigParams;
import com.frontier_silicon.components.setup.RadioNetworkConfig.RadioWiFiSetup;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.DateTimeNodesSender;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.DateTimeParams;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by lsuhov on 4/14/2015.
 */
public class SetupDeviceRunnable implements Runnable {
    private final Object mLock = new Object();
    private IStateOfCheckingHeadlessSetupListener mStateListener;
    private int mCurrentProgress = 0;
    private int mSecondsToAchieve = 0;
    private volatile boolean mShouldStopTheTimer = false;
    private Timer mProgressTimer;

    public SetupDeviceRunnable(IStateOfCheckingHeadlessSetupListener stateListener) {
        setListener(stateListener);
    }

    @Override
    public void run() {
        setupDeviceImpl();
    }

    public void setShouldStopTheTimer(boolean shouldStopTheTimer) {
        mShouldStopTheTimer = shouldStopTheTimer;
    }

    synchronized public void setupDeviceImpl() {
        SetupManager setupManager = SetupManager.getInstance();

        RadioNetworkConfigParams configParams = setupManager.getConfigParams();
        boolean isConfiguredOK = false;

        if (mStateListener == null || configParams == null)
            return;

        FsLogger.log("SetupManager:setupNetworkForRadio keyId= " + configParams.mSelectedAPKeyId + " region= " + configParams.mRegionId /*+ " pass= " + configParams.mWiFiPasscode*/);

        sendConfiguringMessageDependingOnConfigParams(configParams);

        Radio radio = setupManager.getCurrentRadio();
        if (radio != null) {
            setRadioFriendlyName(radio);
        }

        radio = setupManager.getCurrentRadio();
        if (radio != null) {
            setAutoPlayNode(radio);
        }

        radio = setupManager.getCurrentRadio();
        if (radio != null) {
            RadioWiFiSetup radioWiFiSetup = new RadioWiFiSetup(radio);
            isConfiguredOK = radioWiFiSetup.setupNetwork(configParams);

            if (isConfiguredOK) {
                DateTimeParams dateTimeParams = setupManager.getDateTimeParams();
                DateTimeNodesSender dateTimeNodesSender = new DateTimeNodesSender(radio, true);
                dateTimeNodesSender.setup(dateTimeParams);
            }
            isConfiguredOK = radioWiFiSetup.closeSetupNetwork();
        }

        setupManager.closeRadioConnection();

        if (!isConfiguredOK) {
            setStateOfSetup(EStateOfCheckingHeadlessSetup.NodesWereNotSetCorrectly, setupManager);

        } else if (configParams.mConnectionType == EConnectionType.WPS) {
            setStateOfSetup(EStateOfCheckingHeadlessSetup.WaitOnConnectingWithWPS, setupManager);
            updateProgress(FsComponentsConfig.MAX_SECONDS_TO_CONNECT_WITH_WPS + FsComponentsConfig.MAX_SECONDS_TO_LOOK_FOR_CONFIGURED_RADIO);

            int seconds = 0;
            do {
                RadioNodeUtil.waitMs(1000);
                seconds++;

                if (mShouldStopTheTimer) {
                    mShouldStopTheTimer = false;
                    break;
                }

                if (!setupManager.isPhoneStillConnectedToRadioAccessPoint())
                    break;
            } while (seconds < FsComponentsConfig.MAX_SECONDS_TO_CONNECT_WITH_WPS);

            if (setupManager.isPhoneStillConnectedToRadioAccessPoint()) {
                // Setup fail
                setStateOfSetup(EStateOfCheckingHeadlessSetup.NodesWereNotSetCorrectly, setupManager);
                return;
            } else {
                if (!reconnectToPreviousWiFi(setupManager)) {
                    return;
                }

                if (searchAudioDevice(setupManager)) {
                    return;
                }
                sendSetupComplete();
            }
        } else if (configParams.mConnectionType == EConnectionType.Ethernet) {
            if (!reconnectToPreviousWiFi(setupManager)) {
                return;
            }

            if (searchAudioDevice(setupManager)) {
                return;
            }

            sendSetupComplete();

        } else if (configParams.mConnectionType == EConnectionType.WiFi) {
            AccessPointUtil.removeCurrentWiFiConnection();
            tryToConnectToWIFI(setupManager, configParams);
        }
    }

    private boolean reconnectToPreviousWiFi(SetupManager setupManager) {
        setStateOfSetup(EStateOfCheckingHeadlessSetup.ConnectingToSelectedWiFi, setupManager);
        updateProgress(FsComponentsConfig.MAX_SECONDS_TO_WAIT_FOR_CONNECTING_TO_AP);

        AccessPointUtil.removeCurrentWiFiConnection();

        boolean connectedToAP = reconnectToPreviousWiFiImpl(setupManager);

        //Check if the phone is connected to the selected Wi-Fi. If not, try to reconnect.
        if (!connectedToAP) {
            updateProgress(FsComponentsConfig.MAX_SECONDS_TO_WAIT_FOR_CONNECTING_TO_AP);
            connectedToAP = reconnectToPreviousWiFiImpl(setupManager);
        }

        if (!connectedToAP) {
            setStateOfSetup(EStateOfCheckingHeadlessSetup.CouldntConnectToWiFi, setupManager);
            return false;
        }

        return true;
    }

    private boolean reconnectToPreviousWiFiImpl(SetupManager setupManager) {
        int seconds = 0;
        FsLogger.log("Reconnecting to previous wifi");

        setupManager.reconnectToInitialWiFiNetwork();

        while (!AccessPointUtil.isConnectedToGivenAP(setupManager.getWiFiNetworkIdOfPreviousConnectedWiFi())
                && seconds < FsComponentsConfig.MAX_SECONDS_TO_WAIT_FOR_CONNECTING_TO_AP) {
            seconds++;
            RadioNodeUtil.waitMs(1000);
        }

        return AccessPointUtil.isConnectedToGivenAP(setupManager.getWiFiNetworkIdOfPreviousConnectedWiFi());
    }

    private boolean searchAudioDevice(SetupManager setupManager) {
        updateProgress(FsComponentsConfig.MAX_SECONDS_TO_LOOK_FOR_CONFIGURED_RADIO);
        setStateOfSetup(EStateOfCheckingHeadlessSetup.SearchingTheAudioDevice, setupManager);

        boolean deviceFound = searchDeviceWithDiscovery(FsComponentsConfig.MAX_SECONDS_TO_LOOK_FOR_CONFIGURED_RADIO);
        if (!deviceFound) {
            setStateOfSetup(EStateOfCheckingHeadlessSetup.CouldntFindDeviceWithSSDP, setupManager);
            return true;
        }
        return false;
    }

    private void tryToConnectToWIFI(SetupManager setupManager, RadioNetworkConfigParams configParams) {
        setStateOfSetup(EStateOfCheckingHeadlessSetup.ConnectingToSelectedWiFi, setupManager);
        updateProgress(FsComponentsConfig.MAX_SECONDS_TO_WAIT_FOR_CONNECTING_TO_AP);

        boolean connectedToAP = connectToAPSelectedByUser(configParams);

        //Check if the phone is connected to the selected Wi-Fi. If not, try to reconnect.
        if (!connectedToAP) {
            updateProgress(FsComponentsConfig.MAX_SECONDS_TO_WAIT_FOR_CONNECTING_TO_AP);
            connectedToAP = connectToAPSelectedByUser(configParams);
        }

        if (!connectedToAP) {
            setStateOfSetup(EStateOfCheckingHeadlessSetup.CouldntConnectToWiFi, setupManager);
            return;
        }

        if (searchAudioDevice(setupManager)) {
            return;
        }

        sendSetupComplete();
    }

    private void sendConfiguringMessageDependingOnConfigParams(RadioNetworkConfigParams configParams) {
        SetupManager setupManager = SetupManager.getInstance();
        EStateOfCheckingHeadlessSetup stateOfSetup;

        if (configParams.mConnectionType == EConnectionType.WPS) {
            stateOfSetup = EStateOfCheckingHeadlessSetup.ConfiguringWithWPS;
            setStateOfSetup(stateOfSetup, setupManager);
            updateProgress(FsComponentsConfig.MAX_SECOND_TO_CONFIG_WITH_WPS);
        } else {
            stateOfSetup = EStateOfCheckingHeadlessSetup.ConfiguringAudioDevice;
            setStateOfSetup(stateOfSetup, setupManager);
            updateProgress(FsComponentsConfig.MAX_SECONDS_TO_CONFIGURE_THE_DEVICE);
        }
    }

    private void setStateOfSetup(EStateOfCheckingHeadlessSetup stateOfSetup, SetupManager setupManager) {
        setupManager.setStateOfSetup(stateOfSetup);
        sendNewState(stateOfSetup);
    }

    private void setRadioFriendlyName(Radio radio) {

        String friendlyName = SetupManager.getInstance().getFriendlyName();

        if (!TextUtils.isEmpty(friendlyName)) {
            radio.setNode(new NodeSysInfoFriendlyName(friendlyName), true);
            RadioNodeUtil.waitDefaultMs();
        }
    }

    private void setAutoPlayNode(Radio radio) {
        radio.setNode(new NodeSysCfgIrAutoPlayFlag(NodeSysCfgIrAutoPlayFlag.Ord.AUTOPLAY_ON), true);

        RadioNodeUtil.waitDefaultMs();
    }

    synchronized private boolean connectToAPSelectedByUser(RadioNetworkConfigParams configParams) {
        int seconds = 0;
        FsLogger.log("Connecting to " + configParams.mSSID /*+ " with Pass " + configParams.mWiFiPasscode*/);

        AccessPointUtil.connectToAccessPoint(configParams.mSSID, configParams.mWiFiPasscode);

        while (!AccessPointUtil.isConnectedToGivenAP(configParams.mSSID) && seconds < FsComponentsConfig.MAX_SECONDS_TO_WAIT_FOR_CONNECTING_TO_AP) {
            seconds++;
            RadioNodeUtil.waitMs(1000);
        }

        return AccessPointUtil.isConnectedToGivenAP(configParams.mSSID);
    }

    List<Radio> mFoundRadios = null;

    synchronized private boolean searchDeviceWithDiscovery(int secondsAvailable) {
        SetupManager setupManager = SetupManager.getInstance();
        if (setupManager.isDisposed()) {
            return false;
        }

        mFoundRadios = null;
        String friendlyName = setupManager.getFriendlyName();
        FsLogger.log("Starting Discovery scan for " + friendlyName);

        if (TextUtils.isEmpty(friendlyName) || secondsAvailable == 0)
            return false;

        NetRemote netRemote = setupManager.getNetRemote();
        if (netRemote == null)
            return false;

        boolean callbackOnMainThread = false;
        IDiscoveryService discoveryService = netRemote.getDiscoveryService();
        if (discoveryService != null) {
            discoveryService.singleScanOnDemand(callbackOnMainThread, new IScanOnDemandListener() {
                @Override
                public void onScanResults(List<Radio> allRadios) {
                    mFoundRadios = allRadios;
                }
            });
        }

        while (mFoundRadios == null && secondsAvailable > 0) {
            secondsAvailable--;
            RadioNodeUtil.waitMs(1000);

            if (mShouldStopTheTimer) {
                mShouldStopTheTimer = false;
                return true;
            }
        }

        if (mFoundRadios != null) {
            Radio foundRadio = radioIsInDiscoveryScanResults(mFoundRadios, friendlyName);
            if (foundRadio != null) {
                FsLogger.log("Found with Discovery and PING OK " + friendlyName);

                SetupManager.getInstance().setRadioForNextSetupSteps(foundRadio);

                return true;
            }
        }

        return secondsAvailable > 0 && searchDeviceWithDiscovery(secondsAvailable);
    }

    private Radio radioIsInDiscoveryScanResults(List<Radio> foundRadios, String searchedFriendlyName) {
        boolean radioFoundAndAvailable;
        Radio foundRadio = null;

        for (int i = 0; i < foundRadios.size(); i++) {
            Radio radio = foundRadios.get(i);
            String friendlyName = radio.getFriendlyName();

            if (searchedFriendlyName.contentEquals(friendlyName)) {
                FsLogger.log("Found in Discovery list: " + friendlyName + " pinging radio " + radio);
                PingUtil pingUtil = new PingUtil();
                radioFoundAndAvailable = pingUtil.isRadioAvailable(radio);
                if (radioFoundAndAvailable) {
                    foundRadio = radio;
                }
                break;
            }
        }

        return foundRadio;
    }

    private void sendSetupComplete() {
        sendNewState(EStateOfCheckingHeadlessSetup.SuccesfullSetup);
    }

    private void updateProgress(int maxDuration) {
        if (mProgressTimer != null) {
            mProgressTimer.cancel();
            mCurrentProgress = mSecondsToAchieve;
            sendProgress(mSecondsToAchieve);
        }

        mSecondsToAchieve += maxDuration;

        mProgressTimer = new Timer();
        mProgressTimer.schedule(new ProgressTimerTask(), 1000, 1000);
    }

    class ProgressTimerTask extends TimerTask {

        @Override
        public void run() {
            if (mCurrentProgress < mSecondsToAchieve) {
                mCurrentProgress++;
                sendProgress(mCurrentProgress);
            } else {
                sendProgress(mSecondsToAchieve);
                mProgressTimer.cancel();
            }
        }
    }

    private void sendNewState(EStateOfCheckingHeadlessSetup state) {
        synchronized (mLock) {
            if (mStateListener != null)
                mStateListener.onStateOfCheckingHeadlessSetupChanged(state);
        }
    }

    private void sendProgress(int progress) {
        synchronized (mLock) {
            if (mStateListener != null)
                mStateListener.onProgress(progress);
        }
    }

    public void cleanTimer() {
        if (mProgressTimer != null) {
            mProgressTimer.cancel();
            mProgressTimer.purge();
            mProgressTimer = null;
        }
    }

    public void dispose() {
        setShouldStopTheTimer(false);
        cleanTimer();

        synchronized (mLock) {
            mStateListener = null;
        }
    }

    public void setListener(IStateOfCheckingHeadlessSetupListener stateListener) {
        synchronized (mLock) {
            mStateListener = stateListener;
        }
    }
}
