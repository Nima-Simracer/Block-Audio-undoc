package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.view.View;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextMenuButtonClickedEvent;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by lsuhov on 24/10/2016.
 */

public class BrowseNavItemViewModel {
    public ObservableField<String> name = new ObservableField<>();
    public ObservableField<String> artist = new ObservableField<>();
    public ObservableBoolean hasArtist = new ObservableBoolean(false);
    public ObservableBoolean hasArtwork = new ObservableBoolean(false);
    public ObservableBoolean hasContext = new ObservableBoolean(false);
    public boolean isScrollingEnable = UndokPreferences.getInstance().getScrollingEnabled();

    protected int mPosition;
    protected BrowseItemModel mNavBrowseItemModel;

    public BrowseNavItemViewModel(int position, BrowseItemModel navBrowseItemModel) {
        mPosition = position;
        mNavBrowseItemModel = navBrowseItemModel;

        init();
    }

    protected void init() {
        name.set(mNavBrowseItemModel.getName());
        artist.set(mNavBrowseItemModel.getArtist());
        hasArtist.set(mNavBrowseItemModel.hasArtist());
        hasArtwork.set(mNavBrowseItemModel.hasArtwork());
        this.hasContext.set(mNavBrowseItemModel.hasContextMenu());
    }

    public void onContextItemClicked(View view) {
        ContextMenuButtonClickedEvent event = new ContextMenuButtonClickedEvent(mPosition, mNavBrowseItemModel);

        EventBus.getDefault().post(event);
    }

    public void dispose() {
        mNavBrowseItemModel = null;
    }
}
