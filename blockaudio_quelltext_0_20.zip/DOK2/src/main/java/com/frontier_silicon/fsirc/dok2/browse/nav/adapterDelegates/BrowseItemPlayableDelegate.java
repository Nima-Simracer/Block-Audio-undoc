package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseItemPlayableViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseListItemPlayableBinding;

/**
 * Created by lsuhov on 06/11/2016.
 */

public class BrowseItemPlayableDelegate extends RecyclerViewListItemDelegate {

    private int mBrowseType;

    public BrowseItemPlayableDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseListItemPlayableBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_list_item_playable,
                parent, false);

        return new BrowseItemPlayableViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(mBrowseType);
        BrowseItemModel browseItemModel = browseManager.tryGetBrowseItemModel(position);

        BrowseItemPlayableViewHolder playableViewHolder = (BrowseItemPlayableViewHolder) holder;
        BrowseListItemPlayableBinding binding = playableViewHolder.mBinding;

        if ((browseItemModel != null) && browseItemModel.hasArtwork()) {
            Glide.with(playableViewHolder.itemView.getContext())
                    .load(browseItemModel.getArtwork())
                    .into(binding.artworkInList);
        }

        BrowseItemPlayableViewModel viewModel = new BrowseItemPlayableViewModel(position, browseItemModel, browseManager);
        binding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseItemPlayableViewHolder playableViewHolder = (BrowseItemPlayableViewHolder) holder;
        BrowseItemPlayableViewModel viewModel = playableViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            playableViewHolder.mBinding.setViewModel(null);
        }
    }

    private static class BrowseItemPlayableViewHolder extends ListItemViewHolder {
        BrowseListItemPlayableBinding mBinding;

        BrowseItemPlayableViewHolder(BrowseListItemPlayableBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
