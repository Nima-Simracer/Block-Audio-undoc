package com.frontier_silicon.fsirc.dok2.browse.nav.navAirable;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.MessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.FormFailedAirableEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavRefreshEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ShowLoadingProgressEvent;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by adanaila on 10/4/2016.
 */

public class NavMessageManager extends MessageManager {

    private static NavMessageManager mInstance;

    public static NavMessageManager getInstance() {
        if (mInstance == null) {
            mInstance = new NavMessageManager();
        }

        return mInstance;
    }

    private NavMessageManager() {
        super();
    }

    @Override
    public void sendMessageData(long id) {
        EventBus.getDefault().post(new ShowLoadingProgressEvent());

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        NavMessageSetRunnable runnable = new NavMessageSetRunnable(radio, id, new NavMessageSetRunnable.INavMessageDataSendListener() {
            @Override
            public void onNavMessageSend(final boolean result) {
                if(result) {
                    clearItemsLoaded();
                    EventBus.getDefault().post(new NavRefreshEvent(-1));
                }else{
                    EventBus.getDefault().post(new FormFailedAirableEvent());
                }
            }
        });
        mThreadPoolExecutor.submit(runnable);
    }
}
