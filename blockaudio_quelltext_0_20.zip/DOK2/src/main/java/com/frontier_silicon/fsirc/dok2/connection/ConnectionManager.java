package com.frontier_silicon.fsirc.dok2.connection;

import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.AppDestroyedEvent;
import com.frontier_silicon.fsirc.dok2.AppInBackgroundEvent;
import com.frontier_silicon.fsirc.dok2.AppInForegroundEvent;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.notifications.NotificationManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Created by lsuhov on 07/03/2017.
 */

public class ConnectionManager implements IMultiroomGroupingListener {
    private static ConnectionManager mInstance;

    private int CONNECT_TO_RADIO_TIMEOUT = 40_000;

    private String mLastConnectedDeviceSN = null;
    private long mConnectToRadioTaskStartTime = 0;
    private ConnectToSpeakerOrGroupTask mConnectToSpeakerOrGroupTask;
    private RadioConnectivityHandler mConnectivityHandler;
    private List<IConnectToSpeakerOrGroup> mListeners = new CopyOnWriteArrayList<>();

    private ConnectionManager() {
        mConnectivityHandler = new RadioConnectivityHandler();
        MultiroomGroupManager.getInstance().addListener(this);
        EventBus.getDefault().register(this);
    }

    public static ConnectionManager getInstance() {
        if (mInstance == null) {
            mInstance = new ConnectionManager();
        }

        return mInstance;
    }

    public void init() {
        mConnectivityHandler.init();
    }

    public void addListener(IConnectToSpeakerOrGroup listener) {
        if (!mListeners.contains(listener)) {
            mListeners.add(listener);
        }
    }

    @Subscribe
    public void onAppVisible(AppInForegroundEvent event) {
        connectToLastConnectedDevice();
    }

    @Subscribe
    public void onAppNotVisible(AppInBackgroundEvent event) {
        if (!SpeakerDataManager.getInstance().isNotificationAllowed() ||
                !NotificationManager.getInstance().isNotificationShowed()) {
            FsLogger.log("ConnectionManager: AppInBackgroundEvent");
            Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
            if (currentRadio != null) {
                currentRadio.close();
                currentRadio.closeRadioSession();
            }
        }
    }

    @Subscribe
    public void onAppDestroyed(AppDestroyedEvent event) {
        FsLogger.log("ConnectionManager: AppDestroyedEvent");
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (currentRadio != null) {
            currentRadio.close();
            currentRadio.closeRadioSession();
        }
    }


    public void removeListener(IConnectToSpeakerOrGroup listener) {
        mListeners.remove(listener);
    }

    public void cleanup() {
        mConnectivityHandler.cleanup();
        mListeners.clear();
    }

    public void tryConnectToSpeakerOrGroup(MultiroomItemModel multiroomItemModel) {

        if (isValidGroup(multiroomItemModel)) {

            MultiroomDeviceModel serverDeviceModel = MultiroomGroupManager.getInstance().getServerDeviceFromGroupId(
                    multiroomItemModel.getGroupId());

            if (serverDeviceModel != null) {
                tryConnectToSelectedRadio(serverDeviceModel.mRadio);
            } else {
                updateListeners(false, true);
            }
        } else {
            tryConnectToSelectedRadio(multiroomItemModel.getRadio());
        }
    }

    private boolean isValidGroup(MultiroomItemModel item) {
        return ( !MultiroomGroupManager.getInstance().isUngroupedDevicesGroup(item.getGroupId()) &&
                !MultiroomGroupManager.TEMP_GROUP_ID.equalsIgnoreCase(item.getGroupId()) &&
                !MultiroomGroupManager.getInstance().isSecondaryStereoGroup(item.getGroupId()));
    }

    public void tryConnectToSelectedRadio(Radio radio) {

        connectToRadio(radio, true, false);
    }

    private void connectToRadio(final Radio radio, boolean showProgress, boolean failSilently) {
        // check if speaker is already connected
        if (NetRemoteManager.getInstance().checkConnection(radio)) {
            updateListeners(true, false);
            return;
        }

        if (radio == null || !connectToAnotherRadioIsAllowed()) {
            return;
        }

        MultiroomDeviceModel deviceModel = MultiroomGroupManager.getInstance().getDeviceByUdn(radio.getUDN());
        if (deviceModel == null) {
            return;
        }
        boolean isServer = deviceModel.isServer();

        mConnectToSpeakerOrGroupTask = new ConnectToSpeakerOrGroupTask(MainApplication.getCurrentActivity(), radio, isServer,
                showProgress, failSilently, new IConnectToSpeakerOrGroup() {
            @Override
            public void onConnectedToSpeakerOrGroup(final boolean connectedOk, final boolean isGroup) {
                mConnectToSpeakerOrGroupTask = null;

                if (connectedOk) {
                    setLastConnectedDeviceSN(radio.getSN());
                    saveLastConnectedDevice();
                }

                NetRemote.getMainThreadExecutor().execute(() ->
                        updateListeners(connectedOk, isGroup));
            }
        });

        TaskHelper.execute(mConnectToSpeakerOrGroupTask);
        mConnectToRadioTaskStartTime = System.currentTimeMillis();
    }

    private boolean connectToAnotherRadioIsAllowed() {
        return mConnectToSpeakerOrGroupTask == null || mConnectToSpeakerOrGroupTask.getStatus() == AsyncTask.Status.FINISHED ||
                (System.currentTimeMillis() - mConnectToRadioTaskStartTime > CONNECT_TO_RADIO_TIMEOUT);
    }

    public boolean connectToLastConnectedDevice() {
        boolean foundDevice = false;
        Radio radio = getLastConnectedDevice();

        if (radio == null) {
            FsLogger.log("connectToLastConnectedDevice: Trying to reconnect but the radio was not found", LogLevel.Error);
            return foundDevice;
        }

        if (NetRemoteManager.getInstance().checkConnection()) {
            FsLogger.log("connectToLastConnectedDevice: Trying to reconnect but we already have a connection", LogLevel.Error);
            return foundDevice;
        }

        FsLogger.log("connectToLastConnectedDevice: Try to connect to last connected radio SN: " + mLastConnectedDeviceSN, LogLevel.Info);

        connectToRadio(radio, false, true);
        foundDevice = true;

        return foundDevice;
    }

    public Radio getLastConnectedDevice() {
        return NetRemoteManager.getInstance().getRadioFromSN(mLastConnectedDeviceSN);
    }

    public void setLastConnectedDeviceSN(String serialNumber) {
        mLastConnectedDeviceSN = serialNumber;
    }

    public String getLastConnectedDeviceSN() {
        return mLastConnectedDeviceSN;
    }


    public void saveLastConnectedDevice() {
        String snOfLastConnectedSpeaker = getLastConnectedDeviceSN();

        CommonPreferences.getInstance().setLastConnectedDeviceSN(snOfLastConnectedSpeaker);
    }

    public void restoreLastConnectedDevice() {
        String snOfLastConnectedSpeaker = CommonPreferences.getInstance().getLastConnectedDeviceSN();

        setLastConnectedDeviceSN(snOfLastConnectedSpeaker);
    }

    public void setShouldAutoConnectToLastSpeaker(boolean autoConnect) {
        mConnectivityHandler.setShouldAutoConnectToLastSpeaker(autoConnect);
    }

    @Override
    public void onGroupingUpdate() {
        NetRemote.getMainThreadExecutor().execute(() -> {

            Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
            if (!NetRemoteManager.getInstance().checkConnection(currentRadio)) {
                return;
            }

            MultiroomDeviceModel deviceModel = MultiroomGroupManager.getInstance().getDeviceByUdn(currentRadio.getUDN());
            Radio newServerRadio = MultiroomGroupManager.getInstance().getServerOrUngroupedRadio(deviceModel);

            if (newServerRadio == null || newServerRadio.equals(currentRadio)) {
                return;
            }

            FsLogger.log("New server was detected " + newServerRadio, LogLevel.Warning);

            tryConnectToSelectedRadio(newServerRadio);
        });
    }

    private void updateListeners(boolean connectedOk, boolean isGroup) {
        for (IConnectToSpeakerOrGroup listener : mListeners) {
            listener.onConnectedToSpeakerOrGroup(connectedOk, isGroup);
        }
    }
}
