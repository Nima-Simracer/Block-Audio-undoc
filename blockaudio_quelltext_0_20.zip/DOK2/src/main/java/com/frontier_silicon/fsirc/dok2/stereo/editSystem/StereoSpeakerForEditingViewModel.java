package com.frontier_silicon.fsirc.dok2.stereo.editSystem;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.graphics.drawable.BitmapDrawable;
import androidx.annotation.IdRes;
import android.view.View;
import android.widget.RadioGroup;

import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.stereo.EChannelMask;
import com.frontier_silicon.components.stereo.IChannelMaskListener;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.StereoEditPairSpeakerBinding;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

/**
 * Created by lsuhov on 17/08/2017.
 */

public class StereoSpeakerForEditingViewModel {

    public ObservableField<String> speakerName = new ObservableField<>();
    public ObservableField<BitmapDrawable> speakerImage = new ObservableField<>();
    public ObservableBoolean isPrimarySpeaker = new ObservableBoolean();

    private MultiroomDeviceModel mDeviceModel;
    private MultiroomDeviceModel mPrimaryDeviceModel;
    private StereoEditPairSpeakerBinding mSpeakerBinding;
    private Activity mActivity;
    private EChannelMask mChannelMask = EChannelMask.Left;

    public StereoSpeakerForEditingViewModel(MultiroomDeviceModel deviceModel, MultiroomDeviceModel primaryDeviceModel,
                                            StereoEditPairSpeakerBinding speakerBinding, Activity activity) {
        mDeviceModel = deviceModel;
        mPrimaryDeviceModel = primaryDeviceModel;
        mSpeakerBinding = speakerBinding;
        mActivity = activity;

        init();
    }

    private void init() {
        updateName();

        updateSpeakerType();

        updateSpeakerImage();

        updateChannelMask();

        setChannelMaskListener();
    }

    private void setChannelMaskListener() {
        mSpeakerBinding.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (checkedId == R.id.buttonLeftChannel) {
                    mChannelMask = EChannelMask.Left;
                } else if (checkedId == R.id.buttonRightChannel) {
                    mChannelMask = EChannelMask.Right;
                }
                sendChannelMaskToSpeaker();
            }
        });
    }

    private void sendChannelMaskToSpeaker() {
        if (isPrimarySpeaker.get()) {
            StereoManager.getInstance().setChannelMaskToPrimarySpeaker(mChannelMask, mPrimaryDeviceModel.mRadio);
        } else {
            StereoManager.getInstance().setChannelMaskToSecondarySpeaker(mChannelMask, mPrimaryDeviceModel.mRadio);
        }
    }

    private void updateSpeakerType() {
        isPrimarySpeaker.set(mDeviceModel.isPrimaryStereo());
    }

    private void updateChannelMask() {
        if (mPrimaryDeviceModel == null) {
            return;
        }

        IChannelMaskListener listener = new IChannelMaskListener() {
            @Override
            public void onChannelMaskRetrieved(EChannelMask channelMask) {
                if (mActivity == null || mActivity.isFinishing()) {
                    return;
                }

                switch (channelMask) {
                    case Left:
                        mSpeakerBinding.buttonLeftChannel.setChecked(true);
                        mChannelMask = channelMask;
                        break;
                    case Right:
                        mSpeakerBinding.buttonRightChannel.setChecked(true);
                        mChannelMask = channelMask;
                        break;
                    case Stereo:
                        mSpeakerBinding.buttonLeftChannel.setChecked(true);
                        mChannelMask = EChannelMask.Left;
                        break;
                }
            }
        };

        if (isPrimarySpeaker.get()) {
            StereoManager.getInstance().retrievePrimaryChannelMask(mPrimaryDeviceModel.mRadio, listener);
        } else {
            StereoManager.getInstance().retrieveSecondaryChannelMask(mPrimaryDeviceModel.mRadio, listener);
        }
    }

    private void updateName() {
        speakerName.set(mDeviceModel.mRadio.getFriendlyName());
    }

    private void updateSpeakerImage() {

        DokUiUtils.setImageIntoObservableDrawable(speakerImage, mDeviceModel.mRadio, mActivity);
    }

    public void onPlayAlertToneClicked(View v) {
        StereoManager.getInstance().playAlertTone(mDeviceModel.mRadio);
    }

    public void dispose() {
        mDeviceModel = null;
        if (mSpeakerBinding != null) {
            mSpeakerBinding.radioGroup.setOnCheckedChangeListener(null);
            mSpeakerBinding = null;
        }
        mActivity = null;
    }
}
