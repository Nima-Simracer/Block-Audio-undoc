package com.frontier_silicon.fsirc.dok2.browse.dmr.filter;

import com.frontier_silicon.fsirc.dok2.browse.dmr.BrowseDMRItemModel;

import java.util.ArrayList;
import java.util.List;

/**
 * The caretaker class is responsible for holding a
 * <code>LocalMediaMemento</code> in isolation preventing further modification.
 * <p>
 * This memento should represent the
 * unmodified contents of the <code>BrowseDMRAdapter</code> before any text filtering
 * has been applied.
 */
public class CareTaker {
  private LocalMediaMemento mOriginalState;

  /**
   * Stores a <code>LocalMediaMemento</code> object.
   * This should represent the unfiltered list of items from the
   * <code>BrowseDMRAdapter</code>
   *
   * @param originalState The object state to be stored
   */
  public void saveOriginalState(LocalMediaMemento originalState) {
    mOriginalState = originalState;
  }

  /**
   * Returns the unmodified <code>LocalMediaMemento</code> object.
   * This object should represent the contents of the <code>BrowseDMRAdapter</code>
   * before any text filtering was applied.
   *
   * @return The previous state held by the memento
   */
  public LocalMediaMemento getOriginalState() {
    return mOriginalState;
  }

  /**
   * Provides a copy of the state stored in the memento.
   *
   * @return A copy of the unfiltered list of
   */
  public List<BrowseDMRItemModel> copyOriginalState() {
    List<BrowseDMRItemModel> mNewUnfilteredList = new ArrayList<>();

    for (BrowseDMRItemModel currentItem : mOriginalState.getState()) {
      mNewUnfilteredList.add(currentItem);
    }
    return mNewUnfilteredList;
  }
}
