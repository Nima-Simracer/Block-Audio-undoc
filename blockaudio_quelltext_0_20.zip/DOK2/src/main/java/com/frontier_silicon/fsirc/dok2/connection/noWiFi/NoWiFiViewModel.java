package com.frontier_silicon.fsirc.dok2.connection.noWiFi;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import androidx.databinding.ObservableBoolean;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

/**
 * Created by lsuhov on 07/11/2017.
 */

public class NoWiFiViewModel implements IConnectionStateListener {

    public ObservableBoolean isWiFiEnabling = new ObservableBoolean();
    public ObservableBoolean isTurnOnButtonVisible = new ObservableBoolean(false);
    private Activity mActivity;

    public NoWiFiViewModel(Activity activity) {
        mActivity = activity;
    }

    public void onResume() {
        ConnectionStateUtil.getInstance().addListener(this, true);

        updateIsWiFiEnabling();
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            isTurnOnButtonVisible.set(false);
        } else {
            isTurnOnButtonVisible.set(true);
        }
    }

    public void onPause() {
        ConnectionStateUtil.getInstance().removeListener(this);
    }

    private void updateIsWiFiEnabling() {
        isWiFiEnabling.set(AccessPointUtil.isWiFiEnabledOrEnabling());
    }

    @Override
    public void onStateUpdate(final ConnectionState newState) {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        mActivity.runOnUiThread(() -> {
            if (DokUiUtils.isDestroyed(mActivity)) {
                return;
            }

            switch (newState) {
                case NO_WIFI_OR_ETHERNET:
                    break;

                default:
                    NavigationHelper.goToHomeAndClearActivityStack(mActivity);
            }
        });
    }

    public void onOpenWiFiSettings(View v) {
        mActivity.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
    }

    public void onEnableWiFi(View v) {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        final WifiManager wifiMgr = (WifiManager) mActivity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        if (wifiMgr.isWifiEnabled()) {
            try {
                wifiMgr.setWifiEnabled(false);
            } catch (SecurityException e) {
                // Changing Wi-Fi erroneously requires android.permission.UPDATE_DEVICE_STATS
                // https://code.google.com/p/android/issues/detail?id=22036
            }

            DelayedPostsManager.getInstance().postDelayed(() -> restartWiFi(wifiMgr), 1000);

        } else {
            restartWiFi(wifiMgr);
        }

        isWiFiEnabling.set(true);
    }

    private void restartWiFi(WifiManager wifiMgr){
        try {
            wifiMgr.setWifiEnabled(true);
        } catch (SecurityException e) {
            // Changing Wi-Fi erroneously requires android.permission.UPDATE_DEVICE_STATS
            // https://code.google.com/p/android/issues/detail?id=22036
        }

        SetupManager.getInstance().reconnectToInitialWiFiNetwork();
        SetupManager.getInstance().removeInitialWiFiNetwork();
    }

    public void dispose() {
        mActivity = null;
    }
}
