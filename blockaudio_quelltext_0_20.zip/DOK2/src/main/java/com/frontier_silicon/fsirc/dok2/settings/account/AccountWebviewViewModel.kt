package com.frontier_silicon.fsirc.dok2.settings.account


import android.app.Activity
import android.graphics.Bitmap
import android.os.Build
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient

import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication
import com.frontier_silicon.fsirc.dok2.NavigationHelper
import com.frontier_silicon.fsirc.dok2.databinding.FsdcaAccountWebviewActivityBinding
import com.frontier_silicon.loggerlib.FsLogger

import java.util.HashMap

class AccountWebviewViewModel(private var mBinding: FsdcaAccountWebviewActivityBinding?, private var mActivity: Activity?) {
    private var mUrlToOpen: String = ""
    private var mEndpoints: FSDCAEndpoints? = null

    fun init() {
        mEndpoints = FSDCAEndpoints()
        setWebView()
        loadWebView()
    }

    private fun setWebView() {

        val webSettings = mBinding!!.webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        mBinding?.webView?.webViewClient = EmbeddedWebViewClient()
        mBinding?.webView?.webChromeClient = WebChromeClient()
    }

    private fun loadWebView() {
        val intent = mActivity!!.intent
        val bundle = intent.extras
        if (bundle != null) {
            mUrlToOpen = bundle.getString(URL_TO_OPEN_IN_WEBVIEW, "")
        }
        FsLogger.log("Open 3PDA webview for URL: " + mUrlToOpen!!)

        val header = HashMap<String, String>()
        header["Authorization"] = "bearer " + FSAuthManager.getInstance().accessToken

        if (mUrlToOpen != null) {
            mBinding?.webView?.loadUrl(mUrlToOpen, header)
        }
    }

    private inner class EmbeddedWebViewClient : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            return false
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            mBinding?.progressBar?.visibility = View.VISIBLE
        }

        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            mBinding?.progressBar?.visibility = View.GONE
        }

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (mEndpoints != null && mUrlToOpen == mEndpoints!!.getMyAccountUrl() && request.method == "DELETE") {

                    FSAuthManager.getInstance().invalidateToken()
                    FSAuthManager.getInstance().wasAccountDeleted = true
                    NavigationHelper.goToActivityClearingCurrentStack(MainApplication.getCurrentActivity(), FSDCALoginActivity::class.java,
                            NavigationHelper.AnimationType.SlideToRight)

                }
            }

            return super.shouldInterceptRequest(view, request)

        }
    }


    fun dispose() {
        mBinding!!.webView.webChromeClient = null

        mActivity = null
        mBinding = null
        mEndpoints = null
    }

    companion object {
        private val URL_TO_OPEN_IN_WEBVIEW = "URL_TO_OPEN_IN_WEBVIEW"
    }
}
