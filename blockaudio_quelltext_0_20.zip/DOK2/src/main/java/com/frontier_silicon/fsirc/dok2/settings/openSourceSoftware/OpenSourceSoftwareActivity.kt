package com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase
import com.frontier_silicon.fsirc.dok2.databinding.ActivityOpenSourceBinding
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.widget.OpenSourceSoftwareAdapter
import javax.inject.Inject


class OpenSourceSoftwareActivity : UndokActivityBase(), IOnItemSelected, LifecycleObserver {
    lateinit var binding: ActivityOpenSourceBinding
    lateinit var licensesObserver: Observer<List<OpenSourceSoftwareModel>>

    @Inject
    lateinit var adapter: OpenSourceSoftwareAdapter

    @Inject
    lateinit var viewModel: OpenSourceSoftwareVM

    @Inject
    lateinit var linearLayoutManager: LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inject()

        lifecycle.addObserver(this)
        binding = ActivityOpenSourceBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.viewModel = viewModel

        setupAppBar()
        setTitle(R.string.open_source_title)
        enableUpNavigation()
        initRecyclerView()
    }

    override fun onResume() {
        super.onResume()
        licensesObserver = Observer {
            adapter.swapItems(it)
        }
        viewModel.openSourceLicenses.observe(this, licensesObserver)
    }

    override fun onPause() {
        super.onPause()
        viewModel.openSourceLicenses.removeObserver(licensesObserver)
    }


    private fun inject() {
        (application as MainApplication).initOpenSourceComponent(this, this).inject(this)
    }

    private fun initRecyclerView() {
        binding.licensesRecyclerView.layoutManager = linearLayoutManager
        binding.licensesRecyclerView.adapter = adapter
    }

    override fun onItemSelected(position: Int) {
        viewModel.openSourceLicenses.value?.let {
            showInBrowser(it[position].url)
        }
    }

    private fun showInBrowser(url: String) {
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(browserIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        (application as MainApplication).deinitOpenSourceSoftwareComponent()
        lifecycle.removeObserver(this)
    }
}