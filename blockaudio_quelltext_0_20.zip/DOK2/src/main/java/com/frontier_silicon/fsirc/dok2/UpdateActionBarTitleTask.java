package com.frontier_silicon.fsirc.dok2;

import android.os.AsyncTask;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomGroupState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;

import java.util.List;

public class UpdateActionBarTitleTask extends AsyncTask<Void, Void, Boolean> {

	private AppCompatActivity mParentActivity;

    private String mTitle = "";
    private String mSubTitle = "";
	
	public UpdateActionBarTitleTask(AppCompatActivity parentActivity, String defaultTitle) {
		mParentActivity = parentActivity;
        mTitle = defaultTitle;
	}
	
	@Override
	protected Boolean doInBackground(Void... arg0) {

		return getCurrentConnectionName();
	}
	
	@Override
	protected void onPostExecute(Boolean result) {
		if (mParentActivity != null) {
			ActionBar actionBar = mParentActivity.getSupportActionBar();
			if (actionBar == null)
				return;
			
			// show curr. connected group/radio			
			View customView = actionBar.getCustomView();
			if (customView == null)
				return;

            TextView titleView = customView.findViewById(R.id.text);
            titleView.setText(mTitle);
            if (UndokPreferences.getInstance().getScrollingEnabled()) {
				titleView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
			} else {
				titleView.setEllipsize(TextUtils.TruncateAt.END);
			}

			TextView subTitleView = customView.findViewById(R.id.textCurrentConnection);
            subTitleView.setText(mSubTitle);

			if (TextUtils.isEmpty(mSubTitle)) {
				subTitleView.setVisibility(View.GONE);
			} else {
				subTitleView.setVisibility(View.VISIBLE);
			}
		}

		mParentActivity = null;
	}

	private boolean getCurrentConnectionName() {
        boolean ret = false;

        Radio currRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (currRadio != null && currRadio.isConnectionOk()) {

            String currentName = MultiroomGroupManager.getInstance().getCurrentNameOfGroupOrSpeaker();
            if (!TextUtils.isEmpty(currentName)) {
                mTitle = currentName;
            }

            if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {
				NodeMultiroomGroupState.Ord role = MultiroomGroupManager.getInstance().getCurrentDeviceGroupRole();

				mSubTitle = DokUiUtils.getFriendlyNameOrStereoSystemName(currRadio);
				if (role == NodeMultiroomGroupState.Ord.SERVER) {

					long numClients = MultiroomGroupManager.getInstance().getNumClientsForCurrentGroup();
					if (numClients > 0) {
						mSubTitle = mSubTitle + " + " + numClients;
					}
				} else if (role == NodeMultiroomGroupState.Ord.CLIENT) {
					// is client, we need to find server name
					List<MultiroomDeviceModel> groupDevices = MultiroomGroupManager.getInstance().getGroupOfRadio(currRadio);

					for (MultiroomDeviceModel deviceModel: groupDevices) {
						if (deviceModel.mGroupRole == NodeMultiroomGroupState.Ord.SERVER) {

							mSubTitle = deviceModel.toString() + " + " + (groupDevices.size()-1);
							return true;
						}
					}

					mSubTitle = DokUiUtils.getFriendlyNameOrStereoSystemName(currRadio) + " + " + groupDevices.size();
				}
            }

            // Fassung 0.17 Audioblock (19.09.2026) — NEU.
            //
            // Die zweite Zeile in der Kopfzeile war bisher NUR fuer Mehrraum da:
            // sie zeigte, in welcher Gruppe man steckt. Steht das Geraet allein,
            // blieb sie leer — und man sah nirgends, auf welcher Quelle die Box
            // gerade steht. Man musste erst auf "Quelle" tippen und nachsehen.
            //
            // Jetzt steht dort die laufende Quelle, wenn keine Gruppenangabe
            // noetig ist. Die Gruppenangabe hat weiter Vorrang: in einer Gruppe
            // ist wichtiger, mit wem man verbunden ist.
            if (TextUtils.isEmpty(mSubTitle)) {
                mSubTitle = quellenName();
            }

            ret = true;
        }

		return ret;
	}

	/**
	 * Lesbarer Name der Quelle, auf der die Box gerade steht.
	 * Leer, wenn nichts Sinnvolles anzuzeigen ist — dann bleibt die zweite
	 * Zeile wie bisher ausgeblendet.
	 */
	private String quellenName() {
		try {
			NodeSysCapsValidModes.Mode modus =
					SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.get();
			if (modus == null) {
				return "";
			}
			switch (modus) {
				case IR:        return "Internetradio";
				case Spotify:   return "Spotify";
				case DAB:       return "DAB+";
				case FM:        return "UKW";
				case Bluetooth: return "Bluetooth";
				case DMR:       return mParentActivity == null ? ""
						: mParentActivity.getString(R.string.fs_dok_mode_localmusic);
				case MP:        return "Musikwiedergabe";
				case AuxIn:     return "AUX";
				case AuxIn2:    return "AUX 2";
				case AirPlay:   return "AirPlay";
				case Cast:      return "Chromecast";
				case AIRABLE_DEEZER:  return "Deezer";
				case AIRABLE_NAPSTER: return "Napster";
				case AIRABLE_QOBUZ:   return "Qobuz";
				case AIRABLE_TIDAL:   return "Tidal";
				default:        return "";
			}
		} catch (Throwable ignored) {
			// Die Kopfzeile darf an einer Beschriftung niemals scheitern
			return "";
		}
	}
}
