package com.frontier_silicon.fsirc.dok2.browse.bluetooth;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import android.content.Context;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothConnectedDevices;
import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothDiscoverableState;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.bluetooth.settings.BluetoothSettingsActivity;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.List;

public class BrowseBluetoothViewModel implements LifecycleObserver {

    public ObservableBoolean minuetUIShouldBeVisible = new ObservableBoolean(false);
    public ObservableField<String> bluetoothStatus = new ObservableField<>();

    private Lifecycle mLifecycle;
    private IBrowseBluetoothNodesListener mListener;

    BrowseBluetoothViewModel(Lifecycle lifecycle) {
        lifecycle.addObserver(this);

        mLifecycle = lifecycle;
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    public void onResume() {
        updateInformation();
    }

    private void updateInformation() {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        if (radio == null) {
            return;
        }

        if (!radio.isMinuet()) {
            minuetUIShouldBeVisible.set(false);
            return;
        }

        mListener = nodes -> {
            NodeBluetoothDiscoverableState state = (NodeBluetoothDiscoverableState)
                    nodes.get(NodeBluetoothDiscoverableState.class);

            List<NodeBluetoothConnectedDevices.ListItem> connectedDevicesList =
                    (List<NodeBluetoothConnectedDevices.ListItem>)nodes.get(NodeBluetoothConnectedDevices.class);

            Context context = MainApplication.getContext();

            if (state == null) {
                bluetoothStatus.set(context.getString(R.string.bluetooth_unavailable_status));
            } else {

                if (connectedDevicesList != null) {
                    boolean connectedDeviceFound = false;
                    for (NodeBluetoothConnectedDevices.ListItem deviceListItem : connectedDevicesList) {
                        if (deviceListItem.getDeviceState() == NodeListItem.DeviceState.Connected) {

                            FsLogger.log("paired with: " + deviceListItem.getDeviceName());
                            bluetoothStatus.set(MainApplication.getContext().getString(R.string.connected_to, deviceListItem.getDeviceName()));
                            connectedDeviceFound = true;
                            break;
                        }
                    }

                    if (!connectedDeviceFound) {
                        updateBluetoothStateBasedOnNodeDiscoverableState(state);
                    }
                } else {
                    updateBluetoothStateBasedOnNodeDiscoverableState(state);
                }
            }

            minuetUIShouldBeVisible.set(true);
        };

        BrowseBluetoothManager.getInstance().addListenerAndRetrieveResults(radio, mListener);
    }

    private void updateBluetoothStateBasedOnNodeDiscoverableState(NodeBluetoothDiscoverableState nodeState) {
        if (nodeState.getValueEnum() == NodeBluetoothDiscoverableState.Ord.DISCOVERABLE) {

            bluetoothStatus.set(MainApplication.getContext().getString(R.string.bluetooth_discoverable));
        } else {
            bluetoothStatus.set(MainApplication.getContext().getString(R.string.bluetooth_idle));
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    public void onPause() {
        BrowseBluetoothManager.getInstance().removeListener(mListener);
    }

    public void openBluetoothSettings(View v) {
        NavigationHelper.goToActivity(MainApplication.getCurrentActivity(), BluetoothSettingsActivity.class);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void dispose() {
        if (mLifecycle != null) {
            mLifecycle.removeObserver(this);
            mLifecycle = null;
        }

        mListener = null;
    }
}
