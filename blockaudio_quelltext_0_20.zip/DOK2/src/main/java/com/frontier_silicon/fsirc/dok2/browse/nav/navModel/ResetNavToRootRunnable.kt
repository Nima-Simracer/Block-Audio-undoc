package com.frontier_silicon.fsirc.dok2.browse.nav.navModel

import com.frontier_silicon.NetRemoteLib.Node.BaseNavStatus
import com.frontier_silicon.NetRemoteLib.Radio.Radio
import com.frontier_silicon.components.common.RadioNavigationUtil

class ResetNavToRootRunnable(val mRadio: Radio): Runnable {

    override fun run() {
        val statusNode = RadioNavigationUtil.resetNavigationToRoot(mRadio)
        val status = statusNode?.valueEnum

        if (statusNode == null || status == BaseNavStatus.Ord.FAIL || status == BaseNavStatus.Ord.FATAL_ERR || status == BaseNavStatus.Ord.WAITING) {
            return
        }
    }
}