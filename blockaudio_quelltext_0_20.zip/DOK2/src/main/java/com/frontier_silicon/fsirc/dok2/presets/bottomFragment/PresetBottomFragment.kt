package com.frontier_silicon.fsirc.dok2.presets.bottomFragment

import android.app.Dialog
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.databinding.PresetsEditBottomFragmentBinding
import com.frontier_silicon.fsirc.dok2.presets.PresetItemModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class PresetBottomFragment(private val callback: IBottomFragment, val presetItem: PresetItemModel) :
    BottomSheetDialogFragment() {
    private lateinit var binding: PresetsEditBottomFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.presets_edit_bottom_fragment,
            container,
            false
        )
        return binding.root
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = BottomSheetDialog(requireContext(), theme)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        return dialog
    }

    override fun onStart() {
        super.onStart()
        initLayout()
    }

    private fun initLayout() {
        binding.presetName.text = presetItem.mName

        binding.editButton.setOnClickListener {
            callback.onEdit(presetItem)
            dismiss()
        }

        binding.replaceButton.setOnClickListener {
            callback.onReplace(presetItem)
            dismiss()
        }

        binding.deleteButton.setOnClickListener {
            callback.onDelete(presetItem)
            dismiss()
        }

        binding.swapButton.setOnClickListener {
            callback.onSwap(presetItem)
            dismiss()
        }
    }
}