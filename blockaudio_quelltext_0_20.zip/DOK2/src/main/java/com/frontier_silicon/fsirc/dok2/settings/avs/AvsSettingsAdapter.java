package com.frontier_silicon.fsirc.dok2.settings.avs;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.settings.SettingsItemModel;
import com.frontier_silicon.fsirc.dok2.settings.SettingsType;

import java.util.List;

/**
 * Created by mnisipeanu on 05/06/2018.
 */

public class AvsSettingsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<SettingsItemModel> items;
    private OnTouchListener listener;

    public interface OnTouchListener {
        void onLayoutClick(SettingsItemModel item);
    }

    public AvsSettingsAdapter(List<SettingsItemModel> menuItems, OnTouchListener listener) {
        this.listener = listener;
        this.items = menuItems;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tv;
        private ImageView rightIcon;
        private ImageView radioIcon;
        private ImageView radioNotAvailableIcon;
        private CompoundButton compoundButton;

        public ViewHolder(View itemView) {
            super(itemView);

            tv = itemView.findViewById(R.id.text1);
            rightIcon = itemView.findViewById(R.id.rightImageIcon);
            radioIcon = itemView.findViewById(R.id.imageRadioIcon);
            radioNotAvailableIcon = itemView.findViewById(R.id.imageNotAvailable);
            compoundButton = itemView.findViewById(R.id.compoundButton);
        }

        public void setRow(SettingsItemModel item, final int position) {
            if (item.mType != SettingsType.DIVIDER) {

                tv.setText(item.mName);

                if (item.mShowChevron) {
                    rightIcon.setVisibility(View.VISIBLE);
                } else {
                    rightIcon.setVisibility(View.GONE);
                }

                compoundButton.setVisibility(View.GONE);
                radioIcon.setVisibility(View.GONE);
                radioNotAvailableIcon.setVisibility(View.GONE);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onLayoutClick(item);
                    }
                });
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View v;
        v = inflater.inflate(R.layout.settings_list_item, parent, false);
        viewHolder = new ViewHolder(v);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        SettingsItemModel cat = items.get(position);

        ((ViewHolder) holder).setRow(cat, position);
    }
}
