package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.view.View;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;

/**
 * Created by adanaila on 10/31/2016.
 */

public class BrowseFormButtonViewModel extends BrowseFormItemBaseViewModel {
    private FormManager manager;

    public BrowseFormButtonViewModel(int position, FormItem item, FormManager manag) {
        super(position, item);
        this.manager = manag;
    }

    public void onButtonClicked(View view) {
        if(manager.sendFormData(mFormItemBase.getKey()))
        {
            manager.sendDataCompletedEvent();
        }
        else
        {
            manager.sendValidationFailedEvent();
        }
    }
}
