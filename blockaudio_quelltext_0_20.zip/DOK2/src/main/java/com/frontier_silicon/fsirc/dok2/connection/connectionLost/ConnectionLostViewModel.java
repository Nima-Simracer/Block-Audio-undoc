package com.frontier_silicon.fsirc.dok2.connection.connectionLost;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoControllerName;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.connection.ConnectionManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

/**
 * Created by lsuhov on 08/12/15.
 */
public class ConnectionLostViewModel implements IConnectionStateListener, IRadioDiscoveryListener {

    public ObservableField<String> controllerName = new ObservableField<>();
    public ObservableField<String> disconnectedMessage = new ObservableField<>();
    public ObservableBoolean isInvalidSession = new ObservableBoolean(false);
    public ObservableBoolean connecting = new ObservableBoolean(false);

    private Activity mActivity;

    public ConnectionLostViewModel(Activity activity) {
        mActivity = activity;

        init();
    }

    private void init() {
        ConnectionState connectionState = ConnectionStateUtil.getInstance().getConnectionState();
        if (connectionState == ConnectionState.INVALID_SESSION) {
            retrieveLastControllerName();
        } else {
          showDisconnectedMessage();
        }
    }

    private void showDisconnectedMessage() {
        isInvalidSession.set(false);
        disconnectedMessage.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.disconnected_error_message, true));
    }

    private void showInvalidSessionMessage() {
        isInvalidSession.set(true);
        disconnectedMessage.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.reconnect_dlg_msg, true));
    }

    public void onResume() {

        ConnectionStateUtil.getInstance().resetDisconnectState();
        ConnectionStateUtil.getInstance().addListener(this, true);

        NetRemoteManager.getInstance().addRadioDiscoveryListener(this);
    }

    public void onPause() {
        ConnectionStateUtil.getInstance().removeListener(this);
        NetRemoteManager.getInstance().removeRadioDiscoveryListener(this);
    }

    public void retrieveLastControllerName() {
        Radio radio = ConnectionManager.getInstance().getLastConnectedDevice();
        if (radio == null) {
            return;
        }

        radio.getNode(NodeSysInfoControllerName.class, new IGetNodeCallback() {
            @Override
            public void getNodeResult(NodeInfo node) {
                NodeSysInfoControllerName controllerNameNode = (NodeSysInfoControllerName)node;
                controllerName.set(controllerNameNode.getValue());
                if (controllerName.get().isEmpty()) {
                    showDisconnectedMessage();
                } else {
                    showInvalidSessionMessage();
                }
            }

            @Override
            public void getNodeError(Class nodeType, NodeErrorResponse error) {
                controllerName.set("");
                showDisconnectedMessage();
            }
        });
    }

    public void onReconnectClicked(View v) {
        ConnectionManager.getInstance().connectToLastConnectedDevice();

        connecting.set(true);
    }

    public void onShowHomeClicked(View v) {
        goToMyHome();
    }

    private void goToMyHome() {
        NavigationHelper.goToHomeAndClearActivityStack(mActivity);
    }

    @Override
    public void onStateUpdate(final ConnectionState newState) {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (DokUiUtils.isDestroyed(mActivity)) {
                    return;
                }

                switch (newState) {
                    case CONNECTED_TO_RADIO:
                        mActivity.onBackPressed();
                        break;

                    default:
                        break;
                }
            }
        });
    }


    @Override
    public void onRadioFound(Radio radio) {}

    @Override
    public void onRadioLost(final Radio radio, boolean rescanInProgress) {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        Radio disconnectedRadio = ConnectionManager.getInstance().getLastConnectedDevice();
        if (disconnectedRadio == null || radio.equals(disconnectedRadio)) {

            mActivity.runOnUiThread(() -> {
                if (DokUiUtils.isDestroyed(mActivity)) {
                    return;
                }

                goToMyHome();
            });
        }
    }

    @Override
    public void onRadioUpdated(Radio radio) {}

    public void dispose() {
        mActivity = null;
    }
}
