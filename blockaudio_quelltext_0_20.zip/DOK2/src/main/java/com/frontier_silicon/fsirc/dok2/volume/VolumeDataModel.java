package com.frontier_silicon.fsirc.dok2.volume;

import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableInt;

/**
 * Created by cvladu on 24/04/2017.
 */

public class VolumeDataModel {
    public ObservableInt volume = new ObservableInt(0);
    public ObservableBoolean muted = new ObservableBoolean(false);
}

