package com.frontier_silicon.fsirc.dok2.browse.bluetooth.settings;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.BluetoothSettingsActivityBinding;

/**
 * Warning: This class is not supporting other speakers than the connected one
 */
public class BluetoothSettingsActivity extends UndokActivityBase {

    private BluetoothSettingsActivityBinding mBinding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.bluetooth_settings_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.bluetooth_settings);

        setupControls();
    }

    protected void setupControls() {

        BluetoothArrayAdapter adapter = new BluetoothArrayAdapter(this, R.id.bluetoothDeviceList);
        mBinding.bluetoothDeviceList.setAdapter(adapter);

        mBinding.setViewModel(new BluetoothSettingsViewModel(getLifecycle(), adapter));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mBinding = null;
    }
}
