package com.frontier_silicon.fsirc.dok2.presets.di

import androidx.recyclerview.widget.ItemTouchHelper
import com.frontier_silicon.fsirc.dok2.presets.IPresetsControlListener
import com.frontier_silicon.fsirc.dok2.presets.widget.PresetItemTouchHelperCallback
import com.frontier_silicon.fsirc.dok2.presets.widget.PresetsRecyclerViewAdapter
import dagger.Module
import dagger.Provides

@Module
 class PresetsModule {

    @Provides
    fun provideItemTouchHelper(callback: ItemTouchHelper.Callback): ItemTouchHelper {
        return ItemTouchHelper(callback)
    }

     @Provides
    fun providePresetItemTouchCallback(adapter: PresetsRecyclerViewAdapter): ItemTouchHelper.Callback {
        return PresetItemTouchHelperCallback(adapter)
    }

    @PresetsScope
     @Provides
    fun providePresetsRecyclerViewAdapter(listener: IPresetsControlListener): PresetsRecyclerViewAdapter {
        return PresetsRecyclerViewAdapter(listener)
    }
}