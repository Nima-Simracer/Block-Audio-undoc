package com.frontier_silicon.fsirc.dok2.nowPlaying;

import android.graphics.Bitmap;

/**
 * Created by lsuhov on 28/11/2016.
 */

public interface IAlbumPostprocessListener {
    void onPostprocessedAlbum(Bitmap postprocessedAlbum, Bitmap blurredAlbum);
}
