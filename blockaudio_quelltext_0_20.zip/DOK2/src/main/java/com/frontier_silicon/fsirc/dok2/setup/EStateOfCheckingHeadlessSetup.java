package com.frontier_silicon.fsirc.dok2.setup;

public enum EStateOfCheckingHeadlessSetup {
	None,
	ConfiguringAudioDevice,
	ConfiguringWithWPS,
	NodesWereNotSetCorrectly,
	ConnectingToSelectedWiFi,
	WaitOnConnectingWithWPS,
	CouldntConnectToWiFi,
	SearchingTheAudioDevice,
	CouldntFindDeviceWithSSDP,
	SuccesfullSetup
}
