package com.frontier_silicon.fsirc.dok2.settings;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.settings.groupedSpeakers.TransportOptimisationSetterTask;

import java.util.List;

public class SettingsArrayAdapter extends ArrayAdapter<SettingsItemModel> {

    public SettingsArrayAdapter(Context context, int resource, int textViewResourceId, List<SettingsItemModel> objects) {
		super(context, resource, textViewResourceId, objects);
    }

    @SuppressLint("InflateParams")
	@Override
	public View getView(int position, View v, ViewGroup parent) {
        Context context = getContext();
        if (context == null)
            return null;

		LayoutInflater li = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		final SettingsItemModel item = getItem(position);

		if (item.mType != SettingsType.DIVIDER) {

			v = li.inflate(R.layout.settings_list_item, null);

			String text = item.mName;

			TextView tv = (TextView) v.findViewById(R.id.text1);
			tv.setText(text);

			ImageView rightIcon = (ImageView) v.findViewById(R.id.rightImageIcon);

			if (item.mShowChevron) {
                rightIcon.setVisibility(View.VISIBLE);
            } else {
                rightIcon.setVisibility(View.GONE);
            }

			ImageView radioIcon = (ImageView) v.findViewById(R.id.imageRadioIcon);
			updateRadioIcon(item, radioIcon);

			ImageView radioNotAvailableIcon = (ImageView) v.findViewById(R.id.imageNotAvailable);
			updateRadioNotAvailableIcon(item, radioNotAvailableIcon);

            CompoundButton compoundButton = (CompoundButton) v.findViewById(R.id.compoundButton);
            updateCheckableButton(item, compoundButton);
		} else {
			v = li.inflate(R.layout.group_header_list_item, null);

			String text = item.mName;

			TextView tv = (TextView) v.findViewById(R.id.text1);
			tv.setText(text);
		}

		return v;
	}

    private void updateCheckableButton(final SettingsItemModel settingsItemModel, CompoundButton compoundButton) {
        compoundButton.setVisibility(settingsItemModel.mIsCheckable ? View.VISIBLE : View.GONE);

        if (settingsItemModel.mIsCheckable) {
            compoundButton.setChecked(settingsItemModel.mCheckValue);
        }

        compoundButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Context context = getContext();
                if (context == null)
                    return;

                if (settingsItemModel.mType == SettingsType.TRANSPORT_OPTIMISATION) {
                    TransportOptimisationSetterTask task = new TransportOptimisationSetterTask(context, isChecked);
                    TaskHelper.execute(task);
				}
            }
        });
    }


    private void updateRadioIcon(SettingsItemModel item, final ImageView radioIconImage) {

		if (item.mType == SettingsType.AUDIO_DEVICE) {

			Radio radio = NetRemoteManager.getInstance().getRadio(item.mRadioUDN);
			if (radio != null && radio.getImageURL() != null) {

                String bitmapURL = radio.getImageURL().toString();

                Glide.with(getContext())
                        .asBitmap()
                        .load(bitmapURL)
                        .into(new SimpleTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                radioIconImage.setImageBitmap(resource);
                                radioIconImage.setVisibility(View.VISIBLE);
                            }
                        });

			} else {
                radioIconImage.setVisibility(View.GONE);
            }
		} else {
			radioIconImage.setVisibility(View.GONE);
		}
	}

	private void updateRadioNotAvailableIcon(SettingsItemModel item, ImageView radioNotAvailableImageView) {
		if (SettingsUtil.isRadioAvailable(item)) {
			radioNotAvailableImageView.setVisibility(View.GONE);
		} else {
			radioNotAvailableImageView.setVisibility(View.VISIBLE);
		}
	}
}
