package com.frontier_silicon.fsirc.dok2;

import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnClickListener;
import android.preference.PreferenceManager;
import androidx.core.app.ShareCompat;
import androidx.appcompat.app.AlertDialog;

public class UserFeedbackForm {

    private static UserFeedbackForm mInstance;
	private long SHOW_FEEDBACK_DLG_TIME_MS = 10 * 60_000;
	private static final String EMAIL_MSG_TYPE = "message/rfc822";
	
	private static final String PREF_SHOW_FEEDBACK_FORM = "PREF_SHOW_FEEDBACK_FORM";

    private long mCallbackId;

	private String mEmailAddress;
	private Activity mParentActivity;
    private boolean mActivityIsPaused = true;

	private UserFeedbackForm() {
        mCallbackId = DelayedPostsManager.getInstance().registerNewCallbackID();
    }

    public static UserFeedbackForm getInstance() {
        if (mInstance == null) {
            mInstance = new UserFeedbackForm();
        }

        return mInstance;
    }

    // This function is called each time the user enters home screen. This means that the timer will
    // be reset each time at that point.
	public void init(Activity parentActivity, String emailAddress) {
		mParentActivity = parentActivity;
		mEmailAddress = emailAddress;
        mActivityIsPaused = false;
		
		if (canShowFeedbackFormDlg()) {
			startTimer();
		}
	}

	public void setActivity(Activity activity) {
        mParentActivity = activity;
        mActivityIsPaused = false;
    }

    public void setPaused() {
        mActivityIsPaused = true;
    }

	public void cleanup() {
		stopTimer();

        mParentActivity = null;
	}
	
	private void startTimer() {
		DelayedPostsManager.getInstance().postDelayed(new FeedbackFormRunnable(), mCallbackId, SHOW_FEEDBACK_DLG_TIME_MS);
	}

	private void stopTimer() {
		DelayedPostsManager.getInstance().cancelCallback(mCallbackId);
	}

    private boolean canShowFeedbackFormDlg() {

        if (DokUiUtils.isDestroyed(mParentActivity) || mActivityIsPaused) {
            return false;
        }

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mParentActivity);
        return prefs.getBoolean(PREF_SHOW_FEEDBACK_FORM, true);
    }

    private class FeedbackFormRunnable implements Runnable {
        @Override
        public void run() {
            if (canShowFeedbackFormDlg()) {
                showFeedbackDlg(mParentActivity);
            }
        }
    }


    private void showFeedbackDlg(final Activity parentActivity) {
		if (DokUiUtils.isDestroyed(parentActivity) || mActivityIsPaused) {
            return;
        }

        parentActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String dialogKey = "feedback_form_dlg";
                if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, parentActivity))
                    return;

                AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(parentActivity);

                builder.setTitle(parentActivity.getString(R.string.feedback_title_dlg));
                builder.setMessage(parentActivity.getString(R.string.feedback_msg_dlg));

                builder.setPositiveButton(android.R.string.ok, new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        openFeedbackEmail(mParentActivity, mEmailAddress);
                    }
                });

                builder.setNeutralButton(R.string.later, new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        showLater();
                    }
                });

                builder.setNegativeButton(R.string.dont_bother_me_again, new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        setDontBotherAgainFeedbackForm(true);
                    }
                });

                AlertDialog dlg = builder.create();
                DialogsHolder.addDialogToCollection(dialogKey, dlg);
                dlg.show();
            }
        });
	}

	private void showLater() {
		// double the time between notif.
        SHOW_FEEDBACK_DLG_TIME_MS = SHOW_FEEDBACK_DLG_TIME_MS * 2;
		
		stopTimer();
		startTimer();
	}
	
	private void openFeedbackEmail(Activity parentActivity, String emailAddressRecipient) {
		ShareCompat.IntentBuilder builder = ShareCompat.IntentBuilder.from(parentActivity);
		builder.setType(EMAIL_MSG_TYPE);
		builder.addEmailTo(emailAddressRecipient);
		builder.setSubject(parentActivity.getString(R.string.feedback_email_subject));
		builder.setChooserTitle(parentActivity.getString(R.string.feedback_chooser_title));
		builder.startChooser();
		
		// don't bother user again after he sent feedback
		setDontBotherAgainFeedbackForm(true);
	}
	
	private void setDontBotherAgainFeedbackForm(boolean dontShowAgain) {
		if (mParentActivity != null) {
			SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mParentActivity);
			SharedPreferences.Editor prefEditor = prefs.edit();
			prefEditor.putBoolean(PREF_SHOW_FEEDBACK_FORM, !dontShowAgain);	
			prefEditor.commit();
		}
	}
}
