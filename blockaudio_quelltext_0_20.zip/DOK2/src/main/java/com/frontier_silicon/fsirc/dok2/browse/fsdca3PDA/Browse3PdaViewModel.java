package com.frontier_silicon.fsirc.dok2.browse.fsdca3PDA;

import android.content.Intent;
import android.net.Uri;
import android.view.View;

import com.frontier_silicon.components.common.ExternalAppsOpener;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;

public class Browse3PdaViewModel {

    public void openAlexaApp(View view) {
        ExternalAppsOpener.openAlexaApp(MainApplication.getCurrentActivity());
    }

    public void onHowToUseClicked(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.amazon.com/alexa"));
        MainApplication.getCurrentActivity().startActivity(browserIntent);
    }
}
