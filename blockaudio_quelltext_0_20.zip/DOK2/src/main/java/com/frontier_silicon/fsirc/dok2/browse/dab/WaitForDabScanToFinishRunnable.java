package com.frontier_silicon.fsirc.dok2.browse.dab;

import com.frontier_silicon.NetRemoteLib.Node.NodeNavActionDabPrune;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavActionDabScan;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.setup.ScanAvailableWiFiNetworksTask;

public class WaitForDabScanToFinishRunnable implements Runnable {
    private final int MAX_WAIT_FOR_DAB_SCAN = 60;

    private Radio mRadio;

    public WaitForDabScanToFinishRunnable(Radio radio) {
        mRadio = radio;
    }

    @Override
    public void run() {
        NodeNavActionDabScan scanResult = waitForScanToFinish(mRadio);

        if (scanResult == null || scanResult.getValueEnum() != NodeNavActionDabScan.Ord.IDLE) {
            return;
        }

        if (mRadio != null) {
            mRadio.setNode(new NodeNavActionDabPrune(NodeNavActionDabPrune.Ord.PRUNE), true);
        }
    }


    private NodeNavActionDabScan waitForScanToFinish(Radio radio) {
        if (radio == null) {
            return null;
        }

        NodeNavActionDabScan scanResult = (NodeNavActionDabScan) radio.nodeSyncGetter(NodeNavActionDabScan.class, true).get();
        int count = 0;

        while (scanResult != null && scanResult.getValueEnum() == NodeNavActionDabScan.Ord.SCAN && count < MAX_WAIT_FOR_DAB_SCAN) {

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (radio == null) {
                return null;
            }

            scanResult = (NodeNavActionDabScan) radio.nodeSyncGetter(NodeNavActionDabScan.class, true).get();

            count ++;
        }

        return scanResult;
    }
}
