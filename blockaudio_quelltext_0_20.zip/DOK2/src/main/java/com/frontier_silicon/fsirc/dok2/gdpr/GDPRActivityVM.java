package com.frontier_silicon.fsirc.dok2.gdpr;

import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.home.HomeActivity;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;

/**
 * Created by nbalazs on 18/04/2018.
 */

public class GDPRActivityVM {

    private GDPRActivity mActivity;

    GDPRActivityVM(GDPRActivity activity) {
        mActivity = activity;
    }

    public final void onAcceptAndContinuePressed() {
        GDPRVersionManager.onLatestVersionAccepted();
        sendAnalyticsMessage();
        NavigationHelper.goToActivityClearingCurrentStack(mActivity, HomeActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    private void sendAnalyticsMessage() {
        if (UndokPreferences.getInstance().shouldSendInstallEvent()) {
            AnalyticsSender.sendInstallEvent();
        }
    }
}
