package com.frontier_silicon.fsirc.dok2.util;

import android.app.Activity;
import android.widget.EditText;

import com.frontier_silicon.components.common.ErrorSanitizerMessageType;
import com.frontier_silicon.fsirc.dok2.R;

/**
 * Created by lsuhov on 13/09/2017.
 */

public class FriendlyNameSanitizerErrorHandler {
    private int mMaxLengthOfFriendlyName;

    public FriendlyNameSanitizerErrorHandler(int maxLengthOfFriendlyName) {
        mMaxLengthOfFriendlyName = maxLengthOfFriendlyName;
    }

    public void handleMessageErrorType(Activity activity, ErrorSanitizerMessageType messageType, EditText editText) {
        switch (messageType) {
            case EmptyName:
                editText.setError(activity.getString(R.string.empty_friendly_name_not_allowed));
                break;
            case BiggerThanSupportedLimit:
                editText.setError(activity.getString(R.string.length_limit_of_friendly_name_was_exceeded, mMaxLengthOfFriendlyName));
                break;
            case CharacterNotAllowed:
                editText.setError(activity.getString(R.string.invalid_chars_were_entered_message));
                break;
            case WhiteSpaceAtBeginning:
                editText.setError(activity.getString(R.string.whitespace_not_allowed));
                break;
            case MultipleWhiteSpaces:
                editText.setError(activity.getString(R.string.multiple_whitespaces_not_allowed));
                break;
        }
    }
}
