package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.recyclerview.widget.RecyclerView;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.IBrowseItemModelRetrieveListener;

/**
 * Created by lsuhov on 21/10/2016.
 */

public class BrowseItemNotLoadedViewModel implements IBrowseItemModelRetrieveListener {

    int mPosition;
    RecyclerView.Adapter mAdapter;
    BrowseManager mBrowseManager;

    public BrowseItemNotLoadedViewModel(){}

    public BrowseItemNotLoadedViewModel(int position, RecyclerView.Adapter adapter, BrowseManager manager) {
        mPosition = position;
        mAdapter = adapter;
        this.mBrowseManager = manager;

        init();
    }

    private void init() {
        mBrowseManager.getBrowseItemModelAsync(mPosition, this);
    }


    @Override
    public void onBrowseItemModelRetrieved(BrowseItemModel itemModel) {
        if (mAdapter != null) {
            NetRemote.getMainThreadExecutor().execute(() -> {
                if (mAdapter != null) {
                    mAdapter.notifyItemChanged(mPosition);
                }
            });
        }
    }

    public void dispose() {
        mAdapter = null;
    }
}
