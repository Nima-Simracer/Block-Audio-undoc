package com.frontier_silicon.fsirc.dok2.setup;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AlertDialog;

import com.frontier_silicon.NetRemoteLib.Radio.ConnectionErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.IConnectionCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.listOfAP.ListOfAccessPointActivity;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.manualAPSelection.ManualAccessPointSelectionActivity;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

/**
 * Created by nbalazs on 12/04/2018.
 */

public class SetupWithRedirectionBase implements IConnectionCallback, LifecycleObserver {

    private Lifecycle mLifeCycle;
    private Activity mActivity;

    public  SetupWithRedirectionBase(Activity activity, Lifecycle lifeCycle) {
        mLifeCycle = lifeCycle;
        mActivity = activity;
        mLifeCycle.addObserver(this);
    }

    protected void enableRadioConnectionCallback() {

        if (!SetupManager.getInstance().isConnectedToRadio()) {
            goToConnectToHeadlessPageIfNeeded();
        }

        SetupManager.getInstance().registerForRadioConnectionEvents(this);
    }

    @Override
    public void onConnectionSuccess(Radio radio) {
        // Nothing to do here
    }

    @Override
    public void onConnectionError(Radio radio, ConnectionErrorResponse error) {
        // Nothing to do here
    }

    @Override
    public void onDisconnected(Radio radio, ConnectionErrorResponse error) {
        mActivity.runOnUiThread(this::showRadioConnectionLostMessageDialog);
    }

    private void showRadioConnectionLostMessageDialog() {
        String dialogKey = "hui_connection_lost";

        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, mActivity))
            return;

        String radioName = SetupManager.getInstance().getFriendlyName();

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mActivity); // TODO: Add the style later
        builder.setTitle(R.string.connection_lost_title);
        builder.setMessage(mActivity.getString(R.string.connection_lost_description, radioName));
        builder.setPositiveButton(android.R.string.ok, (dialog, which) -> goToConnectToHeadlessPageIfNeeded());

        Dialog mConnectionLostDialog = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, mConnectionLostDialog);

        mConnectionLostDialog.show();
    }

    private void goToConnectToHeadlessPageIfNeeded() {
        if (PermissionsUtil.requestLocationPermission(mActivity, false)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NavigationHelper.goToExistingActivityAndClearBackStack(mActivity, ManualAccessPointSelectionActivity.class, NavigationHelper.AnimationType.SlideToLeft);
            } else {
                NavigationHelper.goToExistingActivityAndClearBackStack(mActivity, ListOfAccessPointActivity.class, NavigationHelper.AnimationType.SlideToLeft);
            }
        } else if (isPermissionDeniedByUserForApiLowerThanOreo()) {
            NavigationHelper.goToExistingActivityAndClearBackStack(mActivity, ManualAccessPointSelectionActivity.class, NavigationHelper.AnimationType.SlideToLeft);
        }
    }

    private boolean isPermissionDeniedByUserForApiLowerThanOreo() {
        return ActivityCompat.shouldShowRequestPermissionRationale(mActivity, Manifest.permission.ACCESS_FINE_LOCATION) && Build.VERSION.SDK_INT < Build.VERSION_CODES.O;
    }


    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    protected void disableRadioConnectionCallback() {
        SetupManager.getInstance().removeFromRadioConnectionEvents(this);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void dispose() {
        mActivity = null;
        mLifeCycle = null;
    }

}
