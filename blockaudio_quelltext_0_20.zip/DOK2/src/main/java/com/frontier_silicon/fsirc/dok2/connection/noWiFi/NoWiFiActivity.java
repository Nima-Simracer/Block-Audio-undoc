package com.frontier_silicon.fsirc.dok2.connection.noWiFi;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.NoWifiActivityBinding;


public class NoWiFiActivity extends UndokActivityBase {

    private NoWifiActivityBinding mBinding;
    private NoWiFiViewModel mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.no_wifi_activity);

        mViewModel = new NoWiFiViewModel(this);
        mBinding.setViewModel(mViewModel);

        setupAppBar();
        setTitle(R.string.no_wifi);

        disableNoWiFiWatcher();
    }

    @Override
    public void onResume() {
        super.onResume();

        mViewModel.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();

        mViewModel.onPause();
    }

    @Override
    protected void onDestroy() {
        if (mBinding != null) {
            mBinding.setViewModel(null);
        }

        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }

        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}
