package com.frontier_silicon.fsirc.dok2.connection;

/**
 * Created by lsuhov on 03/03/2017.
 */
public interface IConnectToSpeakerOrGroup {
    void onConnectedToSpeakerOrGroup(boolean connectedOk, boolean isGroup);
}
