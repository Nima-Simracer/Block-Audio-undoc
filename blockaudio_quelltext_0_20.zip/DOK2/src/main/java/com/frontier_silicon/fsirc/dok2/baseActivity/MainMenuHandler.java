package com.frontier_silicon.fsirc.dok2.baseActivity;

import android.app.Activity;

import androidx.databinding.Observable;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.core.content.ContextCompat;

import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomRescanUtil;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.settings.general.GeneralSettingsActivity;
import com.frontier_silicon.fsirc.dok2.settings.groupedSpeakers.GroupedSpeakersSettingsActivity;
import com.frontier_silicon.fsirc.dok2.settings.speaker.SpeakerSettingsActivity;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

/**
 * Created by lsuhov on 23/05/2017.
 */

public class MainMenuHandler {

    /**
     * We need to show Settings of current connected speaker in @ConnectedSpeakerActivity
     */
    public static final int SHOW_DEVICE_SETTINGS_BIT = 1;

    private Activity mActivity;
    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;
    private int mMenuOptions = 0;

    public MainMenuHandler(Activity activity, int menuOptions) {
        mActivity = activity;
        mMenuOptions = menuOptions;
    }

    public void registerSpeakerDataListener() {
        if (mPropertyChangedCallback == null) {
            mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable observable, int i) {
                    if (DokUiUtils.isDestroyed(mActivity)) {
                        return;
                    }

                    mActivity.runOnUiThread(() -> {
                        if (DokUiUtils.isDestroyed(mActivity)) {
                            return;
                        }

                        mActivity.invalidateOptionsMenu();
                    });
                }
            };
        }

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.isInStandby.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    public void unregisterSpeakerDataListener() {
        if (mPropertyChangedCallback == null) {
            return;
        }

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.isInStandby.removeOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    public void onPrepareOptionsMenu(Menu menu) {
        if (mActivity == null) {
            //It seems that this can be called asynchronously. So it's possible that the activity is already destroyed.
            return;
        }

        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();

        boolean isSpeakerConnected = NetRemoteManager.getInstance().checkConnection(currentRadio);

        boolean isStandby = false;
        if (isSpeakerConnected) {
            isStandby = currentRadio.isInStandby();
        }

        MenuItem rescanMenuItem = menu.findItem(R.id.action_rescan);
        DokUiUtils.setTintToActionMenu(mActivity, rescanMenuItem);

        MenuItem standbyIconMenuItem = menu.findItem(R.id.action_standby_icon);
        if ((standbyIconMenuItem != null) && (mActivity != null)) {
            standbyIconMenuItem.setVisible(isSpeakerConnected);
            Drawable drawable;
            if (isStandby) {
                drawable = ContextCompat.getDrawable(mActivity, R.drawable.ic_standby_on);
            } else {
                drawable = ContextCompat.getDrawable(mActivity, R.drawable.ic_standby_off);
            }

            standbyIconMenuItem.setIcon(drawable);
            DokUiUtils.setTintToActionMenu(mActivity, standbyIconMenuItem);
        }

        MenuItem appSettingsMenuItem = menu.findItem(R.id.action_app_settings);
        DokUiUtils.setTintToActionMenu(mActivity, appSettingsMenuItem);

        MenuItem addRadioByIp = menu.findItem(R.id.action_add_radio_by_ip);
        int color = GuiUtils.getColorFromAttribute(mActivity, R.attr.navigationbar_icon_color);
        if (addRadioByIp != null) {
            addRadioByIp.getIcon().setColorFilter(color, PorterDuff.Mode.SRC_IN);
        }

        MenuItem speakerSettingsMenuItem = menu.findItem(R.id.action_speaker_settings);
        if (speakerSettingsMenuItem != null) {

            if (isSpeakerConnected && isOptionFlagSet(SHOW_DEVICE_SETTINGS_BIT)) {

                if (appSettingsMenuItem != null) {
                    appSettingsMenuItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                }

                String currentName = MultiroomGroupManager.getInstance().getCurrentNameOfGroupOrSpeaker();

                if (!TextUtils.isEmpty(currentName)) {

                    int maxNameSize = 15;
                    if (currentName.length() > maxNameSize) {
                        currentName = currentName.substring(0, maxNameSize);

                        currentName += "...";
                    }

                    speakerSettingsMenuItem.setTitle(mActivity.getString(R.string.speaker_settings, currentName));
                    speakerSettingsMenuItem.setVisible(true);
                }
            } else {
                speakerSettingsMenuItem.setVisible(false);
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_app_settings:
                showApplicationSettings();
                return true;

            case R.id.action_speaker_settings:
                showSpeakerSettings();
                return true;

            case R.id.action_standby_icon:
                powerCurrentDeviceOnOff();
                return true;

        }

        return false;
    }

    private void powerCurrentDeviceOnOff() {
        boolean isStandby = SpeakerDataManager.getInstance().isInStandby();
        SpeakerDataManager.getInstance().enablePower(isStandby);

        MultiroomRescanUtil.getInstance().rescanMultiroomDevicesAndGroups();
    }


    private void showApplicationSettings() {

        NavigationHelper.goToActivity(mActivity, GeneralSettingsActivity.class,
                NavigationHelper.AnimationType.SlideToLeft);
    }

    private void showSpeakerSettings() {
        if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {

            Bundle bundle = new Bundle();
            bundle.putString(NavigationHelper.GROUP_ID, MultiroomGroupManager.getInstance().getCurrentGroupId());

            NavigationHelper.goToActivity(mActivity, GroupedSpeakersSettingsActivity.class,
                    NavigationHelper.AnimationType.SlideToLeft, false, bundle);

        } else if (NetRemoteManager.getInstance().checkConnection()) {
            Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
            if (radio == null) {
                return;
            }

            Bundle bundle = new Bundle();
            bundle.putString(NavigationHelper.RADIO_UDN_ARG, radio.getUDN());

            NavigationHelper.goToActivity(mActivity, SpeakerSettingsActivity.class,
                    NavigationHelper.AnimationType.SlideToLeft, false, bundle);
        }
    }

    private boolean isOptionFlagSet(int optionFlag) {
        return (optionFlag & mMenuOptions) > 0;
    }

    public void dispose() {
        mActivity = null;
    }
}
