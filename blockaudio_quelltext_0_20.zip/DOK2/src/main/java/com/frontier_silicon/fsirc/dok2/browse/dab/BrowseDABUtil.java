package com.frontier_silicon.fsirc.dok2.browse.dab;

import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavActionDabScan;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.common.TaskHelper;

public class BrowseDABUtil {

	public BrowseDABUtil() {
	}
	
	public void checkScanActive(final IDABFrequencyListener listener) {

		if (NetRemoteManager.getInstance().checkConnection()) {
			RadioNodeUtil.getNodeFromRadioAsync(NetRemoteManager.getInstance().getCurrentRadio(), NodeNavActionDabScan.class, new RadioNodeUtil.INodeResultListener() {
				@Override
				public void onNodeResult(NodeInfo node) {
					boolean scanActive = false;
					NodeNavActionDabScan dabScanNode = (NodeNavActionDabScan) node;
					if (dabScanNode != null) {
						scanActive = (dabScanNode.getValueEnum() == NodeNavActionDabScan.Ord.SCAN);
					}

					if (listener != null) {
						listener.onDABScanUpdated(scanActive);
					}
				}
			});
		}
	}

	private boolean isScanning(Radio radio) {
		boolean isScanning = false;
		NodeNavActionDabScan dabScanNode = (NodeNavActionDabScan) radio.nodeSyncGetter(NodeNavActionDabScan.class).get();
		if (dabScanNode != null) {
			isScanning = (dabScanNode.getValueEnum() == NodeNavActionDabScan.Ord.SCAN);
		}

		return isScanning;
	}

	public void rescanDAB(IDABFrequencyListener listener) {
        RescanDABTask rescanDABTask = new RescanDABTask(listener);
        TaskHelper.execute(rescanDABTask);
	}

	private class RescanDABTask extends AsyncTask<Void, Integer, Boolean> {

		private final IDABFrequencyListener mListener;

		public RescanDABTask(IDABFrequencyListener listener) {
			mListener = listener;
		}

		@Override
		protected Boolean doInBackground(Void... arg0) {
			boolean result = false;
            Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
			if (NetRemoteManager.getInstance().checkConnection(radio)) {

				if (!isScanning(radio)) {
					publishProgress();

					RadioNavigationUtil.resetNavigationToRoot(radio);

                    radio.setNode(new NodeNavActionDabScan(NodeNavActionDabScan.Ord.SCAN), true);

					result = true;
				}
			}

			return result;
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			notifyScanStarted(true);
		}

		private void notifyScanStarted(boolean isScanning) {
			if (mListener != null) {
				mListener.onDABScanUpdated(isScanning);
			}
		}

		@Override
		protected void onPostExecute(Boolean result) {
			setPruneAfterScanFinished();
		}
	}

	public void setPruneAfterScanFinished() {
		Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
		Thread thread = new Thread(new WaitForDabScanToFinishRunnable(radio));
		thread.start();
	}

	public void stopDABRescan() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
		if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
			currentRadio.setNode(new NodeNavActionDabScan(NodeNavActionDabScan.Ord.IDLE), false);
		}
	}
}
