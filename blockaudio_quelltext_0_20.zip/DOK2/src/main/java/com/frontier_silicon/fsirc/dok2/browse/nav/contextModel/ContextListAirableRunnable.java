package com.frontier_silicon.fsirc.dok2.browse.nav.contextModel;

import com.frontier_silicon.NetRemoteLib.Node.BaseNavContextList;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.UnifiedBrowseListItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextBrowseResultEvent;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 30/06/16.
 */

public class ContextListAirableRunnable implements Runnable {
    public interface IAirableRetrieverListener {
        void onNavPageRetrieved(List<UnifiedBrowseListItem> listItems, EIRNavigationResult numberOfItemsRetreivedResult);
    }

    private Radio mRadio;
    private IAirableRetrieverListener mListener;

    public ContextListAirableRunnable(Radio radio, IAirableRetrieverListener listener) {
        mRadio = radio;
        this.mListener = listener;
    }

    @Override
    public void run() {
        FsLogger.log("ListNavigationAirable runnable started ", LogLevel.Info);
        if (mRadio == null) {
            return;
        }

        String startKey = "" + -1;
        ArrayList<UnifiedBrowseListItem> navList = new ArrayList<>();
        ArrayList<BaseNavContextList.ListItem> returnedNavList = RadioNavigationUtil.getContextList(mRadio, startKey, true);

        EIRNavigationResult result = ContextBrowseManager.getInstance().retrieveTotalNumberOfItemsFromCurrentListSync(mRadio);

        if (returnedNavList == null) {
            returnedNavList = new ArrayList<>();
        }

        for (BaseNavContextList.ListItem li: returnedNavList) {
            navList.add(new UnifiedBrowseListItem(li));
        }

        if (mListener != null) {
            mListener.onNavPageRetrieved(navList, result);
        }

        dispose();
    }

    private void notifyError() {
        EventBus.getDefault().post(new ContextBrowseResultEvent(EIRNavigationResult.NavigationFailed));
    }

    private void dispose() {
        mRadio = null;
    }
}
