package com.frontier_silicon.fsirc.dok2.stereo;

import android.os.Bundle;

import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.components.stereo.StereoManager;

/**
 * Created by lsuhov on 06/08/2017.
 */

public class StereoBundleHelper {

    public static final String PRIMARY_SPEAKER_UDN = "PRIMARY_SPEAKER_UDN";
    public static final String SECONDARY_SPEAKER_UDN = "SECONDARY_SPEAKER_UDN";
    public static final String SYSTEM_ID = "SYSTEM_ID";

    public static StereoItemModel getPrimaryStereoItemModel(Bundle bundle) {
        String primarySpeakerUdn = bundle.getString(StereoBundleHelper.PRIMARY_SPEAKER_UDN);

        StereoItemModel stereoItemModel = StereoManager.getInstance().getStereoItemModel(primarySpeakerUdn);

        return stereoItemModel;
    }

    public static StereoItemModel getSecondaryStereoItemModel(Bundle bundle) {
        String secondarySpeakerUdn = bundle.getString(StereoBundleHelper.SECONDARY_SPEAKER_UDN);

        StereoItemModel stereoItemModel = StereoManager.getInstance().getStereoItemModel(secondarySpeakerUdn);

        return stereoItemModel;
    }

    public static StereoItemModel getSystemStereoItemModel(Bundle bundle) {
        String systemId = bundle.getString(StereoBundleHelper.SYSTEM_ID);

        StereoItemModel stereoItemModel = StereoManager.getInstance().getStereoSystem(systemId);

        return stereoItemModel;
    }

    public static boolean isStereoItemModelSpeakerValid(StereoItemModel stereoItemModel) {
        if (stereoItemModel == null) {
            return false;
        }

        if (stereoItemModel.deviceModel == null) {
            return false;
        }

        if (stereoItemModel.deviceModel.mRadio == null) {
            return false;
        }

        return true;
    }
}
