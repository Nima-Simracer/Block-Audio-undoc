package com.frontier_silicon.fsirc.dok2.browse.bluetooth;

import java.util.Map;

public interface IBrowseBluetoothNodesListener {
    void onNodesResult(Map<Class, Object> nodes);
}
