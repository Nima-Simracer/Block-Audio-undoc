package com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable;


import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.MessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.ContextBrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextShowLoadingProgressEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavRefreshEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ShowLoadingProgressEvent;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by adanaila on 10/4/2016.
 */

public class ContextMessageManager extends MessageManager{
    private static ContextMessageManager mInstance;
    private BrowseItemModel mSelectedNavItem;
    private int mSelectedNavItemPosition;

    public static ContextMessageManager getInstance() {
        if (mInstance == null) {
            mInstance = new ContextMessageManager();
        }
        return mInstance;
    }

    public void updateSelectedNavItem(int browseItemPosition, BrowseItemModel browseItemModel){
        this.mSelectedNavItem = browseItemModel;
        this.mSelectedNavItemPosition = browseItemPosition;
    }

    public BrowseItemModel getSelectedNavItem(){
        return this.mSelectedNavItem;
    }

    public int getSelectedNavItemPosition(){
        return this.mSelectedNavItemPosition;
    }

    private ContextMessageManager() {
        super();
    }

    @Override
    public void sendMessageData(long id) {
        EventBus.getDefault().post(new ContextShowLoadingProgressEvent());
        ContextBrowseManager.getInstance().CloseContextDialog(true);
    }

    public void refreshUnderlyingNavList(){
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        EventBus.getDefault().post(new ShowLoadingProgressEvent());

        ContextMessageCloseRunnable runnable = new ContextMessageCloseRunnable(radio, new ContextMessageCloseRunnable.IContextMessageDataSendListener() {
            @Override
            public void onContextMessageSend(final boolean result) {
                if(result) {
                    clearItemsLoaded();
                    //reload the nav.list and also close the dialog.
                    EventBus.getDefault().post(new NavRefreshEvent(-1));
                }else{
                }
            }
        });
        mThreadPoolExecutor.submit(runnable);
    }
}
