package com.frontier_silicon.fsirc.dok2.settings.general

class ScrollStateEvent {

}