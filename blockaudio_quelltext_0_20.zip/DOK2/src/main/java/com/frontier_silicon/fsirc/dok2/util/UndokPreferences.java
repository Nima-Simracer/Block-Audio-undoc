package com.frontier_silicon.fsirc.dok2.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Created by cvladu on 23/01/2018.
 */

public class UndokPreferences {
    private final String CHECK_FOR_UPDATE_ONCE_PER_DAY = "CHECK_FOR_UPDATE_ONCE_PER_DAY";
    private final String DISPLAY_AMAZON_INFO = "DISPLAY_AMAZON_INFO";
    private final String FSDCA_TOKEN = "FSDCA_TOKEN";
    private final String GDPR_VERSION_INT = "GDPR_VERSION_INT";
    private final String LAST_GDPR_VERSION_CHECK_TIME = "LAST_GDPR_VERSION_CHECK_TIME";
    private final String SEND_INSTALL_EVENT = "SEND_INSTALL_EVENT";
    private final String SCROLING_ENABLED= "SCROLLING_ENABLED";
    private final String INITIAL_TUTORIAL = "INITIAL_TUTORIAL";
    private final String PRESET_REORDER = "PRESET_REORDER";
    private final String NUMBER_OF_SPEAKERS_EVENT = "NUMBER_OF_SPEAKERS_EVENT";
    private final String MORE_THAN_ONE_VENICEX_DEVICES = "MORE_THAN_ONE_VENICEX_DEVICES";

    private final String OKTIV_PROMO_KEY = "OKTIV_PROMO_KEY";

    private final String NOTIFICATION_USAGE_KEY = "NOTIFICATION_USAGE_KEY";

    private final String uniqueCodeForVeniceX= "VeniceX";



    private Context mContext;
    private static UndokPreferences mInstance = null;

    private UndokPreferences() {
    }

    public static UndokPreferences getInstance() {
        if (mInstance == null) {
            mInstance = new UndokPreferences();
        }

        return mInstance;
    }

    public void init(Context context) {
        mContext = context;
    }

    public void setInstallEventSent() {
        SharedPreferences.Editor editor = getEditor();
        editor.putBoolean(SEND_INSTALL_EVENT, true).commit();
    }

    public boolean shouldSendInstallEvent() {
        SharedPreferences preferences = getPreferences();
        return !preferences.getBoolean(SEND_INSTALL_EVENT, false);
    }

    public void setCurrentTimeForUpdateChecking(Long value) {
        SharedPreferences.Editor editor = getEditor();
        editor.putLong(CHECK_FOR_UPDATE_ONCE_PER_DAY, value).commit();
    }

    public long getLastTimeForUpdateChecking() {
        SharedPreferences preferences = getPreferences();
        return preferences.getLong(CHECK_FOR_UPDATE_ONCE_PER_DAY, -1);
    }

    public void setFsDcaToken(String token) {
        getEditor().putString(FSDCA_TOKEN, token).commit();
    }

    public String getFsDcaToken() {
       return getPreferences().getString(FSDCA_TOKEN, null);
    }

    private SharedPreferences.Editor getEditor() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        return preferences.edit();
    }

    private SharedPreferences getPreferences() {
        return PreferenceManager.getDefaultSharedPreferences(mContext);
    }

    public void setCheckingDateForGDPRVersion(long value) {
        SharedPreferences.Editor editor = getEditor();
        editor.putLong(LAST_GDPR_VERSION_CHECK_TIME, value).apply();
    }

    public long getCheckingDateForGDPRVersion() {
        SharedPreferences preferences = getPreferences();
        return preferences.getLong(LAST_GDPR_VERSION_CHECK_TIME, 0);
    }

    public void setGDPRVersion(int value) {
        SharedPreferences.Editor editor = getEditor();
        editor.putInt(GDPR_VERSION_INT, value).apply();
    }

    public int getGDPRVersion() {
        SharedPreferences preferences = getPreferences();
        return preferences.getInt(GDPR_VERSION_INT, 0);
    }

    public void setScrollingEnabled(Boolean value) {
        SharedPreferences.Editor editor = getEditor();
        editor.putBoolean(SCROLING_ENABLED, value).apply();
    }

    public Boolean initialTutorialWasCompleted() {
        SharedPreferences preferences = getPreferences();
        return preferences.getBoolean(INITIAL_TUTORIAL, false);
    }

    public void setInitialTutorialCompleted(Boolean value) {
        SharedPreferences.Editor editor = getEditor();
        editor.putBoolean(INITIAL_TUTORIAL, value).apply();
    }

    public Boolean getPresetReorderDialogWasShown() {
        SharedPreferences preferences = getPreferences();
        return preferences.getBoolean(PRESET_REORDER, false);
    }

    public void setPresetReorderFeatureDialogShown(Boolean value) {
        SharedPreferences.Editor editor = getEditor();
        editor.putBoolean(PRESET_REORDER, value).apply();
    }

    public Boolean getScrollingEnabled() {
        SharedPreferences preferences = getPreferences();
        return preferences.getBoolean(SCROLING_ENABLED, true);
    }

    public void speakerTypeEventSent(String speakerSerialNumber) {
        SharedPreferences.Editor editor = getEditor();
        editor.putBoolean(speakerSerialNumber, true).apply();
    }

    public Boolean wasSpeakerTypeSent(String speakerSerialNumber) {
        SharedPreferences preferences = getPreferences();
        return preferences.getBoolean(speakerSerialNumber, false);
    }

    public void veniceXTypeEventSent(String speakerSerialNumber) {
        SharedPreferences.Editor editor = getEditor();
        editor.putBoolean(speakerSerialNumber+uniqueCodeForVeniceX, true).apply();
    }

    public Boolean wasVeniceXTypeSent(String speakerSerialNumber) {
        SharedPreferences preferences = getPreferences();
        return preferences.getBoolean(speakerSerialNumber+uniqueCodeForVeniceX, false);
    }

    public boolean wasNumberOfSpeakersSent() {
        SharedPreferences preferences = getPreferences();
        return preferences.getInt(NUMBER_OF_SPEAKERS_EVENT, -1) != -1;
    }

    public void setNumberOfSpeakersSent(int number) {
        SharedPreferences.Editor editor = getEditor();
        editor.putInt(NUMBER_OF_SPEAKERS_EVENT, number).apply();
    }

    public boolean wasMoreThanOneVeniceXDeviceSent() {
        SharedPreferences preferences = getPreferences();
        return preferences.getInt(MORE_THAN_ONE_VENICEX_DEVICES, -1) != -1;
    }

    public void setMoreThanOneVeniceXDevice(int number) {
        SharedPreferences.Editor editor = getEditor();
        editor.putInt(MORE_THAN_ONE_VENICEX_DEVICES, number).apply();
    }

    public boolean wasOktivPromoShowed() {
        SharedPreferences preferences = getPreferences();
        return preferences.getBoolean(OKTIV_PROMO_KEY, false);
    }

    public void setOktivPromoShowed() {
        SharedPreferences.Editor editor = getEditor();
        editor.putBoolean(OKTIV_PROMO_KEY, true).apply();
    }

    public boolean wasNotificationUsageSent() {
        SharedPreferences preferences = getPreferences();
        return preferences.getBoolean(NOTIFICATION_USAGE_KEY, false);
    }

    public void setNotificationUsageSent() {
        SharedPreferences.Editor editor = getEditor();
        editor.putBoolean(NOTIFICATION_USAGE_KEY, true).apply();
    }


    public void clearAllPreferences() {
        setCurrentTimeForUpdateChecking(-1L);
        setFsDcaToken(null);
        setCheckingDateForGDPRVersion(0);
        setGDPRVersion(0);
        setScrollingEnabled(true);
        setInitialTutorialCompleted(false);
        setPresetReorderFeatureDialogShown(false);
    }
}
