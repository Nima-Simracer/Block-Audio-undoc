package com.frontier_silicon.fsirc.dok2.setup.connectionType.wifi;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWlanScanList;

import java.util.List;

public interface IScanAvailableWifiNetworksListener {
	void onReceiveWiFiNetworks(List<NodeSysNetWlanScanList.ListItem> mAPList);
	void onProgress(int progress);
}
