package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.recyclerview.widget.RecyclerView;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates.BrowseListItemFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.ContextBrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates.ListItemViewHolder;
import com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates.RecyclerViewListItemDelegate;

public class ContextBrowseAdapter extends RecyclerView.Adapter<ListItemViewHolder> {

	public ContextBrowseAdapter() {}

    @Override
    public int getItemViewType(int position) {
        return BrowseListItemFactory.getItemViewType(position, BrowseManagerFactory.ContextBrowse);
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RecyclerViewListItemDelegate listItemDelegate = BrowseListItemFactory.getListItemDelegate(viewType,
                BrowseManagerFactory.ContextBrowse);

        return listItemDelegate.onCreateViewHolder(parent);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position) {

        holder.mRecyclerViewListItemDelegate.onBindViewHolder(holder, position, this);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {

        holder.mRecyclerViewListItemDelegate.onViewRecycled(holder);
    }

    @Override
    public int getItemCount() {
        return ContextBrowseManager.getInstance().getTotalCountForCurrentList();
    }
}
