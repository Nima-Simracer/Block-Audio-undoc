package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.databinding.ObservableField;
import android.view.View;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

/**
 * Created by hcostescu on 28/11/16.
 */

public class BrowseNavTrackNotAvailableViewModel{

    public ObservableField<String> name = new ObservableField<>();

    protected int mPosition;
    protected BrowseItemModel mNavBrowseItemModel;

    public BrowseNavTrackNotAvailableViewModel(int position, BrowseItemModel navBrowseItemModel) {
        mPosition = position;
        mNavBrowseItemModel = navBrowseItemModel;

        init();
    }

    protected void init() {
        name.set(mNavBrowseItemModel.getName());
    }

    public void onListItemClicked(View view) {

        androidx.appcompat.app.AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(view.getContext());
        builder
                .setMessage(R.string.text_track_not_available)
                .setNeutralButton("OK", null)
                .show();

    }

    public void dispose() {
        mNavBrowseItemModel = null;
    }
}
