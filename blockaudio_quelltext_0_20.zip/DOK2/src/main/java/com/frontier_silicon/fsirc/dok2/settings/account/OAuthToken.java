package com.frontier_silicon.fsirc.dok2.settings.account;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cvladu on 13/03/2018.
 */

public class OAuthToken {
    public String accessToken = "";
    public String refreshToken = "";
    public int expire = 0;
    public long created = 0;
    public List<String> scopes = new ArrayList<>();

    public boolean isExpired() {
        long time = System.currentTimeMillis();
        long delta = time / 1000 - created;

        if (delta > expire) {
            return true;
        }

        return false;
    }

    public void fromJson(String fsToken) throws JSONException {
        JSONObject jsonToken = new JSONObject(fsToken);

        accessToken = jsonToken.getString("access_token");
        refreshToken = jsonToken.getString("refresh_token");
        expire = jsonToken.getInt("expires_in");
        created = jsonToken.getInt("created_at");

        if (jsonToken.has("scope")) {
            scopes.add(jsonToken.getString("scope"));
        }
    }

    public JSONObject toJson() throws JSONException {
        JSONObject jsonToken = new JSONObject();

        jsonToken.put("access_token", accessToken);
        jsonToken.put("refresh_token", refreshToken);
        jsonToken.put("expires_in", expire);
        jsonToken.put("created_at", created);

        if (scopes.size() > 0) {
            jsonToken.put("scope", scopes.get(0));
        }

        return jsonToken;
    }
}



