package com.frontier_silicon.fsirc.dok2.settings.dateTime

import android.os.Bundle
import com.frontier_silicon.fsirc.dok2.NavigationHelper
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.RadioFromBundleExtractor
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase

class ClockSettingsActivity: UndokActivityBase() {

     override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.settings_date_time_activity)

        setupAppBar()
        enableUpNavigation()
        setTitle(R.string.date_time_settings)

        setupControls()
    }

    private fun setupControls() {
        val clockSettingsFragment = getSupportFragmentManager().findFragmentById(R.id.clockFragment) as ClockSettingsFragment

        if (clockSettingsFragment != null) {

            val bundle = getIntent().getExtras()
            val clientRadio = RadioFromBundleExtractor.extractRadio(bundle, ClockSettingsActivity::class.java)
            clockSettingsFragment.setUseRadio(clientRadio)

            initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack)
            if (bundle != null) {
                addUdnToSpeakerLostWatcher(bundle!!.getString(NavigationHelper.RADIO_UDN_ARG))
            }
        }
    }
}