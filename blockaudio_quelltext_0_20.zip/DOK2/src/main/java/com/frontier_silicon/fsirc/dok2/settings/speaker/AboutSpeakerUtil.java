package com.frontier_silicon.fsirc.dok2.settings.speaker;

import android.app.Activity;
import android.os.AsyncTask;
import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoFriendlyName;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoVersion;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWiredInterfaceEnable;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWiredMacAddress;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWlanConnectedSSID;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWlanMacAddress;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetWlanRssi;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.common.IButtonsResponseWithTextListener;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.fsirc.dok2.DialogsOpener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AboutSpeakerUtil {

	public AboutSpeakerUtil() {
	}

	public void getDeviceInfo(Radio radio, IAboutSpeakerListener listener) {
        AboutSpeakerUpdateTask updateDeviceInfoTask = new AboutSpeakerUpdateTask(radio, listener);
        TaskHelper.execute(updateDeviceInfoTask);
	}

	private List<AboutSpeakerModel> getRadioDeviceInfo(Radio radio) {
		List<AboutSpeakerModel> deviceInfoList = new ArrayList<>();

		AboutSpeakerModel deviceInfo = getDeviceInfoForGivenRadio(radio);

		if (deviceInfo != null) {
			deviceInfoList.add(deviceInfo);
		}

		return deviceInfoList;
	}

	private AboutSpeakerModel getDeviceInfoForGivenRadio(Radio radio) {
		AboutSpeakerModel deviceInfo = new AboutSpeakerModel();
		deviceInfo.mDeviceRadio = radio;
		
		if (radio != null) {
			deviceInfo.mIPAddress = radio.getIpAddress();
		}

		deviceInfo.mWifiNetworkStrength = AboutSpeakerModel.WiFiStrength.NONE;
		deviceInfo.mWifiNetworkStrengthPercent = 0;
		
		if (radio != null) {
			deviceInfo = getRadioAboutInformation(radio, deviceInfo);
		}
		
		return deviceInfo;
	}

	private AboutSpeakerModel getRadioAboutInformation(Radio radio, AboutSpeakerModel deviceInfo) {
		AboutSpeakerModel updatedDeviceInfo = new AboutSpeakerModel(deviceInfo);

		Map<Class, NodeInfo> nodesResults = radio.nodesSyncGetter(
                new Class[]{NodeSysInfoVersion.class, NodeSysNetWlanConnectedSSID.class,
                        NodeSysNetWlanRssi.class, NodeSysNetWlanMacAddress.class,
                        NodeSysNetWiredInterfaceEnable.class, NodeSysNetWiredMacAddress.class})
                .get();

		if (nodesResults != null) {
			return getAboutItemFromNodes(nodesResults, updatedDeviceInfo);
		} else {
			return updatedDeviceInfo;
		}
	}

	private AboutSpeakerModel getAboutItemFromNodes(Map<Class, NodeInfo> nodes, AboutSpeakerModel deviceInfo) {
		AboutSpeakerModel updatedDeviceInfo = new AboutSpeakerModel(deviceInfo);

		NodeSysInfoVersion softwareVersionNode = (NodeSysInfoVersion) nodes.get(NodeSysInfoVersion.class);
		NodeSysNetWlanConnectedSSID ssidNode = (NodeSysNetWlanConnectedSSID) nodes.get(NodeSysNetWlanConnectedSSID.class);
		NodeSysNetWlanRssi signalStrengthNode = (NodeSysNetWlanRssi) nodes.get(NodeSysNetWlanRssi.class);
		NodeSysNetWlanMacAddress macAddressNode = (NodeSysNetWlanMacAddress) nodes.get(NodeSysNetWlanMacAddress.class);

		NodeSysNetWiredInterfaceEnable wiredInterfaceEnabledNode = (NodeSysNetWiredInterfaceEnable) nodes.get(NodeSysNetWiredInterfaceEnable.class);
		NodeSysNetWiredMacAddress wiredMACAddressNode = (NodeSysNetWiredMacAddress) nodes.get(NodeSysNetWiredMacAddress.class);

		if (softwareVersionNode != null) {
			updatedDeviceInfo.mVersion = softwareVersionNode.getValue();
		}

		if (ssidNode != null) {
			String wifiNetworkName = RadioNodeUtil.getHumanReadableSSID(ssidNode.getValue());
			updatedDeviceInfo.mWifiNetworkName = wifiNetworkName;
		}

		if (signalStrengthNode != null) {
			long strengthValue = signalStrengthNode.getValue();

			if (strengthValue > AboutSpeakerModel.WiFiStrength.NONE.getValue() &&
					strengthValue <= AboutSpeakerModel.WiFiStrength.POOR.getValue()) {
				updatedDeviceInfo.mWifiNetworkStrength = AboutSpeakerModel.WiFiStrength.POOR;
			}

			if (strengthValue > AboutSpeakerModel.WiFiStrength.POOR.getValue() &&
					strengthValue <= AboutSpeakerModel.WiFiStrength.GOOD.getValue()) {
				updatedDeviceInfo.mWifiNetworkStrength = AboutSpeakerModel.WiFiStrength.GOOD;
			}

			if (strengthValue > AboutSpeakerModel.WiFiStrength.GOOD.getValue() &&
					strengthValue <= AboutSpeakerModel.WiFiStrength.EXCELLENT.getValue()) {
				updatedDeviceInfo.mWifiNetworkStrength = AboutSpeakerModel.WiFiStrength.EXCELLENT;
			}

			updatedDeviceInfo.mWifiNetworkStrengthPercent = (int) strengthValue;
		}

		if (macAddressNode != null) {
			updatedDeviceInfo.mMACAddress = macAddressNode.getValue();
		}

		if (wiredInterfaceEnabledNode != null) {
			if (wiredInterfaceEnabledNode.getValueEnum() == NodeSysNetWiredInterfaceEnable.Ord.INTERFACE_ENABLE) {
				updatedDeviceInfo.mWiredInterfaceConnected = true;

				if (wiredMACAddressNode != null) {
					updatedDeviceInfo.mMACAddress = wiredMACAddressNode.getValue();
				}
			}
		}

		return updatedDeviceInfo;
	}

	public void changeFriendlyName(AboutSpeakerModel item, Activity activity, IAboutSpeakerListener listener) {
		if (activity != null) {
			if (item.mDeviceRadio != null) {
				Radio radio = item.mDeviceRadio;
                showChangeFriendlyNameOfCurrentDeviceDialog(radio, activity, listener);
			}
		}
	}
	
	public void showChangeFriendlyNameOfCurrentDeviceDialog(final Radio radio, final Activity activity,
                                                            final IAboutSpeakerListener listener) {

        final String friendlyNameOfRadio = radio.getFriendlyName();
        final int maxLengthOfFriendlyName = radio.hasGoogleCast() ?
                FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME_WHEN_GOOGLE_CAST_IS_PRESENT :
                FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME;

        activity.runOnUiThread(new Runnable() {

            @Override
            public void run() {
                DialogsOpener.showChangeFriendlyNameDialog(friendlyNameOfRadio, activity, maxLengthOfFriendlyName,
                        new IButtonsResponseWithTextListener() {

                    @Override
                    public void onOkClicked(final String newFriendlyName) {
                        if (TextUtils.isEmpty(newFriendlyName))
                            return;

                        if (radio != null) {
                            RadioNodeUtil.setNodeToRadioAsync(radio, new NodeSysInfoFriendlyName(newFriendlyName), new RadioNodeUtil.INodeSetResultListener() {
                                @Override
                                public void onNodeSetResult(boolean success) {
                                    onFriendlyNameChanged(radio, newFriendlyName, listener);
                                }
                            });
                        }
                    }

                    @Override
                    public void onCancelClicked() {
                    }
                });
            }
        });
	}

	private void onFriendlyNameChanged(Radio radio, String newFriendlyName, IAboutSpeakerListener listener) {
		if (radio != null) {
			radio.setFriendlyName(newFriendlyName);
		}

		notifyDeviceInfoUpdated(listener);
	}

	private void notifyDeviceInfoUpdated(IAboutSpeakerListener listener) {
		if (listener != null) {
			listener.onDeviceInfoUpdated();
		}
	}

	private class AboutSpeakerUpdateTask extends AsyncTask<Void, Integer, List<AboutSpeakerModel>> {

		private final IAboutSpeakerListener mListener;
		private final Radio mRadio;

		public AboutSpeakerUpdateTask(Radio radio, IAboutSpeakerListener listener) {
			mListener = listener;
			mRadio = radio;
		}

		@Override
		protected List<AboutSpeakerModel> doInBackground(Void... arg0) {

            return getRadioDeviceInfo(mRadio);
		}

		@Override
		protected void onPostExecute(List<AboutSpeakerModel> result) {
			if (mListener != null) {
				mListener.onUpdateAboutDevicesList(result);
			}
		}
	}

}
