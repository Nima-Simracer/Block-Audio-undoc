package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import com.frontier_silicon.NetRemoteLib.Node.BaseNavStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavStatus;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavResultEvent;
import com.frontier_silicon.loggerlib.FsLogger;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * Created by lsuhov on 30/06/16.
 */

public class NavResetToCurrListRunnable implements Runnable {

    private BreadcrumbsKeeper mBreadcrumbsKeeper;
    private Radio mRadio;

    public NavResetToCurrListRunnable(BreadcrumbsKeeper breadcrumbsKeeper, Radio radio) {
        mBreadcrumbsKeeper = breadcrumbsKeeper;
        mRadio = radio;
    }

    @Override
    public void run() {
        if (mRadio == null) {
            return;
        }

        NodeNavStatus statusNode = RadioNavigationUtil.resetNavigationToRoot(mRadio);
        NodeNavStatus.Ord status = statusNode != null ? statusNode.getValueEnum() : null;

        if (statusNode == null || status == BaseNavStatus.Ord.FAIL || status == BaseNavStatus.Ord.FATAL_ERR ||
                status == BaseNavStatus.Ord.WAITING) {
            notifyError();
            dispose();
            return;
        }

        if (mBreadcrumbsKeeper.hasSearchText()) {
            navigateAndSearch();
        } else {
            if (!navigateWithBreadCrumbs()) {
                dispose();
                return;
            }
        }

        EIRNavigationResult numberOfItemsRetrievedResult = NavBrowseManager.getInstance().retrieveTotalNumberOfItemsFromCurrentListSync(mRadio);
        if (numberOfItemsRetrievedResult != EIRNavigationResult.EmptyList) {
            if (numberOfItemsRetrievedResult == EIRNavigationResult.Success) {
                NavBrowseManager.getInstance().retrieveFirstPageSync(mRadio);
            } else {
                NavBrowseManager.getInstance().retrieveAllPagesSync(mRadio);
            }
        }

        NavResultEvent resultEvent = new NavResultEvent(numberOfItemsRetrievedResult);
        EventBus.getDefault().post(resultEvent);

        dispose();
    }

    private boolean navigateWithBreadCrumbs() {
        List<Long> breadCrumbs = mBreadcrumbsKeeper.getBreadCrumbs();
        for (Long index : breadCrumbs) {
            boolean success = RadioNavigationUtil.getInstance().navigateNavItem(mRadio, index);

            if (!success) {
                notifyError();
                return false;
            }
        }

        return true;
    }

    private void navigateAndSearch() {
        List<Long> searchPath = mBreadcrumbsKeeper.getSearchNavigationPath();

        if (searchPath.size() == 0) {
            String logMessage = "NavResetToCurrListRunnable navigateAndSearch - search path is empty";
            FirebaseCrashlytics.getInstance().log(logMessage);
            FsLogger.log(logMessage);
        }

        for (int i = 0; i < searchPath.size() - 1; i++) {
            boolean success = RadioNavigationUtil.getInstance().navigateNavItem(mRadio, searchPath.get(i));

            if (!success) {
                notifyError();
                return;
            }
        }
        //Try to fix #2786
        if (searchPath.size() > 0) {
            RadioNavigationUtil.searchNavItem(mRadio, mBreadcrumbsKeeper.getSearchText(), searchPath.get(searchPath.size() - 1));
        }

        //this is only used for back navigation.
        //if we did navigate in directories after search, we need to redo those also.
        //here navigate all directories after searchDepth until the last step.
        List<Long> breadCrumbs = mBreadcrumbsKeeper.getBreadCrumbsAfterSearch();
        if(breadCrumbs != null && breadCrumbs.size() > 0){
            for (int i = 0; i < breadCrumbs.size() - 1; i++) {
                boolean success = RadioNavigationUtil.getInstance().navigateNavItem(mRadio, breadCrumbs.get(i));

                if (!success) {
                    notifyError();
                    return;
                }
            }
            //normal updateNavigation is not called for this situation, so pop() needs to be done in breadCrumbs.
            mBreadcrumbsKeeper.pop();
        }
    }

    private void notifyError() {
        EventBus.getDefault().post(new NavResultEvent(EIRNavigationResult.NavigationFailed));
    }

    private void dispose() {
        mBreadcrumbsKeeper = null;
        mRadio = null;
    }
}
