package com.frontier_silicon.fsirc.dok2.presets;

import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;

import com.frontier_silicon.NetRemoteLib.Node.BaseNavPresets;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavActionSelectPreset;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavPresetDelete;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavPresetSwapIndex1;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavPresetSwapIndex2;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavPresetSwapSwap;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavPresets;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayAddPreset;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayCaps;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import org.seamless.util.time.DateRange;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PresetsUtil {

	private static final long INVALID_KEY_ID = -1;
	private IPresetsListener mListener;
	
	private boolean mIsAddPresetVisible = false;
	private int nrOfCalls = 0;

	public PresetsUtil() {

	}

    public synchronized void removeListener() {
        mListener = null;
	}

    public synchronized void setListener(IPresetsListener listener) {
        mListener = listener;
	}

    private synchronized void notifyPresetsUpdate(ArrayList<PresetItemModel> presetsList) {
        if (mListener != null) {
            mListener.onPresetsUpdate(presetsList);
        }
	}

	private synchronized void notifyPresetsSupportedCapsUpdate(boolean navigatePresetsSupported, boolean addPresetsSupported) {
		if (mListener != null) {
			mListener.onPresetsSupportedCapsUpdate(navigatePresetsSupported, addPresetsSupported);
		}
	}
	
	public void updatePresetsList() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            UpdatePresetsForGroupTask updatePresetsTask = new UpdatePresetsForGroupTask(currentRadio);
            TaskHelper.execute(updatePresetsTask);
        }
	}

	public void addPreset(final long keyId) {
		final Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
		if (NetRemoteManager.getInstance().checkConnection(radio)) {
			RadioNodeUtil.getNodeFromRadioAsync(radio, NodePlayCaps.class, new RadioNodeUtil.INodeResultListener() {
				@Override
				public void onNodeResult(NodeInfo node) {
					NodePlayCaps playCaps = (NodePlayCaps)node;
					if (playCaps != null) {
						boolean addPresetsSupported = (playCaps.DoesSupport(NodePlayCaps.Operation.AddPreset));
						if (addPresetsSupported) {
							radio.setNode(new NodePlayAddPreset(keyId), false);
						}
					}
				}
			});
		}
	}

	public void saveEditedPreset(String key, String name, String type, String url, ISetNodeCallback callback) {
		final Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
		if (NetRemoteManager.getInstance().checkConnection(radio)) {
			if (type.isEmpty()) {
				if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.IR) {
					type = "AirableRadio";
				} else if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.PODCASTS) {
					type = "Podcasts";
				}
			}
			 String encodedURL="";
			try {
				encodedURL = URLEncoder.encode(url, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

			String [] params = new String[4];
			params[0] = "key=" + key;
			params[1] = "name=" + name;
			params[2] = "type=" + type;
			params[3] = "url=" + encodedURL;

			radio.setListNode(new NodeNavPresets(), false, params, callback);
		}
	}

	public void reorderPresets(ArrayList<PresetItemModel> list, int fromPosition, int toPosition, ISetNodeCallback callback) {
		if (fromPosition == -1 || toPosition == -1) {
			return;
		}

		if (fromPosition > toPosition) {
			nrOfCalls = fromPosition - toPosition + 1;
			for (int i = fromPosition; i>= toPosition; i--) {
				PresetItemModel item = list.get(i);

				saveEditedPreset(String.valueOf(list.indexOf(item)), item.mName, item.mType, item.mPresetUrl, new ISetNodeCallback() {
					@Override
					public void setNodeSuccess(NodeInfo node) {
						nrOfCalls --;

						if (nrOfCalls == 0 ) {
							callback.setNodeSuccess(node);
						}
					}

					@Override
					public void setNodeError(NodeInfo node, NodeErrorResponse error) {
						callback.setNodeError(node, error);

					}
				});
			}
		} else {
			nrOfCalls = toPosition - fromPosition + 1;

			for (int i = fromPosition; i<= toPosition; i++) {
				PresetItemModel item = list.get(i);

				saveEditedPreset(String.valueOf(list.indexOf(item)), item.mName, item.mType, item.mPresetUrl, new ISetNodeCallback() {
					@Override
					public void setNodeSuccess(NodeInfo node) {
						nrOfCalls --;

						if (nrOfCalls == 0 ) {
							callback.setNodeSuccess(node);
						}
					}

					@Override
					public void setNodeError(NodeInfo node, NodeErrorResponse error) {
						callback.setNodeError(node, error);
					}
				});
			}
		}

	}

	public void swapPresets(PresetItemModel source, PresetItemModel destination) {
		saveEditedPreset(String.valueOf(destination.mKeyId), source.mName, source.mType, source.mPresetUrl, null);
		saveEditedPreset(String.valueOf(source.mKeyId), destination.mName, destination.mType, destination.mPresetUrl, null);
		}

    public void deletePreset(final PresetItemModel presetItem, ISetNodeCallback listener) {

	    if (presetItem == null || presetItem.mRadio == null) {
	        return;
        }

        presetItem.mRadio.setNode(new NodeNavPresetDelete(presetItem.mKeyId), false, listener);
    }

	public void selectPreset(PresetItemModel presetItem) {
		RadioNodeUtil.setNodeToRadioAsync(presetItem.mRadio, new NodeNavActionSelectPreset(presetItem.mKeyId), new RadioNodeUtil.INodeSetResultListener() {
			@Override
			public void onNodeSetResult(boolean success) {
			}
		});
	}

	public boolean isPresetSet(PresetItemModel presetItem) {
		return !TextUtils.isEmpty(presetItem.mName);
	}

	public void addPresetSupported(final boolean isPresetNavigationSupported) {
		Radio currRadio = NetRemoteManager.getInstance().getCurrentRadio();
		if (NetRemoteManager.getInstance().checkConnection()) {
			boolean forceUncached = false;
			RadioNodeUtil.getNodesFromRadioAsync(currRadio, new Class[]{NodePlayCaps.class, NodePlayStatus.class}, forceUncached, new RadioNodeUtil.INodesResultListener() {
				@Override
				public void onNodesResult(Map<Class, NodeInfo> nodes) {
					boolean isAddPresetSupported = false;

					NodePlayCaps playCapsNode = (NodePlayCaps) nodes.get(NodePlayCaps.class);
					if (playCapsNode != null) {
						isAddPresetSupported = (playCapsNode.DoesSupport(NodePlayCaps.Operation.AddPreset));

					}

					NodePlayStatus playStatus = (NodePlayStatus) nodes.get(NodePlayStatus.class);
					if (playStatus != null) {
						mIsAddPresetVisible = (isAddPresetSupported && (playStatus.getValueEnum() == NodePlayStatus.Ord.PLAYING) ||
								(playStatus.getValueEnum() == NodePlayStatus.Ord.PAUSED) || (playStatus.getValueEnum() == NodePlayStatus.Ord.BUFFERING));
					} else {
						mIsAddPresetVisible = false;
					}

					notifyPresetsSupportedCapsUpdate(isPresetNavigationSupported, isAddPresetSupported);
				}
			});
		}
	}

	private interface IAvailableDevicePresetsListener {
		void onPresetsUpdate(Radio radio, ArrayList<PresetItemModel> presetsList);
	}

	private class UpdatePresetsForGroupTask extends AsyncTask<Void, Integer, ArrayList<PresetItemModel>> {

		private static final long WAIT_TIME_MS = 200;
		private static final long MAX_WAIT_TIME_MS = 8000;
		private final Radio mCurrentRadio;

		public UpdatePresetsForGroupTask(Radio currentRadio) {
			mCurrentRadio = currentRadio;
		}

		@Override
		protected ArrayList<PresetItemModel> doInBackground(Void... arg0) {
			return getFlatPresetsList(mCurrentRadio, getPresetsMapForGroup(mCurrentRadio));
		}

		@Override
		protected void onPostExecute(ArrayList<PresetItemModel> presetsList) {
			notifyPresetsUpdate(presetsList);
		}

		private ArrayList<PresetItemModel> getFlatPresetsList(final Radio currentRadio, Map<Radio, ArrayList<PresetItemModel>> devicesPresetMap) {
			ArrayList<PresetItemModel> allPresetsList = new ArrayList<>();

			// Crashlytics fix #2346
            // https://gist.github.com/AlainODea/1375759b8720a3f9f094
			ArrayList<Radio> radioList = new ArrayList<>(devicesPresetMap.keySet());

			// sort radios alphabetically, master first
			Collections.sort(radioList, new Comparator<Radio>() {
				@Override
				public int compare(Radio leftItem, Radio rightItem) {
					int compareValue = DokUiUtils.getFriendlyNameOrStereoSystemName(leftItem)
                            .compareTo(DokUiUtils.getFriendlyNameOrStereoSystemName(rightItem));

					if (currentRadio != null) {
						if (currentRadio.equals(leftItem)) {
							compareValue = -1;
						} else {
							if (currentRadio.equals(rightItem)) {
								compareValue = 1;
							}
						}
					}

					return compareValue;
				}
			});

            if (radioList.size() == 1) {
                return devicesPresetMap.get(radioList.get(0));
            }

            int nuRadiosWithPresets = 0;
            for (Radio radio: radioList)
			{
				ArrayList<PresetItemModel> presetsList = devicesPresetMap.get(radio);
				if (presetsList.size() > 0)
					nuRadiosWithPresets++;
			}

			for (Radio radio : radioList) {
				ArrayList<PresetItemModel> presetsList = devicesPresetMap.get(radio);

				if (presetsList.size() > 0) {
					PresetItemModel deviceHeaderItem = new PresetItemModel(DokUiUtils.getFriendlyNameOrStereoSystemName(radio),
							INVALID_KEY_ID, null,null,false, false, radio, radio.getModeSync());
					// add master radio header only when we have clients with presets
					if (nuRadiosWithPresets > 1 || (nuRadiosWithPresets == 1 && !currentRadio.equals(radio)))
						allPresetsList.add(deviceHeaderItem);
					allPresetsList.addAll(presetsList);
				}
			}

			return allPresetsList;
		}

		private Map<Radio, ArrayList<PresetItemModel>> getPresetsMapForGroup(Radio currentRadio) {
			final Map<Radio, ArrayList<PresetItemModel>> devicesPresetMap = new ConcurrentHashMap<>();

			// get presets for group master
			getPresetsForRadio(currentRadio, true, new IAvailableDevicePresetsListener() {
				@Override
				public void onPresetsUpdate(Radio radio, ArrayList<PresetItemModel> presetsList) {
					if (presetsList == null) {
						presetsList = new ArrayList<>();
					}
					devicesPresetMap.put(radio, presetsList);
				}
			});

			// get presets for all clients in current group
			long numClients = MultiroomGroupManager.getInstance().getMaxNumClients();
			for (int clientId = 0; clientId < numClients; clientId++) {
				MultiroomDeviceModel clientDevice = MultiroomGroupManager.getInstance().findClient(clientId);
				if (clientDevice != null) {
					if (clientDevice.mRadio != null) {
						getPresetsForRadio(clientDevice.mRadio, false, new IAvailableDevicePresetsListener() {
							@Override
							public void onPresetsUpdate(Radio radio, ArrayList<PresetItemModel> presetsList) {
								if (presetsList == null) {
									presetsList = new ArrayList<>();
								}
								devicesPresetMap.put(radio, presetsList);
							}
						});
					}
				}
			}

			return devicesPresetMap;
		}

		private void getPresetsForRadio(final Radio radio, final boolean isServer, final IAvailableDevicePresetsListener listener) {
			RadioNavigationUtil.enableNavigation(radio);
			getPresetsList(radio, isServer, listener);

		}

		private void getPresetsList(final Radio radio, final boolean isServer, final IAvailableDevicePresetsListener listener) {
            ArrayList<PresetItemModel> presetsList = null;
            List<NodeListItem> resultList = radio.nodeListSyncGetter(NodeNavPresets.class).get();

            if (resultList != null) {
                boolean isSelectable = true;
                presetsList = new ArrayList<>();

                for (NodeListItem item : resultList) {
                    NodeNavPresets.ListItem presetItem = (NodeNavPresets.ListItem) item;
                    if (canAddPresetItem(presetItem, isServer)) {

                        String modeString = presetItem.getType();
                        NodeSysCapsValidModes.Mode mode = NodeSysCapsValidModes.Mode.UnknownMode;

                        if (modeString != null)
                            mode = NodeSysCapsValidModes.ConvertIdToEnum(modeString);

                        PresetItemModel presetItemModel = new PresetItemModel(presetItem.getName(), presetItem.getKey(), presetItem.getType(), presetItem.getUrl(),
                                isSelectable, isAddButtonVisible(isServer), radio, mode);
                        presetsList.add(presetItemModel);
                    }
                }
            }

            if (listener != null) {
                listener.onPresetsUpdate(radio, presetsList);
            }
		}

		private boolean canAddPresetItem(NodeNavPresets.ListItem presetItem, boolean isServer) {
			return (!TextUtils.isEmpty(presetItem.getName()) || isServer);
		}

		private boolean isAddButtonVisible(boolean isServer) {
			return (isServer && mIsAddPresetVisible);
		}
	}


}
