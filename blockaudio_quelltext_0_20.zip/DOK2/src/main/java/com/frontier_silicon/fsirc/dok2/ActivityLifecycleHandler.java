package com.frontier_silicon.fsirc.dok2;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by lsuhov on 09/07/16.
 */

public class ActivityLifecycleHandler implements Application.ActivityLifecycleCallbacks {

    private int created;
    private int resumed;
    private int paused;
    private int started;
    private int stopped;
    private int destroyed;

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        ++created;
        setCurrentActivity(activity);
    }

    @Override
    public void onActivityStarted(Activity activity) {
        ++started;

        if (!MainApplication.isInForeground()) {
            checkAndSignalIfAppIsVisible();
        }
        setCurrentActivity(activity);
        MainApplication.setAppIsInForeground(isApplicationVisible());


    }

    @Override
    public void onActivityResumed(Activity activity) {
        ++resumed;

        setCurrentActivity(activity);
    }

    @Override
    public void onActivityPaused(Activity activity) {
        ++paused;
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
    }

    @Override
    public void onActivityStopped(Activity activity) {
        ++stopped;

        DelayedPostsManager.getInstance().postDelayed(() -> {
            MainApplication.setAppIsInForeground(isApplicationVisible());

            checkAndSignalIfAppIsNotVisible();
        }, 1000);
        FsLogger.log("application is visible: " + (started > stopped));
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        ++destroyed;

        if (isApplicationDestroyed()) {
            EventBus.getDefault().post(new AppDestroyedEvent());
        }
    }

    private void checkAndSignalIfAppIsNotVisible() {
        if (!isApplicationVisible()) {
            EventBus.getDefault().post(new AppInBackgroundEvent());
        }
    }

    private void checkAndSignalIfAppIsVisible() {
        if (isApplicationVisible()) {
            EventBus.getDefault().post(new AppInForegroundEvent());
        }
    }

    public boolean isApplicationVisible() {
        return started > stopped;
    }

    public boolean isApplicationDestroyed() {
        return created == destroyed;
    }

    public boolean isApplicationInForeground() {
        return resumed > paused;
    }

    private void setCurrentActivity(Activity activity) {
        if (activity instanceof AppCompatActivity) {
            MainApplication.mActivity = (AppCompatActivity) activity;

        } else {
            MainApplication.mActivity = null;

            FsLogger.log(activity.getClass().getSimpleName() + " is not of type AppCompatActivity", LogLevel.Error);
        }
    }
}
