package com.frontier_silicon.fsirc.dok2.update;

public class IsuBackgroundItemModel {
	public boolean mUpdateIsAvailable = false;
	public boolean mUpdateIsMandatory = false;
	
	public IsuBackgroundItemModel() {}
	
	public IsuBackgroundItemModel(boolean updateIsAvailable, boolean updateIsMandatory) {
		mUpdateIsAvailable = updateIsAvailable;
		mUpdateIsMandatory = updateIsMandatory;
	}
}
