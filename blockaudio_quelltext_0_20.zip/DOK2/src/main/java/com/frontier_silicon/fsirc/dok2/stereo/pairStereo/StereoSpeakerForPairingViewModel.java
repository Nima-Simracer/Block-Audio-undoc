package com.frontier_silicon.fsirc.dok2.stereo.pairStereo;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.graphics.drawable.BitmapDrawable;
import androidx.annotation.IdRes;
import android.view.View;
import android.widget.RadioGroup;

import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.stereo.EChannelMask;
import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.StereoPairSpeakerBinding;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

/**
 * Created by lsuhov on 11/08/2017.
 */

public class StereoSpeakerForPairingViewModel {

    public ObservableField<String> speakerName = new ObservableField<>();
    public ObservableField<BitmapDrawable> speakerImage = new ObservableField<>();
    public ObservableBoolean isPrimarySpeaker = new ObservableBoolean();

    private StereoItemModel mStereoItemModel;
    private StereoPairSpeakerBinding mSpeakerBinding;
    private Activity mActivity;
    private EChannelMask mChannelMask = EChannelMask.Left;

    public StereoSpeakerForPairingViewModel(StereoItemModel stereoItemModel, boolean isPrimary,
                                            StereoPairSpeakerBinding speakerBinding, Activity activity) {
        mStereoItemModel = stereoItemModel;
        mSpeakerBinding = speakerBinding;
        mActivity = activity;
        isPrimarySpeaker.set(isPrimary);

        if (stereoItemModel == null || stereoItemModel.deviceModel == null) {
            FsLogger.log("StereoItemModel from StereoSpeakerForPairingViewModel is null", LogLevel.Error);
            return;
        }

        init();
    }

    private void init() {
        updateName();

        updateSpeakerImage();

        setDefaultMaskChannelValue();

        setMaskChannelListener();
    }

    private void updateName() {
        speakerName.set(mStereoItemModel.deviceModel.mRadio.getFriendlyName());
    }

    private void updateSpeakerImage() {

        DokUiUtils.setImageIntoObservableDrawable(speakerImage, mStereoItemModel.deviceModel.mRadio, mActivity);
    }

    private void setDefaultMaskChannelValue() {
        if (isPrimarySpeaker.get()) {
            mSpeakerBinding.buttonLeftChannel.setChecked(true);
            mChannelMask = EChannelMask.Left;
        } else {
            mSpeakerBinding.buttonRightChannel.setChecked(true);
            mChannelMask = EChannelMask.Right;
        }
    }

    private void setMaskChannelListener() {
        mSpeakerBinding.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (checkedId == R.id.buttonLeftChannel) {
                    mChannelMask = EChannelMask.Left;
                } else if (checkedId == R.id.buttonRightChannel) {
                    mChannelMask = EChannelMask.Right;
                }
            }
        });
    }

    public void onPlayAlertToneClicked(View v) {
        StereoManager.getInstance().playAlertTone(mStereoItemModel.deviceModel.mRadio);
    }

    public EChannelMask getChannelMask() {
        return mChannelMask;
    }

    public MultiroomDeviceModel getDeviceModel() {
        return mStereoItemModel.deviceModel;
    }

    public void dispose() {
        mActivity = null;
        mStereoItemModel = null;

        if (mSpeakerBinding != null) {
            mSpeakerBinding.radioGroup.setOnCheckedChangeListener(null);
            mSpeakerBinding = null;
        }
    }
}
