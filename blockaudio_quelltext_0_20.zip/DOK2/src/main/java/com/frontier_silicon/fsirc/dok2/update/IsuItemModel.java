package com.frontier_silicon.fsirc.dok2.update;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuState;

public class IsuItemModel {
	public final Object mLock = new Object();
	public ICheckForUpdateListener mCheckUpdateListener;
	public IUpdateFirmwareListener mUpdateListener;
	
	public volatile boolean mCurrentVersionWasRetrieved;
	public volatile String mCurrentVersion = "";
	public volatile NodeSysIsuState.Ord mUpdateState;
    public volatile ICheckForUpdateListener.ErrorType mErrorType;
	public volatile String mUpdateVersion;
	public volatile long mIsMandatory;
	public volatile String mUpdateDescription = "";
	
	public volatile boolean mIsUpdating;
	public volatile long mProgress;
    public volatile boolean mIsRestarting;
    public volatile boolean mUpdateFailed;
}
