package com.frontier_silicon.fsirc.dok2.home;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.text.TextUtils;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Node.BaseMultiroomGroupState;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysMode;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysPower;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.connection.ConnectionManager;
import com.frontier_silicon.fsirc.dok2.stereo.DifferentFwVersionsDialogOpener;
import com.frontier_silicon.fsirc.dok2.stereo.IDifferentFwVersionResultListener;
import com.frontier_silicon.fsirc.dok2.update.AllDevicesIsuActivity;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;

/**
 * Created by lsuhov on 09/05/2017.
 */

public abstract class HomeBaseItemViewModel {

    protected static final int CONTENT_REFRESH_PERIOD = 15_000;

    protected MultiroomItemModel mMultiroomItemModel;
    protected Activity mActivity;
    protected Radio mRadio = null;

    public ObservableField<String> name = new ObservableField<>();
    public ObservableField<String> currentMode = new ObservableField<>();
    public ObservableBoolean currentModeIsVisible = new ObservableBoolean(false);
    public ObservableBoolean isCheckingAvailability = new ObservableBoolean(false);
    public boolean isScrollingEnable = UndokPreferences.getInstance().getScrollingEnabled();


    // This field should be used for speaker or group availability. For example if the group is missing
    // its server, than this field should be set to false.
    public ObservableBoolean isAvailable = new ObservableBoolean(true);
    public ObservableBoolean isStandby = new ObservableBoolean(false);
    public ObservableBoolean isConnected = new ObservableBoolean(false);
   // public ObservableBoolean isAlexaLogoVisible = new ObservableBoolean(false);

    private final long REFRESH_TIMER_ID;

    HomeBaseItemViewModel(MultiroomItemModel itemModel, Activity activity) {
        mMultiroomItemModel = itemModel;
        mActivity = activity;
        extractRadio();

        REFRESH_TIMER_ID = DelayedPostsManager.getInstance().registerNewCallbackID();
    }

    private void extractRadio() {
        if (mMultiroomItemModel.getIsGroupHeader()) {
            MultiroomDeviceModel serverDevice = MultiroomGroupManager.getInstance().getServerDeviceFromGroupId(mMultiroomItemModel.getGroupId());
            if (serverDevice != null && serverDevice.mRadio != null) {
                mRadio = serverDevice.mRadio;
            }
        } else {
            mRadio = mMultiroomItemModel.getRadio();
        }
    }

    protected void init() {
        updateName();

        updateCurrentModeAndStandby();
        updateIsSelectedState();

        scheduleRefreshTimer();
    }

    protected void updateName() {
        name.set(mMultiroomItemModel.toString());
    }

    private void updateIsSelectedState() {
        isConnected.set(mMultiroomItemModel.getIsActive());
    }

    private void updateCurrentModeAndStandby() {
        if (mRadio == null || mRadio.isCheckingAvailability() || mRadio.isMissing()) {
            return;
        }

        MultiroomDeviceModel deviceModel = mMultiroomItemModel.getDeviceModel();
        if (deviceModel != null && deviceModel.mGroupRole == BaseMultiroomGroupState.Ord.CLIENT) {
            return;
        }

        mRadio.getNodes(new Class[] {NodeSysPower.class, NodeSysMode.class}, nodeResponses -> {
            NodeSysPower powerNode = (NodeSysPower) nodeResponses.get(NodeSysPower.class).getNodeInfo();
            NodeSysMode modeNode = (NodeSysMode) nodeResponses.get(NodeSysMode.class).getNodeInfo();

            isStandby.set(powerNode != null && powerNode.getValueEnum() == NodeSysPower.Ord.OFF);

            updateCurrentModeImpl(modeNode);
        });
    }

    private void updateCurrentModeImpl(NodeSysMode modeNode) {
        if (modeNode == null || mRadio == null) {
            return;
        }

        mRadio.getModeAsListItem(modeNode, false, mode -> {
            if (mActivity == null) {
                return;
            }

            if (mode == null) {
                currentMode.set("");
                currentModeIsVisible.set(false);

//                if (mRadio.hasFSDCA()) {
//                    isAlexaLogoVisible.set(true);
//                }

                return;
            }

            if (mode.getId().equals(NodeSysCapsValidModes.Mode.DMR.name())) {
                currentMode.set(mActivity.getString(R.string.fs_dok_mode_localmusic));
                currentModeIsVisible.set(true);

            } else if (mode.getId().equals(NodeSysCapsValidModes.Mode.UnknownMode.name()) ||
                    mode.getId().equals(NodeSysCapsValidModes.Mode.Audsync.name()) ||
                    mode.getId().equals(NodeSysCapsValidModes.Mode.None.name())) {
                currentMode.set("");
                currentModeIsVisible.set(false);

            } else {
                currentMode.set(mode.getLabel());
                currentModeIsVisible.set(true);
            }

       //     decideToDisplayAlexaLogoOrNot(mode);
        });
    }

//    private void decideToDisplayAlexaLogoOrNot(NodeSysCapsValidModes.ListItem listItemCurrentMode) {
//        if (listItemCurrentMode == null) {
//            return;
//        }
//
//        NodeSysCapsValidModes.Mode currentMode = NodeSysCapsValidModes.ConvertIdToEnum(listItemCurrentMode.getId());
//
//        if (mRadio != null && mRadio.hasFSDCA()) {
//            if (shouldDisplayAlexaLogo(currentMode)) {
//                isAlexaLogoVisible.set(true);
//            } else {
//                isAlexaLogoVisible.set(false);
//            }
//        }
//    }


    public boolean shouldDisplayAlexaLogo(NodeSysCapsValidModes.Mode currentMode) {
        switch (currentMode) {

            case FSDCA_3PDA:
            case DAB:
            case FM:
            case IR:
            case Bluetooth:
            case AuxIn:
            case CD:
            case OPTICAL:
            case Standby:
            case SD:
                return true;
            default:
                return false;
        }
    }

    protected void scheduleRefreshTimer() {
        cancelRefreshTimer();

        DelayedPostsManager.getInstance().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (DokUiUtils.isDestroyed(mActivity) || ((HomeActivity)mActivity).isStopped()) {
                    dispose();
                    return;
                }

                if (mRadio == null) {
                    return;
                }

                updateCurrentModeAndStandby();

                scheduleRefreshTimer();
            }
        }, REFRESH_TIMER_ID, CONTENT_REFRESH_PERIOD);
    }

    public void cancelRefreshTimer() {
        DelayedPostsManager.getInstance().cancelCallback(REFRESH_TIMER_ID);
    }

    public void onListItemClicked(View view) {
        DifferentFwVersionsDialogOpener dialogOpener = new DifferentFwVersionsDialogOpener();
        String systemName = StereoManager.getInstance().checkIfMultichannelSystemHasDifferentFwVersionsAndReturnItsName(mMultiroomItemModel);

        if (dialogOpener.canShowDifferentVersionsWarning() && !TextUtils.isEmpty(systemName)) {

            showWarningMessageForDifferentFwVersionsInMultichannel(systemName, dialogOpener);
        } else {
            ConnectionManager.getInstance().tryConnectToSpeakerOrGroup(mMultiroomItemModel);
        }
    }

    private void showWarningMessageForDifferentFwVersionsInMultichannel(String systemName, DifferentFwVersionsDialogOpener dialogOpener) {

        dialogOpener.showDifferentFwMessageForStereoSystem(systemName, mActivity, new IDifferentFwVersionResultListener() {
            @Override
            public void continueOperation() {
                ConnectionManager.getInstance().tryConnectToSpeakerOrGroup(mMultiroomItemModel);
            }

            @Override
            public void goToUpdateSection() {
                NavigationHelper.goToActivity(mActivity, AllDevicesIsuActivity.class);
            }
        });
    }

    public void dispose() {
        cancelRefreshTimer();

        mMultiroomItemModel = null;
        mActivity = null;
        mRadio = null;
    }
}
