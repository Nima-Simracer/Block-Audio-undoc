package com.frontier_silicon.fsirc.dok2.browse.bluetooth;

import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothConnectedDevices;
import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothDiscoverableState;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BluetoothNodesRetrieverRunnable implements Runnable {

    private Radio mRadio;
    private IBrowseBluetoothNodesListener mCallback;

    BluetoothNodesRetrieverRunnable(Radio radio, IBrowseBluetoothNodesListener callback) {
        mRadio = radio;
        mCallback = callback;
    }

    @Override
    public void run() {
        if (mRadio == null) {
            if (mCallback != null) {
                mCallback.onNodesResult(new HashMap<>());
            }
            dispose();
        }

        NodeBluetoothDiscoverableState bluetoothDiscoverableStateNode = (NodeBluetoothDiscoverableState)
                mRadio.nodeSyncGetter(NodeBluetoothDiscoverableState.class).get();

        List list = mRadio.nodeListSyncGetter(NodeBluetoothConnectedDevices.class).get();

        Map<Class, Object> nodeResponses = new HashMap<>();
        nodeResponses.put(NodeBluetoothDiscoverableState.class, bluetoothDiscoverableStateNode);
        nodeResponses.put(NodeBluetoothConnectedDevices.class, list);

        mCallback.onNodesResult(nodeResponses);

        dispose();
    }

    private void dispose() {
        mRadio = null;
        mCallback = null;
    }
}
