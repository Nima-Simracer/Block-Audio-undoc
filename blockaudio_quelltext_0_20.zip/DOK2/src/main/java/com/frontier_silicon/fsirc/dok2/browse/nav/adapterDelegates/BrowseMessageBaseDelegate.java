package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseMessageBaseViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.MessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.messageItems.MessageItem;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseMessageBaseBinding;

/**
 * Created by adanaila on 07/11/2016.
 */

public class BrowseMessageBaseDelegate extends RecyclerViewListItemDelegate {

    private int mBrowseType;

    public BrowseMessageBaseDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseMessageBaseBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_message_base,
                parent, false);
        return new BrowseMessageBaseViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(mBrowseType);
        BrowseItemModel browseItemModel = browseManager.tryGetBrowseItemModel(position);

        MessageManager messageManager = BrowseManagerFactory.getMessageManager(mBrowseType);
        MessageItem messageItem = messageManager.getItem(browseItemModel);

        BrowseMessageBaseViewHolder descriptionViewHolder = (BrowseMessageBaseViewHolder) holder;

        BrowseMessageBaseViewModel viewModel = new BrowseMessageBaseViewModel(position, messageItem, descriptionViewHolder.mBinding.messageText);

        descriptionViewHolder.mBinding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseMessageBaseViewHolder messageBaseViewHolder = (BrowseMessageBaseViewHolder) holder;
        BrowseMessageBaseViewModel viewModel = messageBaseViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            messageBaseViewHolder.mBinding.setViewModel(null);
        }

        messageBaseViewHolder.mBinding.messageText.setText("");
    }

    protected static class BrowseMessageBaseViewHolder extends ListItemViewHolder {
        BrowseMessageBaseBinding mBinding;

        BrowseMessageBaseViewHolder(BrowseMessageBaseBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
