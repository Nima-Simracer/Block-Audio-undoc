package com.frontier_silicon.fsirc.dok2.nowPlaying;

import android.app.Activity;
import android.content.Intent;
import androidx.databinding.Observable;
import android.text.TextUtils;

import com.coderus.localmediaplayback.LocalMediaDMR;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.BasePlayRepeat;
import com.frontier_silicon.NetRemoteLib.Node.NodeCastAppName;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayCaps;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayConcurencyStr;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayControl;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayErrorStr;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoAlbum;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoAlbumDescription;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoArtist;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoArtistDescription;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoDescription;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoDuration;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoGraphicUri;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoName;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoProviderLogoUri;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoProviderName;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoText;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayNotificationMessage;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayPosition;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayRating;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayRepeat;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayShuffle;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayShuffleStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIpodDockStatus;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.browse.BrowseFMUtil;
import com.frontier_silicon.fsirc.dok2.browse.IFMRadioInfoListener;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.FragmentFactory;
import com.frontier_silicon.fsirc.dok2.notifications.NotificationManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.Map;

/**
 * Created by hcostescu on 10/05/17.
 */

public class NowPlayingManager implements INodeNotificationCallback, IFMRadioInfoListener {

    private static final long INVALID_VALUE = -1;
    private static final long SPOTIFY_SKIP_15_SECONDS = 15000;


    private static NowPlayingManager mInstance;
    private NowPlayingDataModel mNowPlayingDataModel = new NowPlayingDataModel();
    private Radio mRadio;
    private BrowseFMUtil mBrowseFMUtil;
    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;

    public interface OnUpdate{
        void onPlaybackUpdate();
    }

    private OnUpdate listener;

    private NowPlayingManager() {
        mBrowseFMUtil = new BrowseFMUtil();
    }

    public static NowPlayingManager getInstance() {
        if (mInstance == null) {
            mInstance = new NowPlayingManager();
        }

        return mInstance;
    }

    public NowPlayingDataModel getNowPlayingDataModel() {
        return mNowPlayingDataModel;
    }

    public void setDMRPlaying(boolean isPlaying){
        mNowPlayingDataModel.dmrPlaying.set(isPlaying);
    }

    public boolean isDMRPlaying(){
        return getNowPlayingDataModel().dmrPlaying.get();
    }

    public void setCurrentTrackUri(String uri) {
        getNowPlayingDataModel().trackUri.set(uri);
    }

    public String getCurrentTrackUri(){
        return getNowPlayingDataModel().trackUri.get();
    }

    public void bindToRadio(Radio radio) {
        //  should replace PlaybackInfoViewModel.getInstance().updateAllPlaybackInfo(true);
        FsLogger.log("bindToRadio NowPlaying");
        unbindFromPreviousRadio();

        if (radio == null) {
            return;
        }

        mRadio = radio;
        mRadio.addNotificationListener(this);

        updateAllPlaybackInfo(true, true);

        addSettingsListener();
    }

    private void unbindFromPreviousRadio() {

        if (mRadio != null) {
            mRadio.removeNotificationListener(this);
        }

        unregisterFMNotifCallbacks();
        removeSettingsListener();

        mRadio = null;
        mNowPlayingDataModel.resetToDefault();
        NotificationManager.getInstance().stopMediaNotificationService();
    }

    private void addSettingsListener() {
        removeSettingsListener();

        if (mPropertyChangedCallback == null) {
            mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable observable, int i) {
                    if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby) {

                    } else if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode) {

                        if (SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.get() != NodeSysCapsValidModes.Mode.DMR) {
                            FragmentFactory.getInstance().removeDRMRadio(NetRemoteManager.getInstance().getCurrentRadio());
                        }
                        cleanDRMPlaylist();

                        // on mode change a reset view is requested,
                        // new mode data if exists is loaded async and for a while wrong or mixed data is visible on screen
                        mNowPlayingDataModel.resetToDefault();

                        updateAllPlaybackInfo(false, false);
                    }
                }
            };
        }

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.isInStandby.addOnPropertyChangedCallback(mPropertyChangedCallback);
        speakerDataModel.currentMode.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void removeSettingsListener() {
        if (mPropertyChangedCallback == null) {
            return;
        }

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.isInStandby.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        speakerDataModel.currentMode.removeOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    @Override
    public void onNodeUpdated(NodeInfo node) {
        if (node instanceof NodePlayInfoName ||
                node instanceof NodePlayInfoText) {
            updateTrackInformation(false,false);

        } else if( node instanceof NodePlayStatus) {
            updateCapsNode(false);
            updatePlaybackState(false);

        } else if ( node instanceof NodePlayRepeat ||
                node instanceof NodePlayShuffle ||
                node instanceof NodePlayShuffleStatus) {
            updatePlaybackState(false);

        } else if (node instanceof NodePlayRating) {
            requestSongRating();
        } else if (node instanceof NodePlayNotificationMessage) {
            processPlayNotificationMessage((NodePlayNotificationMessage)node);
        }
    }

    private void processPlayNotificationMessage(NodePlayNotificationMessage node) {
        if (node == null || TextUtils.isEmpty(node.getValue())) {
            mNowPlayingDataModel.notificationMessage.set("");
            return;
        }

        mNowPlayingDataModel.notificationMessage.set(node.getValue());
    }

    private void updateCapsNode(boolean sync) {
        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {

            if (sync){
                NodePlayCaps node = (NodePlayCaps)mRadio.nodeSyncGetter(NodePlayCaps.class).get();
                mNowPlayingDataModel.playCaps.set(node);
            } else {
                final Radio calledRadio = mRadio;
                RadioNodeUtil.getNodeFromRadioAsync(calledRadio, NodePlayCaps.class, new RadioNodeUtil.INodeResultListener() {
                    @Override
                    public void onNodeResult(NodeInfo node) {
                        if (calledRadio == null || !calledRadio.equals(mRadio)) {
                            FsLogger.log("Play caps wiil not be updated because current radio has changed", LogLevel.Warning);
                            return;
                        }

                        mNowPlayingDataModel.playCaps.set((NodePlayCaps) node);
                        if (node != null)
                            FsLogger.log("getNodeResult: " + node.getName() + " value= " + node.toString());
                    }
                });
            }
        } else {
            mNowPlayingDataModel.resetToDefault();
        }

    }

    public void updateAllPlaybackInfo(boolean forceUncached, boolean sync) {
        registerFMNotifCallbacks();
        updateFMInfo();

        updateTrackInformation(forceUncached, sync);
        updatePlaybackState(sync);
        updateCapsNode(sync);
    }

    private void updateTrackInformation(boolean forceUncached, boolean sync) {

        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {
            if(sync) {
                nodePlayInfoResultsSync(forceUncached, mRadio);
            } else {
                nodePlayInfoResultsAsync(forceUncached, mRadio);
            }

        } else {
            mNowPlayingDataModel.resetToDefault();
        }
    }

    private NodeSysCapsValidModes.Mode getCurrentMode() {
        return SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.get();
    }

    private void nodePlayInfoResultsAsync(final boolean forceUncached, final Radio radio) {

        RadioNodeUtil.getNodesFromRadioAsync(radio, new Class[]{
                NodePlayInfoName.class, NodePlayInfoText.class, NodePlayInfoArtist.class,
                NodePlayInfoAlbum.class, NodePlayErrorStr.class, NodePlayInfoDuration.class,
                NodePlayPosition.class, NodeCastAppName.class, NodePlayInfoGraphicUri.class}, forceUncached, new RadioNodeUtil.INodesResultListener() {
            @Override
            public void onNodesResult(Map<Class, NodeInfo> nodes) {
                UpdatePlayInfoData(nodes, radio, forceUncached);
            }
        });
    }

    private void nodePlayInfoResultsSync(final boolean forceUncached, final Radio radio) {

        final Map<Class, NodeInfo> nodes =  radio.nodesSyncGetter(new Class[] {
                NodePlayInfoName.class, NodePlayInfoText.class, NodePlayInfoArtist.class,
                NodePlayInfoAlbum.class, NodePlayErrorStr.class, NodePlayInfoDuration.class,
                NodePlayPosition.class, NodeCastAppName.class, NodePlayInfoGraphicUri.class}).get();

        NetRemote.getMainThreadExecutor().execute(() -> UpdatePlayInfoData(nodes, radio, forceUncached));
    }

    private void UpdatePlayInfoData(Map<Class, NodeInfo> nodes, Radio radio, boolean forceUncached) {
        if (radio == null || !radio.equals(mRadio)) {
            FsLogger.log("UpdatePlayInfoData not run because radio has changed", LogLevel.Warning);
            return;
        }

        NodePlayInfoName infoNameNode = (NodePlayInfoName) nodes.get(NodePlayInfoName.class);

        if (infoNameNode != null) {
            String txtLine = infoNameNode.getValue().trim();

            if ((getCurrentMode() != NodeSysCapsValidModes.Mode.FM) && txtLine.endsWith("MHz")) {
                txtLine = "";
            }
            mNowPlayingDataModel.playInfoName.set(txtLine);
        }

        NodePlayInfoText infoTextNode = (NodePlayInfoText) nodes.get(NodePlayInfoText.class);
        if (infoTextNode != null) {
            mNowPlayingDataModel.playInfoText.set(infoTextNode.getValue());
        }

        NodePlayInfoArtist infoArtistNode = (NodePlayInfoArtist) nodes.get(NodePlayInfoArtist.class);
        if (infoArtistNode != null) {
            mNowPlayingDataModel.artist.set(infoArtistNode.getValue());
        }

        NodePlayInfoAlbum infoAlbumNode = (NodePlayInfoAlbum) nodes.get(NodePlayInfoAlbum.class);
        if (infoAlbumNode != null) {
            mNowPlayingDataModel.album.set(infoAlbumNode.getValue());
        }

        NodePlayErrorStr errorStrNode = (NodePlayErrorStr) nodes.get(NodePlayErrorStr.class);
        if (errorStrNode != null) {
            mNowPlayingDataModel.playError.set(errorStrNode.getValue());
        }

        NodePlayInfoDuration durationNode = (NodePlayInfoDuration) nodes.get(NodePlayInfoDuration.class);
        if (durationNode != null) {
            mNowPlayingDataModel.duration.set(durationNode.getValue());
        }

        NodePlayPosition positionNode = (NodePlayPosition) nodes.get(NodePlayPosition.class);
        if (positionNode != null) {
            mNowPlayingDataModel.elapsedTime.set(positionNode.getValue());
        } else {
            mNowPlayingDataModel.elapsedTime.set(-1);
        }

        NodePlayInfoGraphicUri graphicUriNode = (NodePlayInfoGraphicUri) nodes.get(NodePlayInfoGraphicUri.class);
        if (graphicUriNode != null) {
            String highQualityGraphicUri = getHighQualityGraphicUri(graphicUriNode.getValue());
            mNowPlayingDataModel.graphicUri.set(highQualityGraphicUri);
        } else {
            mNowPlayingDataModel.graphicUri.set("");
        }

        NodeCastAppName nodeCastAppName = (NodeCastAppName) nodes.get(NodeCastAppName.class);
        if (nodeCastAppName != null) {
            String castAppName = nodeCastAppName.getValue();
            mNowPlayingDataModel.castingApp.set(castAppName);
        } else {
            mNowPlayingDataModel.castingApp.set("");
        }

        // time act as a unique hash
        mNowPlayingDataModel.trackUpdated.set(System.currentTimeMillis());
        NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();
        if (currentMode == null) {
            return;
        }

        if (currentMode.isAirable()) {
            albumArtistInfo(radio, forceUncached);
        } else if (currentMode == NodeSysCapsValidModes.Mode.FSDCA_3PDA) {
            get3PdaInformation(radio, forceUncached);
        }
    }

    private String getHighQualityGraphicUri(String lowQualityUrl) {
        String highQualityUri = "";
        if (lowQualityUrl.contains("150x150")) {
            highQualityUri = lowQualityUrl.replaceAll("150x150","500x500");
        }

        return highQualityUri.isEmpty() ? lowQualityUrl : highQualityUri;
    }

    private void albumArtistInfo(Radio radio, boolean forceUncached) {
        RadioNodeUtil.getNodesFromRadioAsync(radio, new Class[]{ NodePlayInfoDescription.class, NodePlayInfoAlbumDescription.class, NodePlayInfoArtistDescription.class}, forceUncached, new RadioNodeUtil.INodesResultListener() {
            @Override
            public void onNodesResult(Map<Class, NodeInfo> nodes) {
                if (radio == null || !radio.equals(mRadio)) {
                    FsLogger.log("albumArtistInfo not run because radio has changed", LogLevel.Warning);
                    return;
                }

                NodePlayInfoDescription nodePlayInfoDescription = (NodePlayInfoDescription) nodes.get(NodePlayInfoDescription.class);
                if (nodePlayInfoDescription != null) {
                    String trackDescription = nodePlayInfoDescription.getValue();

                    mNowPlayingDataModel.trackDescription.set(trackDescription);
                } else {
                    mNowPlayingDataModel.trackDescription.set("");
                }

                NodePlayInfoAlbumDescription nodePlayInfoAlbumDescription = (NodePlayInfoAlbumDescription) nodes.get(NodePlayInfoAlbumDescription.class);
                if (nodePlayInfoAlbumDescription != null) {
                    String infoAlbumDescription = nodePlayInfoAlbumDescription.getValue();
                    mNowPlayingDataModel.infoAlbumDescription.set(infoAlbumDescription);
                } else {
                    mNowPlayingDataModel.infoAlbumDescription.set("");
                }

                NodePlayInfoArtistDescription nodePlayInfoArtistDescription = (NodePlayInfoArtistDescription) nodes.get(NodePlayInfoArtistDescription.class);
                if (nodePlayInfoArtistDescription != null) {
                    String infoArtistDescription = nodePlayInfoArtistDescription.getValue();
                    mNowPlayingDataModel.infoArtistDescription.set(infoArtistDescription);
                } else {
                    mNowPlayingDataModel.infoArtistDescription.set("");
                }
            }
        });
    }

    private void get3PdaInformation(Radio radio, boolean forceUncached) {
        RadioNodeUtil.getNodesFromRadioAsync(radio, new Class[]{NodePlayInfoProviderLogoUri.class, NodePlayInfoProviderName.class}, forceUncached, new RadioNodeUtil.INodesResultListener() {
            @Override
            public void onNodesResult(Map<Class, NodeInfo> nodes) {
                if (radio == null || !radio.equals(mRadio)) {
                    FsLogger.log("providerLogo retrieving does not run because radio has changed", LogLevel.Warning);
                    return;
                }

                NodePlayInfoProviderLogoUri nodeProviderLogoUri = (NodePlayInfoProviderLogoUri) nodes.get(NodePlayInfoProviderLogoUri.class);
                if (nodeProviderLogoUri != null) {
                    String logoUri = nodeProviderLogoUri.getValue();
                    mNowPlayingDataModel.providerLogoUri.set(logoUri);
                } else {
                    mNowPlayingDataModel.providerLogoUri.set("");
                }

                NodePlayInfoProviderName nodeProviderName = (NodePlayInfoProviderName) nodes.get(NodePlayInfoProviderName.class);
                if (nodeProviderName != null) {
                    String providerName = nodeProviderName.getValue();
                    mNowPlayingDataModel.providerName.set(providerName);
                } else {
                    mNowPlayingDataModel.providerName.set("");
                }
            }
        });
    }

    private void updatePlaybackState(boolean sync) {
        if (sync) {
            updatePlaybackStateSync();
        } else {
            updatePlaybackStateAsync();
        }
    }
    private void updatePlaybackStateSync() {

        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {

            Map<Class, NodeInfo> nodes =  mRadio.nodesSyncGetter(new Class[] {
                    NodePlayStatus.class, NodePlayErrorStr.class, NodePlayPosition.class, NodePlayRepeat.class,
                    NodePlayShuffle.class, NodePlayShuffleStatus.class, NodeSysIpodDockStatus.class,
                    NodePlayInfoDuration.class}).get();

            UpdatePlaybackStateData(nodes, mRadio);
        } else {
            mNowPlayingDataModel.resetToDefault();
        }
    }

    private void updatePlaybackStateAsync() {

        final Radio currentRadio = mRadio;
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            boolean forceUncached = false;

            RadioNodeUtil.getNodesFromRadioAsync(currentRadio,
                    new Class[]{ NodePlayStatus.class, NodePlayErrorStr.class, NodePlayPosition.class,
                            NodePlayRepeat.class, NodePlayShuffle.class, NodePlayShuffleStatus.class,
                            NodeSysIpodDockStatus.class, NodePlayInfoDuration.class},
                    forceUncached,
                    nodes -> UpdatePlaybackStateData(nodes, currentRadio));

        } else {
            mNowPlayingDataModel.resetToDefault();
        }
    }

    private void UpdatePlaybackStateData(Map<Class, NodeInfo> nodes, Radio radio) {

        if (radio == null || !radio.equals(mRadio)) {
            FsLogger.log("UpdatePlaybackStateData not run because radio has changed", LogLevel.Warning);
            return;
        }

        NodePlayStatus nodePlayStatus = (NodePlayStatus)nodes.get(NodePlayStatus.class);
        mNowPlayingDataModel.playStatus.set(nodePlayStatus);

        if (nodePlayStatus != null) {
            FsLogger.log("getNodeResult: " + nodes.get(NodePlayStatus.class).getName() + " value= " + nodes.get(NodePlayStatus.class).toString());

            NodePlayErrorStr nodePlayErrorStr = (NodePlayErrorStr) nodes.get(NodePlayErrorStr.class);

            if (mNowPlayingDataModel.isError()) {

                if (nodePlayErrorStr != null) {
                    mNowPlayingDataModel.playErrorMsg.set(nodePlayErrorStr.getValue());
                } else {
                    mNowPlayingDataModel.playErrorMsg.set("");
                }
            } else {
                mNowPlayingDataModel.playErrorMsg.set("");
            }

            if (mNowPlayingDataModel.isErrorPopup()) {
                handleErrorPopupState(nodePlayErrorStr);
            } else {
                mNowPlayingDataModel.playErrPopupMessage.set("");
                mNowPlayingDataModel.concurrencyString.set("");
            }

            if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.AIRABLE_AMAZON_MP) {
               requestSongRating();
            }
        }

        NodePlayPosition nodePlayPosition = (NodePlayPosition) nodes.get(NodePlayPosition.class);
        if (nodePlayPosition != null) {
            if (mNowPlayingDataModel.isPlaying() || mNowPlayingDataModel.isPaused()) {
                mNowPlayingDataModel.elapsedTime.set(nodePlayPosition.getValue());
            }
            FsLogger.log("getNodeResult: " + 	nodes.get(NodePlayPosition.class).getName() + " value= " + nodes.get(NodePlayPosition.class).toString());
        }
        else
            mNowPlayingDataModel.elapsedTime.set(INVALID_VALUE);

        NodePlayRepeat nodePlayRepeat = (NodePlayRepeat) nodes.get(NodePlayRepeat.class);
        if (nodePlayRepeat != null) {
            mNowPlayingDataModel.repeatMode.set((nodePlayRepeat.getValueEnum()));
            FsLogger.log("getNodeResult: " + 	nodes.get(NodePlayRepeat.class).getName() + " value= " + nodes.get(NodePlayRepeat.class).toString());
        }
        else
            mNowPlayingDataModel.repeatMode.set(BasePlayRepeat.Ord.OFF);

        NodePlayShuffle nodePlaySuffle = (NodePlayShuffle) nodes.get(NodePlayShuffle.class);
        if (nodePlaySuffle != null) {
            mNowPlayingDataModel.isShuffle.set((nodePlaySuffle.getValueEnum() == NodePlayShuffle.Ord.ON));
            FsLogger.log("getNodeResult: " + 	nodes.get(NodePlayShuffle.class).getName() + " value= " + nodes.get(NodePlayShuffle.class).toString());
        }
        else
            mNowPlayingDataModel.isShuffle.set(false);

        NodePlayShuffleStatus nodePlaySuffleStatus = (NodePlayShuffleStatus)nodes.get(NodePlayShuffleStatus.class);
        if (nodePlaySuffleStatus != null)
        {
            mNowPlayingDataModel.isShuffleError.set((NodePlayShuffleStatus.Ord.TOO_MANY_ITEMS == nodePlaySuffleStatus.getValueEnum()));
            FsLogger.log("getNodeResult: " + nodePlaySuffleStatus.getName() + " value= " + nodePlaySuffleStatus.toString());
        }
        else
            mNowPlayingDataModel.isShuffleError.set(false);


        NodeSysIpodDockStatus nodeSysIpodDockStatus = (NodeSysIpodDockStatus) nodes.get(NodeSysIpodDockStatus.class);
        if (nodeSysIpodDockStatus != null) {
            mNowPlayingDataModel.iPodDockStatus.set(nodeSysIpodDockStatus.getValueEnum());
            FsLogger.log("getNodeResult: " + nodeSysIpodDockStatus.getName() + " value= " + nodeSysIpodDockStatus.toString());
        }
        else
            mNowPlayingDataModel.iPodDockStatus.set(NodeSysIpodDockStatus.Ord.NOT_DOCKED);


        NodePlayInfoDuration nodePlayInfoDuration = (NodePlayInfoDuration)nodes.get(NodePlayInfoDuration.class);
        if (nodePlayInfoDuration != null) {
            mNowPlayingDataModel.duration.set(nodePlayInfoDuration.getValue());
            FsLogger.log("getNodeResult: " + nodePlayInfoDuration.getName() + " value= " + nodePlayInfoDuration.toString());
        }
        else
            mNowPlayingDataModel.duration.set(INVALID_VALUE);

        if (listener != null) {
            listener.onPlaybackUpdate();
        }
    }

    private void handleErrorPopupState(NodePlayErrorStr nodePlayErrorStr) {
        mNowPlayingDataModel.playErrPopupMessage.set("");
        mNowPlayingDataModel.concurrencyString.set("");

        NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();

        if (currentMode == NodeSysCapsValidModes.Mode.AIRABLE_AMAZON_MP) {
            RadioNodeUtil.getNodeFromRadioAsync(mRadio, NodePlayConcurencyStr.class, node -> {
                if (node == null) {
                    return;
                }

                NodePlayConcurencyStr playConcurencyString = (NodePlayConcurencyStr) node;
                mNowPlayingDataModel.concurrencyString.set(playConcurencyString.getValue());
            });
        } else  {
            if (nodePlayErrorStr != null) {
                mNowPlayingDataModel.playErrPopupMessage.set(nodePlayErrorStr.getValue());
            }
        }
    }

    private void requestSongRating() {

        if (mRadio == null) {
            FsLogger.log("NowPlayingManager: requestSongRating: radio is null");
            return;
        }

        RadioNodeUtil.getNodeFromRadioAsync(mRadio, NodePlayRating.class, new RadioNodeUtil.INodeResultListener() {
            @Override
            public void onNodeResult(NodeInfo node) {
                if (node != null) {
                    NodePlayRating nodeRating = (NodePlayRating) node;
                    mNowPlayingDataModel.songRating.set(nodeRating.getValueEnum());
                }
            }
        });
    }

    public void setManagerUpdatesListener(OnUpdate callback){
        this.listener = callback;
    }

    private void updateFMInfo() {
        if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.FM) {
            mNowPlayingDataModel.fmPercentProgress.set(mBrowseFMUtil.getPercentValue(mBrowseFMUtil.getCurrentFrequencyKHz()));
        }
    }

    @Override
    public void onUpdateFrequencyInfo(final boolean fmFreqChanged) {
        if (fmFreqChanged) {
            mNowPlayingDataModel.fmPercentProgress.set(mBrowseFMUtil.getPercentValue(mBrowseFMUtil.getCurrentFrequencyKHz()));
        }
    }

    private void registerFMNotifCallbacks() {
        if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.FM) {
            unregisterFMNotifCallbacks();
            if (mBrowseFMUtil != null) {
                mBrowseFMUtil.addListener(this);

                mBrowseFMUtil.updateFMFrequencyInfo();

                mBrowseFMUtil.registerFrequencyInfoNotifCallback();
            }
        }
    }

    private void unregisterFMNotifCallbacks() {
        if (mBrowseFMUtil != null) {
            mBrowseFMUtil.removeListener(this);
            mBrowseFMUtil.unregisterFrequencyInfoNotifCallback();
        }
    }

    public void setManualFrequency(int progress) {
        long freqValue = mBrowseFMUtil.getValueFromPercent(progress);
        mBrowseFMUtil.setFMRadioFrequency(freqValue);
    }

    public void onManualFrequencyChanged(int progress) {
        // update freq. text. the actual commit (set) is done at seek bar release
        long freqValue = mBrowseFMUtil.getValueFromPercent(progress);
        mNowPlayingDataModel.playInfoName.set(mBrowseFMUtil.getFrequencyDisplayTxt(freqValue));
    }

    public void scanBackward() {
        mBrowseFMUtil.changeFrequencyByStep(-mBrowseFMUtil.getFrequencyStepKHz());
    }

    protected void scanForward() {
        mBrowseFMUtil.changeFrequencyByStep(mBrowseFMUtil.getFrequencyStepKHz());
    }

    public void seek(long seekPos) {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            currentRadio.setNode(new NodePlayPosition(seekPos), false);
        }
    }

    public void play() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.PLAY);
            currentRadio.setNode(playNode, false);
        }
    }

    public void pause() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.PAUSE);
            currentRadio.setNode(playNode, false);
        }
    }

    public void stop() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.STOP);
            currentRadio.setNode(playNode, false);
        }
    }

    public void next() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.NEXT);
            currentRadio.setNode(playNode, false);
        }
    }

    public void previous() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.PREVIOUS);
            currentRadio.setNode(playNode, false);
        }
    }

    public int getProgressPercent(long position, long duration) {
        float posNorm = 0;

        if (duration > 0) {
            posNorm = (float)position / (float)duration;
        }

        return Math.round(posNorm * 100);
    }

    public long getPositionMilisec(int percent, long duration) {
        float pos = ((float)percent * (float)duration)/100.0f;
        return Math.round(pos);
    }

    public void enableShuffle(boolean enable) {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            NodePlayShuffle shuffleNode;
            if (enable) {
                shuffleNode = new NodePlayShuffle(NodePlayShuffle.Ord.ON);
            } else {
                shuffleNode = new NodePlayShuffle(NodePlayShuffle.Ord.OFF);
            }

            currentRadio.setNode(shuffleNode, false);
        }
    }

    public void enableRepeat(BasePlayRepeat.Ord value) {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {

            NodePlayRepeat repeatNode = new NodePlayRepeat(value);

            currentRadio.setNode(repeatNode, false);
        }
    }

    public void setThumbsUp() {
        // force button refresh until we receive the notification that is changed
        if (mNowPlayingDataModel.songRating.get().equals(NodePlayRating.Ord.POSITIVE)) {
            mNowPlayingDataModel.songRating.set(NodePlayRating.Ord.NEUTRAL);
        } else if (mNowPlayingDataModel.songRating.get().equals(NodePlayRating.Ord.NEUTRAL)){
            mNowPlayingDataModel.songRating.set(NodePlayRating.Ord.POSITIVE);
        }

        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            NodePlayRating rating = new NodePlayRating(NodePlayRating.Ord.POSITIVE);
            currentRadio.setNode(rating,false);
        }
    }

    public void setThumbsDown() {
        // force button refresh until we receive the notification that is changed
        if (mNowPlayingDataModel.songRating.get().equals(NodePlayRating.Ord.NEGATIVE)) {
            mNowPlayingDataModel.songRating.set(NodePlayRating.Ord.NEUTRAL);
        } else if (mNowPlayingDataModel.songRating.get().equals(NodePlayRating.Ord.NEUTRAL)){
            mNowPlayingDataModel.songRating.set(NodePlayRating.Ord.NEGATIVE);
        }

        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            NodePlayRating rating = new NodePlayRating(NodePlayRating.Ord.NEGATIVE);
            currentRadio.setNode(rating,false);
        }
    }

    public void skipBackward() {
        switch (SpeakerDataManager.getInstance().getCurrentMode()) {
            case Spotify:
                setPlayPosition(mNowPlayingDataModel.elapsedTime.get() - SPOTIFY_SKIP_15_SECONDS);
                mNowPlayingDataModel.elapsedTime.set(mNowPlayingDataModel.elapsedTime.get() - SPOTIFY_SKIP_15_SECONDS);
                break;
        }
    }

    public void skipForward() {
        switch (SpeakerDataManager.getInstance().getCurrentMode()) {
            case Spotify:
                setPlayPosition(mNowPlayingDataModel.elapsedTime.get() + SPOTIFY_SKIP_15_SECONDS);
                mNowPlayingDataModel.elapsedTime.set(mNowPlayingDataModel.elapsedTime.get() + SPOTIFY_SKIP_15_SECONDS);
                break;
        }
    }

    public void setEntireDuration() {
        setPlayPosition(mNowPlayingDataModel.duration.get());
        mNowPlayingDataModel.elapsedTime.set(mNowPlayingDataModel.duration.get());
    }

    public void setInitialDuration() {
        setPlayPosition(0);
        mNowPlayingDataModel.elapsedTime.set(0);
    }


    private void setPlayPosition(long duration) {
        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {
            mRadio.setNode(new NodePlayPosition(duration), false);
        }
    }

    public boolean canSkipForward() {
        switch (SpeakerDataManager.getInstance().getCurrentMode()) {
            case Spotify:
                return mNowPlayingDataModel.duration.get() - mNowPlayingDataModel.elapsedTime.get() > SPOTIFY_SKIP_15_SECONDS;

            default:
                return false;
        }

    }

    public boolean canSkipBackward() {
        switch (SpeakerDataManager.getInstance().getCurrentMode()) {
            case Spotify:
                return mNowPlayingDataModel.elapsedTime.get() > SPOTIFY_SKIP_15_SECONDS;

            default:
                return false;
        }
    }


    public void updatePlayPosition() {

        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {
            mRadio.getNode(NodePlayPosition.class, false, false, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    if (mNowPlayingDataModel == null) {
                        return;
                    }
                    NodePlayPosition pp = (NodePlayPosition) node;

                    if (mNowPlayingDataModel.elapsedTime.get() < pp.getValue() || Math.abs(pp.getValue() - mNowPlayingDataModel.elapsedTime.get()) > 2500) {
                        mNowPlayingDataModel.elapsedTime.set(pp.getValue());
                    }
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    if (mNowPlayingDataModel == null) {
                        return;
                    }
                    mNowPlayingDataModel.elapsedTime.set(-1);
                }
            });
        }
    }

    private void cleanDRMPlaylist(){

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        if (radio != null) {
            Intent intent = new Intent(LocalMediaDMR.LOCAL_MUSIC_CMD_RECEIVER);
            // You can also include some extra data.
            intent.putExtra("cmd", LocalMediaDMR.CMD_STOP_PLAY);
            intent.putExtra("udn", radio.getUDN());

            Activity activity = MainApplication.getCurrentActivity();

            if (!DokUiUtils.isDestroyed(activity)) {
                try {
                    activity.sendBroadcast(intent);
                } catch (RuntimeException e) {

                }
            }
        }
    }
}
