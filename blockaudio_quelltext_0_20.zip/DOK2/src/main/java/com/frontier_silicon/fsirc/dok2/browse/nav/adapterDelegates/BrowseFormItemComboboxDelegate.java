package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseFormComboboxViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.FormOptionAdapter;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormComboboxOption;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.AirableItemSelectionManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseFormItemComboboxBinding;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 07/11/2016.
 */

public class BrowseFormItemComboboxDelegate extends AirableSelectableItemDelegate {

    private int mBrowseType;

    public BrowseFormItemComboboxDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseFormItemComboboxBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_form_item_combobox,
                parent, false);
        //Spiiner does not have keyboard active, so listener is not created for it, only the item is added
        //so it can be selected in UI
        AirableItemSelectionManager.getInstance().addSelectableItem(binding.spinnerItem);

        return new BrowseFormItemComboboxViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        FormManager formManager = BrowseManagerFactory.getFormManager(mBrowseType);
        FormItem formItem = formManager.getItemByPosition(position);

        BrowseFormItemComboboxViewHolder comboboxViewHolder = (BrowseFormItemComboboxViewHolder) holder;

        List<FormComboboxOption> items = new ArrayList<>();
        FormOptionAdapter spinnerAdapter = new FormOptionAdapter(comboboxViewHolder.itemView.getContext(), R.layout.form_spinner_item,  items);

        BrowseFormComboboxViewModel mViewModel = new BrowseFormComboboxViewModel(position, formItem, spinnerAdapter, items);

        comboboxViewHolder.mBinding.spinnerItem.setAdapter(spinnerAdapter);

        comboboxViewHolder.mBinding.spinnerItem.setOnItemSelectedListener(mViewModel);

        comboboxViewHolder.mBinding.setViewModel(mViewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseFormItemComboboxViewHolder comboboxViewHolder = (BrowseFormItemComboboxViewHolder) holder;
        BrowseFormComboboxViewModel viewModel = comboboxViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            comboboxViewHolder.mBinding.setViewModel(null);
        }

        comboboxViewHolder.mBinding.spinnerItem.setOnItemSelectedListener(null);
    }

    private static class BrowseFormItemComboboxViewHolder extends ListItemViewHolder {
        BrowseFormItemComboboxBinding mBinding;

        BrowseFormItemComboboxViewHolder(BrowseFormItemComboboxBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
