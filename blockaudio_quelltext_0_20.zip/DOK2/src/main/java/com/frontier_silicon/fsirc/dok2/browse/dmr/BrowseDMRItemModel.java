package com.frontier_silicon.fsirc.dok2.browse.dmr;

public class BrowseDMRItemModel {

    public enum Types {
        PLAYLIST,
        GENRE,
        ARTIST,
        ALBUM_ALL,
        ALBUM,
        TRACK,

        ROOT_ARTISTS,
        ROOT_ALL_ALBUMS,
        ROOT_ALL_TRACKS,
        ROOT_ALL_GENRES,
        ROOT_ALL_PLAYLISTS,
    }

    private Types mType;
    private String mName;
    private long mItemId;
    private long mAritstId;

    /**
     * Overload constructor for use with creating Artists item model. The artistId
     * is set to the same value as the itemId.
     *
     * @param type        The type of container Artist, Album or Song
     * @param displayName The text that should represent the item in a list
     * @param itemId      The _id value of the item from the <code>Mediastore</code>
     */
    public BrowseDMRItemModel(Types type, String displayName, int itemId) {
        this(type, displayName, itemId, itemId);
    }

    /**
     * Default constructor
     *
     * @param type        The type of container Artist, Album or Song
     * @param displayName The text that should represent the item in a list
     * @param itemId      The _id value of the item from the <code>Mediastore</code>
     * @param artistId    The id value of the artist in the <code>Mediastore</code>
     */
    public BrowseDMRItemModel(Types type, String displayName, long itemId, long artistId) {
        mType = type;

        mName = displayName;
        if (mName == null) {
            mName = "";
        }

        mItemId = itemId;
        mAritstId = artistId;
    }

    /**
     * Returns one of the following constants based on the
     * type of content represented by the item model
     * <ul>
     * <li>Artists</li>
     * <li>Album</li>
     * <li>Track</li>
     * </ul>
     *
     * @return
     */
    public Types getType() {
        return mType;
    }

    /**
     * Returns the string that should be used to
     * represent the item in the list view
     *
     * @return Text describing the media item
     */
    public String getDisplayText() {
        return mName;
    }

    /**
     * Returns the <code>MediaStore</code> _id value of the
     * media item.
     *
     * @return Unique id for media item
     */
    public long getItemId() {
        return mItemId;
    }

    /**
     * Returns the <code>MediaStore</code> _id value
     * that the album or track is associated with
     *
     * @return Unique id for the artist
     */
    public long getArtistId() {
        return mAritstId;
    }
}
