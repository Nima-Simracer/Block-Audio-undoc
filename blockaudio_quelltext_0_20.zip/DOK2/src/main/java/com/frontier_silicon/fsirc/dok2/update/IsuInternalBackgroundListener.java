package com.frontier_silicon.fsirc.dok2.update;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;

import java.util.Map;

interface IsuInternalBackgroundListener {
	void onIsuResults(Map<Radio, IsuBackgroundItemModel> hashItemModels);
}
