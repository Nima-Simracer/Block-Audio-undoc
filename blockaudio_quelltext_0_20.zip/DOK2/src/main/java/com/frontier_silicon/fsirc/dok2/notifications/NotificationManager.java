package com.frontier_silicon.fsirc.dok2.notifications;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.databinding.Observable;

import com.frontier_silicon.NetRemoteLib.Node.BasePlayStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.AppInBackgroundEvent;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingDataModel;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;
import com.frontier_silicon.loggerlib.FsLogger;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Created by mnisipeanu on 16/03/2018.
 */

public class NotificationManager {
    private static NotificationManager instance;
    public final static String TAG = "NotificationManager: ";

    private Context mContext;
    private NowPlayingDataModel npDataModel;
    private BasePlayStatus.Ord mLastValue = BasePlayStatus.Ord.IDLE;

    private Observable.OnPropertyChangedCallback mSpeakerPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
        @Override
        public void onPropertyChanged(Observable observable, int i) {
            //FsLogger.log(TAG + "property change (speaker): " + observable.getClass());
            if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode) {
                FsLogger.log(TAG + "property change (speaker): " + observable.getClass() + " - " + SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.get());

                modeChanged();
            }
        }
    };

    private Observable.OnPropertyChangedCallback mNowPlayingPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
        @Override
        public void onPropertyChanged(Observable observable, int i) {
            if (NetRemoteManager.getInstance().getCurrentRadio() == null) {
                return;
            }

            FsLogger.log(TAG + "property change (np): " + observable.getClass().getName());

            if (observable == npDataModel.trackUpdated) {

                playStatusChanged(NetRemoteManager.getInstance().getCurrentRadio(), npDataModel);
                Log.d(TAG ,"INTERESTLOG: TrackUpdated");
            } else if (observable == npDataModel.graphicUri) {

                artworkChanged(npDataModel);
            } else if (observable == npDataModel.playStatus) {
                if (npDataModel.playStatus.get() != null &&
                        mLastValue != npDataModel.playStatus.get().getValueEnum()) {
                    playStatusChanged(NetRemoteManager.getInstance().getCurrentRadio(), npDataModel);
                    Log.d(TAG, "INTERESTLOG: playStatusChanged" + npDataModel.playStatus.get());
                    mLastValue = npDataModel.playStatus.get().getValueEnum();
                }
            } else {
                FsLogger.log(TAG + "property not used change (np) ");
            }
        }
    };

    private NotificationManager() {
    }

    public static NotificationManager getInstance() {
        if (instance == null) {
            instance = new NotificationManager();
        }

        return instance;
    }

    public void setContext(Context ctx) {
        if ((ctx != null) && ctx.equals(mContext)) {
            return;
        }

        mContext = ctx;

        if (mContext == null) {
            removePropertyChangeObservers();
        } else {
            addPropertyChangeObservers();
        }
    }

    private void addPropertyChangeObservers() {
        // prevent possible duplicate callbacks“
        removePropertyChangeObservers();

        FsLogger.log(TAG + "-> restore callbacks");
        npDataModel = NowPlayingManager.getInstance().getNowPlayingDataModel();
        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();

        if (speakerDataModel != null) {
            speakerDataModel.currentMode.addOnPropertyChangedCallback(mSpeakerPropertyChangedCallback);

            //force a initial check
            mSpeakerPropertyChangedCallback.onPropertyChanged(speakerDataModel.currentMode, 0);
        }

        if (npDataModel != null) {
            npDataModel.playStatus.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
            npDataModel.trackUpdated.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
            npDataModel.graphicUri.addOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);

            mNowPlayingPropertyChangedCallback.onPropertyChanged(npDataModel.playStatus, 0);
        }

    }

    private void removePropertyChangeObservers() {
        FsLogger.log(TAG + "-> remove callbacks");

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();

        if (speakerDataModel != null) {
            speakerDataModel.currentMode.removeOnPropertyChangedCallback(mSpeakerPropertyChangedCallback);
        }

        if (npDataModel != null) {
            npDataModel.playStatus.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
            npDataModel.trackUpdated.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
            npDataModel.graphicUri.removeOnPropertyChangedCallback(mNowPlayingPropertyChangedCallback);
        }

        EventBus.getDefault().unregister(this);
    }

    public void stopMediaNotificationService() {
        if (mContext != null && MediaNotificationService.isServiceRunning(mContext)) {
            mContext.stopService(new Intent(mContext, MediaNotificationService.class));
            MediaNotificationService.removeNotification();
            FsLogger.log(TAG + "Service stopped");
        }
    }

    public void startMediaNotificationService() {
        if (mContext!= null && PermissionsUtil.isNotificationPermissionGranted(mContext)) {

            if (mContext != null && !MediaNotificationService.isServiceRunning(mContext)) {
                NotificationMode notiMode = getNotificationMode();

                if (npDataModel != null && notiMode == NotificationMode.DMR && !npDataModel.dmrPlaying.get()) {
                    return;
                }

                if (notiMode != null) {
                    MediaNotificationService.startService(mContext, NetRemoteManager.getInstance().getCurrentRadio(), notiMode);
                }
            }
        }
    }

    public boolean isNotificationShowed() {
        return MediaNotificationService.getNotification() != null;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onAppInBackgroundEvent(AppInBackgroundEvent event) {
        FsLogger.log(TAG + "app is in background");

        removePropertyChangeObservers();
    }

    @Subscribe()
    public void onThemeChangedEvent(ThemeChangedEvent event) {
        NotificationBase n = MediaNotificationService.getNotification();

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (n != null && n.mode == getNotificationMode() && radio != null) {
            stopMediaNotificationService();
        }


    }

    private void artworkChanged(NowPlayingDataModel model) {
        if (getNotificationMode() == null) {
            return;
        }

        NotificationBase notification = MediaNotificationService.getNotification();

        if (notification != null) {
            FsLogger.log(TAG + "requesting track artwork update ");
            notification.requestTrackArtworkUpdate();
        } else {
            FsLogger.log(TAG + "noti null, track artwork not updated ");
        }
    }

    private void playStatusChanged(Radio radio, NowPlayingDataModel model) {

        if (getNotificationMode() == null) {
            return;
        }

        boolean closeService = true;

        if (model.isStopped()) {
            if (getNotificationMode() == NotificationMode.IR) {
                closeService = false;
            }
        } else if (model.isPlaying()) {
            closeService = false;
        } else if (model.isBuffering()) {
            closeService = false;
        } else if (model.isPaused()) {
            closeService = false;
        } else if (model.isIdle()) {

            closeService = false;
        } else if (model.isError()) {
            closeService = true;
        }


        if (closeService) {
            stopMediaNotificationService();
        } else {
            if (MediaNotificationService.isServiceRunning(mContext)) {
                NotificationBase notification = MediaNotificationService.getNotification();

                if (notification != null) {
                    FsLogger.log(TAG + "requesting track update ");
                    notification.requestTrackUpdate();
                } else {
                    FsLogger.log(TAG + "noti null, track not updated ");
                }
            } else {
                startMediaNotificationService();
            }
        }
    }


    private NotificationMode getNotificationMode() {

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();

        if (speakerDataModel.currentMode.get() == NodeSysCapsValidModes.Mode.DMR) {
            return NotificationMode.DMR;

        } else if (speakerDataModel.currentMode.get() == NodeSysCapsValidModes.Mode.IR) {
            return NotificationMode.IR;

        } else if (speakerDataModel.currentMode.get() == NodeSysCapsValidModes.Mode.MP) {
            return NotificationMode.MP;

        } else if (speakerDataModel.currentMode.get() == NodeSysCapsValidModes.Mode.PODCASTS) {
            return NotificationMode.MP;
        }
        else {
            FsLogger.log("playbackState unknown mode: " + speakerDataModel.currentMode.get());
        }

        return null;
    }


    private void modeChanged() {
        NotificationBase n = MediaNotificationService.getNotification();

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (n != null && n.mode == getNotificationMode() && radio != null) {
            //FsLogger.log(TAG + " Mode change detected: " + getNotificationMode() + ", Radio: " + radio);
            return;
        }

        stopMediaNotificationService();

    }

}
