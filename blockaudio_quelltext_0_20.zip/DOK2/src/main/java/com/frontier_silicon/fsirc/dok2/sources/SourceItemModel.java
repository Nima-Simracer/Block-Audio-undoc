package com.frontier_silicon.fsirc.dok2.sources;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;

public class SourceItemModel {

	public String mName;
	public long mKey = -1;
	public boolean mIsStreamable = false;

	public boolean mIsCurrentModeSelected = false;

	public String mModeId;
	public Radio mRadio = null;

    public enum CastApp {
        Spotify, TuneIn, PlayMusic, NPROne, MoreApps, NONE
    }

    // Cast apps are a special source in UNDOK, we just jump to an external app. However, in the
    // longer term there could be a tighter integration and then it would make sense to declare
    // the app as part of the constructor.
    public CastApp mApp;

	public SourceItemModel(String name, String modeId, boolean isStreamable, long key) {
		mName = name;
		mModeId = modeId;
		mKey = key;
		mIsStreamable = isStreamable;
        mApp = CastApp.NONE;
	}
}
