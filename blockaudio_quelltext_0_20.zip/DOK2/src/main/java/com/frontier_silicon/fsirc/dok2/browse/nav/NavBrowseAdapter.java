package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates.BrowseFormItemMultiselDelegate;
import com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates.BrowseListItemFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates.ListItemViewHolder;
import com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates.RecyclerViewListItemDelegate;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseManager;

public class NavBrowseAdapter extends RecyclerView.Adapter<ListItemViewHolder> {

    private RecyclerView mRecyclerView;
    private Context mContext;

	public NavBrowseAdapter(Context context) {
	    mContext = context;
    }

    @Override
    public int getItemViewType(int position) {
        return BrowseListItemFactory.getItemViewType(position, BrowseManagerFactory.NavBrowse);
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RecyclerViewListItemDelegate listItemDelegate = BrowseListItemFactory.getListItemDelegate(viewType,
                BrowseManagerFactory.NavBrowse);

        if (listItemDelegate instanceof BrowseFormItemMultiselDelegate) {
            listItemDelegate.setContext(mContext);
        }

        return listItemDelegate.onCreateViewHolder(parent);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position) {

        holder.mRecyclerViewListItemDelegate.onBindViewHolder(holder, position, this);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {

        holder.mRecyclerViewListItemDelegate.onViewRecycled(holder);
    }

    @Override
    public int getItemCount() {
        return NavBrowseManager.getInstance().getTotalCountForCurrentList();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);

        mRecyclerView = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);

        mRecyclerView = null;
        mContext = null;
    }

    public RecyclerView getRecyclerView() {
        return mRecyclerView;
    }
}
