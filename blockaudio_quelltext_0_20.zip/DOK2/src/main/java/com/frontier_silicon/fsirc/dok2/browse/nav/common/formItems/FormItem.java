package com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems;

import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;

/**
 * Created by adanaila on 10/7/2016.
 */

public class FormItem {
    private Long key;
    private NodeListItem.FormItemType type;
    private String label;
    private String description;
    private String id;

    public FormItem(Long keyP, NodeListItem.FormItemType typeP, String idP, String labelP, String descriptionP)
    {
        this.key = keyP;
        this.description = descriptionP;
        this.id = idP;
        this.type = typeP;
        this.label = labelP;
    }

    public Long getKey(){return this.key;}
    public NodeListItem.FormItemType getType(){return this.type;}
    public String getId(){return this.id;}
    public String getLabel(){return this.label;}
    public String getDescription(){return this.description;}
}
