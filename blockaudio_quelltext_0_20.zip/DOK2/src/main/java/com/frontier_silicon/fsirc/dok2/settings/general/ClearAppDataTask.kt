package com.frontier_silicon.fsirc.dok2.settings.general

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.frontier_silicon.NetRemoteLib.Discovery.deviceSerializer.DeviceDetailsSerializerManager
import com.frontier_silicon.components.common.CommonPreferences
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication
import com.frontier_silicon.fsirc.dok2.util.ThemeUtil
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences
import com.frontier_silicon.loggerlib.FsLogger
import java.io.File
import java.util.concurrent.Executor
import java.util.concurrent.Executors


class ClearAppDataTask {
    private val executor: Executor = Executors.newSingleThreadExecutor()

    fun clearAppDataAsync(callback: IComplete) {
        val runnable = ClearAppDataRunnable(callback)
        executor.execute(runnable)
    }


    class ClearAppDataRunnable constructor(callback: IComplete) : Runnable {
        private val handler: Handler = Handler(Looper.getMainLooper())
        private var callback = callback


        override fun run() {
            UndokPreferences.getInstance().clearAllPreferences()
            CommonPreferences.getInstance().clearAllPreferences()
            DeviceDetailsSerializerManager.getInstance().deleteCachedData(MainApplication.getContext())
            deleteLogFile(MainApplication.getContext())
            resetCurrentTheme()
            handler.post {
                callback?.let {
                    it.onComplete()
                }
            }
        }

        fun resetCurrentTheme() {
            CommonPreferences.getInstance().setCurrentThemeIndex(0)
            MainApplication.getContext().setTheme(ThemeUtil.getThemeResId())
        }

        fun deleteLogFile(context: Context) {
            val logFilePath: String = context.getFilesDir().toString() + "//netremotelib.txt"

            val file = File(logFilePath)
            if (file.exists()) {
                if (file.delete()) {
                    FsLogger.log("Log file deleted successfully")
                } else {
                    FsLogger.log("Log file  couldn't be deleted")
                }
            } else {
                FsLogger.log("Log file  file not existing")
            }
        }


    }

    interface IComplete {
        fun onComplete()
    }
}