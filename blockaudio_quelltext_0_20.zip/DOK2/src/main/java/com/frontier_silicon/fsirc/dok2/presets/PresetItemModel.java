package com.frontier_silicon.fsirc.dok2.presets;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;

public class PresetItemModel {

	public String mName;
	public long mKeyId;
	public String mPresetUrl;
	public String mType;

	public boolean mIsSelectable;
	public boolean mIsAddPossible;

	public Radio mRadio;
    public NodeSysCapsValidModes.Mode mMode;

    public PresetItemModel(String name, long keyId, String type, String url, boolean isSelectable, boolean isAddPossible, Radio radio, NodeSysCapsValidModes.Mode mode) {
		mName = name;
		mKeyId = keyId;
		mPresetUrl = url;
		mType = type;
		mIsSelectable = isSelectable;
		mIsAddPossible = isAddPossible;
		mRadio = radio;
		mMode = mode;
	}

	public boolean isPresetEmpty() {
    	if (mName.isEmpty() && mMode == NodeSysCapsValidModes.Mode.UnknownMode) {
    		return true;
		}

		return false;
	}

}
