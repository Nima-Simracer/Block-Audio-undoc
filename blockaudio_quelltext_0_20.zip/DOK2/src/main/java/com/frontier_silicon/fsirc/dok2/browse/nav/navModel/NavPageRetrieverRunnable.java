package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import com.frontier_silicon.NetRemoteLib.Node.BaseNavList;
import com.frontier_silicon.NetRemoteLib.Node.BaseNavStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavStatus;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.PageRetrieverRunnable;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.UnifiedBrowseListItem;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 30/06/16.
 */

public class NavPageRetrieverRunnable extends PageRetrieverRunnable{

    public NavPageRetrieverRunnable(int startIndex, Radio radio, boolean firstPageOnly, IPageRetrieverListener listener) {
        super(startIndex, radio, firstPageOnly, listener);
    }

    @Override
    public void run() {
        FsLogger.log("navigation runnable started " + mStartIndex, LogLevel.Info);

        ArrayList<UnifiedBrowseListItem> navList = new ArrayList<>();

        NodeNavStatus statusNode = RadioNavigationUtil.enableNavigation(mRadio);

        if (statusNode == null || statusNode.getValueEnum() == BaseNavStatus.Ord.FAIL ||
                statusNode.getValueEnum() == BaseNavStatus.Ord.FATAL_ERR) {
            sendNavListToListener(navList);
            dispose();
            return;
        }

        String startKey = "" + mStartIndex;
        List<BaseNavList.ListItem> returnedNavList = RadioNavigationUtil.getInstance().getNavList(mRadio, startKey, mFirstPageOnly);

        if (returnedNavList != null) {
            for (BaseNavList.ListItem li: returnedNavList) {
                navList.add(new UnifiedBrowseListItem(li));
            }
        }

        sendNavListToListener(navList);

        dispose();
    }
}
