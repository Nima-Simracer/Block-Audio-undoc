package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.ViewGroup;

/**
 * Created by lsuhov on 06/11/2016.
 */

public abstract class RecyclerViewListItemDelegate {
    public Context mContext;
    public abstract ListItemViewHolder onCreateViewHolder(ViewGroup parent);

    public abstract void onBindViewHolder(ListItemViewHolder holder, int position,
                                          RecyclerView.Adapter<ListItemViewHolder> adapter);

    public abstract void onViewRecycled(ListItemViewHolder holder);

    public void setContext(Context context) {
        mContext = context;
    }

}
