package com.frontier_silicon.fsirc.dok2.connectedSpeaker.firstConnectionTutorial

import android.app.Activity
import android.os.Build
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences
import me.toptas.fancyshowcase.FancyShowCaseQueue
import me.toptas.fancyshowcase.FancyShowCaseView
import me.toptas.fancyshowcase.listener.OnViewInflateListener

interface ITutorialListener {
    fun onSkip()
    fun onEnd()
}
class UserInitialTutorial(val tutorialListener: ITutorialListener) {


       var queue: FancyShowCaseQueue = FancyShowCaseQueue()

    fun getTutorial(activity: Activity, view: View, titleId: Int, textId: Int): FancyShowCaseView {
        var tempTutorialFancyShowCaseView: FancyShowCaseView? = null
        val titleIdString = SmartRadioStringsManager.getSmartRadioString(titleId, true)
        val textIdString = SmartRadioStringsManager.getSmartRadioString(textId, true)

        val tutorialFancyShowCaseView = FancyShowCaseView.Builder(activity)
            .focusOn(view)
            .closeOnTouch(false)
            .enableTouchOnFocusedView(false)
            .customView(R.layout.connected_tutorial_view, object: OnViewInflateListener {
                @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
                override fun onViewInflated(view: View) {
                    val tutorialCardView = view.findViewById<CardView>(R.id.tutorial_card_view)
                    val params = tutorialCardView.layoutParams as ConstraintLayout.LayoutParams

                    val highlightedViewLocation = intArrayOf(0, 0)
                    tempTutorialFancyShowCaseView!!.getLocationOnScreen(highlightedViewLocation)

                    tutorialCardView.post {
                        params.bottomMargin = highlightedViewLocation[1] + tempTutorialFancyShowCaseView!!.focusHeight * 2
                        tutorialCardView.layoutParams = params
                    }

                    val titleTextView = view.findViewById<TextView>(R.id.tutorial_title)
                    titleTextView.text = titleIdString

                    val descriptionTextView = view.findViewById<TextView>(R.id.tutorial_description)
                    descriptionTextView.text = textIdString

                    view.findViewById<Button>(R.id.nextButton).setOnClickListener {
                        tempTutorialFancyShowCaseView!!.hide()
                    }

                    view.findViewById<Button>(R.id.exitButton).setOnClickListener {
                        queue.cancel()

                        tutorialListener.let {
                            it.onSkip()
                        }
                    }
                }
            })
            .build()

        tempTutorialFancyShowCaseView = tutorialFancyShowCaseView

        return tutorialFancyShowCaseView
    }

    fun getMenuPosition(activity: Activity, titleId: Int, textId: Int, x: Int, y: Int): FancyShowCaseView {
        var tempTutorialFancyShowCaseView: FancyShowCaseView? = null

        val tutorialFancyShowCaseView = FancyShowCaseView.Builder(activity)
            .focusCircleAtPosition(x + 200,y - 20, 100)
            .closeOnTouch(false)
            .enableTouchOnFocusedView(false)
            .customView(R.layout.connected_tutorial_view, object: OnViewInflateListener {
                @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
                override fun onViewInflated(view: View) {
                    val tutorialCardView = view.findViewById<CardView>(R.id.tutorial_card_view)
                    val params = tutorialCardView.layoutParams as ConstraintLayout.LayoutParams

                    val highlightedViewLocation = intArrayOf(0, 0)
                    tempTutorialFancyShowCaseView!!.getLocationOnScreen(highlightedViewLocation)

                    tutorialCardView.post {
                        params.bottomMargin = highlightedViewLocation[1] + 100 * 4
                        tutorialCardView.layoutParams = params
                    }

                    val titleTextView = view.findViewById<TextView>(R.id.tutorial_title)
                    titleTextView.text = activity.getText(titleId)

                    val descriptionTextView = view.findViewById<TextView>(R.id.tutorial_description)
                    descriptionTextView.text = activity.getText(textId)

                    view.findViewById<Button>(R.id.nextButton).text = MainApplication.getContext().getString(R.string.tutorial_exit)
                    view.findViewById<Button>(R.id.nextButton).setOnClickListener {
                        tempTutorialFancyShowCaseView!!.hide()
                        tutorialListener.let {
                            it.onEnd()
                        }
                    }

                    view.findViewById<Button>(R.id.exitButton).setOnClickListener {
                        queue.cancel()
                    }
                }
            })
            .build()

        tempTutorialFancyShowCaseView = tutorialFancyShowCaseView

        return tutorialFancyShowCaseView
    }
}