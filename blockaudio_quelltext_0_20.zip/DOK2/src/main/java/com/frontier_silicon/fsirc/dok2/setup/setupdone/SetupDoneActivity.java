package com.frontier_silicon.fsirc.dok2.setup.setupdone;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupDoneActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;

/**
 * Created by nbalazs on 21/03/2018.
 *
 */
public class SetupDoneActivity extends SetupActivityBase {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetupDoneActivityBinding mBinding = DataBindingUtil.setContentView(this, R.layout.setup_done_activity);

        mBinding.setViewModel(new SetupDoneActivityVM(this));

        configureToolbarWithoutExitButton(R.string.setup_title_finished);
        mBinding.setupNewSpeaker.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.set_up_new_speaker, true));
        mBinding.exitSetup.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.go_to_my_home, false));
    }
}
