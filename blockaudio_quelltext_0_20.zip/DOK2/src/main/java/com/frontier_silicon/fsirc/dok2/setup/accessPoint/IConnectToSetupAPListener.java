package com.frontier_silicon.fsirc.dok2.setup.accessPoint;

public interface IConnectToSetupAPListener {
	void refreshList();
	void onConnectToApFailed();
}
