package com.frontier_silicon.fsirc.dok2.nowPlaying;

import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.NetRemoteLib.Radio.RadioVIS;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class RadioVisManager implements RadioVIS.Callback {
	private static RadioVisManager mInstance;

	private String mRadioVisLastSessionID = null;
	RadioVIS mRadioVis;

	private List<IRadioVisCallback> mListeners;
	
	private RadioVisManager() {
		mListeners = new CopyOnWriteArrayList<>();
	}
	
	public interface IRadioVisCallback {
		void onNewRadioVisImageUrl(String imageUrl);
	}
	
	public static RadioVisManager getInstance() {
		if (mInstance == null)
			mInstance = new RadioVisManager();
		
		return mInstance;
	}

	public void setListener(IRadioVisCallback listener) {
		mListeners.add(listener);
		
		if (mListeners.size() == 1) {
			updateRadioVIS();
		}
	}
	
	public void removeListener(IRadioVisCallback listener) {
		mListeners.remove(listener);
		
		if (mListeners.size() == 0)
			pauseRadioVIS();
	}
	
	void notifyNewBitmap(String imageUrl) {
		for (int i = 0; i < mListeners.size(); i++) {
			mListeners.get(i).onNewRadioVisImageUrl(imageUrl);
		}
	}
	
	private void updateRadioVIS() {
		if (!NetRemoteManager.getInstance().checkConnection())
			return;
		
		Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
		boolean changedRadio = (currentRadio == null);
		
		String currentSessionId = null;
		if (currentRadio != null)
			currentSessionId = currentRadio.getSessionId();
		
		changedRadio |= currentSessionId != null && 
				mRadioVisLastSessionID != null &&
				(!currentSessionId.contentEquals(mRadioVisLastSessionID));

        if (mRadioVis != null && mRadioVis.getRadio() != null) {
            String radioVisSessionId = mRadioVis.getRadio().getSessionId();
            if (!TextUtils.isEmpty(radioVisSessionId) && !TextUtils.isEmpty(currentSessionId)) {
                changedRadio |= !radioVisSessionId.equals(currentSessionId);
            }
        }
		  
		mRadioVisLastSessionID = currentSessionId;

		if (changedRadio) {
			/* It has changed, so have to lose the RadioVIS helper so that a new one is created below. */
			closeRadioVIS();
		}

		if (currentRadio == null)
			return;

        if (mRadioVis == null || mRadioVis.getRadio() == null) {
            if (mRadioVis == null) {
                mRadioVis = new RadioVIS(currentRadio, MainApplication.getContext());
            } else {
                mRadioVis.setRadio(currentRadio);
            }

            mRadioVis.registerCallback(this);
        }

        setRadioVisImageIfPossible();

        mRadioVis.resume();
        mRadioVis.setEnabled(true);
	}
	
	private void setRadioVisImageIfPossible() {

		if (NetRemoteManager.getInstance().checkConnection()) {
            NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();
            boolean isDABOrFMMode = false;
            if (currentMode != null) {
                isDABOrFMMode = (currentMode == NodeSysCapsValidModes.Mode.DAB || currentMode == NodeSysCapsValidModes.Mode.FM);
            }

            if (isDABOrFMMode) {

                String imageUrl = null;
                if (mRadioVis != null) {
                    imageUrl = mRadioVis.getCurrentImageURL();
                }

                notifyNewBitmap(imageUrl);
            }
		}
	}

	private void pauseRadioVIS() {
        if (mRadioVis != null)
            mRadioVis.pause();
	}

	private void closeRadioVIS() {
        if (mRadioVis != null) {
            mRadioVis.close();
            mRadioVis.deregisterCallback(this);
        }
	}

	public void cleanup() {
		closeRadioVIS();
		mRadioVisLastSessionID = "";
	}

	public void refreshRadioVis(){
        setRadioVisImageIfPossible();

		updateRadioVIS();
	}

	@Override
	public void radioVisUrlUpdate(String newUrl) {

        setRadioVisImageIfPossible();
	}

	@Override
	public void radioVisEnablementChanged(boolean enabled, ErrorCode reason) {
		if (enabled)
			return;

        NetRemote.getMainThreadExecutor().execute(() -> notifyNewBitmap(null));
	}

}
