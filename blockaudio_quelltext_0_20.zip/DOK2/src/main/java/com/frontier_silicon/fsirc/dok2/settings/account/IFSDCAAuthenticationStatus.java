package com.frontier_silicon.fsirc.dok2.settings.account;

/**
 * Created by cvladu on 08/03/2018.
 */

public interface IFSDCAAuthenticationStatus {
    void notAuthenticated();
}
