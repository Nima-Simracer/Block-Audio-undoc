package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

import android.util.Log;

import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;

public class BrowseItemModel {

    protected UnifiedBrowseListItem mNavListItem = null;

    public BrowseItemModel() {}

    public BrowseItemModel(UnifiedBrowseListItem navListItem) {
        mNavListItem = navListItem;
    }

    public String getName() {
        if (mNavListItem != null) {
            return mNavListItem.getName();
        }
        return "";
    }

    public Long getKey() {
        if (mNavListItem != null) {
            return mNavListItem.getKey();
        }
        return -1L;
    }

    public boolean isDirectory() {
        return (mNavListItem != null && mNavListItem.getType() == NodeListItem.FieldType.Directory);
    }

    public boolean isPlayable() {
        return (mNavListItem != null && mNavListItem.getType() == NodeListItem.FieldType.PlayableItem);
    }

    public boolean isSearch() {
        return (mNavListItem != null && mNavListItem.getType() == NodeListItem.FieldType.SearchDirectory);
    }

    public boolean hasArtwork() {
        return (mNavListItem != null && mNavListItem.getGraphicUri() != null && !mNavListItem.getGraphicUri().isEmpty());
    }

    public String getArtwork(){
        if (mNavListItem != null && !mNavListItem.getGraphicUri().isEmpty()) {
            return mNavListItem.getGraphicUri();
        }
        return "";
    }

    public boolean hasArtist() {
        return (mNavListItem != null && mNavListItem.getArtist() != null && !mNavListItem.getArtist().isEmpty());
    }

    public String getArtist(){
        if (mNavListItem != null) {
            return mNavListItem.getArtist();
        }
        return "";
    }

    public boolean hasContextMenu() {
        return (mNavListItem != null && mNavListItem.getContextMenu() != null && mNavListItem.getContextMenu().equals(NodeListItem.FieldContextMenu.True));
    }

    @BrowseItemType.EBrowseNavItemType
    public int getSubType(){
        if (mNavListItem != null) {
            //TODO extend if needed for more then AIRABLE message items
            switch(mNavListItem.getSubType()){
                case Text:
                    return BrowseItemType.MessageText;
                case Button:
                    return BrowseItemType.MessageButton;
            }
        }

        return BrowseItemType.NotLoadedYet;
    }

    @BrowseItemType.EBrowseNavItemType
    public int getType() {
        if (mNavListItem != null) {

            if (mNavListItem.getSubType() != null &&
                    mNavListItem.getSubType().equals(NodeListItem.FieldSubType.Disabled)) {
                return BrowseItemType.TrackNotAvailable;
            }
            Log.d("NAV TYPE", mNavListItem.getType().toString());

            switch (mNavListItem.getType()) {
                case Directory:
                    return BrowseItemType.Directory;
                case PlayableItem:
                    return BrowseItemType.PlayableItem;
                case Unknown:
                    return BrowseItemType.Unknown;
                case FormItem:
                    return BrowseItemType.FormItem;
                case MessageItem:
                    return BrowseItemType.MessageItem;
                case FetchErrItem:
                    return BrowseItemType.FetchErrItem;
                case OAuth:
                    return BrowseItemType.OAuth;
            }
        }

        return BrowseItemType.NotLoadedYet;
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof BrowseItemModel) {
            BrowseItemModel browseItem = (BrowseItemModel) other;
            return this.mNavListItem.equals(browseItem.mNavListItem);
        } else {
            return false;
        }
    }
}
