package com.frontier_silicon.fsirc.dok2.setup.AccessPointConfig;

import android.net.wifi.ScanResult;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;

public class AccessPointModel {
	private boolean mIsGroupHeader = false;
	private ScanResult mScanResult;
	private String mTitle;
	private int mSignalStrength;

    public AccessPointModel(String title) {
		this.mTitle = title;
		this.mIsGroupHeader = true;
	}
	
	public AccessPointModel(ScanResult scanResult) {
		this.mScanResult = scanResult;
		this.mIsGroupHeader = false;
        calculateSignalLevel();
	}
	
	public AccessPointModel(String title, boolean fakeItem) {
		this.mTitle = title;
		this.mIsGroupHeader = false;
	}
	
	public boolean getIsGroupHeader() {
		return this.mIsGroupHeader;
	}
	
	public String getTitle() {
		return this.mTitle;
	}
	
	public ScanResult getScanResult() {
		return this.mScanResult;
	}

    public int getSignalStrength() {
        return  this.mSignalStrength;
    }

	private void calculateSignalLevel() {
		mSignalStrength = AccessPointUtil.getWifiManager().calculateSignalLevel(mScanResult.level,4);
	}
}
