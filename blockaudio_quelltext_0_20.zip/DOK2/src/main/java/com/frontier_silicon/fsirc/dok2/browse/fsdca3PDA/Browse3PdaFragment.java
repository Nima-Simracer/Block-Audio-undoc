package com.frontier_silicon.fsirc.dok2.browse.fsdca3PDA;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.databinding.Browse3pdaFragmentBinding;

public class Browse3PdaFragment extends BaseFragment implements IChildFragment, IPageSwitchListener {
    public static final String FRAGMENT_TAG = "TAG_BROWSE_3PDA_FRAGMENT";
    public Browse3pdaFragmentBinding mBinding;
    private Browse3PdaViewModel mViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mBinding = DataBindingUtil.inflate(inflater, R.layout.browse_3pda_fragment, container, false );
        mViewModel = new Browse3PdaViewModel();
        mBinding.setViewModel(mViewModel);
        mBinding.fsdcaNews.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.fsdca_how_to_use, false));
        return mBinding.getRoot();
    }

    @Override
    public boolean isBackButtonHandledByFragment(boolean upButton) {
        return false;
    }

    @Override
    public void onBackButton() {

    }

    @Override
    public String getStaticTag() {
        return FRAGMENT_TAG;
    }

    @Override
    public void onFragmentActivated() {

    }

    @Override
    public void onFragmentDeactivated() {

    }
}
