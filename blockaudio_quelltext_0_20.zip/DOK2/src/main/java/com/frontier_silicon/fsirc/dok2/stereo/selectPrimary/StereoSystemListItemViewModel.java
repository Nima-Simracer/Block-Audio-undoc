package com.frontier_silicon.fsirc.dok2.stereo.selectPrimary;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.os.Bundle;
import android.view.View;

import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.stereo.StereoBundleHelper;
import com.frontier_silicon.fsirc.dok2.stereo.editSystem.EditStereoSystemActivity;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

/**
 * Created by lsuhov on 10/08/2017.
 */

public class StereoSystemListItemViewModel {

    public ObservableField<String> name = new ObservableField<>();
    public ObservableBoolean isIncomplete = new ObservableBoolean(false);

    private StereoItemModel mStereoItemModel;
    private Activity mActivity;

    StereoSystemListItemViewModel(StereoItemModel stereoItemModel, Activity activity) {
        mStereoItemModel = stereoItemModel;
        mActivity = activity;

        if (stereoItemModel.deviceModels == null) {
            FsLogger.log("List of StereoItemModel seems to be invalid", LogLevel.Error);
            return;
        }

        init();
    }

    private void init() {
        updateName();
        checkIfSystemIsIncomplete();
    }

    private void checkIfSystemIsIncomplete() {
        isIncomplete.set(mStereoItemModel.isIncomplete());
    }

    private void updateName() {
        name.set(mStereoItemModel.systemName);
    }

    public void onListItemClicked(View v) {
        Bundle bundle = new Bundle();
        bundle.putString(StereoBundleHelper.SYSTEM_ID, mStereoItemModel.systemId);

        NavigationHelper.goToActivity(mActivity, EditStereoSystemActivity.class,
                NavigationHelper.AnimationType.SlideToLeft, false, bundle);
    }

    public void dispose() {
        mStereoItemModel = null;
        mActivity = null;
    }
}
