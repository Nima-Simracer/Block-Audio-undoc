package com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable;

import com.frontier_silicon.NetRemoteLib.Node.NodeNavContextFormData;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormSetRunnable;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

public class ContextFormSetRunnable extends FormSetRunnable {

    public ContextFormSetRunnable(Radio radio, String params, long id, INavFormDataSendListener listener) {
        super(radio, params, id, listener);
    }

    @Override
    public void run() {
        FsLogger.log("form data set runnable started ", LogLevel.Info);

        if (NetRemoteManager.getInstance().checkConnection(mRadio)) {
            NodeNavContextFormData node = new NodeNavContextFormData(this.mParams);
            if(mRadio.nodeSyncSetter(node).set())
                sendResultToListener(RadioNavigationUtil.getInstance().navigateContextItem(mRadio,mId));
            else
                sendResultToListener(false);
        }
        dispose();
    }
}
