package com.frontier_silicon.fsirc.dok2.connectedSpeaker;

public interface IChildFragment {

	boolean isBackButtonHandledByFragment(boolean upButton);
	void onBackButton();
	String getStaticTag();
}
