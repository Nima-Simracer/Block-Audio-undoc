package com.frontier_silicon.fsirc.dok2.update;

/**
 * Created by lsuhov on 6/17/2015.
 */
public interface IsuBackgroundListener {
    void onNewIsuResults();
}
