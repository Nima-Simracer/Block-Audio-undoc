package com.frontier_silicon.fsirc.dok2.speakerData;

import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import androidx.databinding.ObservableInt;

import com.frontier_silicon.NetRemoteLib.Node.NodeCastTos;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIpodDockStatus;

/**
 * This class is intended to keep general up to date data, about the current radio
 *
 * Created by lsuhov on 07/04/2017.
 */

public class SpeakerDataModel {

    public ObservableField<NodeSysCapsValidModes.Mode> currentMode = new ObservableField<>(NodeSysCapsValidModes.Mode.UnknownMode);
    public ObservableBoolean isNavigationSupportedForCurrentMode = new ObservableBoolean(false);
    public ObservableBoolean isPresetNavigationSupported = new ObservableBoolean(false);
    public ObservableBoolean isPresetEditionSupported = new ObservableBoolean(false);
    public ObservableBoolean isInStandby = new ObservableBoolean(false);
    public ObservableField<String> friendlyName = new ObservableField<>();
    public ObservableField<NodeSysIpodDockStatus.Ord> ipodDockStatus = new ObservableField<>();
    public ObservableField<NodeCastTos.Ord> castTosStatus = new ObservableField<>();
    public ObservableInt maxNumberOfMultiroomClients = new ObservableInt(4);
    public ObservableBoolean isCLearButtonFromPresetsVisible = new ObservableBoolean(false);
    public ObservableBoolean isAvsLoggedIn = new ObservableBoolean(false);
}
