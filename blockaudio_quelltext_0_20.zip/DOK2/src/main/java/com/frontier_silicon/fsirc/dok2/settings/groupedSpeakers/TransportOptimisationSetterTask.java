package com.frontier_silicon.fsirc.dok2.settings.groupedSpeakers;

import android.content.Context;

import com.frontier_silicon.components.common.BaseShowProgressDialogTask;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.connection.AfterConnectionNodesSetter;
import com.frontier_silicon.fsirc.dok2.R;

import java.util.List;

/**
 * Created by lsuhov on 16/03/16.
 */
public class TransportOptimisationSetterTask extends BaseShowProgressDialogTask<Boolean> {
    private boolean mTransportOptimisationValue;

    public TransportOptimisationSetterTask(Context context, boolean transportOptimisationValue) {
        mContext = context;
        mTransportOptimisationValue = transportOptimisationValue;

        mDialogKey = "transport_optimisation_setter";
        mLoadingMessage = mContext.getString(R.string.please_wait);
    }

    @Override
    protected Boolean doInBackground(Integer... params) {
        MultiroomGroupManager multiroomGroupManager = MultiroomGroupManager.getInstance();
        List<MultiroomItemModel> multiroomItems = multiroomGroupManager.getItemModelsFromCurrentGroup();
        for (int i = 0; i < multiroomItems.size(); i++) {
            MultiroomItemModel multiroomItemModel = multiroomItems.get(i);

            AfterConnectionNodesSetter.setTransportOptimisationSync(multiroomItemModel.getRadio(), mTransportOptimisationValue);
        }

        return true;
    }

    @Override
    protected void onPostExecute(Boolean result) {
        super.onPostExecute(result);

        dispose();
    }
}
