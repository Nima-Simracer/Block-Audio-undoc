package com.frontier_silicon.fsirc.dok2.setup.connectionType;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SetupSelectConnectionTypeActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;


/**
 * Created by nbalazs on 07/03/2018.
 *
 */

public class SelectConnectionTypeActivity extends SetupActivityBase {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetupSelectConnectionTypeActivityBinding mBinding = DataBindingUtil.setContentView(this, R.layout.setup_select_connection_type_activity);

        mBinding.setViewModel(new SelectConnectionTypeActivityVM(this));

        configureToolbarWithExitButton(R.string.setup_title_choose_connection_type);
    }

    @Override
    protected void onStart() {
        super.onStart();
        enableRadioConnectionCallbackAndWiFiMonitor();
    }
}
