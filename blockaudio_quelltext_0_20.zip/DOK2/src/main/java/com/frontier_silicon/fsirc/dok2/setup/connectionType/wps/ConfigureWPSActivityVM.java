package com.frontier_silicon.fsirc.dok2.setup.connectionType.wps;

import android.app.Activity;

import com.frontier_silicon.components.setup.RadioNetworkConfig.EConnectionType;
import com.frontier_silicon.components.setup.RadioNetworkConfig.RadioNetworkConfigParams;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.finishing.FinishingSetupActivity;

/**
 * Created by nbalazs on 08/03/2018.
 */

public final class ConfigureWPSActivityVM {

    private Activity mActivity;

    ConfigureWPSActivityVM(Activity activity) {
        mActivity = activity;
    }

    public void onNextPressed() {
        RadioNetworkConfigParams configParams = new RadioNetworkConfigParams();
        configParams.mConnectionType = EConnectionType.WPS;

        SetupManager.getInstance().setNetworkConfigParams(configParams);

        NavigationHelper.goToActivity(mActivity, FinishingSetupActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    public void onBackPressed() {
        mActivity.onBackPressed();
    }
}
