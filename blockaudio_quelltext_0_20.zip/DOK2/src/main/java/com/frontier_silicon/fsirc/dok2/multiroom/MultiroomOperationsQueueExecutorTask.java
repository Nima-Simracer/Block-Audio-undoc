package com.frontier_silicon.fsirc.dok2.multiroom;

import android.content.Context;

import com.frontier_silicon.components.common.BaseShowProgressDialogTask;
import com.frontier_silicon.components.multiroom.IMultiroomOperationListener;
import com.frontier_silicon.components.multiroom.MultiroomOperation;
import com.frontier_silicon.components.multiroom.MultiroomOperationResult;
import com.frontier_silicon.components.multiroom.MultiroomOperationsQueueExecutor;
import com.frontier_silicon.fsirc.dok2.R;

import java.util.List;

/**
 * Created by lsuhov on 20/02/2017.
 */

public class MultiroomOperationsQueueExecutorTask extends BaseShowProgressDialogTask<MultiroomOperationResult> {

    private IMultiroomOperationListener mListener;
    private List<MultiroomOperation> mOperationsList;

    public MultiroomOperationsQueueExecutorTask(Context context, List<MultiroomOperation> operationsList,
                                                IMultiroomOperationListener listener) {
        mContext = context;
        mListener = listener;
        mOperationsList = operationsList;

        mDialogKey = "multiroom_groups_update";
        mLoadingMessage = mContext.getString(R.string.multiroom_update_task_dlg);
        TASK_TIMEOUT_MS = mOperationsList.size() * TASK_TIMEOUT_MS;
        mDialogCancelable = false;
    }

    @Override
    protected MultiroomOperationResult doInBackground(Integer... params) {
        return new MultiroomOperationsQueueExecutor(mOperationsList).execute();
    }

    @Override
    protected void onPostExecute(MultiroomOperationResult result) {
        super.onPostExecute(result);

        if (result == null) {
            result = new MultiroomOperationResult();
            result.mOperationResult = MultiroomOperationResult.OperationResult.TIMEOUT_ERR;
        }

        if (mListener != null) {
            mListener.onOperationComplete(result);
            mListener = null;
        }
    }
}
