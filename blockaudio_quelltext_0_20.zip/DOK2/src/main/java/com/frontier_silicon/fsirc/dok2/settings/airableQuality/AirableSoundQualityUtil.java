package com.frontier_silicon.fsirc.dok2.settings.airableQuality;

import android.os.AsyncTask;
import android.util.Log;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioAirableQuality;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioQuality;
import com.frontier_silicon.NetRemoteLib.Radio.ErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.Vector;

public class AirableSoundQualityUtil {
    private Vector<IAirableQualitySoundListener> mListeners;
    private Radio mClientRadio;
    private boolean mUseLegacyNode = true;


    public AirableSoundQualityUtil() {
        mListeners = new Vector<>();
    }

    synchronized public boolean removeListener(IAirableQualitySoundListener listener) {
        return mListeners.remove(listener);
    }

    synchronized public boolean addListener(IAirableQualitySoundListener listener) {
        return mListeners.add(listener);
    }

    synchronized public void notifyAirableSoundQualityUpdate(Long eqList) {
        for (IAirableQualitySoundListener listener : mListeners) {
            listener.onAirableQualitySoundUpdate(eqList);
        }
    }

    public void checkWhichNodeShouldBeUsed() {
        if (mClientRadio == null) {
            return;
        }

        mClientRadio.setNode(new NodeSysAudioQuality(100l), new ISetNodeCallback() {
            @Override
            public void setNodeSuccess(NodeInfo node) {
                updateSelectedSoundQuality();
            }

            @Override
            public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                if (error.getFSStatus() == ErrorResponse.FSStatusCode.FS_NODE_DOES_NOT_EXIST) {
                    mUseLegacyNode = true;
                } else {
                    mUseLegacyNode = false;
                }

                updateSelectedSoundQuality();
            }
        });
    }

    public void setAirableSoundQuality(long keyId) {
        if (mUseLegacyNode) {
            mClientRadio.setNode(new NodeSysAudioAirableQuality(keyId), false);
        } else {
            mClientRadio.setNode(new NodeSysAudioQuality(keyId), false);
        }
    }

    public void updateSelectedSoundQuality() {
        UpdateEqualizerPresetsTask updateEqualizersTask = new UpdateEqualizerPresetsTask();
        TaskHelper.execute(updateEqualizersTask);
    }

    public void setClientRadio(Radio clientRadio) {
        mClientRadio = clientRadio;
    }

    private class UpdateEqualizerPresetsTask extends AsyncTask<Void, Integer, Boolean> {
        private long mAirplayAudiQuality;

        public UpdateEqualizerPresetsTask() {
           }

        @Override
        protected Boolean doInBackground(Void... arg0) {
            boolean result = false;
            mAirplayAudiQuality = -1;

            Radio radio = mClientRadio;

            if (radio != null)
                if (mUseLegacyNode) {
                    result = getAirplayQualitySoundNodeResult(radio);
                } else {
                    result = getQualitySoundNodeResult(radio);
                }

            return result;
        }

        private boolean getAirplayQualitySoundNodeResult(Radio radio) {
            if (radio == null) {
                return false;
            }
            radio.getNode(NodeSysAudioAirableQuality.class, true, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    mAirplayAudiQuality = ((NodeSysAudioAirableQuality) node).getValue();
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    FsLogger.log("getListNode failed " + nodeType + " " + error, LogLevel.Error);
                }
            });
            return true;
        }

        private boolean getQualitySoundNodeResult(Radio radio) {
            if (radio == null) {
                return false;
            }
            radio.getNode(NodeSysAudioQuality.class, true, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    mAirplayAudiQuality = ((NodeSysAudioQuality) node).getValue();
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    FsLogger.log("getListNode failed " + nodeType + " " + error, LogLevel.Error);
                }
            });
            return true;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            notifyAirableSoundQualityUpdate(mAirplayAudiQuality);
        }
    }

    public void dispose() {
        mListeners.clear();
        mClientRadio = null;
    }
}