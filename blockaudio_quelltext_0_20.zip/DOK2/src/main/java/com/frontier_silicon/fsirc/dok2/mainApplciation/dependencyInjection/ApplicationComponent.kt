package com.frontier_silicon.fsirc.dok2.mainApplciation.dependencyInjection

import android.app.Application
import com.frontier_silicon.fsirc.dok2.presets.di.PresetsComponent
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.di.OpenSourceSoftwareComponent
import com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.di.ConnectivityAssistantComponent
import dagger.BindsInstance
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component
interface ApplicationComponent {

    @Component.Builder
    interface Builder {

        @BindsInstance
        fun application(application: Application): Builder

        fun build(): ApplicationComponent
    }

    fun getConnectivityAssistantFactory(): ConnectivityAssistantComponent.Factory

    fun getPresetsComponentFactory(): PresetsComponent.Builder

    fun getOpenSourceSoftwareBuilder(): OpenSourceSoftwareComponent.Builder
}
