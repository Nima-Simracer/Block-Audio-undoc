package com.frontier_silicon.fsirc.dok2;

import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by lsuhov on 28/11/2016.
 */

public class ThreadPoolForNetworklessOperations {
    private static ThreadPoolForNetworklessOperations mInstance;

    private final int corePoolSize = 0;
    private final int maxPoolSize = 1;
    // Sets the amount of time an idle thread waits before terminating
    private final int KEEP_ALIVE_TIME = 500;
    // Sets the Time Unit to seconds
    private final TimeUnit KEEP_ALIVE_TIME_UNIT = TimeUnit.MILLISECONDS;
    private BlockingQueue<Runnable> mNavigationRunnablesQueue = new LinkedBlockingQueue<>(100);
    private ExecutorService mThreadPoolExecutor;

    private ThreadPoolForNetworklessOperations() {
        mThreadPoolExecutor = new ThreadPoolExecutor(corePoolSize, maxPoolSize, KEEP_ALIVE_TIME,
                KEEP_ALIVE_TIME_UNIT, mNavigationRunnablesQueue, new RejectedExecutionHandler() {
            @Override
            public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
                FsLogger.log("ThreadPoolForNetworklessOperations: thread execution was rejected", LogLevel.Error);
            }
        });
    }

    public static ThreadPoolForNetworklessOperations getInstance() {
        if (mInstance == null) {
            mInstance = new ThreadPoolForNetworklessOperations();
        }

        return mInstance;
    }

    public void submit(Runnable runnable) {
        mThreadPoolExecutor.submit(runnable);
    }
}
