package com.frontier_silicon.fsirc.dok2.stereo.selectSecondary;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.os.Bundle;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.stereo.StereoBundleHelper;
import com.frontier_silicon.fsirc.dok2.stereo.StereoSpeakerListItemViewModel;
import com.frontier_silicon.fsirc.dok2.stereo.pairStereo.PairStereoActivity;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

/**
 * Created by lsuhov on 10/08/2017.
 */

public class SecondarySpeakerListItemViewModel extends StereoSpeakerListItemViewModel {

    private StereoItemModel mPrimaryStereoItemModel;

    public SecondarySpeakerListItemViewModel(StereoItemModel stereoItemModel,
                                             StereoItemModel primaryStereoItemModel, Activity activity) {
        super(stereoItemModel, activity);

        mPrimaryStereoItemModel = primaryStereoItemModel;
    }

    @Override
    public void onListItemClicked(View v) {
        Radio primaryRadio = mPrimaryStereoItemModel.deviceModel.mRadio;
        Radio secondaryRadio = mStereoItemModel.deviceModel.mRadio;
        if (primaryRadio == null || secondaryRadio == null) {
            FsLogger.log("Primary or secondary radio is null", LogLevel.Error);
            return;
        }

        Bundle bundle = new Bundle();
        bundle.putString(StereoBundleHelper.PRIMARY_SPEAKER_UDN, primaryRadio.getUDN());
        bundle.putString(StereoBundleHelper.SECONDARY_SPEAKER_UDN, secondaryRadio.getUDN());

        NavigationHelper.goToActivity(mActivity, PairStereoActivity.class,
                NavigationHelper.AnimationType.SlideToLeft, false, bundle);
    }

    @Override
    public void dispose() {
        super.dispose();

        mPrimaryStereoItemModel = null;
    }
}
