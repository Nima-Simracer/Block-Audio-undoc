package com.frontier_silicon.fsirc.dok2.setup.fsdca;

import android.app.Activity;
import android.content.Context;

import androidx.appcompat.app.AlertDialog;
import androidx.databinding.ObservableBoolean;
import android.os.Bundle;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.settings.account.FSAuthManager;
import com.frontier_silicon.fsirc.dok2.settings.account.FSDCALoginActivity;
import com.frontier_silicon.fsirc.dok2.settings.account.OAuthToken;
import com.frontier_silicon.fsirc.dok2.settings.account.addDevice.AddDeviceManager;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.setupdone.SetupDoneActivity;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

public class SetupFSDCAAssociationViewModel {
    private static String START_ASSOCIATION_AUTOMATICALLY = "START_ASSOCIATION_AUTOMATICALLY";
    private Activity mActivity;
    public ObservableBoolean isProgressBarVisible = new ObservableBoolean(false);
    public ObservableBoolean isAssociateButtonVisible = new ObservableBoolean(true);

    public SetupFSDCAAssociationViewModel(Activity activity) {
        mActivity = activity;

        checkIfAssociationShouldStartAutomatically();
    }

    private void checkIfAssociationShouldStartAutomatically() {
        Bundle bundle = mActivity.getIntent().getExtras();
        if (bundle != null) {
           if (bundle.getBoolean(START_ASSOCIATION_AUTOMATICALLY, false)) {
               associateFsdcaSpeakerToUndokAccount();
           }
        }
    }


    public void onAssociationButtonClicked() {
        associateFsdcaSpeakerToUndokAccount();
    }

    public void onSkipButtonClicked() {
        NavigationHelper.goToActivity(mActivity, SetupDoneActivity.class);
    }

    private void associateFsdcaSpeakerToUndokAccount() {
        isProgressBarVisible.set(true);

        FSAuthManager.getInstance().getToken(new FSAuthManager.OnToken() {
            @Override
            public void onToken(OAuthToken token) {
                startAssociationProcess();
            }

            @Override
            public void onFailed(FSAuthManager.Error error) {
                NavigationHelper.goToActivity(mActivity, FSDCALoginActivity.class);
            }
        });
    }

    private void startAssociationProcess() {
        Radio radio = SetupManager.getInstance().getRadioForNextSetupSteps();
        FSAuthManager.getInstance().getAssociatedDevices(() -> {
            tryToAssociateSpeaker(radio);
        });
    }

    private void tryToAssociateSpeaker(Radio radio) {
        if (!AddDeviceManager.getInstance().isASpeakerWithTheSameNameAlreadyAssociated(radio)) {
           associateSpeaker(radio);
        } else {
            isProgressBarVisible.set(false);
            isAssociateButtonVisible.set(false);
            displayAlertDialogForExistingSpeaker();
        }
    }

    private void displayAlertDialogForExistingSpeaker() {
        Context context = MainApplication.getContext();

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(MainApplication.getCurrentActivity());
        builder.setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.fsdca_speaker_already_associated_title, true))
                .setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.fsdca_speaker_already_associated_message, true))
                .setNeutralButton(android.R.string.ok, null)
                .create().show();
    }

    private void associateSpeaker(Radio radio) {
        AddDeviceManager.getInstance().associateSpeakerWithUndokAccount(radio, success -> {
            if (success) {
                isProgressBarVisible.set(false);
                NavigationHelper.goToActivity(mActivity, SetupDoneActivity.class);
            } else {
                isProgressBarVisible.set(false);
                Toast.makeText(mActivity, mActivity.getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
            }
        });
    }
}
