package com.frontier_silicon.fsirc.dok2.settings;

import java.util.List;

public interface ISettingsControlListener {

	void onSettingsUpdated(List<SettingsItemModel> settingsList);
}
