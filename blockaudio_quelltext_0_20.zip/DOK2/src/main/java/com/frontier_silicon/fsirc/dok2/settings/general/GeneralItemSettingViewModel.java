package com.frontier_silicon.fsirc.dok2.settings.general;

import android.app.Activity;
import android.content.Intent;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.net.Uri;
import androidx.core.app.ShareCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AlertDialog;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;

import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.gdpr.GDPRActivity;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.notifications.ThemeChangedEvent;
import com.frontier_silicon.fsirc.dok2.settings.FWVersionRunnable;
import com.frontier_silicon.fsirc.dok2.settings.SettingsItemModel;
import com.frontier_silicon.fsirc.dok2.settings.SettingsType;
import com.frontier_silicon.fsirc.dok2.settings.about.AboutActivity;
import com.frontier_silicon.fsirc.dok2.settings.account.FSAuthManager;
import com.frontier_silicon.fsirc.dok2.settings.account.FSDCALoginActivity;
import com.frontier_silicon.fsirc.dok2.settings.account.FSDCAMainActivity;
import com.frontier_silicon.fsirc.dok2.settings.account.OAuthToken;
import com.frontier_silicon.fsirc.dok2.settings.gdpr.SettingsWebViewActivity;
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.OpenSourceSoftwareActivity;
import com.frontier_silicon.fsirc.dok2.settings.speakerList.SpeakerListSettingsActivity;
import com.frontier_silicon.fsirc.dok2.settings.theme.ThemeDialogManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemeUtil;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;

import org.greenrobot.eventbus.EventBus;

import java.io.File;

/**
 * Created by lsuhov on 11/10/2017.
 */

public class GeneralItemSettingViewModel {

    public ObservableField<String> name = new ObservableField<>();
    public ObservableBoolean showCheckbox = new ObservableBoolean(false);
    public ObservableBoolean isChecked = new ObservableBoolean(false);
    public ObservableBoolean showChevron = new ObservableBoolean(false);
    public ObservableBoolean showFWVersionProgressBar = new ObservableBoolean(false);
    public ObservableBoolean isScrollingEnable = new ObservableBoolean(true);

    private SettingsItemModel mSettingsItemModel;
    private Activity mActivity;
    private long mPostDelayedId;

    public GeneralItemSettingViewModel(SettingsItemModel settingsItemModel, Activity activity) {
        mSettingsItemModel = settingsItemModel;
        mActivity = activity;

        init();
    }

    private void init() {
        name.set(mSettingsItemModel.mName);
        showCheckbox.set(mSettingsItemModel.mIsCheckable);
        isChecked.set(mSettingsItemModel.mCheckValue);
        showChevron.set(mSettingsItemModel.mShowChevron);
        isScrollingEnable.set(mSettingsItemModel.mShouldScroll);
    }

    public void onListItemClicked(View v) {
        Bundle bundle = new Bundle();
        switch (mSettingsItemModel.mType) {
            case SPEAKER_LIST:

                NavigationHelper.goToActivity(mActivity, SpeakerListSettingsActivity.class);
                break;

            case THEMES:
                showSwitchThemeDialog();
                break;

            case IR_STATION_SUGGESTION:
                showIRStationSuggestionInBrowser();
                break;

            case SEND_LOG:
                showDialogForSendingLogs();
                break;

            case ACCOUNT_MANAGER:
               startProgressBarWithDelay();
                goToFsdcaActivityProperly();
                break;

            case ABOUT_APP:
                NavigationHelper.goToActivity(mActivity, AboutActivity.class);
                break;

            case EUROPEAN_DATA:
                bundle.putString("SETTINGS_TYPE_KEY", SettingsType.EUROPEAN_DATA.name());
                NavigationHelper.goToActivity(mActivity, SettingsWebViewActivity.class, bundle);
                break;

            case IT_SERVICE_STATUS:
                bundle.putString("SETTINGS_TYPE_KEY", SettingsType.IT_SERVICE_STATUS.name());
                NavigationHelper.goToActivity(mActivity, SettingsWebViewActivity.class, bundle);
                break;

            case FAQ:
                bundle.putString("SETTINGS_TYPE_KEY", SettingsType.FAQ.name());
                NavigationHelper.goToActivity(mActivity, SettingsWebViewActivity.class, bundle);
                break;

            case CLEAR_APP_DATA:
                showClearAppDataDialog();
                break;

            case OPEN_SOURCE_SOFTWARE:
                NavigationHelper.goToActivity(mActivity, OpenSourceSoftwareActivity.class, bundle);
                break;
        }
    }

    private void startProgressBarWithDelay() {
        Runnable runnable = () -> showFWVersionProgressBar.set(true);

        mPostDelayedId = DelayedPostsManager.getInstance().registerNewCallbackID();
        DelayedPostsManager.getInstance().postDelayed(runnable, mPostDelayedId, 1000);
    }

    private void stopProgressBar() {
        DelayedPostsManager.getInstance().removeCallbackId(mPostDelayedId);
    }

    private void goToFsdcaActivityProperly() {
        FSAuthManager.getInstance().getToken(new FSAuthManager.OnToken() {
            @Override
            public void onToken(OAuthToken token) {
                NavigationHelper.goToActivity(mActivity, FSDCAMainActivity.class);
                stopProgressBar();
            }

            @Override
            public void onFailed(FSAuthManager.Error error) {
                NavigationHelper.goToActivity(mActivity, FSDCALoginActivity.class);
                stopProgressBar();
            }
        });
    }

    private void showIRStationSuggestionInBrowser() {
        String url = mActivity.getString(R.string.ir_station_suggestion_url);
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        mActivity.startActivity(browserIntent);
    }

    private void emailLogToSupport(String problemReportedByUser) {
        showFWVersionProgressBar.set(true);
        FWVersionRunnable runnable = new FWVersionRunnable(fwVersion -> {
            if (DokUiUtils.isDestroyed(mActivity)) {
                return;
            }
            showFWVersionProgressBar.set(false);
            composeEmail(fwVersion, problemReportedByUser);
        });

        Thread thread = new Thread(runnable);
        thread.start();
    }

    private void showDialogForSendingLogs() {
        AlertDialog.Builder dialogBuilder = ThemedAlertDialogBuilder.create(mActivity);
        LayoutInflater inflater = mActivity.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.send_log_dialog, null);
        dialogBuilder.setView(dialogView);

        EditText editText = dialogView.findViewById(R.id.descriptionTextView);
        dialogBuilder.setPositiveButton(android.R.string.ok, (dialog, which) -> {
            emailLogToSupport(editText.getText().toString());
        });

        dialogBuilder.setNegativeButton(android.R.string.cancel, null);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
        DialogsHolder.addDialogToCollection("send_Log_dialog", alertDialog);
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        setTextWatcher(editText, alertDialog);
    }

    private void setTextWatcher(EditText editText, AlertDialog alertDialog) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (editText.length() < 25) {
                    alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                } else {
                    alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                }
            }
        });
    }



    private void composeEmail(String fwVersion, String problemReportedByUser) {
        final String supportEmail = mActivity.getString(R.string.contact_link);

        String logFilePath = mActivity.getFilesDir() + "//netremotelib.txt";

        if (TextUtils.isEmpty(logFilePath)) {
            return;
        }

        ShareCompat.IntentBuilder builder = ShareCompat.IntentBuilder.from(mActivity);
        builder.setType("message/rfc822");
        builder.addEmailTo(supportEmail);
        builder.setSubject(mActivity.getString(R.string.feedback_email_title));
        String feedBackEmailBody = problemReportedByUser + "\n" + mActivity.getString(R.string.feedback_email_body_logs);

        builder.setText(feedBackEmailBody +  DokUiUtils.getInfoForFeedbackAndLogs(DokUiUtils.FeedbackType.Logs,fwVersion, mActivity));
        builder.addStream(
                FileProvider.getUriForFile(mActivity,
                        mActivity.getApplicationContext().getPackageName() + ".util.LocalFileProvider",
                        new File(logFilePath))
        );

        builder.setChooserTitle("email logs");
        builder.startChooser();
    }

    private void showSwitchThemeDialog() {
        ThemeDialogManager.getInstance().showDialog(mActivity, (dialog, which) -> {
            CommonPreferences.getInstance().setCurrentThemeIndex(which);
            MainApplication.getContext().setTheme(ThemeUtil.getThemeResId());

            dialog.dismiss();

            NavigationHelper.goToHomeAndClearActivityStack(mActivity);
            EventBus.getDefault().post(new ThemeChangedEvent());
        });
    }

    public void onCheckedChanged(CompoundButton buttonView, boolean checked) {
        if (mSettingsItemModel.mType == SettingsType.LOGGING_ENABLED) {
            mSettingsItemModel.mCheckValue = checked;
            this.isChecked.set(checked);

            CommonPreferences.getInstance().setLoggingEnabled(checked);
            MainApplication.setLoggingActive(checked);
        } else if (mSettingsItemModel.mType == SettingsType.SCROLLING_ENABLED) {
            mSettingsItemModel.mCheckValue = checked;
            this.isChecked.set(checked);
        UndokPreferences.getInstance().setScrollingEnabled(checked);
        EventBus.getDefault().post(new ScrollStateEvent());

        }
    }

    private void showClearAppDataDialog() {
        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mActivity);
        builder.setTitle(mActivity.getString(R.string.clear_app_data_title))
                .setMessage(mActivity.getString(R.string.clear_app_data_message))
                .setPositiveButton(android.R.string.ok, (dialog, id) -> {
                   clearAppData();
                })
                .setNegativeButton(android.R.string.cancel, null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void clearAppData() {
        ClearAppDataTask task = new ClearAppDataTask();

        task.clearAppDataAsync(() -> {
            if (mActivity != null) {
                mActivity.finishAffinity();
                openGDPRActivity();
            }
        });
    }

    public void openGDPRActivity() {
        NavigationHelper.goToActivity(mActivity, GDPRActivity.class, NavigationHelper.AnimationType.SlideToLeft, true);
    }

    public void dispose() {
        mSettingsItemModel = null;
        mActivity = null;
    }
}
