package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;

/**
 * Created by lsuhov on 30/06/16.
 */

public abstract class BrowsePageModel {

    protected int startIndex;
    public List<BrowseItemModel> browseIRItemModels = new ArrayList<>();
    public boolean searchItemWasFound = false;
    public Long searchItemKey = -1L;

    protected ExecutorService mExecutorService;
    protected boolean itemsWereRetrieved = false;
    protected int numberOfRetries = 0;
    protected final int maxNumberOfRetries = 2;
    protected final Object mLock = new Object();
    protected Queue<BrowseItemWaitingInfo> queueOfListeners = new ConcurrentLinkedQueue<>();
    protected boolean mIsDisposed = false;

    public BrowsePageModel(int key, ExecutorService executorService) {
        startIndex = key;
        mExecutorService = executorService;

        startRetrievingBrowsePage();
    }

    public BrowsePageModel(int key, List<UnifiedBrowseListItem> listItems, ExecutorService executorService) {
        startIndex = key;
        mExecutorService = executorService;

        parseBrowseList(listItems);
    }

    public void getBrowseItemModelAsync(int position, IBrowseItemModelRetrieveListener listener) {
        if (mIsDisposed) {
            return;
        }

        if (itemsWereRetrieved) {
            if (position < browseIRItemModels.size()) {
                listener.onBrowseItemModelRetrieved(browseIRItemModels.get(position));
            } else {
                if (numberOfRetries < maxNumberOfRetries) {
                    FsLogger.log("Requested BrowseItem is not existent. page " + startIndex +
                            ", position. Restarting retrieval" + position, LogLevel.Error);

                    addListenerToQueue(position, listener);

                    numberOfRetries++;
                    startRetrievingBrowsePage();
                } else {
                    listener.onBrowseItemModelRetrieved(null);
                }
            }
        } else {
            addListenerToQueue(position, listener);
        }
    }

    public BrowseItemModel tryGetBrowseItemModel(int position) {
        if (itemsWereRetrieved) {
             if (position < browseIRItemModels.size()) {
                return browseIRItemModels.get(position);
            }
        }
        return null;
    }

    public void deleteItem(int position) {
        if (itemsWereRetrieved) {
            if (position < browseIRItemModels.size()) {
                browseIRItemModels.remove(position);
            }
        }
    }

    public void dispose() {
        synchronized (mLock) {
            mIsDisposed = true;
            queueOfListeners.clear();
            browseIRItemModels.clear();
            mExecutorService = null;
            searchItemKey = -1L;
        }
    }

    private void addListenerToQueue(int position, IBrowseItemModelRetrieveListener listener) {
        BrowseItemWaitingInfo browseItemWaitingInfo = new BrowseItemWaitingInfo(position, listener);
        synchronized (mLock) {
            queueOfListeners.add(browseItemWaitingInfo);
        }
    }

    protected abstract void startRetrievingBrowsePage();

    protected void parseBrowseList(List<UnifiedBrowseListItem> navList) {
        for (UnifiedBrowseListItem listItem : navList) {
            if (listItem.getType() == NodeListItem.FieldType.SearchDirectory) {

                searchItemKey = listItem.getKey();
                searchItemWasFound = true;
                continue;
            }

            BrowseItemModel browseIRItemModel = new BrowseItemModel(listItem);
                browseIRItemModels.add(browseIRItemModel);

        }

        itemsWereRetrieved = true;
        notifyAllListenersFromQueue();
    }

    private void notifyAllListenersFromQueue() {
        synchronized (mLock) {
            while (queueOfListeners.peek() != null) {
                BrowseItemWaitingInfo waitingInfo = queueOfListeners.poll();
                getBrowseItemModelAsync(waitingInfo.position, waitingInfo.listener);

                waitingInfo.listener = null;
            }
        }
        //EventBus.getDefault().post(new NavShowListEvent());
    }

    private class BrowseItemWaitingInfo {
        int position;
        IBrowseItemModelRetrieveListener listener;

        BrowseItemWaitingInfo(int position, IBrowseItemModelRetrieveListener listener) {
            this.position = position;
            this.listener = listener;
        }
    }
}
