package com.frontier_silicon.fsirc.dok2;

import android.os.Bundle;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

/**
 * Created by lsuhov on 18/05/2017.
 */

public class RadioFromBundleExtractor {
    public static Radio extractRadio(Bundle bundle, Class classType) {
        return extractRadio(bundle, NavigationHelper.RADIO_UDN_ARG, classType);
    }

    public static Radio extractRadio(Bundle bundle, String bundleKey, Class classType) {
        if (bundle == null) {
            FsLogger.log("bundle from " + classType.toString() + "should not be null", LogLevel.Error);
            return null;
        }

        String radioUDN = bundle.getString(bundleKey);
        Radio radio = NetRemoteManager.getInstance().getRadio(radioUDN);

        if (radio == null) {
            FsLogger.log("radio was not found for udn= " + radioUDN + " in " + classType.toString(),
                    LogLevel.Error);
        }

        return radio;
    }
}
