package com.frontier_silicon.fsirc.dok2.update;

import android.content.Context;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.SortedList;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.IsuListItemBinding;

public class AllDevicesIsuAdapter extends RecyclerView.Adapter<AllDevicesIsuAdapter.IsuDeviceViewHolder> {
	private Context mContext;
    RecyclerView mRecyclerView;

    public SortedList<Radio> mSortedRadios;

    public class IsuDeviceViewHolder extends RecyclerView.ViewHolder {
        IsuListItemBinding mBinding;

        public IsuDeviceViewHolder(IsuListItemBinding isuListItemBinding) {
            super(isuListItemBinding.getRoot());

            mBinding = isuListItemBinding;
        }
    }
	
	public AllDevicesIsuAdapter(Context context) {
		mContext = context;
        initSortedList();
	}

    @Override
    public IsuDeviceViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        IsuListItemBinding isuListItemBinding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                R.layout.isu_list_item,
                parent,
                false);

        IsuDeviceViewHolder isuDeviceViewHolder = new IsuDeviceViewHolder(isuListItemBinding);

        return isuDeviceViewHolder;
    }

    @Override
    public void onBindViewHolder(final IsuDeviceViewHolder holder, int position) {
        if (position >= mSortedRadios.size())
            return;

        Radio radio = mSortedRadios.get(position);
        IsuItemModel isuModel = AllDevicesIsuManager.getInstance().getIsuModel(radio);
        final IsuListItemBinding binding = holder.mBinding;

        final IsuViewModel viewModel = new IsuViewModel(mContext, radio, isuModel);
        binding.setViewModel(viewModel);
    }

    @Override
    public int getItemCount() {
        return mSortedRadios.size();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);

        mRecyclerView = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);

        mRecyclerView = null;
    }

    private void initSortedList() {

        mSortedRadios = new SortedList<>(Radio.class, new SortedList.Callback<Radio>() {
            @Override
            public int compare(Radio o1, Radio o2) {
                return o1.compareTo(o2);
            }

            @Override
            public void onInserted(final int position, final int count) {

                if (mRecyclerView != null) {
                    if (mRecyclerView.isComputingLayout()) {
                        mRecyclerView.post(new Runnable() {
                            @Override
                            public void run() {
                                notifyItemRangeInserted(position, count);
                            }
                        });
                    } else {
                        notifyItemRangeInserted(position, count);
                    }
                }
            }

            @Override
            public void onRemoved(final int position, final int count) {
                if (mRecyclerView != null) {
                    if (mRecyclerView.isComputingLayout()) {
                        mRecyclerView.post(new Runnable() {
                            @Override
                            public void run() {
                                notifyItemRangeRemoved(position, count);
                            }
                        });
                    } else {
                        notifyItemRangeRemoved(position, count);
                    }
                }
            }

            @Override
            public void onMoved(final int fromPosition, final int toPosition) {
                if (mRecyclerView != null) {
                    if (mRecyclerView.isComputingLayout()) {
                        mRecyclerView.post(new Runnable() {
                            @Override
                            public void run() {
                                notifyItemMoved(fromPosition, toPosition);
                            }
                        });
                    } else {
                        notifyItemMoved(fromPosition, toPosition);
                    }
                }
            }

            @Override
            public void onChanged(final int position, final int count) {
                if (mRecyclerView != null) {
                    if (mRecyclerView.isComputingLayout()) {
                        mRecyclerView.post(new Runnable() {
                            @Override
                            public void run() {
                                notifyItemRangeChanged(position, count);
                            }
                        });
                    } else {
                        notifyItemRangeChanged(position, count);
                    }
                }
            }

            @Override
            public boolean areContentsTheSame(Radio oldItem, Radio newItem) {
                return oldItem.compareTo(newItem) == 0;
            }

            @Override
            public boolean areItemsTheSame(Radio item1, Radio item2) {
                return item1.equals(item2);
            }
        });
    }

}
