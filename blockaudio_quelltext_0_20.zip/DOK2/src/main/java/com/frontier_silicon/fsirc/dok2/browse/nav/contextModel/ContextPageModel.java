package com.frontier_silicon.fsirc.dok2.browse.nav.contextModel;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowsePageModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.PageRetrieverRunnable;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.UnifiedBrowseListItem;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.List;
import java.util.concurrent.ExecutorService;

/**
 * Created by adanaila on 21/11/16.
 */

public class ContextPageModel extends BrowsePageModel{

    public ContextPageModel(int key, ExecutorService executorService) {
        super(key,executorService);
    }

    public ContextPageModel(int key, List<UnifiedBrowseListItem> listItems, ExecutorService executorService) {
        super(key, listItems, executorService);
    }

    protected void startRetrievingBrowsePage() {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        ContextPageRetrieverRunnable runnable = new ContextPageRetrieverRunnable(startIndex, radio, true, new PageRetrieverRunnable.IPageRetrieverListener() {
            @Override
            public void onNavPageRetrieved(final List<UnifiedBrowseListItem> listItems) {
                NetRemote.getMainThreadExecutor().execute(() -> {
                    if (!mIsDisposed) {
                        parseBrowseList(listItems);
                    }
                });
            }
        });

        FsLogger.log("adding navigation runnable " + startIndex, LogLevel.Info);
        mExecutorService.submit(runnable);
    }
}
