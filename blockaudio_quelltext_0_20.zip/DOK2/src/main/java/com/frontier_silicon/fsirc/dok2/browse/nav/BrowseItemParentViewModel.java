package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.view.View;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;

/**
 * Created by lsuhov on 19/10/2016.
 */

public class BrowseItemParentViewModel extends BrowseNavItemViewModel {
    BrowseManager mBrowseManager;


    public BrowseItemParentViewModel(int position, BrowseItemModel navBrowseItemModel, BrowseManager manager) {
        super(position, navBrowseItemModel);
        this.mBrowseManager = manager;
    }

    public void onListItemClicked(View view) {
        mBrowseManager.navigateToDirectory(mNavBrowseItemModel.getKey());
    }
}
