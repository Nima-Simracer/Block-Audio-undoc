package com.frontier_silicon.fsirc.dok2;

public class AppDestroyedEvent { }
