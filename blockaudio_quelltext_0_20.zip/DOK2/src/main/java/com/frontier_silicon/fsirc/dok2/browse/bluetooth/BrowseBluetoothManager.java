package com.frontier_silicon.fsirc.dok2.browse.bluetooth;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothConnectedDevicesListVersion;
import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothDiscoverableState;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DelayedPostsManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class BrowseBluetoothManager {
    private static BrowseBluetoothManager mInstance = null;

    private Map<Class, Object> mBluetoothNodes = new HashMap<>();
    private List<IBrowseBluetoothNodesListener> mListeners = new CopyOnWriteArrayList<>();
    private Radio mRadio;
    private INodeNotificationCallback mNotificationListener;

    private BrowseBluetoothManager() {}

    public static BrowseBluetoothManager getInstance() {
        if (mInstance == null) {
            mInstance = new BrowseBluetoothManager();
        }

        return mInstance;
    }

    public void addListenerAndRetrieveResults(Radio radio, IBrowseBluetoothNodesListener callback) {
        if (mRadio != null && !mRadio.equals(radio)) {
            // If by any chance the radio somehow changed, we should remove the listener from it
            dispose();
        }

        if (radio == null) {
            return;
        }

        mRadio = radio;
        mListeners.add(callback);

        if (mListeners.size() == 1) {
            init();
        }

        if (mBluetoothNodes.size() > 0) {
            //If we have cached data, provide it
            callback.onNodesResult(mBluetoothNodes);
        }
    }

    public void removeListener(IBrowseBluetoothNodesListener callback) {
        mListeners.remove(callback);
        if (mListeners.size() == 0) {
            dispose();
        }
    }

    public void pair() {
        if (mRadio != null) {
            mRadio.setNode(new NodeBluetoothDiscoverableState(NodeBluetoothDiscoverableState.Ord.DISCOVERABLE), false);
        }
    }

    public Map<Class, Object> getNodes() {
        return mBluetoothNodes;
    }

    private void init() {
        mNotificationListener = node -> {
            if (node instanceof NodeBluetoothDiscoverableState ||
                    node instanceof NodeBluetoothConnectedDevicesListVersion) {
                retrieveBluetoothNodes();
            }
        };

        mRadio.addNotificationListener(mNotificationListener);

        retrieveBluetoothNodes();
    }

    private void retrieveBluetoothNodes() {
        BluetoothNodesRetrieverRunnable runnable = new BluetoothNodesRetrieverRunnable(mRadio, nodes -> {
            mBluetoothNodes = nodes;

            NetRemote.getMainThreadExecutor().execute(this::notifyAllListeners);
        });

        new Thread(runnable).start();
    }

    private void notifyAllListeners() {
        for (IBrowseBluetoothNodesListener listener : mListeners) {
            listener.onNodesResult(mBluetoothNodes);
        }
    }

    private void dispose() {
        mListeners.clear();

        if (mRadio != null) {
            mRadio.removeNotificationListener(mNotificationListener);
            mRadio = null;
        }

        mNotificationListener = null;

        DelayedPostsManager.getInstance().postDelayed(() -> {
            //We need to delay the clearing, for the case when the user is navigating between the two bluetooth pages
            if (mListeners.size() == 0) {
                mBluetoothNodes.clear();
            }
        }, 1000);
    }
}
