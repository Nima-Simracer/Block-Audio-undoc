package com.frontier_silicon.fsirc.dok2.connectedSpeaker;

import static com.frontier_silicon.fsirc.dok2.util.PermissionsUtil.PERMISSIONS_REQUEST_NOTIFICATIONS;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.databinding.Observable;

import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

import android.text.BoringLayout;
import android.view.View;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.ExternalAppsOpener;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.LayoutDecider;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.UpdateActionBarTitleTask;
import com.frontier_silicon.fsirc.dok2.baseActivity.MainMenuHandler;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.browse.dmr.BrowseDMRFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.firstConnectionTutorial.ITutorialListener;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.firstConnectionTutorial.UserInitialTutorial;
import com.frontier_silicon.fsirc.dok2.connection.ConnectionManager;
import com.frontier_silicon.fsirc.dok2.connection.connectionLost.ConnectionLostActivity;
import com.frontier_silicon.fsirc.dok2.home.HomeActivity;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.notifications.NotificationManager;
import com.frontier_silicon.fsirc.dok2.sources.SourcesFragment;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingManager;
import com.frontier_silicon.fsirc.dok2.presets.PresetsActivity;
import com.frontier_silicon.fsirc.dok2.presets.PresetsFragment;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.fsirc.dok2.volume.volumeControl.VolumeCtrlFragment;
import com.frontier_silicon.fsirc.dok2.widgets.SlidingTabLayout;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import me.toptas.fancyshowcase.FancyShowCaseView;


public class ConnectedSpeakerActivity extends UndokActivityBase implements IParentActivity,
        IMultiroomGroupingListener,
        IConnectionStateListener {

    private static final int INVALID_TAB_ID = -1;

    SectionsPagerAdapter mSectionsPagerAdapter;

    ViewPager mViewPager;

    private SlidingTabLayout mSlidingTabLayout;

    public static int MAIN_CONTAINER_ID = R.id.mainContainer;
    public static int NOW_PLAYING_LANDSCAPE_CONTAINER_ID = R.id.globalNowPlayingFragmentContainer;

    private static final String RESTORE_BUNDLE_ORIENTATION = "RESTORE_BUNDLE_ORIENTATION";
    private static final String RESTORE_BUNDLE_TAB_POSITION = "RESTORE_BUNDLE_TAB_POSITION";

    private int mPrevTabPosition = INVALID_TAB_ID;

    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;

    private int currentOrientation;
    private ConnectedSpeakerViewModel viewModel;

    private Observer<Boolean> showOktivPopupObserver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main_activity_tabs);

        setActionBar();

        enableMainMenu(MainMenuHandler.SHOW_DEVICE_SETTINGS_BIT);
        //enableUpNavigation();

        initPagerViewAndTabs();
        initVolumeControl();
        viewModel = new ViewModelProvider(this).get(ConnectedSpeakerViewModel.class);

        manageNowPlayingFragmentOnRotation();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);

            FsLogger.log("app is battery optimised: " + pm.isIgnoringBatteryOptimizations(this.getPackageName()));
        }

        currentOrientation = getResources().getConfiguration().orientation;

        //in case bundle has info from previous orientation, it will override the actions from bellow function
        switchToFragmentOnConnection();
        handleRedirectIntent();
        sendSpeakerTypeEvent();
        viewModel.registerDicoveryListener();
        viewModel.shouldShowOktivPromo();

    }


    private void showNotificationPermissionRequest() {
        if (PermissionsUtil.shouldShowNotificationPermission(this)) {
            if (PermissionsUtil.shouldShowNotificationPermissionRationale(this)) {
                PermissionsUtil.showNotificationPermissionDialog(this);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS,}, PERMISSIONS_REQUEST_NOTIFICATIONS);
            }
        }
    }


    public void handleRedirectIntent() {
        Intent intent = getIntent();
        FsLogger.log("Amazon Login redirection response received ", LogLevel.Info);

        if (intent != null) {
            Uri uri = intent.getData();
            FsLogger.log("Amazon Login redirection response uri:" + uri, LogLevel.Info);

            if (uri != null && uri.toString().contains(ConnectedSpeakerViewModel.REDIRECT_URL)) {
                switchFragment(FragmentFactory.BROWSE_TAG);
                viewModel.setLoginCompleteNode();
            }
        }
    }

    private void initPagerViewAndTabs() {
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.

        if (!LayoutDecider.isTabletAndLandscape(this)) {
            mSectionsPagerAdapter = new SectionsPagerAdapterPortrait(getApplicationContext(), getSupportFragmentManager());
        } else {
            mSectionsPagerAdapter = new SectionsPagerAdapterLandscape(getApplicationContext(), getSupportFragmentManager());
        }
        // Set up the ViewPager with the sections adapter.
        mViewPager = findViewById(R.id.mainContainer);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        mViewPager.setOffscreenPageLimit(0);
        //mViewPager.setOffscreenPageLimit(mSectionsPagerAdapter.getCount());

        mSlidingTabLayout = findViewById(R.id.sliding_tabs);
        mSlidingTabLayout.setDistributeEvenly(true);
        mSlidingTabLayout.setDefaultTextColorList(GuiUtils.getColorStateListFromAttribute(this, R.attr.tabbing_text_color));

        int tabColor = GuiUtils.getColorFromAttribute(this, R.attr.tabbing_highlighted_tab_color);
        mSlidingTabLayout.setSelectedIndicatorColors(tabColor, tabColor, tabColor);

        mSlidingTabLayout.setViewPager(mViewPager);
        mSlidingTabLayout.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //FsLogger.log("page scrolled: " + position);
            }

            @Override
            public void onPageSelected(int position) {
                GuiUtils.hideKeyboard(ConnectedSpeakerActivity.this);
                onPageChanged(position);

                //FsLogger.log("page changed: " + position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        mViewPager.setCurrentItem(mSectionsPagerAdapter.getDefaultTabId());
    }

    private void initVolumeControl() {
        if (!LayoutDecider.isLandscape(this)) {
            Fragment volumeFragment = new VolumeCtrlFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.layoutEmbeddedVolumeCtrlMainActivity, volumeFragment).commit();
        }
    }

    @Override
    public void switchFragment(String fragmentTag) {
        if (isLandscapeNowPlaying(fragmentTag)) {
            return;
        }

        // if fragment is one of the tabs => slide to show it
        int tabPosition = mSectionsPagerAdapter.getPosition(fragmentTag);
        if (tabPosition != INVALID_TAB_ID) {
            mViewPager.setCurrentItem(tabPosition);
        } else {
            FsLogger.log("switchFragment: unknown tab tag was received");
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == PresetsActivity.RESULT_CODE_LANDSCAPE) {
            switchFragment(PresetsFragment.FRAGMENT_TAG);
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private boolean isLandscapeNowPlaying(String fragmentTag) {
        return (LayoutDecider.isTabletAndLandscape(this) && FragmentFactory.NOW_PLAYING_TAG.equals(fragmentTag));
    }

    private void setActionBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        super.setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(true);

        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setCustomView(R.layout.actionbar_custom);

        actionBar.getCustomView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigationHelper.goToActivity(ConnectedSpeakerActivity.this, HomeActivity.class, NavigationHelper.AnimationType.SlideToRight);
            }
        });

        updateToolbarTitle();
    }

    private void updateToolbarTitle() {
        if (DokUiUtils.isDestroyed(this)) {
            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (DokUiUtils.isDestroyed(ConnectedSpeakerActivity.this)) {
                    return;
                }

                String title = getString(R.string.dashboard);

                UpdateActionBarTitleTask updateTitleTask = new UpdateActionBarTitleTask(ConnectedSpeakerActivity.this, title);
                TaskHelper.execute(updateTitleTask);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        showNotificationPermissionRequest();
    }

    protected void onResume() {
        super.onResume();

        registerMultiroomGroupNotifListener();

        ConnectionStateUtil.getInstance().addListener(this, true);

        addSpeakerSettingsListener();

        if (!UndokPreferences.getInstance().initialTutorialWasCompleted()) {
            initFirstTimeUsageGuide();
        }

        registerObserver();
    }

    private void registerObserver() {
        showOktivPopupObserver = aBoolean -> {
          if (aBoolean) {
              if (UndokPreferences.getInstance().initialTutorialWasCompleted()) {
                  showOktivPopup(this);
              }
          }
        };

        viewModel.getShouldShowOktivPromo().observe(this, showOktivPopupObserver);
    }

    private  void showOktivPopup(Activity activity) {
        viewModel.getShouldShowOktivPromo().setValue(false);
        AlertDialog.Builder oktivPromoBuilder = ThemedAlertDialogBuilder.create(activity);
        oktivPromoBuilder.setMessage(activity.getString(R.string.oktiv_promo));
        oktivPromoBuilder.setNeutralButton(activity.getString(R.string.download_now), (dialogInterface, i) -> {
            UndokPreferences.getInstance().setOktivPromoShowed();
            AnalyticsSender.sendOktivDownloadButtonPressed();
            ExternalAppsOpener.openAppInStore(ConnectedSpeakerViewModel.OKTIV_PACKAGE, activity);
        });

        oktivPromoBuilder.setNegativeButton(android.R.string.cancel, (dialogInterface, i) -> {
            AnalyticsSender.sendOktivCancelButtonPressed();
        });

        oktivPromoBuilder.setPositiveButton(activity.getString(R.string.dont_bother_me_again), (dialogInterface, i) -> {
            UndokPreferences.getInstance().setOktivPromoShowed();
            AnalyticsSender.sendOktivNeverShowAgainButtonPressed();
        });

      AlertDialog  dialog = oktivPromoBuilder.create();
      dialog.setCancelable(false);
      dialog.show();
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        updateCurrentFragment();
    }

    protected void onPause() {
        super.onPause();

        unregisterMultiroomGroupNotifListener();

        ConnectionStateUtil.getInstance().removeListener(this);

        removeSpeakerSettingsListener();

        notifyNowPlayingActivated(false);

        notifyFragmentDeactivated(mViewPager.getCurrentItem());

        removeObservers();
    }

    private void removeObservers() {
        viewModel.getShouldShowOktivPromo().removeObserver(showOktivPopupObserver);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        mSlidingTabLayout.setOnPageChangeListener(null);
        mSectionsPagerAdapter.dispose();
        viewModel.removeDiscoveryListner();

        super.onDestroy();
    }

    private void updateCurrentFragment() {
        notifyFragmentActivated(mViewPager.getCurrentItem());

        refreshFragments();

        notifyNowPlayingActivated(true);
    }

    private void refreshFragments() {

        refreshNowPlayingFragment();
        refreshBrowseFragment();
    }

    private void refreshNowPlayingFragment() {
        if (LayoutDecider.isTabletAndLandscape(this)) {
            refreshNowPlayingFragmentForTabletLandscape();
        } else {
            refreshNowPlayingFragmentPortrait();
        }
    }

    public void refreshNowPlayingFragmentForTabletLandscape() {
        if (findViewById(NOW_PLAYING_LANDSCAPE_CONTAINER_ID) == null) {
            return;
        }

        IChildFragment childFragment = (IChildFragment) getSupportFragmentManager().findFragmentById(NOW_PLAYING_LANDSCAPE_CONTAINER_ID);
        if (childFragment != null) {

            long currentTabId = FragmentFactory.getInstance().getNowPlayingTabIdForFragmentTag(childFragment.getStaticTag());
            long neededTabId = FragmentFactory.getInstance().getNowPlayingFragmentTabId();

            if (currentTabId != neededTabId) {
                manageNowPlayingFragmentOnRotation();
            }
        } else {
            manageNowPlayingFragmentOnRotation();
        }
    }

    private void refreshNowPlayingFragmentPortrait() {
        int tabPosition = mSectionsPagerAdapter.getPosition(FragmentFactory.NOW_PLAYING_TAG);
        if (tabPosition == INVALID_TAB_ID) {
            FsLogger.log("refreshFragments: browse fragment was not found", LogLevel.Error);
            return;
        }

        IChildFragment childFragment = (IChildFragment) mSectionsPagerAdapter.getFragment(tabPosition);
        if (childFragment == null) {
            return;
        }

        long currentTabId = FragmentFactory.getInstance().getNowPlayingTabIdForFragmentTag(childFragment.getStaticTag());
        long neededTabId = FragmentFactory.getInstance().getNowPlayingFragmentTabId();

        if (currentTabId != neededTabId) {
            notifyTabShouldChange(tabPosition);
        }
    }


    private void refreshBrowseFragment() {
        int tabPosition = mSectionsPagerAdapter.getPosition(FragmentFactory.BROWSE_TAG);
        if (tabPosition == INVALID_TAB_ID) {
            FsLogger.log("refreshFragments: browse fragment was not found", LogLevel.Error);
            return;
        }

        IChildFragment childFragment = (IChildFragment) mSectionsPagerAdapter.getFragment(tabPosition);
        if (childFragment == null) {
            return;
        }

        long currentTabId = FragmentFactory.getInstance().getBrowseFragmentTabIdFromFragmentTag(childFragment.getStaticTag());
        long neededTabId = FragmentFactory.getInstance().getBrowseFragmentTabIdForCurrentMode();

        if (currentTabId != neededTabId) {
            notifyTabShouldChange(tabPosition);
        }
    }

    private void notifyTabShouldChange(final int tabPosition) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (DokUiUtils.isDestroyed(ConnectedSpeakerActivity.this)) {
                    return;
                }

                mSectionsPagerAdapter.notifyTabContentShouldChange(tabPosition);
            }
        });
    }

    private void switchToFragmentOnConnection() {

        NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();

        if (currentMode != null) {
            if (LayoutDecider.isTabletAndLandscape(this))
                switchFragment(FragmentFactory.BROWSE_TAG);
            else {

                switchFragment(FragmentFactory.NOW_PLAYING_TAG);

                if ((currentMode == NodeSysCapsValidModes.Mode.DMR) && !NowPlayingManager.getInstance().isDMRPlaying()) {
                    FsLogger.log("dmr playing: ");
                    //SectionsPagerAdapter tmpAdapter = (SectionsPagerAdapter) mViewPager.getAdapter();

                    //FsLogger.log("dmr playing (position): " + tmpAdapter.getBrowseTabPosition());

                    //mViewPager.setCurrentItem(tmpAdapter.getBrowseTabPosition(), true);
                    switchFragment(FragmentFactory.BROWSE_TAG);
                }

            }
        } else {
            switchFragment(SourcesFragment.FRAGMENT_TAG);
        }
    }

    public void onGroupingUpdate() {
        updateToolbarTitle();
    }

    private void registerMultiroomGroupNotifListener() {
        MultiroomGroupManager.getInstance().addListener(this);
    }

    private void unregisterMultiroomGroupNotifListener() {
        MultiroomGroupManager.getInstance().removeListener(this);
    }

    public void onModeChange() {
        refreshFragments();

        ConnectedSpeakerActivity.this.invalidateOptionsMenu();

        // Fassung 0.17 Audioblock (19.09.2026) — NEU.
        // Seit die zweite Zeile der Kopfzeile die laufende Quelle zeigt, muss
        // sie beim Quellenwechsel neu geschrieben werden. Vorher wurde der
        // Titel nur bei einer Namensaenderung aufgefrischt — dann haette dort
        // noch "Internetradio" gestanden, waehrend Spotify laeuft.
        updateToolbarTitle();
    }

    private void addSpeakerSettingsListener() {
        mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().isInStandby) {
                    onPowerChange();
                } else if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode) {
                    onModeChange();
                } else if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().friendlyName) {
                    updateToolbarTitle();
                }
            }
        };

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.isInStandby.addOnPropertyChangedCallback(mPropertyChangedCallback);
        speakerDataModel.currentMode.addOnPropertyChangedCallback(mPropertyChangedCallback);
        speakerDataModel.friendlyName.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void removeSpeakerSettingsListener() {

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.isInStandby.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        speakerDataModel.currentMode.removeOnPropertyChangedCallback(mPropertyChangedCallback);
        speakerDataModel.friendlyName.removeOnPropertyChangedCallback(mPropertyChangedCallback);

        mPropertyChangedCallback = null;
    }

    private void onPowerChange() {
        runOnUiThread(() -> {

            refreshNowPlayingFragment();
            switchFragment(FragmentFactory.NOW_PLAYING_TAG);

            Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
            if (currentRadio != null && currentRadio.isVenice()) {
                updateBrowseScreenForVenice();
            }
        });
    }

    private void updateBrowseScreenForVenice() {
        if (LayoutDecider.isLandscape(this)) {
            int browsePageIndex = mSectionsPagerAdapter.getBrowseTabPosition();
            int currentPageIndex = mSectionsPagerAdapter.getBrowseTabPosition();
            if (browsePageIndex == currentPageIndex) {
                mSectionsPagerAdapter.notifyTabContentShouldChange(browsePageIndex);
            }
        }

    }

    private void onPageChanged(int position) {

        Fragment fragment = mSectionsPagerAdapter.getFragment(position);
        if (fragment instanceof BrowseDMRFragment) {
            BrowseDMRFragment browseDMRFragment = (BrowseDMRFragment) fragment;

            browseDMRFragment.mPermissionRequestShown = false;
        }

        notifyFragmentActivated(position);
        notifyFragmentDeactivated(mPrevTabPosition);

        mPrevTabPosition = position;
    }

    private void notifyFragmentActivated(int pageIndex) {
        Fragment currFragment = mSectionsPagerAdapter.getFragment(pageIndex);
        if (currFragment != null) {
            try {
                IPageSwitchListener fragmentListener = (IPageSwitchListener) currFragment;
                fragmentListener.onFragmentActivated();
            } catch (ClassCastException e) {
            }
        }
    }

    private void notifyFragmentDeactivated(int pageIndex) {
        Fragment currFragment = mSectionsPagerAdapter.getFragment(pageIndex);
        if (currFragment != null) {
            try {
                IPageSwitchListener fragmentListener = (IPageSwitchListener) currFragment;
                fragmentListener.onFragmentDeactivated();
            } catch (ClassCastException e) {
            }
        }
    }

    private void manageNowPlayingFragmentOnRotation() {

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        Fragment fragment = null;

        for (Fragment f : getSupportFragmentManager().getFragments()) {
            if (FragmentFactory.getInstance().isNowPlayingFragment(f)) {
                fragment = f;
            }
        }
        if (fragment != null)
            transaction.remove(fragment);

        if (LayoutDecider.isTabletAndLandscape(this)) {

            fragment = FragmentFactory.getInstance().getFragment(FragmentFactory.NOW_PLAYING_TAG);
            transaction.replace(NOW_PLAYING_LANDSCAPE_CONTAINER_ID, fragment);
        }

        transaction.commit();
    }


    public void notifyNowPlayingActivated(boolean activated) {
        if (findViewById(NOW_PLAYING_LANDSCAPE_CONTAINER_ID) != null) {
            Fragment currFragment = getSupportFragmentManager().findFragmentById(NOW_PLAYING_LANDSCAPE_CONTAINER_ID);
            if (currFragment != null) {
                try {
                    IPageSwitchListener fragmentListener = (IPageSwitchListener) currFragment;
                    if (activated) {
                        fragmentListener.onFragmentActivated();
                    } else {
                        fragmentListener.onFragmentDeactivated();
                    }
                } catch (ClassCastException e) {
                }
            }
        }
    }

    @Override
    public void onStateUpdate(final ConnectionState newState) {
        FsLogger.log("~~~~~~~~~ STATE: " + newState);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                switch (newState) {

                    case SEARCHING_RADIOS_NO_SPEAKER_FOUND_YET:
                    case SEARCHING_RADIOS_SPEAKER_FOUND:
                        if (!NetRemoteManager.getInstance().checkConnection()) {
                            NavigationHelper.goToHomeAndClearActivityStack(ConnectedSpeakerActivity.this);
                        }
                        break;

                    case NO_RADIOS_FOUND:
                    case CONNECTED_RADIO_AP_MODE:
                    case NOT_CONNECTED_TO_RADIO:
                    case DISCONNECTED_PIN_ERROR:
                        //case NO_WIFI_OR_ETHERNET:
                        NavigationHelper.goToHomeAndClearActivityStack(ConnectedSpeakerActivity.this);
                        break;

                    case CONNECTED_TO_RADIO:

                        updateCurrentFragment();

                        updateToolbarTitle();
                        ConnectedSpeakerActivity.this.invalidateOptionsMenu();
                        break;

                    case INVALID_SESSION:
                    case DISCONNECTED:
                        if (ConnectionManager.getInstance().getLastConnectedDevice() != null) {
                            NavigationHelper.goToActivity(ConnectedSpeakerActivity.this, ConnectionLostActivity.class);
                        } else {
                            NavigationHelper.goToHomeAndClearActivityStack(ConnectedSpeakerActivity.this);
                        }
                        break;

                    default:
                        break;
                }
            }
        });

    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt(RESTORE_BUNDLE_ORIENTATION, currentOrientation);
        outState.putInt(RESTORE_BUNDLE_TAB_POSITION, mViewPager.getCurrentItem());
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        // restore default tab (after landscape/portrait rotation)
        int tabItem = savedInstanceState.getInt(RESTORE_BUNDLE_TAB_POSITION);
        int lastOrientation = savedInstanceState.getInt(RESTORE_BUNDLE_ORIENTATION);
        currentOrientation = getResources().getConfiguration().orientation;

        if (lastOrientation != currentOrientation) {
            if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
                switch (tabItem) {
                    case 1:
                        // now playing is not available in tabs
                        tabItem = 0;
                        break;
                    case 2:
                        // browse is moved to poz 2 from 3 in landscape
                        tabItem = 1;
                        break;
                }
            } else {
                switch (tabItem) {
                    case 1:
                        tabItem = 2;
                        break;
                    case 2:
                        tabItem = 1;
                        //NavigationHelper.goToActivityForResult(this, PresetsActivity.class, NavigationHelper.AnimationType.SlideToLeft, null, 12);
                        break;
                }
            }
        }

        mViewPager.setCurrentItem(tabItem);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == PERMISSIONS_REQUEST_NOTIFICATIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                NotificationManager.getInstance().startMediaNotificationService();
            }
        }

        int orientation = getResources().getConfiguration().orientation;
        int targetFragmentPos = 2;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            targetFragmentPos = 1;
        }

        Fragment fragment = mSectionsPagerAdapter.getFragment(targetFragmentPos);
        if (fragment instanceof BrowseDMRFragment) {
            BrowseDMRFragment browseDMRFragment = (BrowseDMRFragment) fragment;

            try {
                browseDMRFragment.onRequestPermissionsResult(requestCode, permissions, grantResults);
            } catch (ArrayIndexOutOfBoundsException e) {

            }
        }
    }

    @Override
    public void onBackPressed() {

        Fragment currentFragment = mSectionsPagerAdapter.getFragment(mViewPager.getCurrentItem());

        boolean backHandled = false;
        if (currentFragment != null) {
            if (currentFragment instanceof IChildFragment) {
                backHandled = ((IChildFragment) currentFragment).isBackButtonHandledByFragment(false);
                if (backHandled) {
                    ((IChildFragment) currentFragment).onBackButton();
                }
            }
        }

        if (!backHandled) {
            super.onBackPressed();
        }
    }

    private void initFirstTimeUsageGuide() {
        DelayedPostsManager.getInstance().postDelayed((Runnable) () -> {
            UserInitialTutorial tutorial = new UserInitialTutorial(new ITutorialListener() {
                @Override
                public void onSkip() {
                    UndokPreferences.getInstance().setInitialTutorialCompleted(true);

                    if (viewModel.getShouldShowOktivPromo().getValue()) {
                        showOktivPopup(ConnectedSpeakerActivity.this);
                    }
                }

                @Override
                public void onEnd() {
                    UndokPreferences.getInstance().setInitialTutorialCompleted(true);

                    if (viewModel.getShouldShowOktivPromo().getValue()) {
                        showOktivPopup(ConnectedSpeakerActivity.this);
                    }
                }
            });
            View source = findViewById(mSectionsPagerAdapter.getTabId(0));
            if (source != null) {
                FancyShowCaseView sourceView = tutorial.getTutorial(ConnectedSpeakerActivity.this, source, R.string.mode, R.string.tutorial_source);
                tutorial.getQueue().add(sourceView);
            }

            View nowPlaying = findViewById(mSectionsPagerAdapter.getTabId(1));
            if (nowPlaying != null) {
                FancyShowCaseView nowPlayingView = tutorial.getTutorial(ConnectedSpeakerActivity.this, nowPlaying, R.string.now_playing, R.string.tutorial_now_playing);
                tutorial.getQueue().add(nowPlayingView);
            }
            View browse = findViewById(mSectionsPagerAdapter.getTabId(2));
            if (browse != null) {
                FancyShowCaseView browseView = tutorial.getTutorial(ConnectedSpeakerActivity.this, browse, R.string.browse, R.string.tutorial_browse);
                tutorial.getQueue().add(browseView);
            }
            View volume = findViewById(R.id.layoutEmbeddedVolumeCtrlMainActivity);
            if (volume != null) {
                FancyShowCaseView volumeView = tutorial.getTutorial(ConnectedSpeakerActivity.this, volume, R.string.multiroom_volumes, R.string.tutorial_volume);
                tutorial.getQueue().add(volumeView);
            }

            View standByView = findViewById(R.id.action_standby_icon);
            if (standByView != null) {
                FancyShowCaseView standByViewShowCase = tutorial.getTutorial(ConnectedSpeakerActivity.this, standByView, R.string.standby, R.string.tutorial_power_off);
                tutorial.getQueue().add(standByViewShowCase);
            }


            View standbyView = findViewById(R.id.action_standby_icon);
            if (standByView != null) {
                int standByPosition[] = new int[2];
                standbyView.getLocationOnScreen(standByPosition);
                FancyShowCaseView settingsShowCase = tutorial.getMenuPosition(ConnectedSpeakerActivity.this, R.string.undok_settings, R.string.tutorial_settings, standByPosition[0], standByPosition[1]);
                tutorial.getQueue().add(settingsShowCase);
            }
            tutorial.getQueue().show();
        }, 1500);
    }

    private void sendSpeakerTypeEvent() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (currentRadio != null) {
            String serialNumber = NetRemoteManager.getInstance().getCurrentRadio().getSN();


            if (currentRadio != null &&
                    currentRadio.isVeniceXDevice() &&
                    !UndokPreferences.getInstance().wasVeniceXTypeSent(serialNumber)) {
                AnalyticsSender.sendIsVeniceXDevice();
                UndokPreferences.getInstance().veniceXTypeEventSent(serialNumber);
            } else if (currentRadio != null &&
                    !currentRadio.isVeniceXDevice() &&
                    !UndokPreferences.getInstance().wasSpeakerTypeSent(serialNumber)) {
                AnalyticsSender.sendIsNotVeniceXDevice();
                UndokPreferences.getInstance().speakerTypeEventSent(serialNumber);
            }
        }
    }
}

