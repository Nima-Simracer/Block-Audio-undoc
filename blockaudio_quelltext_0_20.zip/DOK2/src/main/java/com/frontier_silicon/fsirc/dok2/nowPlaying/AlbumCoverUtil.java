package com.frontier_silicon.fsirc.dok2.nowPlaying;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.sources.SourceIconsResourceIdFactory;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

public class AlbumCoverUtil {

    static public int updateAlbumArtworkOverlayImage() {
        try {
            if (NetRemoteManager.getInstance().checkConnection()) {

                NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();
                boolean isIPodDocked = NowPlayingManager.getInstance().getNowPlayingDataModel().isIPodDocked();

                boolean hasAvs = false;
                Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

                if (radio != null) {
                    hasAvs = radio.hasAVS();
                }

                int imageResId = getResourceImageForGivenMode(currentMode, isIPodDocked, hasAvs);
                if (imageResId >= 0) {
                    return imageResId;
                }
            } else {
                return R.drawable.ic_noconnection;
            }
        } catch (OutOfMemoryError e) {
            FsLogger.log("Image Resource failed to load: " + e.getLocalizedMessage(), LogLevel.Error);
        }
        return R.drawable.ic_noconnection;
    }

    private static int getResourceImageForGivenMode(NodeSysCapsValidModes.Mode mode, boolean isIPodDocked, boolean hasAvs) {
        int defaultResId = R.drawable.ic_genericnocoverdisplay;

        if (mode == null) {
            return defaultResId;
        }

        switch (mode) {
            case AirPlay:
                return R.drawable.ic_airplaydisplay;
            case AuxIn:
                return R.drawable.ic_auxindisplay;
            case DAB:
                return getDABLogoBasedOnCurrentTheme();
            case DMR:
                return R.drawable.ic_dmrdisplay;
            case FM:
                return R.drawable.ic_fmradiodisplay;
            case iPod:
                if (isIPodDocked) {
                    return R.drawable.ic_ipoddisplay;
                } else {
                    return R.drawable.ic_insertipoddisplay;
                }
            case IR:
                return R.drawable.ic_internetradiodisplay;
            case MP:
                return R.drawable.ic_musicplayerdisplay;
            case Spotify:
                return getSpotifyLogoBasedOnTheme();
            case Bluetooth:
                return R.drawable.ic_bluetoothdisplay;
            case Cast:
                return R.drawable.ic_castdisplay;
            case AIRABLE_DEEZER:
                return getDeezerLogoBasedOnTheme();
            case AIRABLE_NAPSTER:
                return getNapsterLogoBasedOnTheme();
            case AIRABLE_QOBUZ:
                return getQobuzLogoBasedOnTheme();
            case AIRABLE_TIDAL:
                return getTidalLogoBasedOnTheme();
            case AIRABLE_ALDI:
                return R.drawable.ic_aldilifedisplay;
            case AIRABLE_HOFER:
                return R.drawable.ic_hoferdisplay;
            case AIRABLE_AMAZON_MP:
                return getAmazonMusicLogoBasedOnTheme();
            case AIRABLE_CALM:
                return getCalmLogoBasedOnTheme();
            case AIRABLE_SAAVN:
                return  getSaavnLogoBasedOnTheme();
            case AIRABLE_KLASSIK:
                return getKlassikLogoBasedOnTheme();
            case AVS:
                return R.drawable.ic_amazon_alexa;

            case CD:
                return R.drawable.ic_cd;

            case SD:
                return R.drawable.ic_sd;

            case None:
                if (hasAvs) {
                    return R.drawable.ic_amazon_alexa;
                }

            case PODCASTS:
                return R.drawable.ic_dynamicmode_now_playing;
            default:
                return defaultResId;

        }
    }

    public static int UpdateAirableIconOverAlbum(NodeSysCapsValidModes.Mode mode) {
        int iconResId = R.drawable.ic_dynamicmode;
        if (mode == null)
            return iconResId;

        switch (mode) {
            case AIRABLE_DEEZER:
                return R.drawable.ic_deezer_source_now_playing;
            case AIRABLE_NAPSTER:
                return R.drawable.ic_nowplaying_modes_napster;
            case AIRABLE_QOBUZ:
                return R.drawable.ic_qobuzdisplay;
            case AIRABLE_TIDAL:
                return R.drawable.ic_modes_tidal_white;
            case AIRABLE_ALDI:
                return R.drawable.ic_nowplaying_modes_aldi;
            case AIRABLE_HOFER:
                return R.drawable.ic_nowplaying_modes_hofer;
            case AIRABLE_AMAZON_MP:
                return R.drawable.ic_modes_amazon_white;
            case AIRABLE_CALM:
                return R.drawable.ic_modes_calm_white;
            case AIRABLE_SAAVN:
                return R.drawable.ic_saavn_np_white;
            case AIRABLE_KLASSIK:
                return R.drawable.ic_modes_klassik_white;
        }
        return iconResId;
    }

    private static int getKlassikLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_klassik_np_black;
        } else {
            return R.drawable.ic_klassik_np_white;
        }
    }

    private static int getSaavnLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_saavn_np_black;
        } else {
            return R.drawable.ic_saavn_np_white;
        }
    }

    private static int getCalmLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_np_calm_black;
        } else {
            return R.drawable.ic_np_calm_white;
        }
    }

    private static int getSpotifyLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_spotify_black;
        } else {
            return R.drawable.ic_spotify_white;
        }
    }

    private static int getTidalLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_tidal_black;
        } else {
            return R.drawable.ic_tidal_white;
        }
    }

    private static int getNapsterLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_napster_np_black;
        } else {
            return R.drawable.ic_napster_np_white;
        }
    }


    private static int getDeezerLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_deezer_np_black;
        } else {
            return R.drawable.ic_deezer_np_white;
        }
    }

    private static int getQobuzLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_qobuz_np_black;
        } else {
            return R.drawable.ic_qobuz_np_white;
        }
    }


    private static int getDABLogoBasedOnCurrentTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_dab_light;
        } else {
            return R.drawable.ic_dab_white;
        }
    }

    private static int getAmazonMusicLogoBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_amazon_np_indigo;
        } else {
            return R.drawable.ic_amazon_np_white;
        }
    }
}
