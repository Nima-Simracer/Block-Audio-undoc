package com.frontier_silicon.fsirc.dok2.gdpr;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by nbalazs on 19/04/2018.
 */

public class GDPRVersionManager {

    private static boolean mLoadLocalVersion = false;

    private static boolean GDPR_CHECKING_ENABLED = true;

    private static int mVersion;

    private static Date mDate;

    private static boolean mFirstCheckIsDone = false;

    public static Date getDate() {
        return GDPR_CHECKING_ENABLED ? mDate : null;
    }

    public static int getVersion() {
        return GDPR_CHECKING_ENABLED ? mVersion : Integer.MIN_VALUE;
    }

    public static boolean firstCheckIsDone() {
        return !GDPR_CHECKING_ENABLED || mFirstCheckIsDone;
    }

    public static void setFirstCheckIsDone() {
        if (GDPR_CHECKING_ENABLED) {
            mFirstCheckIsDone = true;
        }
    }

    public static boolean getLoadLocalVersion() {
        return  mLoadLocalVersion;
    }

    public interface IGDPRVersionReadyListener {
        void onVersionReceived(boolean newVersionIsAvailable);
    }

    public static boolean isInternetConnectionAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            return false;
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    static void onLatestVersionAccepted() {
        if (GDPR_CHECKING_ENABLED) {
            // Save the latest versions
            UndokPreferences.getInstance().setGDPRVersion(mVersion);
            // Save the current date
            UndokPreferences.getInstance().setCheckingDateForGDPRVersion(System.currentTimeMillis());
        }
    }

    private GDPRVersionManager() {
    }

    public static void setGDPREnabled(boolean enableGDPRChecking) {
        GDPR_CHECKING_ENABLED = enableGDPRChecking;
    }

    public static void checkAsync(String url, IGDPRVersionReadyListener listener) {

        if (!GDPR_CHECKING_ENABLED) {
            listener.onVersionReceived(false);
            return;
        }

        boolean expired24h = false;
        long lastCheckingDate = UndokPreferences.getInstance().getCheckingDateForGDPRVersion();

        // Not initialised
        if (lastCheckingDate == 0) {
            expired24h = true;
        }

        // Initialised, maybe expired

        if (!expired24h) {
            try {
                if (System.currentTimeMillis() - lastCheckingDate > 24 * 60 * 60 * 1000) {
                    expired24h = true;
                }
            } catch (Exception exception) {
                expired24h = true;
            }
        }

        if (expired24h) {
            new LoaderTask(url, listener).execute();
        } else {
            new LoaderTask(url, null).execute();
            listener.onVersionReceived(false);
        }
    }

    private static class LoaderTask extends AsyncTask<Void, Void, Void> {

        private String mUrl;

        private IGDPRVersionReadyListener mListener;

        private boolean mIsExpired = false;

        private LoaderTask(String url, IGDPRVersionReadyListener listener) {
            mUrl = url;
            mListener = listener;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            JSONObject jsonObject = readURL(mUrl);
            if (jsonObject != null) {
                try {
                    JSONObject theVersion = jsonObject.getJSONObject("version");
                    JSONObject theDate = jsonObject.getJSONObject("data");
                    String mMajorVersion = theVersion.getString("major");
                    String mMinorVersion = theVersion.getString("minor");
                    String day = theDate.getString("day");
                    String month = theDate.getString("month");
                    String year = theDate.getString("year");

                    mVersion = Integer.parseInt(mMajorVersion) * 10 + Integer.parseInt(mMinorVersion);

                    String dateString = day + "/" + month + "/" + year;
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    mDate = simpleDateFormat.parse(dateString);

                    if (UndokPreferences.getInstance().getGDPRVersion() < mVersion) {
                        mIsExpired = true;
                    }
                } catch (Exception ignored) {
                }
            } else {
                if (UndokPreferences.getInstance().getGDPRVersion() > 0) {
                    mIsExpired = false;
                } else {
                    mIsExpired = true;
                    mLoadLocalVersion = true;
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (mListener != null) mListener.onVersionReceived(mIsExpired);
        }
    }

    @SuppressWarnings("ConstantConditions")
    private static JSONObject readURL(String httpLink) {
        JSONObject jsonObject = null;

        try {
            Request request = new Request.Builder().url(httpLink).build();
            Response response = NetRemote.getOkHttpClientForInternet().newCall(request).execute();
            if (response.isSuccessful()) {
                FsLogger.log("Response from " + httpLink);
                String body = new String(response.body().bytes());
                response.close();
                jsonObject = new JSONObject(body);
            } else {
                FsLogger.log("Request error at: " + httpLink + ", code :" + response.code(), LogLevel.Error);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return jsonObject;
    }
}
