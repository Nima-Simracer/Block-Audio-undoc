package com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;

/**
 * Created by lsuhov on 30/06/16.
 */

public interface IFormItemRetrieveListener {
    void onFormItemRetrieved(FormItem itemModel);
}
