package com.frontier_silicon.fsirc.dok2.connection.connectionLost;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.ConnectionLostActivityBinding;

public class ConnectionLostActivity extends UndokActivityBase {

    private ConnectionLostViewModel mViewModel;
    private ConnectionLostActivityBinding mBinding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.connection_lost_activity);

        mViewModel = new ConnectionLostViewModel(this);
        mBinding.setViewModel(mViewModel);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.connection_lost_title);

        setupControls();
    }

    public void onResume() {
        super.onResume();

        ConnectionState connectionState = ConnectionStateUtil.getInstance().getConnectionState();
        if (connectionState == ConnectionState.INVALID_SESSION) {
            measureSquareLayout();
        }

        mViewModel.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();

        mViewModel.onPause();
    }

    @Override
    public void onDestroy() {
        if (mBinding != null) {
            mBinding.setViewModel(null);
        }

        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }

        super.onDestroy();
    }

    private void setupControls() {

        measureSquareLayout();
        mBinding.buttonShowHome.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.connect_to_another_radio, true));
    }


    private void measureSquareLayout() {
        ViewTreeObserver treeObserver = mBinding.connectionLostSquareLayout.getViewTreeObserver();
        ViewTreeObserver.OnGlobalLayoutListener listener = new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                ViewGroup.LayoutParams layoutParams = mBinding.connectionLostSquareLayout.getLayoutParams();
                int height = mBinding.connectionLostSquareLayout.getHeight();
                int width = mBinding.connectionLostSquareLayout.getWidth();
                if (height > width) {
                    layoutParams.width = height;
                } else if (layoutParams.width > layoutParams.height){
                    layoutParams.height = width;
                }
                mBinding.connectionLostSquareLayout.setLayoutParams(layoutParams);

                GuiUtils.removeViewTreeObserverListener(mBinding.connectionLostSquareLayout, this);
            }
        };
        treeObserver.addOnGlobalLayoutListener(listener);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {

            NavigationHelper.goToHomeAndClearActivityStack(ConnectionLostActivity.this);
            onBackOrUp();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
