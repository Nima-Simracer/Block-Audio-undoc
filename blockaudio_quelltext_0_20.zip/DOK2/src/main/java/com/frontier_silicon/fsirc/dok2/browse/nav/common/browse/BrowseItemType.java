package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by lsuhov on 21/10/2016.
 */

public class BrowseItemType {

    @IntDef({NotImplemented, NotLoadedYet, Directory, PlayableItem, SearchDirectory, Unknown, FormItem,
            MessageItem, DescriptionFormItem, TextFormItem, PasswordFormItem, ComboboxFormItem, ButtonFormItem,
            FetchErrItem, MessageText, MessageButton, OAuth,FormItemNotLoadedYet,TrackNotAvailable, SubscribeFormItem, MultiselFormItem})
    @Retention(RetentionPolicy.SOURCE)
    public @interface EBrowseNavItemType {}

    /**
     * New type of item that is not yet handled by adapter
     */
    public final static int NotImplemented = -1;
    /**
     * The item is not loaded yet, show a special list item
     */
    public final static int NotLoadedYet = 0;
    /**
     * A directory.
     */
    public final static int Directory = 1;
    /**
     * A playable item.
     */
    public final static int PlayableItem = 2;
    /**
     * An item that will pop up a search dialogue, and then present the results as a directory.
     */
    public final static int SearchDirectory = 3;
    /**
     * An item on unknown type.
     */
    public final static int Unknown = 4;
    /**
     * An item that will contain forms data.
     */
    public final static int FormItem = 5;
    /**
     * An item that will contain the data of a message
     */
    public final static int MessageItem = 6;
    /**
     * Sub item of the FormItem type that holds a simple text to display
     */
    public final static int DescriptionFormItem = 7;
    /**
     * Sub item of the FormItem type for a text box
     */
    public final static int TextFormItem = 8;
    /**
     * Sub item of the FormItem type for a password box
     */
    public final static int PasswordFormItem = 9;
    /**
     * Sub item of the FormItem type for a combobox
     */
    public final static int ComboboxFormItem = 10;
    /**
     * Sub item of the FormItem type for a button
     */
    public final static int ButtonFormItem = 11;
    /**
     * An error occurred while retrieving the item.
     */
    public final static int FetchErrItem = 12;
    /**
     * Text item to display in a message
     */
    public final static int MessageText = 13;
    /**
     * Button item to display in a message
     */
    public final static int MessageButton = 14;
    /**
     * AmazonLogin item to display in a message
     */
    public final static int OAuth = 15;
    /**
     * Form item not loaded yet
     */
    public final static int FormItemNotLoadedYet = 16;
    /**
     * Track not available
     */
    public final static int TrackNotAvailable = 17;
    /**
     * Subscribe form item
     */
    public final static int SubscribeFormItem = 18;

    /**
     * Multisel form item
     */
    public final static int MultiselFormItem = 19;


}
