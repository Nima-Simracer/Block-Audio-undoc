package com.frontier_silicon.fsirc.dok2.nowPlaying;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.graphics.drawable.PictureDrawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.text.TextUtils;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.caverock.androidsvg.SVG;
import com.caverock.androidsvg.SVGParseException;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;

public class AlbumCoverDownloader {

	private static final int LIMIT_RESULTS = 1;

	public void getArtworkBitmapFromUrl(final String artworkURL, final String albumQuery,
                                        final IAlbumCoverListener listener,
                                        final boolean isSpotifyMode, final Context context) {

		NetRemote.getMainThreadExecutor().execute(() -> {

            if (DokUiUtils.isDestroyed(context)) {
                return;
}

            if (!TextUtils.isEmpty(artworkURL)) {
                Glide.with(context)
                        .asBitmap()
                        .load(artworkURL)
                        .into(new SimpleTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                listener.onAlbumCoverUpdate(resource);
                            }
                        });

            } else {
                tryFallbackFromSpotify(albumQuery, listener, isSpotifyMode, context);
            }
        });
	}

	public void getSVGProviderLogoFromUrl(String url, IAlbumCoverListener listener) {
		Request request = new Request.Builder().url(url).build();

		NetRemote.getOkHttpClientForInternet().newCall(request).enqueue(new Callback() {
			@Override
			public void onFailure(Call call, IOException e) {
				FsLogger.log("SVG provider logo not retrieved");
			}

			@Override
			public void onResponse(Call call, Response response) throws IOException {
				Picture picture = null;
				try {
					if (response != null && response.body() != null) {
						picture = SVG.getFromInputStream(response.body().byteStream()).renderToPicture();
					}
				} catch (SVGParseException e) {
					e.printStackTrace();
				}

				final PictureDrawable pd = new PictureDrawable(picture);
				final  Bitmap bitmap = Bitmap.createBitmap(pd.getIntrinsicWidth(), pd.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
				Canvas canvas = new Canvas(bitmap);
				canvas.drawPicture(pd.getPicture());

				NetRemote.getMainThreadExecutor().execute(() -> {
                    if (listener != null) {
                        listener.onAlbumCoverUpdate(bitmap);
                    }
                });
			}
		});
	}

	private void tryFallbackFromSpotify(final String albumQuery, final IAlbumCoverListener listener,
                                        boolean isSpotifyMode, final Context context) {
		// get from Spotify web API (fallback for pre-2.9 radios)
		if (!TextUtils.isEmpty(albumQuery) && isSpotifyMode) {
			String urlRequest = generateSpotifyURL(albumQuery);

            Request request = new Request.Builder().url(urlRequest).build();

            NetRemote.getOkHttpClientForInternet().newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    listener.onAlbumCoverUpdate(null);
                }

                @Override
                public void onResponse(Call call, okhttp3.Response response) throws IOException {
                    try {
                        JSONObject jsonObject = new JSONObject(response.body().string());

                        String artworkURL = getAlbumArtworkURLFromSpotifyJSONResponse(jsonObject);
                        FsLogger.log("NowPlaying: getAlbumArtwork TRY Spotify " + albumQuery + " " + artworkURL);

                        getArtworkBitmapFromUrl(artworkURL, null, listener, false, context);

                    } catch (JSONException e) {
                        e.printStackTrace();
                        listener.onAlbumCoverUpdate(null);
                    }

                }
            });

		} else {
			listener.onAlbumCoverUpdate(null);
		}
	}

	private String generateSpotifyURL(String trackInfo) {
		String urlEncTrackInfo = trackInfo;
		try {
			urlEncTrackInfo = URLEncoder.encode(trackInfo, "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return "https://api.spotify.com/v1/search?q=" + urlEncTrackInfo + "&type=track&limit=" + LIMIT_RESULTS;
	}

	String getAlbumArtworkURLFromSpotifyJSONResponse(JSONObject jsonResponse) {
		int HI_RES_IMG_IDX = 0;
		int MED_RES_IMG_IDX = 1;

		String artworkURL = "";

		try {
			JSONObject jsonTracks = jsonResponse.getJSONObject("tracks");
			JSONArray jsonResults = jsonTracks.getJSONArray("items");
			if (jsonResults.length() > 0) {
				JSONObject item = (JSONObject) jsonResults.get(0);
				JSONObject album = item.getJSONObject("album");
				JSONArray albumImages = album.getJSONArray("images");

				int imgIdx = -1;
				boolean hasHiResImg = (albumImages.length() > 0);
				boolean hasMedResImg = (albumImages.length() > 1);
				if (hasHiResImg) {
					imgIdx = HI_RES_IMG_IDX;
				}
				if (hasMedResImg) {
					imgIdx = MED_RES_IMG_IDX;
				}
				if (imgIdx >= 0) {
					JSONObject img = (JSONObject) albumImages.get(imgIdx);
					artworkURL = img.getString("url");
				}

				FsLogger.log("getAlbumArtwork artwork URL from Spotify: " + artworkURL);
			}
		} catch (JSONException e) {
		}

		return artworkURL;
	}

}
