package com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.common.UnifiedFormListItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormRetrieverRunnable;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;

public class ContextFormRetrieverRunnable extends FormRetrieverRunnable{

    public ContextFormRetrieverRunnable(Radio radio, INavFormRetrieverListener listener) {
        super(radio, listener);
    }

    @Override
    public void run() {
        FsLogger.log("form retriever runnable started ", LogLevel.Info);

        ArrayList<UnifiedFormListItem> formItemNode = RadioNavigationUtil.getContextFormList(mRadio);

        if (formItemNode != null) {
            sendNavListToListener(formItemNode);
        }
        dispose();
    }
}
