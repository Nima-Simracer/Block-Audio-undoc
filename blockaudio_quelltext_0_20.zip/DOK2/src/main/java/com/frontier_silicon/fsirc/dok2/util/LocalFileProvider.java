package com.frontier_silicon.fsirc.dok2.util;

import androidx.core.content.FileProvider;

/**
 * Created by mnisipeanu on 06/10/2017.
 */

public class LocalFileProvider extends FileProvider {
}
