package com.frontier_silicon.fsirc.dok2.settings;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoVersion;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;

/**
 * Created by hcostescu on 06/03/18.
 */

public class FWVersionRunnable implements Runnable{
    private IFWVersionResult mCallback;
    private String mSoftwareVersion = "Unknown";

    public FWVersionRunnable(IFWVersionResult callback)
    {
        mCallback = callback;
    }

    @Override
    public void run() {
        mSoftwareVersion = "Unknown";
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null && !NetRemoteManager.getInstance().getRadios().isEmpty()) {
            radio = NetRemoteManager.getInstance().getRadios().get(0);
        }
        if (radio != null) {
            radio.getNode(NodeSysInfoVersion.class, true, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    NodeSysInfoVersion state = (NodeSysInfoVersion) node;
                    NetRemote.getMainThreadExecutor().execute(() -> {
                        if (mCallback != null)
                            mCallback.onFWVersionResultComplete(state.getValue());
                        dispose();
                    });

                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    NetRemote.getMainThreadExecutor().execute(() -> {
                        if (mCallback != null)
                            mCallback.onFWVersionResultComplete(mSoftwareVersion);
                        dispose();
                    });
                }
            });
        }
        else {
            NetRemote.getMainThreadExecutor().execute(() -> {
                if (mCallback != null)
                    mCallback.onFWVersionResultComplete(mSoftwareVersion);
                dispose();
            });
        }
    }

    private void dispose() {
        mCallback = null;
    }
}