package com.frontier_silicon.fsirc.dok2.update;

public interface IAllDevicesIsuListener {
	void updatesAreAvailable(boolean allDevicesHaveUpdates);
	void noUpdatesAvailable();
	void failed();
	void isuFinished();
}
