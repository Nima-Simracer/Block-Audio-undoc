package com.frontier_silicon.fsirc.dok2.settings.account;

/**
 * Created by cvladu on 26/02/2018.
 */

public interface IFSDCAConnectionStatus {

    void onConnected();

    void onFailedConnecting();
}
