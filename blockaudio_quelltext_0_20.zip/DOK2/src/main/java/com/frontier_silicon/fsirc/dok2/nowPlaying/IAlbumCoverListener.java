package com.frontier_silicon.fsirc.dok2.nowPlaying;

import android.graphics.Bitmap;

public interface IAlbumCoverListener {

	void onAlbumCoverUpdate(Bitmap albumCover);
	
}
