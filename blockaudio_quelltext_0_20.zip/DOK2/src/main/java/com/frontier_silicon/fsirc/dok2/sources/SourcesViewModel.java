package com.frontier_silicon.fsirc.dok2.sources;

import android.app.Activity;
import android.app.ProgressDialog;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import android.content.Context;
import androidx.databinding.Observable;
import androidx.databinding.ObservableBoolean;
import androidx.appcompat.app.AlertDialog;
import android.widget.ExpandableListAdapter;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysMode;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetAuthorisationReturnUrl;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.ExternalAppsOpener;
import com.frontier_silicon.components.common.LayoutDecider;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomOperation;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.ConnectedSpeakerViewModel;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.FragmentFactory;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IParentActivity;
import com.frontier_silicon.fsirc.dok2.connection.ConnectionManager;
import com.frontier_silicon.fsirc.dok2.multiroom.MultiroomDialogsUtil;
import com.frontier_silicon.fsirc.dok2.multiroom.MultiroomOperationsQueueExecutorTask;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.fsirc.dok2.webview.GoogleCastAppsActivity;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lsuhov on 05/03/2018.
 */

public class SourcesViewModel implements LifecycleObserver, IMultiroomGroupingListener {

    private static final String MODE_CHANGE_PROGRESS_DLG = "MODE_CHANGE_PROGRESS_DLG";
    private static final long MODE_CHANGE_DLG_WAIT_TIMEOUT_MS = 5 * 1000;

    private Lifecycle mLifecycle;
    private SourcesExpandableArrayAdapter mAdapter;
    private ArrayList<SourceItemModel> mModesItemsList;
    private HashMap<SourceItemModel, List<SourceItemModel>> mModesMap;
    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;

    private SourceItemModel currentSourceItem = null;
    private boolean mIsModeChangedFromApp = false;

    private long modeChangingTimeoutId = -1;
    public ObservableBoolean sourceLoading = new ObservableBoolean(false);
    public ObservableBoolean emptyView = new ObservableBoolean(false);

    public SourcesViewModel(Lifecycle lifecycle) {
        mLifecycle = lifecycle;
        mModesItemsList = new ArrayList<>();
        mModesMap = new HashMap<>();

        mAdapter = new SourcesExpandableArrayAdapter(MainApplication.getContext(), mModesItemsList, mModesMap);

        lifecycle.addObserver(this);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    public void onResume() {
        registerMultiroomGroupNotifListener();

        addSpeakerSettingsListener();

        updateModes();
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    public void onPause() {
        closeModeChangingProgressDlg();

        removeSpeakerSettingsListener();

        unregisterMultiroomGroupNotifListener();
    }

    private void addSpeakerSettingsListener() {
        if (mPropertyChangedCallback == null) {
            mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable observable, int i) {
                    if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode) {
                        onModeChange();
                    }
                }
            };
        }

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.currentMode.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void removeSpeakerSettingsListener() {
        if (mPropertyChangedCallback == null) {
            return;
        }

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.currentMode.removeOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void registerMultiroomGroupNotifListener() {
        MultiroomGroupManager.getInstance().addListener(this);
    }

    private void unregisterMultiroomGroupNotifListener() {
        MultiroomGroupManager.getInstance().removeListener(this);
    }

    ExpandableListAdapter getAdapter() {
        return mAdapter;
    }

    boolean onGroupClicked(int groupPosition) {
        boolean clickHandled = false;

        // the group header == the source item
        if (mAdapter.getChildrenCount(groupPosition) <= 0) {
            SourceItemModel groupItem = (SourceItemModel) mAdapter.getGroup(groupPosition);

            if (!((groupItem.mModeId == null) || (groupItem.mModeId.equals("")))) {
                onModeItemClick(groupItem);
            }

            clickHandled = true;
        }

        return clickHandled;
    }

    boolean onChildClicked(int groupPosition, int childPosition) {
        SourceItemModel childItem = (SourceItemModel) mAdapter.getChild(groupPosition, childPosition);
        onModeItemClick(childItem);

        return true;
    }

    private void onModeItemClick(SourceItemModel sourceItem) {
        AnalyticsSender.sendMusicSourceChangingAnalytics(sourceItem.mName);

        if (sourceItem.mApp == SourceItemModel.CastApp.MoreApps) {
            // Open a webview to the google cast apps options
            NavigationHelper.goToActivity(MainApplication.getCurrentActivity(), GoogleCastAppsActivity.class,
                    NavigationHelper.AnimationType.SlideToLeft);
            return;
        }

        if (sourceItem.mApp != SourceItemModel.CastApp.NONE) {
            switchToExternalApp(sourceItem.mApp);
            return;
        }

        currentSourceItem = sourceItem;

        if (sourceItem.mRadio == null) {
            FsLogger.log("Cannot switch mode on null radio", LogLevel.Error);
            return;
        }


        if (sourceItem.mRadio.equals(NetRemoteManager.getInstance().getCurrentRadio())) {
            FsLogger.log("Changing mode for current radio " + sourceItem.mRadio);
            changeModeForCurrentRadio(sourceItem);

        } else if (sourceItem.mKey >= 0) {
            FsLogger.log("Changing mode for client");
            changeModeWhileMultiroom(sourceItem);
        }
    }

    private void changeModeForCurrentRadio(SourceItemModel modeItem) {
        if (modeItem.mKey >= 0) {
            if (SpeakerDataManager.getInstance().isInStandby()) {
                // power ON and change mode if in standby mode
                SpeakerDataManager.getInstance().enablePower(true);

                SpeakerDataManager.getInstance().setMode(modeItem.mKey);

                switchFragmentTo(FragmentFactory.NOW_PLAYING_TAG);
            } else {
                if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {
                    changeModeWhileMultiroom(modeItem);
                } else {
                    changeMode(modeItem);
                }
            }
        }
    }

    private void changeModeWhileMultiroom(SourceItemModel modeItem) {
        try {
            if (modeItem.mIsStreamable) {
                changeMode(modeItem);
            } else {
                showConfirmStandaloneModeChangeDlg(modeItem);
            }
        } catch (Exception e) {
        }
    }

    private void changeMode(final SourceItemModel modeItem) {
        try {
            if (!modeItem.mIsCurrentModeSelected) {
                showModeChangingProgressDlg();
            }

            if (NodeSysCapsValidModes.Mode.AIRABLE_SAAVN == NodeSysCapsValidModes.ConvertIdToEnum(modeItem.mModeId)) {
                setAuthenticationUrlForSaavnMode();
            }

            mIsModeChangedFromApp = true;

            Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
            if (currentRadio != null && currentRadio.equals(modeItem.mRadio)) {
                SpeakerDataManager.getInstance().setMode(modeItem.mKey);
            } else {
                SourcesRadioUtil.setModeAsync(modeItem.mRadio, modeItem.mKey, null);
            }

            // DMR mode do not report back node changed, so force mode change check
            if (NodeSysCapsValidModes.Mode.DMR == NodeSysCapsValidModes.ConvertIdToEnum(modeItem.mModeId)) {

                modeItem.mRadio.getNode(NodeSysMode.class, false, true, new IGetNodeCallback() {
                    @Override
                    public void getNodeResult(NodeInfo node) {

                        forceDMRBrowseFragmentLoad();

                        //Mode selection tick must be manually moved in Landscape
                        if(LayoutDecider.isLandscape(MainApplication.getCurrentActivity())){
                            mAdapter.removeSelectionTick();
                            modeItem.mIsCurrentModeSelected = true;
                            mAdapter.notifyDataSetChanged();
                        }

                        onModeChange();
                    }

                    @Override
                    public void getNodeError(Class nodeType, NodeErrorResponse error) {

                    }
                });

            }
        } catch (Exception e) {
            FsLogger.log("SourcesFragment: " + e, LogLevel.Error);
        }
    }

    private void setAuthenticationUrlForSaavnMode() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();

        if (currentRadio != null) {
            currentRadio.setNode(new NodeSysNetAuthorisationReturnUrl(ConnectedSpeakerViewModel.REDIRECT_URL), false);
        }
    }

    /**
     * The speaker does not report its mode as being DMR unless playback has started so we
     * provide the Fragment factory with the current radio so it knows when to load a Local
     * Music fragment. Additionally notify the activity that the adapter should be updated,
     * as it will not get a notification from the of a mode change.
     */
    private void forceDMRBrowseFragmentLoad() {
        //Let the fragment factory know which device to return DMR fragments for
        FragmentFactory.getInstance().addDMRRadio(NetRemoteManager.getInstance().getCurrentRadio());

        //Set DMR as current mode to display correct items
        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.set(NodeSysCapsValidModes.Mode.DMR);
    }

    private void showModeChangingProgressDlg() {
        NetRemote.getMainThreadExecutor().execute(() -> {
            closeModeChangingProgressDlg();

            ProgressDialog progressDialog = new ProgressDialog(MainApplication.getCurrentActivity());

            progressDialog.setMessage(MainApplication.getContext().getString(R.string.please_wait));
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);

            DialogsHolder.addDialogToCollection(MODE_CHANGE_PROGRESS_DLG, progressDialog);

            progressDialog.show();

            initTimeoutTimer();
        });
    }

    private void closeModeChangingProgressDlg() {
        stopTimeoutTimer();

        DialogsHolder.dismissDialog(MODE_CHANGE_PROGRESS_DLG);
    }

    private void initTimeoutTimer() {
        modeChangingTimeoutId = DelayedPostsManager.getInstance().registerNewCallbackID();
        DelayedPostsManager.getInstance().postDelayed(() -> {

            closeModeChangingProgressDlg();

            if (mLifecycle == null) {
                return;
            }

            switchToProperFragmentAfterModeChange();

        }, modeChangingTimeoutId, MODE_CHANGE_DLG_WAIT_TIMEOUT_MS);
    }

    private void stopTimeoutTimer() {
        DelayedPostsManager.getInstance().cancelCallback(modeChangingTimeoutId);
    }

    protected void onModeChange() {
        NetRemote.getMainThreadExecutor().execute(() -> {
            updateModes();

            closeModeChangingProgressDlg();

            if (mIsModeChangedFromApp) {
                mIsModeChangedFromApp = false;

                switchToProperFragmentAfterModeChange();
            } else {
                FsLogger.log("Mode changed from speaker");
            }
        });
    }

    public void sourcesState(boolean loading){
        if (loading) {
            emptyView.set(false);
            sourceLoading.set(mAdapter.getSize() == 0);
        } else {
            sourceLoading.set(false);
            emptyView.set(mAdapter.getSize() == 0);
        }
    }

    private void updateModes() {
        if (!DokUiUtils.isAtLeastStarted(mLifecycle)) {
            FsLogger.log("Sources fragment is not started");
            return;
        }

        sourcesState(true);

        SourcesRadioUtil.getAvailableModes((groupList, sourcesMap, selectedSourceItem) ->
                NetRemote.getMainThreadExecutor().execute(() -> {

            if (!DokUiUtils.isAtLeastStarted(mLifecycle)) {
                FsLogger.log("Sources fragment is not started");
                return;
            }

            currentSourceItem = selectedSourceItem;

            mModesItemsList.clear();
            mModesItemsList.addAll(groupList);

            mModesMap.clear();
            sortRadioListToDisplayForModes((HashMap<SourceItemModel, List<SourceItemModel>>) sourcesMap);
            mModesMap.putAll(sourcesMap);

            mAdapter.notifyDataSetChanged();

            if (currentSourceItem != null && currentSourceItem.mModeId.equalsIgnoreCase(NodeSysCapsValidModes.Mode.DMR.name())) {
                forceDMRBrowseFragmentLoad();
            } else {
                //TODO: cleanDRMPlaylist();
                FragmentFactory.getInstance().removeDRMRadio(NetRemoteManager.getInstance().getCurrentRadio());
            }

            sourcesState(false);
        }));
    }

    public void sortRadioListToDisplayForModes(HashMap<SourceItemModel, List<SourceItemModel>> newSourcesMap) {
        for (Map.Entry<SourceItemModel, List<SourceItemModel>> entry : newSourcesMap.entrySet()) {
            if (entry.getValue().size() == 0 ) {
                continue;
            }

           Collections.sort(entry.getValue(), (o1, o2) -> o1.mRadio.getFriendlyName().compareTo(o2.mRadio.getFriendlyName()));
        }
    }

    private void switchToProperFragmentAfterModeChange() {
        if (currentSourceItem != null &&
                (NodeSysCapsValidModes.Mode.DMR == NodeSysCapsValidModes.ConvertIdToEnum(currentSourceItem.mModeId) ||
                NodeSysCapsValidModes.ConvertIdToEnum(currentSourceItem.mModeId).isAirable())) {

            switchFragmentTo(FragmentFactory.BROWSE_TAG);
        } else {
            switchFragmentTo(FragmentFactory.NOW_PLAYING_TAG);
        }
    }

    private void switchFragmentTo(String fragmentTag){

        Activity parentActivity = MainApplication.getCurrentActivity();

        if (parentActivity != null && parentActivity instanceof IParentActivity) {
            ((IParentActivity) parentActivity).switchFragment(fragmentTag);
        }
    }

    private void switchToExternalApp(SourceItemModel.CastApp app) {
        Activity activity = MainApplication.getCurrentActivity();

        switch (app) {
            case Spotify:
                ExternalAppsOpener.openSpotify(activity);
                break;
            case TuneIn:
                ExternalAppsOpener.openTunein(activity);
                break;
            case PlayMusic:
                ExternalAppsOpener.openGooglePlay(activity);
                break;
            case NPROne:
                ExternalAppsOpener.openNprone(activity);
                break;
            case NONE:
                break;
        }
    }



    private void showConfirmStandaloneModeChangeDlg(final SourceItemModel modeItem) {
        String dialogKey = "standalone_mode_change_dlg";
        Activity activity = MainApplication.getCurrentActivity();
        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, activity))
            return;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity);

        builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.standalone_mode_selected, true));

        builder.setNegativeButton(android.R.string.cancel, null);
        builder.setPositiveButton(android.R.string.ok, (dialog, which) -> changeModeAndConnectToStandaloneRadio(modeItem));

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);
        dlg.show();
    }

    private void changeModeAndConnectToStandaloneRadio(final SourceItemModel sourceItem) {
        //send request to speaker to remove from group
        Context parentActivity = MainApplication.getCurrentActivity();
        Radio radio = sourceItem.mRadio;

        if (radio!= null) {
            MultiroomDeviceModel deviceModel = MultiroomGroupManager.getInstance().getDeviceByUdn(radio.getUDN());
            if (deviceModel != null) {
                List<MultiroomOperation> operationList = new ArrayList<>();
                MultiroomOperation operation = new MultiroomOperation();
                operation.mMultiroomDeviceUDN = deviceModel.mMultiroomUDN;
                operation.mGroupId = MultiroomGroupManager.NO_GROUP_ID;
                operation.mOldGroupId = MultiroomGroupManager.getInstance().getCurrentGroupId();
                operation.mGroupName = MultiroomGroupManager.NO_GROUP_NAME;
                operation.mOldGroupName = MultiroomGroupManager.getInstance().getCurrentGroupName();
                operation.mOperationType = MultiroomOperation.MultiroomGroupEditOperation.ADD_REMOVE_SPEAKER_TO_FROM_GROUP;

                operationList.add(operation);

                MultiroomOperationsQueueExecutorTask executorTask = new MultiroomOperationsQueueExecutorTask(parentActivity,
                        operationList, result -> {

                            Activity parentActivity1 = MainApplication.getCurrentActivity();
                            switch (result.mOperationResult) {
                                case DESTROY_GROUP_ERR:
                                    MultiroomDialogsUtil.showDestroyGroupError(parentActivity1);
                                    break;
                                case UNGROUP_DEVICE_ERR:
                                    MultiroomDialogsUtil.showUngroupDeviceError(parentActivity1);
                                    break;
                                case SUCCESS:
                                    //connect to selected radio
                                    changeMode(sourceItem);

                                    ConnectionManager.getInstance().tryConnectToSelectedRadio(sourceItem.mRadio);
                                    break;
                            }
                        });
                TaskHelper.execute(executorTask);
            }
        }
    }

    @Override
    public void onGroupingUpdate() {
        NetRemote.getMainThreadExecutor().execute(() -> updateModes());
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void dispose() {
        mAdapter.dispose();
        if (mLifecycle != null) {
            mLifecycle.removeObserver(this);
            mLifecycle = null;
        }
        mPropertyChangedCallback = null;
    }
}
