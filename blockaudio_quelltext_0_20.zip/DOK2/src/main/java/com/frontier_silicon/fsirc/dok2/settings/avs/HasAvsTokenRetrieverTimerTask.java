package com.frontier_silicon.fsirc.dok2.settings.avs;



import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeAvsHastoken;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNodeUtil;

import java.util.Timer;
import java.util.TimerTask;

public class HasAvsTokenRetrieverTimerTask {
    public final int CHECK_PERIOD = 1000;
    private AVSTimerTAsk mTimerTask;
    private Timer mTimer;

    public void startAvsTokenRetriever(Radio radio, IAvsTokenResponse listener) {
        mTimerTask = new AVSTimerTAsk(radio, listener);
        mTimer = new Timer();
        mTimer.schedule(mTimerTask, 400,CHECK_PERIOD);
    }

    public void stopAvsTokenChecker() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer.purge();
            mTimer = null;
        }

        if (mTimerTask != null) {
            mTimerTask.cancel();
            mTimerTask.dispose();
            mTimerTask = null;
        }
    }

    class AVSTimerTAsk extends TimerTask {
        boolean isCanceled = false;
        private Radio radio;
        private IAvsTokenResponse listner;

        public AVSTimerTAsk(Radio radio, IAvsTokenResponse listener) {
            this.radio = radio;
            this.listner = listener;
        }

        @Override
        public void run() {
            if (isCanceled) {
                return;
            }

            checkAvsToken(radio, listner);
        }

            public void dispose() {
                isCanceled = true;
                radio = null;
                listner = null;
            }
    }

    private void checkAvsToken(Radio radio, IAvsTokenResponse listener) {
        if (radio == null) {
            return;
        }

        RadioNodeUtil.getNodeFromRadioAsync(radio, NodeAvsHastoken.class, node -> {
            if (node != null && listener != null) {
                NodeAvsHastoken nodeAvsHastoken = (NodeAvsHastoken) node;
                if (NodeAvsHastoken.Ord.TRUE == nodeAvsHastoken.getValueEnum()) {
                    notifySubscriber(listener);
                }
            }
        });
    }

    public void notifySubscriber(IAvsTokenResponse listener) {
        NetRemote.getMainThreadExecutor().execute(() -> listener.onToken());
    }

    interface IAvsTokenResponse {
        void onToken();
    }
}
