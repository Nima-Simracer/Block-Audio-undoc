package com.frontier_silicon.fsirc.dok2.mainApplciation.dependencyInjection

import com.frontier_silicon.fsirc.dok2.presets.di.PresetsComponent
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.di.OpenSourceSoftwareComponent
import com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.di.ConnectivityAssistantComponent
import dagger.Module

@Module(subcomponents = [PresetsComponent::class, ConnectivityAssistantComponent::class, OpenSourceSoftwareComponent::class])
object ApplicationProvideModule {
}