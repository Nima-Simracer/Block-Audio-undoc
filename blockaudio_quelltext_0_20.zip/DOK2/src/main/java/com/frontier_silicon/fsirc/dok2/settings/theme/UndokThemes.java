package com.frontier_silicon.fsirc.dok2.settings.theme;

public enum UndokThemes {
        DEFAULT,
        PURPLE,
        RED,
        BLUE,
        GREEN,
        LIGHT,
        DARK
}
