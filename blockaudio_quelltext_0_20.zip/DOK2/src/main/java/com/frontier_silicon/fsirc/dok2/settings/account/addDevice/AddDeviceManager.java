package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.settings.account.FSAuthManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cvladu on 07/03/2018.
 */

public class AddDeviceManager {
    private static AddDeviceManager mInstance = null;

    private AddDeviceManager() {
    }

    public static AddDeviceManager getInstance() {
        if (mInstance == null) {
            mInstance = new AddDeviceManager();
        }

        return mInstance;
    }

    public void getUnassociatedSpeakers(List<MultiroomItemModel> multiroomItemModelList, UnassociatedSpeakersRetrieverRunnable.IFSDCAAssociationChecked callback) {
        List<MultiroomItemModel> fsdcaSpeakers = getSpeakersListForFSDCACapability(multiroomItemModelList);

        UnassociatedSpeakersRetrieverRunnable unassociatedSpeakersRunnable = new UnassociatedSpeakersRetrieverRunnable(fsdcaSpeakers, callback);
        Thread unassociatedSpeakers = new Thread(unassociatedSpeakersRunnable);
        unassociatedSpeakers.start();
    }

    public List<MultiroomItemModel> getSpeakersListForFSDCACapability(List<MultiroomItemModel> multiroomItemModelList) {
        List<MultiroomItemModel> fsdcaSpeakers = new ArrayList<>();

        for (MultiroomItemModel multiroomItemModel : multiroomItemModelList) {
            if (multiroomItemModel != null && multiroomItemModel.getRadio() != null && multiroomItemModel.getRadio().hasFSDCA()) {
                fsdcaSpeakers.add(multiroomItemModel);
            }
        }

        return fsdcaSpeakers;
    }

    public void associateSpeakerWithUndokAccount(final Radio radio, final AssociateSpeakerWithUndokAccountRunnable.IAssociationFinished listener) {

        AssociateSpeakerWithUndokAccountRunnable associateSPeakerRunnable = new AssociateSpeakerWithUndokAccountRunnable(radio, listener);

        Thread associateSpeaker = new Thread(associateSPeakerRunnable);
        associateSpeaker.start();
    }

    public boolean isASpeakerWithTheSameNameAlreadyAssociated(Radio radio) {
        for (FSDCADeviceModel device : FSAuthManager.getInstance().getAssociatedDevices()) {
            if (radio != null && device.getName().equals(radio.getFriendlyName())) {
                return true;
            }
        }

        return false;
    }
}
