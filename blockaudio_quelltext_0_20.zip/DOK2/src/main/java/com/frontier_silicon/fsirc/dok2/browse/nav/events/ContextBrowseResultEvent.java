package com.frontier_silicon.fsirc.dok2.browse.nav.events;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;

/**
 * Created by lsuhov on 02/07/16.
 */

public class ContextBrowseResultEvent {
    public EIRNavigationResult result;

    public ContextBrowseResultEvent(EIRNavigationResult result) {
        this.result = result;
    }
}
