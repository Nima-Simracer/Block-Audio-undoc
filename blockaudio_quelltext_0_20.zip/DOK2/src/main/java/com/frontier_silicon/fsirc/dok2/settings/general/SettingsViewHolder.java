package com.frontier_silicon.fsirc.dok2.settings.general;

import androidx.recyclerview.widget.RecyclerView;

import com.frontier_silicon.fsirc.dok2.databinding.SettingsBindableListItemBinding;

/**
 * Created by lsuhov on 11/10/2017.
 */

public class SettingsViewHolder extends RecyclerView.ViewHolder {

    SettingsBindableListItemBinding mBinding;

    public SettingsViewHolder(SettingsBindableListItemBinding binding) {
        super(binding.getRoot());

        mBinding = binding;
    }
}
