package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseMessageButtonViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.MessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.messageItems.MessageItem;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseMessageButtonBinding;

/**
 * Created by lsuhov on 07/11/2016.
 */

public class BrowseMessageButtonDelegate extends RecyclerViewListItemDelegate {

    private int mBrowseType;

    public BrowseMessageButtonDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseMessageButtonBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_message_button,
                parent, false);
        return new BrowseMessageButtonViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(mBrowseType);
        BrowseItemModel browseItemModel = browseManager.tryGetBrowseItemModel(position);

        MessageManager messageManager = BrowseManagerFactory.getMessageManager(mBrowseType);
        MessageItem messageItem = messageManager.getItem(browseItemModel);

        BrowseMessageButtonViewHolder buttonViewHolder = (BrowseMessageButtonViewHolder) holder;
        BrowseMessageButtonViewModel viewModel = new BrowseMessageButtonViewModel(position, messageItem, messageManager);
        buttonViewHolder.mBinding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseMessageButtonViewHolder formButtonViewHolder = (BrowseMessageButtonViewHolder) holder;
        BrowseMessageButtonViewModel viewModel = formButtonViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            formButtonViewHolder.mBinding.setViewModel(null);
        }
    }

    protected static class BrowseMessageButtonViewHolder extends ListItemViewHolder {
        public BrowseMessageButtonBinding mBinding;

        BrowseMessageButtonViewHolder(BrowseMessageButtonBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
