package com.frontier_silicon.fsirc.dok2.settings.gdpr;

import android.content.Intent;
import androidx.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.SettingsGdprActivityBinding;
import com.frontier_silicon.fsirc.dok2.settings.SettingsType;

public class SettingsWebViewActivity extends UndokActivityBase {
    private SettingsGdprActivityBinding mBinding;
    private String SETTINGS_TYPE_KEY = "SETTINGS_TYPE_KEY";

    private String settingsType;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.settings_gdpr_activity);

        setupAppBar();
        settingsType = getIntent().getExtras().getString(SETTINGS_TYPE_KEY);

        if (settingsType.equals(SettingsType.EUROPEAN_DATA.name())) {
            setTitle(R.string.settings_gdpr);
        } else if (settingsType.equals(SettingsType.IT_SERVICE_STATUS.name())) {
            setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.service_status, true));
        } else if (settingsType.equals(SettingsType.FAQ.name())) {
            setTitle(R.string.faq);
        }

        setupControls();
        enableUpNavigation();
    }

    private void setupControls() {
        String url="";
        if (settingsType.equals(SettingsType.EUROPEAN_DATA.name())) {
            url = getString(R.string.gdpr_website);
        } else if (settingsType.equals(SettingsType.IT_SERVICE_STATUS.name())) {
            url = getString(R.string.it_service_status_link);
        } else if (settingsType.equals(SettingsType.FAQ.name())) {
            url = getString(R.string.faq_link);
        }

        WebSettings webSettings = mBinding.webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        mBinding.webView.setBackgroundColor(Color.TRANSPARENT);

        mBinding.webView.getSettings().setSupportZoom(true);
        mBinding.webView.getSettings().setBuiltInZoomControls(true);
        mBinding.webView.getSettings().setDisplayZoomControls(false);
        mBinding.webView.getSettings().setLoadWithOverviewMode(true);
        mBinding.webView.clearHistory();
        mBinding.webView.clearFormData();
        mBinding.webView.clearCache(true);
        mBinding.webView.setWebViewClient(new EmbeddedWebViewClient());
        mBinding.webView.setWebChromeClient(new EmbeddedWebChromeClient());
        mBinding.webView.loadUrl(url);
    }

    private class EmbeddedWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            mBinding.webView.setInitialScale(0);
            if (url.startsWith("mailto:")) {
                startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse(url)));
            } else {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
            }
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            mBinding.progressLoading.setProgress(0);
            mBinding.progressLoading.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            mBinding.progressLoading.setVisibility(View.INVISIBLE);
        }
    }

    private class EmbeddedWebChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            mBinding.progressLoading.setProgress(newProgress);
        }
    }
}
