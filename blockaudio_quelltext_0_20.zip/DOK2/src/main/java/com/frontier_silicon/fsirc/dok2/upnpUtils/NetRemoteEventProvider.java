package com.frontier_silicon.fsirc.dok2.upnpUtils;

import com.coderus.localmediaplayback.eventProvider.EventProvider;
import com.coderus.localmediaplayback.eventProvider.EventProviderListener;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayStatus;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.HashSet;
import java.util.Iterator;

public class NetRemoteEventProvider implements EventProvider, INodeNotificationCallback {
  private final String LOG_TAG = getClass().getSimpleName();
  private HashSet<EventProviderListener> mEventProviderListeners = new HashSet();
  private final String NODE_PLAYING = "<PLAYING>";
  private final String NODE_BUFFERING = "BUFFERING";
  private final String NODE_REBUFFERING = "REBUFFERING";
  private final String NODE_IDLE = "<IDLE>";
  private final String NO_MEDIA = "NO_MEDIA_PRESENT";
  private String mLastPlayStatus = NO_MEDIA;
  @Override
  public void setListener(EventProviderListener eventProviderListener) {
    mEventProviderListeners.add(eventProviderListener);
    FsLogger.log(LOG_TAG + String.format("EventProviderListener added to NetRemoteEventProvider new size %d", mEventProviderListeners.size()), LogLevel.Warning);
  }

  @Override
  public void onNodeUpdated(NodeInfo node) {
    if (node instanceof NodePlayStatus) {
        FsLogger.log(LOG_TAG + String.format("Play status node received with value: %s", node.toString()));
      String nodeState = node.toString();
      String playStatus = NO_MEDIA;

      FsLogger.log("LocalMedia: nodeUpdate: " + nodeState);
      /**
       * Goes to IDLE after playback finishes, not stopped.
       * Stopped would be user hit stop button, which we actually
       * want to stop playing for, not play next track.
       *
       * Another quirk: Sends IDLE before playback of track starts
       * ignore IDLE is last status isn't playing for now to workaround.
       * (This is probably desired anyway)
       */
      switch (nodeState) {
        case NODE_IDLE:

          if (mLastPlayStatus.equalsIgnoreCase(NODE_PLAYING)) {
            playStatus = "STOPPED";
          }
          break;
        case NODE_PLAYING:
          playStatus = "PLAYING";
          break;
        case NODE_BUFFERING:
        case NODE_REBUFFERING:
          playStatus = "TRANSITIONING";
          break;
      }

      if (!mEventProviderListeners.isEmpty()) {
        Iterator eventListenersIterator = mEventProviderListeners.iterator();

        while(eventListenersIterator.hasNext()) {
          EventProviderListener eventProvider = (EventProviderListener) eventListenersIterator.next();
          // Remove null references where control points have removed themselves
          if (eventProvider == null) {
            eventListenersIterator.remove();
            continue;
          }

          eventProvider.reportedTransportStateDidUpdate(null, playStatus);
        }

      } else {
        FsLogger.log(LOG_TAG + String.format("NetRemoteEventProvider has not listeners to notify "), LogLevel.Error);
      }

      mLastPlayStatus = nodeState;
    }

  }
}
