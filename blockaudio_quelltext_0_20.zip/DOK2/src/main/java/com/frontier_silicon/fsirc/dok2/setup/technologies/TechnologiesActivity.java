package com.frontier_silicon.fsirc.dok2.setup.technologies;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupTechnologiesActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

/**
 * Created by nbalazs on 21/03/2018.
 *
 */

public class TechnologiesActivity extends SetupActivityBase {
    private SetupTechnologiesActivityBinding mBinding;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.setup_technologies_activity);

        mBinding.setViewModel(new TechnologiesActivityVM(this));

        configureToolbarWithoutExitButton(R.string.setup_title_technologies_supported);

        mBinding.textViewGoogleCastDescr.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_google_cast_description, false));
        tintImagesBasedOnTheme();

    }


    private void tintImagesBasedOnTheme() {
        if (DokUiUtils.isLightTheme()) {
            mBinding.bluetoothImage.setColorFilter(getResources().getColor(R.color.dark_black_nowplaying_bottom_background_color));
            mBinding.spotifyImage.setColorFilter(getResources().getColor(R.color.dark_black_nowplaying_bottom_background_color));
        } else {
            mBinding.bluetoothImage.setColorFilter(getResources().getColor(R.color.dark_black_wizard_network_icons_inactive_color));
            mBinding.spotifyImage.setColorFilter(getResources().getColor(R.color.dark_black_wizard_network_icons_inactive_color));
           // mBinding.alexaImage.setColorFilter(getResources().getColor(R.color.dark_black_wizard_network_icons_inactive_color));
        }
    }

    @Override
    public void onBackPressed() {
        // In this screen the user should not be able to go back
    }
}
