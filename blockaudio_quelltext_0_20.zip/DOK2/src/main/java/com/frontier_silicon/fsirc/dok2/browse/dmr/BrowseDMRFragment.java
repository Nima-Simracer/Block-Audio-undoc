package com.frontier_silicon.fsirc.dok2.browse.dmr;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.databinding.Observable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.coderus.localmediaplayback.ControlPoint;
import com.coderus.localmediaplayback.LocalMediaDMR;
import com.coderus.localmediaplayback.Manager;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.FragmentFactory;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IParentActivity;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.notifications.MediaNotificationService;
import com.frontier_silicon.fsirc.dok2.notifications.NotificationMode;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.loggerlib.LogLevel;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysMode;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.dmr.filter.CareTaker;
import com.frontier_silicon.fsirc.dok2.browse.dmr.filter.TextFilterHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.upnpUtils.ClingHelper;

import org.fourthline.cling.model.ValidationException;
import org.fourthline.cling.model.meta.RemoteDevice;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BrowseDMRFragment extends BaseFragment implements IChildFragment, IPageSwitchListener, MediaHandler, INodeNotificationCallback {
    public static final String FRAGMENT_TAG = "TAG_BROWSE_DMR_FRAGMENT";
    public static final String LOG_TAG = FRAGMENT_TAG + ": ";

    private static final String PREF_STORAGE_RATIONAL_PERMISSION_SHOWN = "pref_storage_rational_permission_shown";
    private View mEmptyListView;
    private View mNoResultsFoundTextView;
    private TextView mBrowseNotSupportedText;
    private TextView mSelectionLabel;
    private ListView mMediaListView;
    private ListView mFilterListView;
    private LinearLayout mFilterItemsLayout;
    private BrowseDMRAdapter mAdapter;
    public static boolean mPermissionRequestShown = false;
    private BrowseLocalMediaHelper mBrowseLocalMediaHelper;
    private int PERMISSIONS_REQUEST_EXTERNAL_STORAGE = 1;
    private RemoteDevice mRadio;

    private static Manager mLocalMediaService;
    private boolean mLocalMediaBound;
    private CareTaker mMementoCareTaker;
    private boolean mListFiltered = false;
    private EditText mTextFilterBox;
    private TextFilterHelper mTextFilterHelper;
    private boolean mHasPermission = false;
    private int mEmptyViewPreviousVisibility;
    private int mNoResultsFoundTextPreviousVisibility;
    private int mBrowseNotSupportedPreviousVisibility;
    private static int mSelectedFilterCategory;
    private String[] permissionsToRequest;
    private boolean mRationalPermissionWasShown = false;


    private static BrowseDMRItemModel mSelectedDMRItem;

    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;

    // Service connection used by the local media playback library
    private ServiceConnection mLocalMediaPlaybackConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            FsLogger.log(LOG_TAG + "Local media playback service connected to browse DMR fragment");
            Manager.ManagerBinder binder = (Manager.ManagerBinder) service;
            mLocalMediaService = binder.getService();

            mLocalMediaService.setLifecycleListener(new Manager.ManagerLifecycleListener() {
                public void onEvent(Manager.ServiceLifeEvent event){
                    if (event == Manager.ServiceLifeEvent.REQUEST_CLIENT_UNDBIND) {
                        try {
                            Activity activity = getActivity();
                            if (activity == null) {
                                return;
                            }
                            activity.getApplicationContext().unbindService(mLocalMediaPlaybackConnection);
                        }catch (IllegalArgumentException e){}
                    }
                }
            });
            mLocalMediaService.init();

            mLocalMediaBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            FsLogger.log(LOG_TAG + "Local media playback service disconnected from browse DMR fragment");
            mLocalMediaBound = false;
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.browse_dmr_fragment, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mMediaListView = getView().findViewById(R.id.browseItemsList);
        mSelectionLabel = getView().findViewById(R.id.selectionLabel);
        mSelectionLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBrowseLocalMediaHelper.navigateUpTree();
            }
        });
        mTextFilterHelper = new TextFilterHelper();

        List<BrowseDMRItemModel> mMediaList = new ArrayList<>();
        if (mMediaListView != null) {
            mAdapter = new BrowseDMRAdapter(getActivity(), android.R.layout.simple_list_item_1, mMediaList);
            if (NowPlayingManager.getInstance().isDMRPlaying()) {
                mAdapter.selectTrack(NowPlayingManager.getInstance().getCurrentTrackUri());
            }

            mMediaListView.setAdapter(mAdapter);

            if (mBrowseLocalMediaHelper == null) {
                mBrowseLocalMediaHelper = new BrowseLocalMediaHelper(getActivity(), mAdapter, this);
            } else {
                mBrowseLocalMediaHelper.setAdapter(mAdapter);
            }
            mBrowseLocalMediaHelper.setSelectionLabel(mSelectionLabel);

            mMediaListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                    GuiUtils.hideKeyboard(getActivity());

                    mSelectedDMRItem = mBrowseLocalMediaHelper.updateDisplay(position);
                    BrowseDMRItemModel.Types selectedType = mSelectedDMRItem.getType();

                    //If a song was selected we want to keep the filter
                    if (selectedType != BrowseDMRItemModel.Types.TRACK) {
                        resetFiltering();
                    } else {
                        // switch to now Playing
                        try {
                            IParentActivity parentActivity = (IParentActivity) getActivity();
                            parentActivity.switchFragment(FragmentFactory.NOW_PLAYING_TAG);
                        } catch (Exception e) {
                        }
                    }
                }
            });

            mEmptyListView = getView().findViewById(R.id.empty);
            mMediaListView.setEmptyView(mEmptyListView);
            mNoResultsFoundTextView = getView().findViewById(R.id.textNoResults);
            mBrowseNotSupportedText = getView().findViewById(R.id.textBrowseNotSupported);
            mBrowseNotSupportedText.setVisibility(View.GONE);

            setupFilterOptions();

            setupTextFiltering();

            /**
             * DMR functionality is disabled when the permission has not been granted.
             *
             * By monitoring for mode changes the request can be made each time a user
             * navigates back to the local media mode.
             */
            Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
            if (NetRemoteManager.getInstance().checkConnection()) {
                radio.addNotificationListener(this);
            }

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        onFragmentActivated();

        if (mHasPermission) {
            if (!mBrowseLocalMediaHelper.isNavRootLevel()) {
                mBrowseLocalMediaHelper.restoreAdapter();
            } else {

                mBrowseLocalMediaHelper.changeTopLevelFilter(mSelectedFilterCategory);
            }
            updateNavigationSupported(true);
        }
    }

    @Override
    public void onPause() {

        GuiUtils.hideKeyboard(getActivity());
        mTextFilterBox.getText().clear();
        mTextFilterBox.clearFocus();

        super.onPause();
    }

    @Override
    public void onStart() {
        super.onStart();
        bindLocalMediaServices();

        registerRadioNotifications();
    }

    @Override
    public void onStop() {
        mRadio = null;
        unregisterRadioNotifications();

        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mLocalMediaBound) {
            try {
                getActivity().getApplicationContext().unbindService(mLocalMediaPlaybackConnection);
            } catch (IllegalArgumentException e) {
            }
            mLocalMediaBound = false;
        }

        try {
            getActivity().getApplicationContext().unregisterReceiver(playerEventStateReceiver);
        } catch (IllegalArgumentException e) {
            FsLogger.log(e.getLocalizedMessage(), LogLevel.Error);
        }

    }

    private final BroadcastReceiver playerEventStateReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            String uriStr;

            ControlPoint.EventState eventState = (ControlPoint.EventState) intent.getSerializableExtra("play_state");

            if (eventState != null) {

                switch (eventState) {

                    case PLAYING:
                        uriStr = intent.getStringExtra("uri");
                        NowPlayingManager.getInstance().setCurrentTrackUri(uriStr);
                        mAdapter.selectTrack(uriStr);

                        break;
                    case STOPPED:
                        mAdapter.selectTrack("");
                        NowPlayingManager.getInstance().setCurrentTrackUri("");

                        break;
                }

            }
        }
    };

    @Override
    public void onFragmentActivated() {
        FsLogger.log("LocalMedia: BrowseDMRFragment activated");
        mTextFilterBox.clearFocus();
        GuiUtils.hideKeyboard(mTextFilterBox, getActivity());


        if (!mHasPermission) {

            checkPermissions();
        }

        if (mRadio != null) {

            Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
            if ((radio != null) && (!mRadio.getIdentity().getUdn().getIdentifierString().equals(radio.getUDN()))) {
                initialiseClingDevice(radio);
            }
        }

        // listen track change
        IntentFilter receiverFilter = new IntentFilter();
        receiverFilter.addAction(LocalMediaDMR.LOCAL_MUSIC_PLAY_STATE);

        try {
            getActivity().getApplicationContext().unregisterReceiver(playerEventStateReceiver);
        } catch (IllegalArgumentException e) {

        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getActivity().getApplicationContext().registerReceiver(playerEventStateReceiver, receiverFilter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            getActivity().getApplicationContext().registerReceiver(playerEventStateReceiver, receiverFilter);
        }

        if (mAdapter != null) {
            if (NowPlayingManager.getInstance().isDMRPlaying()) {
                mAdapter.selectTrack(NowPlayingManager.getInstance().getCurrentTrackUri());
            }
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onFragmentDeactivated() {

        mTextFilterBox.clearFocus();
        GuiUtils.hideKeyboard(getActivity());
    }

    private void registerRadioNotifications() {
        if (mPropertyChangedCallback == null) {
            mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable observable, int i) {
                    if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode) {
                        FragmentFactory.getInstance().removeDRMRadio(NetRemoteManager.getInstance().getCurrentRadio());
                    }
                }
            };
        }
        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void unregisterRadioNotifications() {
        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.removeOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void checkPermissions() {
        // Required permissions


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest = new String[] { Manifest.permission.READ_MEDIA_AUDIO};
        } else {
           permissionsToRequest = new String[] { Manifest.permission.READ_EXTERNAL_STORAGE};
        }

        boolean granted = true;
        for (String p : permissionsToRequest) {
            if (ContextCompat.checkSelfPermission(getActivity(), p) != PackageManager.PERMISSION_GRANTED) {
                granted = false;
                break;
            }
        }
        if (!granted) {
            mHasPermission = false;

            /**
             * We don't have permission, if the dialog has not previously been shown we
             * should do so now
             */
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), permissionsToRequest[0]) && !mRationalPermissionWasShown) {
                showPermissionRationaleDialogForStorage();
            } else if (PermissionsUtil.wasPermissionRationaleShown(getActivity(), PREF_STORAGE_RATIONAL_PERMISSION_SHOWN)) {
                updateNavigationSupported(false);
            }  else {
                requestPermissions(permissionsToRequest, PERMISSIONS_REQUEST_EXTERNAL_STORAGE);
            }
        } else {
            //Required permission has been granted
            mHasPermission = true;
            mBrowseLocalMediaHelper.changeTopLevelFilter(mSelectedFilterCategory);
        }
    }

    private  void showPermissionRationaleDialogForStorage() {
        AlertDialog.Builder permissionRationaleDlgBuilder = ThemedAlertDialogBuilder.create(getActivity());
        permissionRationaleDlgBuilder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.storage_permission_message, false));
        permissionRationaleDlgBuilder.setPositiveButton(android.R.string.ok, (dialogInterface, i) -> requestPermissions(permissionsToRequest, PERMISSIONS_REQUEST_EXTERNAL_STORAGE));

        permissionRationaleDlgBuilder.create().show();

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        SharedPreferences.Editor prefEditor = prefs.edit();
        prefEditor.putBoolean(PREF_STORAGE_RATIONAL_PERMISSION_SHOWN, true);
        mRationalPermissionWasShown = true;
        prefEditor.apply();
    }

    private void initialiseClingDevice(Radio radio) {
        if (radio != null) {
            try {
                mRadio = (RemoteDevice) ClingHelper.createClingDevice(radio);
            } catch (URISyntaxException e) {
                FsLogger.log(LOG_TAG + "Error constructing URI with manufacture details for Cling device", LogLevel.Error);
            } catch (ValidationException e) {
                FsLogger.log(LOG_TAG + "Error constructing Cling device object with given parameters", LogLevel.Error);
            } catch (MalformedURLException e) {
                FsLogger.log(LOG_TAG + "Error creating Cling device with with URL descriptor", LogLevel.Error);
            } catch (UnknownHostException e) {
                FsLogger.log(LOG_TAG + "Error creating Cling device with InetAddress address", LogLevel.Error);
            }
        } else {
            FsLogger.log(LOG_TAG + "Error creating cling object current radio was null", LogLevel.Error);
        }
    }

    /**
     * Handles work required to show and hide filter list view, populate its contents
     * and handle click events.
     */
    private void setupFilterOptions() {
        mFilterListView = (ListView) getView().findViewById(R.id.filterItemsList);
        mFilterItemsLayout = (LinearLayout) getView().findViewById(R.id.filterItemsLayout);
        Resources resources = getActivity().getResources();
        List<String> filterOptions = new ArrayList<>();
        filterOptions.add(resources.getString(R.string.fs_dok_browse_dmr_filter_artists));
        filterOptions.add(resources.getString(R.string.fs_dok_browse_dmr_filter_album));
        filterOptions.add(resources.getString(R.string.fs_dok_browse_dmr_filter_song));
        filterOptions.add(resources.getString(R.string.fs_dok_browse_dmr_filter_genre));
        filterOptions.add(resources.getString(R.string.fs_dok_browse_dmr_filter_playlists));

        final BrowseDMRFilterAdapter filterAdapter = new BrowseDMRFilterAdapter(getActivity(), R.layout.browse_filter_list_item, filterOptions, mSelectedFilterCategory);
        mFilterListView.setAdapter(filterAdapter);
        mFilterListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                if (mHasPermission) {
                    mBrowseLocalMediaHelper.changeTopLevelFilter(position);
                    mSelectedFilterCategory = position;

                    View tmpView = adapterView.getChildAt(position);
                    if (tmpView != null) {
                        ImageView newFilterTick = (ImageView) adapterView.getChildAt(position).findViewById(R.id.imageViewSelected);
                        filterAdapter.moveSelectionTick(newFilterTick);
                    }

                    resetFiltering();
                    hideSelectionLabel();
                }

                animateFilterListOut();
            }

        });

        LinearLayout searchLayout = (LinearLayout) getView().findViewById(R.id.layoutSearch);
        searchLayout.bringToFront();

        ImageButton showFilterButton = (ImageButton) getView().findViewById(R.id.buttonSearch);
        mBrowseLocalMediaHelper.setFilterButton(showFilterButton);
        showFilterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mFilterItemsLayout.getVisibility() == View.VISIBLE) {
                    animateFilterListOut();
                } else {
                    mTextFilterBox.setText("");
                    animateFilterListIn();
                }
            }
        });
    }

    private void setupTextFiltering() {
        mMementoCareTaker = new CareTaker();
        mTextFilterBox = (EditText) getView().findViewById(R.id.editTextSearchLocalMedia);
        

        mTextFilterBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
                if (!mListFiltered) {
                    FsLogger.log(LOG_TAG + "List previously unfiltered saving state", LogLevel.Info);
                    mMementoCareTaker.saveOriginalState(mAdapter.saveStateToMemento());
                    mListFiltered = true;
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String enteredText = editable.toString();
                int enteredTextLength = enteredText.length();
                int newListSize;

                //If zero we need to display unfiltered list
                if (enteredTextLength == 0) {
                    FsLogger.log(LOG_TAG + "No text in filter after update resetting", LogLevel.Info);
                    newListSize = mAdapter.restoreStateFromMemento(mMementoCareTaker.getOriginalState());
                    mListFiltered = false;
                } else {
                    //Otherwise filter based on the unfiltered list
                    newListSize = mTextFilterHelper.filterMediaList(enteredText, mMementoCareTaker.copyOriginalState(), mAdapter);
                }

                setupEmptyListView(newListSize);
            }
        });

        mTextFilterBox.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    // Perform action on key press

                    if(mTextFilterBox.requestFocus()) {
                        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

                        GuiUtils.hideKeyboard(getActivity());
                    }

                    return true;
                }
                return false;
            }
        });

    }

    /**
     * Resets all previous filtering data
     * ensuring that filtering is applied
     * to the new list in view
     */
    private void resetFiltering() {
        mListFiltered = false;
        mTextFilterBox.setText("");
    }

    /**
     * Slides the list of filter options into view from underneath the search area
     * using a translate animation. Additionally the EditText for the filter is disabled
     * and the empty list view is set to <code>INVISIBLE</code> in order to prevent it being visible
     * when no search results are found and the filter menu is shown
     */
    private void animateFilterListIn() {
        mFilterItemsLayout.setVisibility(View.VISIBLE);
        TranslateAnimation slideInAnim = new TranslateAnimation(0, 0, -mFilterItemsLayout.getHeight(), 0);
        slideInAnim.setDuration(300);
        mFilterItemsLayout.startAnimation(slideInAnim);

        //mTextFilterBox.setEnabled(false);
        mTextFilterBox.setHint(R.string.dmr_filters_title);

        //Save it's value before modification for restoration
        mNoResultsFoundTextPreviousVisibility = mNoResultsFoundTextView.getVisibility();
        mNoResultsFoundTextView.setVisibility(View.INVISIBLE);

        mEmptyViewPreviousVisibility = mEmptyListView.getVisibility();
        mEmptyListView.setVisibility(View.INVISIBLE);

        mBrowseNotSupportedPreviousVisibility = mBrowseNotSupportedText.getVisibility();
        mBrowseNotSupportedText.setVisibility(View.INVISIBLE);
    }

    /**
     * Slides the list of filter options out of view from behind the search area
     * using a translate animation. Additionally the EditText for the filter is enabled
     * and the empty list view is set to visible again.
     */
    private void animateFilterListOut() {
        TranslateAnimation slideOutAnim = new TranslateAnimation(0, 0, 0, -mFilterItemsLayout.getHeight());
        slideOutAnim.setDuration(300);
        slideOutAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) { /* Not required*/ }

            @Override
            public void onAnimationEnd(Animation animation) {
                mFilterItemsLayout.setVisibility(View.GONE);

                //Return view elements to their previous state
                mEmptyListView.setVisibility(mEmptyViewPreviousVisibility);
                mNoResultsFoundTextView.setVisibility(mNoResultsFoundTextPreviousVisibility);
                mBrowseNotSupportedText.setVisibility(mBrowseNotSupportedPreviousVisibility);

                mTextFilterBox.setHint(R.string.dmr_search);
            }

            @Override
            public void onAnimationRepeat(Animation animation) { /* Not required*/ }
        });

        if (mHasPermission) {
            mTextFilterBox.setEnabled(true);
        }


        mFilterItemsLayout.startAnimation(slideOutAnim);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (permissions.length > 0 && permissions[0].equalsIgnoreCase(permissionsToRequest[0])) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mHasPermission = true;

                //Show artists by default
                mBrowseLocalMediaHelper.changeTopLevelFilter(mSelectedFilterCategory);
                updateNavigationSupported(true);
            }
            mAdapter.notifyDataSetChanged();
        }
    }

    public void updateNavigationSupported(final boolean isNavigationSupported) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isNavigationSupported) {
                    mBrowseNotSupportedText.setVisibility(View.GONE);
                    mEmptyListView.setVisibility(View.GONE);
                    mTextFilterBox.setEnabled(true);
                    //mTextFilterBox.setText(R.string.search_hint);
                } else {
                    mBrowseNotSupportedText.setVisibility(View.VISIBLE);
                    mBrowseNotSupportedText.setText(R.string.dmr_browse_no_permissions);

                    mEmptyListView.setVisibility(View.GONE);
                    mMediaListView.setEmptyView(null);
                    //mTextFilterBox.setEnabled(false);
                }
            }
        });
    }

    /**
     * Adjust the view elements to whether media items are displayed on screen or not.
     * <p>
     * When no media is visible to the user the 'no results message' should be shown and
     * the spinner should be hidden. While the opposite is true when media is being shown.
     *
     * @param size The number of items returned by a query
     */
    public void setupEmptyListView(int size) {
        if (mHasPermission) {
            if (size > 0) {
                mMediaListView.setEmptyView(mEmptyListView);
                mNoResultsFoundTextView.setVisibility(View.GONE);
                mNoResultsFoundTextPreviousVisibility = View.GONE;
            } else {
                mNoResultsFoundTextPreviousVisibility = View.VISIBLE;
                mNoResultsFoundTextView.setVisibility(View.VISIBLE);
                mEmptyListView.setVisibility(View.GONE);
                mMediaListView.setEmptyView(null);
            }
        }
    }

    @Override
    public void hideSelectionLabel() {
        if (mSelectionLabel != null) {
            mSelectionLabel.setText("");
            mSelectionLabel.setVisibility(View.GONE);
            //mBrowseLocalMediaHelper.clearSelectionLabelBackstack();
        }
    }

    private void bindLocalMediaServices() {
        if (!mLocalMediaBound) {
            boolean result = getActivity().getApplicationContext().bindService(
                    new Intent(getActivity(), Manager.class),
                    mLocalMediaPlaybackConnection,
                    Context.BIND_AUTO_CREATE
            );

            if (!result) {
                FsLogger.log(LOG_TAG + "Binding to Local Media Playback service failed", LogLevel.Error);
            }
        }
    }

    boolean back = false;
    @Override
    public boolean isBackButtonHandledByFragment(boolean upButton) {
        // hide the "up" btn (always)
        if (upButton) {
            return false;
        }

        // use the default back behaviour if root level
        if (mBrowseLocalMediaHelper.isNavRootLevel()) {

            if (mNoResultsFoundTextView.getVisibility() == View.VISIBLE) {
                mNoResultsFoundTextView.setVisibility(View.INVISIBLE);

                mMediaListView.setEmptyView(mEmptyListView);
                mTextFilterBox.setText("");
                mTextFilterBox.setHint(R.string.dmr_search);
                mTextFilterBox.setEnabled(true);
            } else

            // show filters is one is on root level
            if (mFilterItemsLayout.getVisibility() != View.VISIBLE) {
                animateFilterListIn();
                back = true;
                return true;
            } else {

                return false;
            }
        }

        return true;
    }

    @Override
    public void onBackButton() {
        if (!mBrowseLocalMediaHelper.navigateUpTree()){

            if (mFilterItemsLayout.getVisibility() != View.VISIBLE) {
                animateFilterListIn();
            } else {
                if (!back) {
                    animateFilterListOut();
                } else {
                    back = false;
                }
            }
        }
    }

    public String getStaticTag() {
        return FRAGMENT_TAG;
    }

    @Override
    public void invokePlayMediaList(List<Uri> mediaList, int playFromPosition) {

        if (mLocalMediaService != null) {
            mLocalMediaService.stopForeground(true);
        }

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        if (mRadio == null) {
            initialiseClingDevice(radio);
        }

        if (mRadio != null) {
            // The library should be run as a started service to allow playback after the app
            // has been closed.
            Intent localMediaPlayback = new Intent(getActivity(), Manager.class);
            getActivity().startService(localMediaPlayback);

            // Create a notification and run the service in the foreground
            try {
                MediaNotificationService.startService(getActivity(), radio, NotificationMode.DMR);
            } catch (RuntimeException e) {
                FsLogger.log("noti: system prevent service to start");
            }

            mLocalMediaService.playMedia(mRadio, mediaList, playFromPosition, false);
            NowPlayingManager.getInstance().setDMRPlaying(true);

            FsLogger.log(LOG_TAG + String.format(Locale.getDefault(), "Sending playlist of size %d to %s",
                    mediaList.size(), mRadio.getDetails().getFriendlyName()), LogLevel.Info);
        } else {
            FsLogger.log(LOG_TAG + "Unable to invoke play media on local media library radio was null",
                    LogLevel.Error);
        }
    }

    @Override
    public void onNodeUpdated(NodeInfo node) {
        if (node instanceof NodeSysMode) {
            //Mode changes reset permission request
            mPermissionRequestShown = false;
        }
    }
}

