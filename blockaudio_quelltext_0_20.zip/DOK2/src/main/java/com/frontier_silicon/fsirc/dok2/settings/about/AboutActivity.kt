package com.frontier_silicon.fsirc.dok2.settings.about

import androidx.databinding.DataBindingUtil
import android.os.Bundle
import android.text.Html
import android.text.method.LinkMovementMethod
import android.view.View
import com.frontier_silicon.components.common.GuiUtils
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase
import com.frontier_silicon.fsirc.dok2.databinding.AboutActivityBinding
import com.frontier_silicon.fsirc.dok2.settings.FWVersionRunnable
import com.frontier_silicon.fsirc.dok2.settings.IFWVersionResult
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils
import java.util.*

class AboutActivity: UndokActivityBase() {
    private var mSoftwareVersion = "Unknown"
    private var mBinding: AboutActivityBinding? = null

     override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mBinding = DataBindingUtil.setContentView(this, R.layout.about_activity)

        setupAppBar()
        enableUpNavigation()
        setTitle(R.string.about)
        setupControls()
    }

    private fun setupControls() {
        mBinding!!.textVersion.text = getString(R.string.app_version, DokUiUtils.getAppVersion(this))

        val year = Calendar.getInstance().get(Calendar.YEAR)
        mBinding!!.textInfoAbout.text = getString(R.string.about_description, year.toString())

       // setEmailContent()

        GuiUtils.setTintToDrawable(mBinding!!.aboutFrameLayout.background, this, R.attr.navigationbar_background_color)
    }

   /* override fun onResume() {
        super.onResume()
        mBinding!!.progressBarRetrievingFWVersionAbout.visibility = View.VISIBLE
        val runnable = FWVersionRunnable(IFWVersionResult { fwVersion ->
            mSoftwareVersion = fwVersion
            setEmailContent()
        })
        val thread = Thread(runnable)
        thread.start()
    }


    private fun setEmailContent() {
        if (DokUiUtils.isDestroyed(this)) {
            return
        }

        mBinding!!.progressBarRetrievingFWVersionAbout.visibility = View.GONE
        var subjectText = getString(R.string.feedback_email_subject)
        val bodyText = getString(R.string.feedback_email_body)

        var fullBody = bodyText + DokUiUtils.getInfoForFeedbackAndLogs(DokUiUtils.FeedbackType.Feedback, mSoftwareVersion, this)

        // Replace spaces with %20
        subjectText = subjectText.replace(" ", "%20")
        fullBody = fullBody.replace(" ", "%20")

        mBinding!!.textLinkContact.text = Html.fromHtml("<a href=\"mailto:" + getString(R.string.contact_link) +
               "?subject=" + subjectText +
                "&body=" + fullBody + "\" >" +
               getString(R.string.contact_link) + "</a>")
    }  */
}