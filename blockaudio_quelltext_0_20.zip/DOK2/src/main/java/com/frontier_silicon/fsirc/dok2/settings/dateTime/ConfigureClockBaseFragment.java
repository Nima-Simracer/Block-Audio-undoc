package com.frontier_silicon.fsirc.dok2.settings.dateTime;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import com.frontier_silicon.NetRemoteLib.Node.BaseSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.BaseSysClockMode;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsUtcSettingsList;
import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.DateTimeParams;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public abstract class ConfigureClockBaseFragment extends BaseFragment {


    protected Spinner mHourFormatSpinner;
    protected Spinner mClockSourceSpinner;
    protected ViewGroup mFmAndDabClockLayout;
    protected ViewGroup mNetworkClockLayout;
    protected ViewGroup mManualClockLayout;
    protected Spinner mTimeZoneSpinner;
    protected CheckBox mDaylightSavingCheckbox;
    protected TextView mDateTextView;
    protected TextView mTimeTextView;

    protected DateTimeParams mDateTimeParams;
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.setup_configure_clock_fragment, container, false);
    }

    protected void setupControls() {
        setupHourFormatSpinner();
        extractClockSourceLayouts();
        setupClockSourceSpinner();
        setupDateChooser();
        setupTimeChooser();
    }

    private void setupTimeChooser() {
        ImageButton editTimeBtn = getView().findViewById(R.id.buttonEditTime);
        editTimeBtn.setOnClickListener(view -> showTimePickerDlg());

        mTimeTextView = getView().findViewById(R.id.textViewTime);
        mTimeTextView.setOnClickListener(v -> showTimePickerDlg());
    }

    private void showTimePickerDlg() {
        Context parentActivity = getActivity();

        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        boolean is24hMode = (mDateTimeParams.mHourFormat == BaseSysClockMode.Ord._24_HOUR);

        TimePickerDialog datePickerDialog = new TimePickerDialog(parentActivity, (timePicker, hour1, minute1) -> {
            mDateTimeParams.mHour = hour1;
            mDateTimeParams.mMinute = minute1;
            updateTimeEditText();
        }, hour, minute, is24hMode);

        datePickerDialog.show();
    }

    private void updateTimeEditText() {
        mTimeTextView.setText(getTimeDisplayString(mDateTimeParams.mHour, mDateTimeParams.mMinute, mDateTimeParams.mHourFormat));
    }

    private String getTimeDisplayString(int hour, int minute, BaseSysClockMode.Ord hourFormat) {

        String minuteStr = "" + minute;
        if (minute < 10) {
            minuteStr = "0" + minute;
        }

        String ampmStr = "";
        if (hourFormat == BaseSysClockMode.Ord._12_HOUR) {
            if (hour < 12) {
                ampmStr = "AM";
                if (hour == 0) {
                    hour = 12;
                }
            } else {
                ampmStr = "PM";
                if (hour > 12) {
                    hour = hour - 12;
                }
            }
        }

        return hour + ":" + minuteStr + " " + ampmStr;

    }

    private void setupDateChooser() {
        ImageButton editDateBtn = getView().findViewById(R.id.buttonEditDate);
        editDateBtn.setOnClickListener(view -> showDatePickerDlg());

        mDateTextView =  getView().findViewById(R.id.textViewDate);
        mDateTextView.setOnClickListener(v -> showDatePickerDlg());
    }

    private void showDatePickerDlg() {
        Context parentActivity = getActivity();

        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int monthOfYear = c.get(Calendar.MONTH);
        int dayOfMonth = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(parentActivity, (datePicker, year1, month, day) -> {
            mDateTimeParams.mDateYear = year1;
            mDateTimeParams.mDateMonth = month + 1;
            mDateTimeParams.mDateDay = day;
            updateDateEditText();
        }, year, monthOfYear, dayOfMonth);

        datePickerDialog.show();
    }

    private String getDateDisplayString(int year, int month, int day) {
        boolean ddmmyyyy = true;
//        if (dateFormat != null) {
//            ddmmyyyy = (dateFormat == BaseSysClockDateFormat.Ord.DATE_DD_MM_YYYY);
//        }

        String dayStr = "" + day;
        if (day < 10) {
            dayStr = "0" + day;
        }

        String monthStr = "" + month;
        if (month < 10) {
            monthStr = "0" + month;
        }

        if (ddmmyyyy) {
            return dayStr + "-" + monthStr + "-" + year;
        } else {
            return monthStr + "-" + dayStr + "-" + year;
        }
    }

    public void extractClockSourceLayouts() {
        mFmAndDabClockLayout = getView().findViewById(R.id.fmAndDabClockSourceLayout);
        mNetworkClockLayout = getView().findViewById(R.id.networkClockSourceLayout);
        mManualClockLayout = getView().findViewById(R.id.manualClockSourceLayout);

        mTimeZoneSpinner = getView().findViewById(R.id.spinnerTimeZone);
        mTimeZoneSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                onUtcTimeZoneSelectionChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mDaylightSavingCheckbox = getView().findViewById(R.id.checkBoxDaylightSaving);
        mDaylightSavingCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> onDaylightSavingChanged());
    }

    private void setupHourFormatSpinner() {
        mHourFormatSpinner = getView().findViewById(R.id.spinnerHourFormat);
        ArrayAdapter<CharSequence> hourAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.hour_format_array,
                android.R.layout.simple_spinner_item);
        hourAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mHourFormatSpinner.setAdapter(hourAdapter);
        mHourFormatSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                onHourFormatSelectionChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void setupClockSourceSpinner() {
        mClockSourceSpinner = getView().findViewById(R.id.spinnerClockSource);

        final List<NodeSysCapsClockSourceList.ListItem> nodeListItems = getNodeClockSourceListItems();
        List<String> lstSources = getClockSourceStringList(nodeListItems);

        ArrayAdapter<String> clockSourceAdapter = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, lstSources);
        clockSourceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mClockSourceSpinner.setAdapter(clockSourceAdapter);
        mClockSourceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                NodeSysCapsClockSourceList.ListItem listItemModel = nodeListItems.get(position);
                NodeListItem.FieldSource clockSource = listItemModel.getSource();
                onSelectedClockSourceChanged(clockSource);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    abstract protected List<NodeSysCapsClockSourceList.ListItem> getNodeClockSourceListItems();
    abstract protected List<NodeSysCapsUtcSettingsList.ListItem> getUTCTimeZoneList();

    private List<String> getClockSourceStringList(List<NodeSysCapsClockSourceList.ListItem> nodeListItems) {
        List<String> lstSources = new ArrayList<>();
        for (int i = 0; i < nodeListItems.size(); i++) {

            int stringId = -1;

            BaseSysCapsClockSourceList.ListItem listItem = nodeListItems.get(i);
            if (listItem.getSource() == null) {
                continue;
            }

            switch (listItem.getSource()) {
                case DAB:
                    stringId = R.string.dab_update;
                    break;
                case FM:
                    stringId = R.string.fm_update;
                    break;
                case Manual:
                    stringId = R.string.no_update;
                    break;
                case SNTP:
                    stringId = R.string.network_update;
                    break;
                default:
                    FsLogger.log("Clock Source not available");
            }

            String strOption = "";
            if (stringId != -1)
                strOption = getString(stringId);

            lstSources.add(strOption);
        }

        return lstSources;
    }

    private void onSelectedClockSourceChanged(NodeListItem.FieldSource clockSource) {
        hideAllClockSourceLayouts();

        switch (clockSource) {
            case FM:
            case DAB:
                mFmAndDabClockLayout.setVisibility(View.VISIBLE);
                break;
            case SNTP:
                mNetworkClockLayout.setVisibility(View.VISIBLE);
                onNetworkClockSourceSelected();
                break;
            case Manual:
                mManualClockLayout.setVisibility(View.VISIBLE);
                onManualClockSourceSelected();
                break;
        }

        if (mDateTimeParams == null) {
            return;
        }
        mDateTimeParams.mClockSource = clockSource;
    }

    private void onManualClockSourceSelected() {
        updateDateEditText();
        onHourFormatSelectionChanged();
    }

    private void updateDateEditText() {
        mDateTextView.setText(getDateDisplayString(mDateTimeParams.mDateYear, mDateTimeParams.mDateMonth, mDateTimeParams.mDateDay));
    }

    private void onNetworkClockSourceSelected() {
        fillTimeZonesSpinnerIfNeeded();
    }

    private void fillTimeZonesSpinnerIfNeeded() {
        Adapter adapter = mTimeZoneSpinner.getAdapter();
        if (adapter != null)
            return;

        List<NodeSysCapsUtcSettingsList.ListItem> nodeUtcList = getUTCTimeZoneList();
        if (nodeUtcList == null)
            return;

        List<String> strList = new ArrayList<>();
        for (NodeSysCapsUtcSettingsList.ListItem nodeListItem: nodeUtcList) {
            strList.add(getString(R.string.utc) + " " + getFormattedTimeOffset(nodeListItem.getTime()) +
                    ": " + nodeListItem.getRegion());
        }

        ArrayAdapter<String> mUtcTimeZonesAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, strList);
        mUtcTimeZonesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mTimeZoneSpinner.setAdapter(mUtcTimeZonesAdapter);

        updateUTCSelectionFromParams();
    }

    private String getFormattedTimeOffset(Long time) {
        int hours = (int) (time / 3600);
        int minutes = Math.abs((int) ((time % 3600) / 60));

        String formatedTime = String.format("%02d:%02d", hours, minutes);
        if (time >= 0) {
            formatedTime = "+" + formatedTime;
        } else if (hours == 0 && time < 0) {
            formatedTime = "-" + formatedTime;
        }

        return formatedTime;
    }

    private void onDaylightSavingChanged() {
        if (mDateTimeParams == null)
            return;

        mDateTimeParams.mDaylightSaving = mDaylightSavingCheckbox.isChecked();
    }

    protected void onUtcTimeZoneSelectionChanged() {
        if (mDateTimeParams == null)
            return;

        NodeSysCapsUtcSettingsList.ListItem utcOffset = getUtcOffsetFromSpinner();
        if (utcOffset != null) {
            mDateTimeParams.setUTCOffsetNode(utcOffset);
            mDateTimeParams.setSelectedTimeZone(utcOffset.getRegion());
        }
    }

    private NodeSysCapsUtcSettingsList.ListItem getUtcOffsetFromSpinner() {
        List<NodeSysCapsUtcSettingsList.ListItem> utcList = getUTCTimeZoneList();
        if (utcList == null)
            return null;

        int position = mTimeZoneSpinner.getSelectedItemPosition();
        if (position == -1)
            return null;

        return utcList.get(position);
    }

    private void onHourFormatSelectionChanged() {
        if (mDateTimeParams == null)
            return;

        mDateTimeParams.mHourFormat = BaseSysClockMode.Ord.values()[mHourFormatSpinner.getSelectedItemPosition()];

        updateTimeEditText();
    }

    private void hideAllClockSourceLayouts() {
        mFmAndDabClockLayout.setVisibility(View.GONE);
        mNetworkClockLayout.setVisibility(View.GONE);
        mManualClockLayout.setVisibility(View.GONE);
    }


    private void updateUTCSelectionFromParams() {
        if (mDateTimeParams.getUTCOffsetNode() == null) {
            if (mDateTimeParams.mUtcOffsetSeconds != null) {
                setTimeZoneForDateTimeParams();
                return;
            } else {
                setTimeZoneFromPhone();
                return;
            }
        }

        Long indexOfUtcItem = mDateTimeParams.getUTCOffsetNode().getKey();
        mTimeZoneSpinner.setSelection(indexOfUtcItem.intValue());
    }

    private void setTimeZoneFromPhone() {
        TimeZone phoneTimeZone = mDateTimeParams.mPhoneTimeZone;
        List<NodeSysCapsUtcSettingsList.ListItem> nodeUtcList = getUTCTimeZoneList();
        if (nodeUtcList == null)
            return;

        int phoneTimeZoneOffset = phoneTimeZone.getRawOffset() / 1000;

        for (int i = 0; i < nodeUtcList.size(); i++) {
            NodeSysCapsUtcSettingsList.ListItem timeZoneItem = nodeUtcList.get(i);
            if (phoneTimeZoneOffset == timeZoneItem.getTime()) {
                mTimeZoneSpinner.setSelection(timeZoneItem.getKey().intValue());
                return;
            }
        }
    }

    private void setTimeZoneForDateTimeParams() {
        List<NodeSysCapsUtcSettingsList.ListItem> nodeUtcList = getUTCTimeZoneList();
        if (nodeUtcList == null)
            return;

        for (int i = 0; i < nodeUtcList.size(); i++) {
            NodeSysCapsUtcSettingsList.ListItem timeZoneItem = nodeUtcList.get(i);
            if (mDateTimeParams.getSelectedTimeZone()== ""){
                if (mDateTimeParams.mUtcOffsetSeconds.equals(timeZoneItem.getTime())) {
                    mTimeZoneSpinner.setSelection(timeZoneItem.getKey().intValue());
                }
            }
            else {
                if (mDateTimeParams.mUtcOffsetSeconds.equals(timeZoneItem.getTime()) && timeZoneItem.getRegion().equals(mDateTimeParams.getSelectedTimeZone())) {
                    mTimeZoneSpinner.setSelection(timeZoneItem.getKey().intValue());
                    return;
                }
            }
        }
    }

    protected void updateDaylightSavingFromParams() {
        mDaylightSavingCheckbox.setChecked(mDateTimeParams.mDaylightSaving);
    }

    protected void updateHourFormatSelectionFromParams() {
        if (mDateTimeParams.mHourFormat == BaseSysClockMode.Ord._12_HOUR) {
            mHourFormatSpinner.setSelection(0);
        } else {
            mHourFormatSpinner.setSelection(1);
        }
    }

    protected void updateClockSourceSelectionFromParams() {
        List<NodeSysCapsClockSourceList.ListItem> listItems = getNodeClockSourceListItems();
        for (int i = 0; i < listItems.size(); i++) {
            NodeSysCapsClockSourceList.ListItem nodeListItem = listItems.get(i);
            if (nodeListItem.getSource() == mDateTimeParams.mClockSource) {
                mClockSourceSpinner.setSelection(i);
                break;
            }
        }
    }

}
