package com.frontier_silicon.fsirc.dok2.stereo.selectSecondary;

import android.app.Activity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.StereoSpeakerListItemBinding;
import com.frontier_silicon.fsirc.dok2.stereo.StereoSpeakersDiffCallback;
import com.frontier_silicon.fsirc.dok2.stereo.StereoSpeakerListItemViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 03/08/2017.
 */

public class SelectSecondarySpeakerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<StereoItemModel> mStereoItemModels = new ArrayList<>();
    private Activity mActivity;
    private StereoItemModel mPrimaryStereoItemModel;

    public SelectSecondarySpeakerAdapter(StereoItemModel primaryStereoItemModel, Activity activity) {
        mActivity = activity;
        mPrimaryStereoItemModel = primaryStereoItemModel;
    }

    private class StereoSpeakerViewHolder extends RecyclerView.ViewHolder {
        StereoSpeakerListItemBinding mBinding;

        StereoSpeakerViewHolder(StereoSpeakerListItemBinding binding) {
            super(binding.getRoot());

            mBinding = binding;
        }
    }

    public void swapItems(List<StereoItemModel> stereoItemModels) {
        StereoSpeakersDiffCallback diffCallback = new StereoSpeakersDiffCallback(mStereoItemModels, stereoItemModels);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        mStereoItemModels.clear();
        mStereoItemModels.addAll(stereoItemModels);

        diffResult.dispatchUpdatesTo(this);
    }

    @Override
    public int getItemViewType(int position) {
        StereoItemModel stereoItemModel = mStereoItemModels.get(position);

        return stereoItemModel.itemType;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case StereoItemModel.SPEAKER: {
                StereoSpeakerListItemBinding binding = DataBindingUtil.inflate(
                        LayoutInflater.from(parent.getContext()),
                        R.layout.stereo_speaker_list_item,
                        parent, false);

                return new StereoSpeakerViewHolder(binding);
            }
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
        StereoItemModel stereoItemModel = mStereoItemModels.get(position);

        switch (stereoItemModel.itemType) {
            case StereoItemModel.SPEAKER: {
                StereoSpeakerViewHolder stereoSpeakerViewHolder = (StereoSpeakerViewHolder)viewHolder;
                StereoSpeakerListItemBinding binding = stereoSpeakerViewHolder.mBinding;

                StereoSpeakerListItemViewModel viewModel = new SecondarySpeakerListItemViewModel(stereoItemModel,
                        mPrimaryStereoItemModel, mActivity);
                binding.setViewModel(viewModel);

                break;
            }
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder viewHolder) {

        if (viewHolder instanceof StereoSpeakerViewHolder) {
            StereoSpeakerViewHolder stereoSpeakerViewHolder = (StereoSpeakerViewHolder)viewHolder;
            StereoSpeakerListItemViewModel speakerViewModel = stereoSpeakerViewHolder.mBinding.getViewModel();

            if (speakerViewModel != null) {
                speakerViewModel.dispose();
                stereoSpeakerViewHolder.mBinding.setViewModel(null);
            }
        }
    }

    @Override
    public int getItemCount() {
        return mStereoItemModels.size();
    }

    public void dispose() {
        mStereoItemModels.clear();
        mActivity = null;
    }
}
