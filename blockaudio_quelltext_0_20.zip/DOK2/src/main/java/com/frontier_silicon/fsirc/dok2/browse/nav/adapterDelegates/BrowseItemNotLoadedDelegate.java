package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseItemNotLoadedViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.R;

/**
 * Created by lsuhov on 06/11/2016.
 */

public class BrowseItemNotLoadedDelegate extends RecyclerViewListItemDelegate {

    private int mBrowseType;

    public BrowseItemNotLoadedDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.browse_list_item_not_loaded, parent, false);

        return new BrowseItemNotLoadedViewHolder(view, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        BrowseItemNotLoadedViewHolder notLoadedViewHolder = (BrowseItemNotLoadedViewHolder) holder;

        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(mBrowseType);

        notLoadedViewHolder.mViewModel = new BrowseItemNotLoadedViewModel(position, adapter, browseManager);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseItemNotLoadedViewHolder notLoadedViewHolder = (BrowseItemNotLoadedViewHolder)holder;
        BrowseItemNotLoadedViewModel viewModel = notLoadedViewHolder.mViewModel;
        if (viewModel != null) {
            viewModel.dispose();
            notLoadedViewHolder.mViewModel = null;
        }
    }

    private static class BrowseItemNotLoadedViewHolder extends ListItemViewHolder {
        BrowseItemNotLoadedViewModel mViewModel;

        BrowseItemNotLoadedViewHolder(View view, BrowseItemNotLoadedDelegate delegate) {
            super(view, delegate);
        }
    }
}
