package com.frontier_silicon.fsirc.dok2.multiroom;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.IDialogButtonsResponse;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.IMultiroomOperationListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.multiroom.MultiroomOperation;

import java.util.List;

public class MultiroomEditGroupTask extends AsyncTask<Void, Integer, Boolean> {

    private final MultiroomEditGroupUtil mEditGroupUtil;
    private final List<MultiroomEditGroupItemModel> mAllRadios;
    private final boolean mRenameGroup;
    private final String mNewGroupName;
    private final MultiroomItemModel mMultiroomItemModel;
    private final Context mContext;
    private List<MultiroomOperation> mOperationList;
    private IMultiroomOperationListener mListener;
    private boolean mTooManyClients = false;
    private boolean mGroupNameDuplicated = false;

    public MultiroomEditGroupTask(Context context, List<MultiroomEditGroupItemModel> allRadios,
                                  boolean renameGroup, String newGroupName, MultiroomItemModel multiroomItemModel,
                                  IMultiroomOperationListener listener) {
        this.mContext = context;
        this.mAllRadios = allRadios;
        this.mRenameGroup = renameGroup;
        this.mNewGroupName = newGroupName;
        this.mMultiroomItemModel = multiroomItemModel;
        this.mListener = listener;
        this.mEditGroupUtil = new MultiroomEditGroupUtil();
    }

    @Override
    protected Boolean doInBackground(Void... voids) {
        boolean startEditGroupOps = false;
        mTooManyClients = false;

        this.mOperationList = mEditGroupUtil.getOperationsList(this.mAllRadios, this.mRenameGroup, this.mNewGroupName, this.mMultiroomItemModel);

        int numClientsInGroup = mEditGroupUtil.getNumFinalClientsInGroup(this.mAllRadios, this.mRenameGroup, this.mMultiroomItemModel);

        if (mEditGroupUtil.checkNumClientsInGroup(this.mMultiroomItemModel, numClientsInGroup)) {
            if (!this.mOperationList.isEmpty()) {
                if (this.mRenameGroup && MultiroomGroupManager.getInstance().isGroupNameDuplicated(this.mNewGroupName)) {
                    mGroupNameDuplicated = true;
                    startEditGroupOps = false;
                } else {
                    startEditGroupOps = true;
                }
            }
        } else {
            mTooManyClients = true;
            startEditGroupOps = false;
        }

        return startEditGroupOps;
    }

    @Override
    protected void onPostExecute(Boolean startEditGroupOps) {
        if (startEditGroupOps) {
            MultiroomOperationsQueueExecutorTask executorTask = new MultiroomOperationsQueueExecutorTask(this.mContext,
                    this.mOperationList, this.mListener);
            TaskHelper.execute(executorTask);
        } else {
            if (mTooManyClients) {
                mEditGroupUtil.notifyTooManyClientsInGroup(this.mContext);
            }

            if (mGroupNameDuplicated) {
                mEditGroupUtil.showDuplicateGroupDialog(this.mContext, this.mNewGroupName, new IDialogButtonsResponse() {
                    @Override
                    public void onPositiveClicked() {
                        MultiroomOperationsQueueExecutorTask executorTask = new MultiroomOperationsQueueExecutorTask(
                                mContext, mOperationList, mListener);
                        TaskHelper.execute(executorTask);

                        if (!DialogsHolder.activityIsFinishing((Activity) MultiroomEditGroupTask.this.mContext)) {
                            DialogsHolder.dismissDialog(MultiroomEditGroupDialog.DIALOG_KEY);
                        }
                    }

                    @Override
                    public void onNegativeClicked() {
                        Dialog dialog = DialogsHolder.getDialog(MultiroomEditGroupDialog.DIALOG_KEY);

                        if (dialog != null) {
                            dialog.show();
                        }
                    }

                    @Override
                    public void onNeutralClicked() {
                    }
                });
            }
        }

        if (startEditGroupOps || mOperationList.isEmpty()) {
            if (!DialogsHolder.activityIsFinishing((Activity) this.mContext)) {
                DialogsHolder.dismissDialog(MultiroomEditGroupDialog.DIALOG_KEY);
            }
        }
    }

}
