package com.frontier_silicon.fsirc.dok2.settings.staticRadioSearch

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.frontier_silicon.NetRemoteLib.Discovery.DeviceRecord
import com.frontier_silicon.fsirc.dok2.NavigationHelper
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.databinding.StaticRadioFragmentBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class FragmentStaticRadioFound(private val deviceRecord: DeviceRecord, private val ipAddress: String): BottomSheetDialogFragment() {
    private lateinit var binding: StaticRadioFragmentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.static_radio_fragment, container, false)
        binding.searchAnotherRadioButton.setText(SmartRadioStringsManager.getSmartRadioString(R.string.static_radio_search_another_speaker, true))
        return binding.root
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = BottomSheetDialog(requireContext(), theme)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        return dialog
    }


    override fun onStart() {
        super.onStart()
        initLayout()
    }

    private fun initLayout() {
        deviceRecord?.friendlyName?.let {
            val smartRadiowasDiscovered = getString(R.string.static_radio_speaker_was_discovered, it, ipAddress)
            binding.speakerTextView.text = SmartRadioStringsManager.getSmartRadioString(smartRadiowasDiscovered, true, true)
        }

        binding.goToHomeScreenButton.setOnClickListener {
            NavigationHelper.goToHomeAndClearActivityStack(activity)
        }

        binding.searchAnotherRadioButton.setOnClickListener{
            dismiss()

        }
    }
}