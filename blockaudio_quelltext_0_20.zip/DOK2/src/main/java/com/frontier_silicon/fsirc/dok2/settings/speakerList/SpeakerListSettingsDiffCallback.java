package com.frontier_silicon.fsirc.dok2.settings.speakerList;

import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.frontier_silicon.components.multiroom.MultiroomItemModel;

import java.util.List;

/**
 * Created by lsuhov on 12/10/2017.
 */

public class SpeakerListSettingsDiffCallback extends DiffUtil.Callback {

    List<MultiroomItemModel> mOldList;
    List<MultiroomItemModel> mNewList;

    public SpeakerListSettingsDiffCallback(List<MultiroomItemModel> oldList, List<MultiroomItemModel> newList) {
        mOldList = oldList;
        mNewList = newList;
    }

    @Override
    public int getOldListSize() {
        return mOldList.size();
    }

    @Override
    public int getNewListSize() {
        return mNewList.size();
    }

    /**
     * Called by the DiffUtil to decide whether two object represent the same Item.
     * <p>
     * For example, if your items have unique ids, this method should check their id equality.
     *
     * @param oldItemPosition The position of the item in the old list
     * @param newItemPosition The position of the item in the new list
     * @return True if the two items represent the same object or false if they are different.
     */
    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        MultiroomItemModel oldItem = mOldList.get(oldItemPosition);
        MultiroomItemModel newItem = mNewList.get(newItemPosition);

        if (oldItem != null) {
            if (newItem != null) {
                return oldItem.equals(newItem);
            } else {
                return false;
            }
        } else {
            if (newItem != null) {
                return false;
            } else {
                return true;
            }
        }
    }

    /**
     * Called by the DiffUtil when it wants to check whether two items have the same data.
     * DiffUtil uses this information to detect if the contents of an item has changed.
     * <p>
     * DiffUtil uses this method to check equality instead of {@link Object#equals(Object)}
     * so that you can change its behavior depending on your UI.
     * For example, if you are using DiffUtil with a
     * {@link RecyclerView.Adapter RecyclerView.Adapter}, you should
     * return whether the items' visual representations are the same.
     * <p>
     * This method is called only if {@link #areItemsTheSame(int, int)} returns
     * {@code true} for these items.
     *
     * @param oldItemPosition The position of the item in the old list
     * @param newItemPosition The position of the item in the new list which replaces the
     *                        oldItem
     * @return True if the contents of the items are the same or false if they are different.
     */
    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        MultiroomItemModel oldItem = mOldList.get(oldItemPosition);
        MultiroomItemModel newItem = mNewList.get(newItemPosition);

        // checking single speakers
        if (newItem.getType() == MultiroomItemModel.SimpleSpeaker ||
                newItem.getType() == MultiroomItemModel.MultiroomSpeaker ||
                newItem.getType() == MultiroomItemModel.SingleGroupSpeaker) {

            String oldName = oldItem.getDeviceModel().mFrozenFriendlyName;
            String newName = newItem.getDeviceModel().toString();

            return oldName.contentEquals(newName);
        }

        return oldItem.toString().equals(newItem.toString());
    }
}
