package com.frontier_silicon.fsirc.dok2.setup.finishing;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupFinishingActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;

/**
 * Created by nbalazs on 21/03/2018.
 *
 */

public class FinishingSetupActivity extends SetupActivityBase {

    private FinishingSetupActivityVM mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetupFinishingActivityBinding mBinding = DataBindingUtil.setContentView(this, R.layout.setup_finishing_activity);

        mViewModel = new FinishingSetupActivityVM(this);

        mBinding.setViewModel(mViewModel);

        configureToolbarWithoutExitButton(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_title_configuring_device, true));
    }

    @Override
    protected void onResume() {
        super.onResume();
        mViewModel.startSetupProcess();
    }
}
