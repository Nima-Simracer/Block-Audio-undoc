package com.frontier_silicon.fsirc.dok2.setup.accessPoint.manualAPSelection;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;
import com.frontier_silicon.NetRemoteLib.Radio.ConnectionErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.IConnectionCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.setup.ConnectToSetupAPHelper;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.IConnectToSetupAPListener;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.speakerName.NameYourSpeakerActivity;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;

/**
 * Created by nbalazs on 08/03/2018.
 */

public class ManualAccessPointSelectionActivityVM extends BroadcastReceiver implements IConnectionCallback,
        IConnectToSetupAPListener {

    private Activity mActivity;
    private SetupManager mSetupManager;
    private ConnectToSetupAPHelper mConnectHelper;

    public ObservableField<String> connectedAP = new ObservableField<>();
    public ObservableBoolean isConnectedToAP = new ObservableBoolean();
    public ObservableBoolean isConnectingToRadio = new ObservableBoolean();
    public ObservableBoolean isConnectedToApAndRadio = new ObservableBoolean();

    ManualAccessPointSelectionActivityVM(Activity activity) {
        mActivity = activity;

        init();
    }

    private void init() {
        mSetupManager = SetupManager.getInstance();
        mConnectHelper = ConnectToSetupAPHelper.getInstance();
    }

    public void onResume() {
        mConnectHelper.attachActivity(mActivity, this);
        mSetupManager.registerForRadioConnectionEvents(this);

        startWifiMonitor();

        mConnectHelper.checkConnectionToAPAndRadio();
        updateObservables();
    }

    public void onPause() {
        mConnectHelper.detachActivity();
        mSetupManager.removeFromRadioConnectionEvents(this);

        stopWifiMonitor();
    }

    public void openWiFiSettings() {
        if (isLocationDisabledForUpperOreo()) {
            PermissionsUtil.showLocationDialog(mActivity);

        } else {
            mActivity.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        }
    }

    public void onBackPressed() {
        mActivity.onBackPressed();
    }

    public void onNextPressed() {
        NavigationHelper.goToActivity(mActivity, NameYourSpeakerActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    private boolean isLocationDisabledForUpperOreo() {
        return Build.VERSION.SDK_INT > Build.VERSION_CODES.O && !AccessPointUtil.checkLocationIfAndroid6OrMore(mActivity);
    }

    @Override
    public void refreshList() {
        mActivity.runOnUiThread(this::updateObservables);
    }

    @Override
    public void onConnectToApFailed() {
        mActivity.runOnUiThread(this::updateObservables);
    }


    @Override
    public void onConnectionSuccess(Radio radio) {
        mActivity.runOnUiThread(this::updateObservables);
    }


    @Override
    public void onConnectionError(Radio radio, ConnectionErrorResponse error) {
        mActivity.runOnUiThread(this::updateObservables);
    }


    @Override
    public void onDisconnected(Radio radio, ConnectionErrorResponse error) {
        mActivity.runOnUiThread(this::updateObservables);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        NetworkInfo info = intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
        if (info != null) {
            mActivity.runOnUiThread(() -> {
                mConnectHelper.checkConnectionToAPAndRadio();
                updateObservables();
            });
        }
    }

    private void startWifiMonitor() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.wifi.STATE_CHANGE");
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        mActivity.registerReceiver(this, intentFilter);
    }

    private void stopWifiMonitor() {
        mActivity.unregisterReceiver(this);
    }

    private void updateObservables() {
        updateConnectionStatusOfAP();
        updateConnectingToRadio();
        updateConnectionStatusOfApAndRadio();
    }

    @SuppressLint("StringFormatInvalid")
    private void updateConnectionStatusOfAP() {
        if (mSetupManager.isConnectedToHeadlessAP()) {
            String ssid = AccessPointUtil.getSSIDOfCurrentConnection();
            connectedAP.set(mActivity.getString(R.string.setup_connected_to, ssid));
            isConnectedToAP.set(true);
        } else {
            connectedAP.set(mActivity.getString(R.string.setup_not_connected_to_compatible_ap));
            isConnectedToAP.set(false);
        }
    }

    private void updateConnectingToRadio() {
        boolean isConnecting = mSetupManager.isConnectingToRadio();
        isConnectingToRadio.set(isConnecting);
    }

    private void updateConnectionStatusOfApAndRadio() {
        isConnectedToApAndRadio.set(mSetupManager.isConnectedToHeadlessAP() &&
                                    mSetupManager.isConnectedToRadio());
    }

    public void dispose() {
        mActivity = null;
        mSetupManager = null;
    }
}
