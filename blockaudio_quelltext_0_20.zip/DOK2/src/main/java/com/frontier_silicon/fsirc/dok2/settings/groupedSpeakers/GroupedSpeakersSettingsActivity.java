package com.frontier_silicon.fsirc.dok2.settings.groupedSpeakers;

import android.os.Bundle;
import androidx.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.connection.RadioConnectionDialogsUtil;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.settings.ISettingsControlListener;
import com.frontier_silicon.fsirc.dok2.settings.SettingsArrayAdapter;
import com.frontier_silicon.fsirc.dok2.settings.SettingsItemModel;
import com.frontier_silicon.fsirc.dok2.settings.SettingsUtil;
import com.frontier_silicon.fsirc.dok2.settings.sleepTimer.SleepTimerActivity;
import com.frontier_silicon.fsirc.dok2.settings.speaker.SpeakerSettingsActivity;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import java.util.ArrayList;
import java.util.List;

public class GroupedSpeakersSettingsActivity extends UndokActivityBase implements ISettingsControlListener,
        IMultiroomGroupingListener {

	private SettingsArrayAdapter mAdapter;
	private ArrayList<SettingsItemModel> mSettingsItemsList;

	private SettingsUtil mSettingsUtil = new SettingsUtil();
    private String mGroupId = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_grouped_speakers_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.settings);

        Bundle bundle = getIntent().getExtras();
        if (bundle == null) {
            return;
        }
        mGroupId = bundle.getString(NavigationHelper.GROUP_ID);
        if (TextUtils.isEmpty(mGroupId)) {
            return;
        }

        setupControls();
    }

	public void onResume() {
		super.onResume();

        updateSettingsAsync();

		registerMultiroomGroupNotifListener();
	}

    public void onPause() {
		super.onPause();

		unregisterMultiroomGroupNotifListener();
	}

    protected void setupControls() {
		mSettingsItemsList = new ArrayList<>();

		mAdapter = new SettingsArrayAdapter(this, R.layout.settings_list_item ,R.id.text1, mSettingsItemsList);
        ListView mListView = findViewById(R.id.settingsList);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
				onListItemClick(position);
			}
		});

        View mEmptyListView = findViewById(R.id.empty);
		mListView.setEmptyView(mEmptyListView);
	}
	
	protected void updateSettingsAsync() {
		if (mSettingsUtil != null) {
            mSettingsUtil.getGroupSettings(mGroupId, this, this);
		}
	}
	
	protected void updateSettings(List<SettingsItemModel> settingsList) {
		if (mAdapter != null) {
			mSettingsItemsList.clear();
			mSettingsItemsList.addAll(settingsList);

			if (mSettingsItemsList.size() == 0) {
				onBackPressed();
			} else {
				mAdapter.notifyDataSetChanged();
			}
		}
	}

	protected void onListItemClick(int position) {
		try {
			SettingsItemModel settingsItem = mAdapter.getItem(position);
			onSelectSetting(settingsItem);
		} catch (Exception e) {	
			e.printStackTrace();
		}
	}
	
	protected void onSelectSetting(SettingsItemModel settingsItem) {

        String radioUDN = settingsItem.mRadioUDN;
        if (radioUDN == null) {
            MultiroomDeviceModel deviceModel = MultiroomGroupManager.getInstance().getServerDeviceFromGroupId(mGroupId);
            if (deviceModel == null) {
                return;
            }
            radioUDN = deviceModel.mRadio.getUDN();
        }

        Bundle bundle = new Bundle();
        bundle.putString(NavigationHelper.RADIO_UDN_ARG, radioUDN);

		switch (settingsItem.mType) {

			case SLEEP:
                NavigationHelper.goToActivity(this, SleepTimerActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
				break;

			case AUDIO_DEVICE:
                if (SettingsUtil.isRadioAvailable(settingsItem)) {
                    NavigationHelper.goToActivity(this, SpeakerSettingsActivity.class,
                            NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                } else {
                    if (!DokUiUtils.isDestroyed(this)) {
                        RadioConnectionDialogsUtil.showRadioNotAvailableOnTheNetworkDlg(this,
                                NetRemoteManager.getInstance().getRadio(settingsItem.mRadioUDN), null);
                    }
                }
				break;

			default:
				break;
		}
	}

	@Override
	public void onSettingsUpdated(final List<SettingsItemModel> settingsList) {
		if (!DokUiUtils.isDestroyed(this)) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					updateSettings(settingsList);
				}
			});
		}
	}

	private void registerMultiroomGroupNotifListener() {
		unregisterMultiroomGroupNotifListener();
		MultiroomGroupManager.getInstance().addListener(this);
	}

	private void unregisterMultiroomGroupNotifListener() {
		MultiroomGroupManager.getInstance().removeListener(this);
	}

	@Override
	public void onGroupingUpdate() {
		if (!DokUiUtils.isDestroyed(this)) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					updateSettingsAsync();
				}
			});
		}
	}
}
