package com.frontier_silicon.fsirc.dok2.notifications;

import android.app.ActivityManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.coderus.localmediaplayback.Manager;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingDataModel;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

/**
 * Created by mnisipeanu on 22/05/2017.
 */

public class MediaNotificationService extends Service {
    private static final String TAG = "MediaNotiService ";
    private static NotificationBase currentNotification;

    private static Manager mLocalMediaService;
    private boolean mLocalMediaBound = false;
    private static Radio radio;
    private static Radio tmpRadio;

    private NotificationMode notificationMode;

    private ServiceConnection mLocalMediaPlaybackConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            FsLogger.log(TAG + "Local media playback service connected to browse DMR fragment");
            Manager.ManagerBinder binder = (Manager.ManagerBinder) service;
            mLocalMediaService = binder.getService();
            mLocalMediaService.init();

            mLocalMediaBound = true;

            if (radio != null) {
                int tintColor = GuiUtils.getColorFromAttribute(MainApplication.getContext(), R.attr.sources_icon_color);

                try {
                    LocalMediaNotification
                            .newInstance()
                            .setContext(getApplicationContext(), radio)
                            .setPlayStarted(true)
                            .setTint(tintColor)
                            //.setData( mPlaybackInfoViewModel.playInfoName.get(), mPlaybackInfoViewModel.mPlayArtist + " (" + mPlaybackInfoViewModel.mPlayAlbum + ")")
                            .create();

                    LocalMediaNotification
                            .getInstance().startForeground(MediaNotificationService.this);
                    currentNotification = LocalMediaNotification.getInstance();
                } catch (NullPointerException e) {
                    FsLogger.log(TAG + " notification closed by system");
                    stopSelf();
                }
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            FsLogger.log(TAG + "Local media playback service disconnected from browse DMR fragment");
            mLocalMediaBound = false;
        }
    };


    public static void startService(Context ctx, Radio radio, NotificationMode mode){

        if (radio == null) {
            FsLogger.log(TAG + " start service with null radio");
            return;
        } else if (ctx == null) {
            FsLogger.log(TAG + " start service on null context");
            return;
        }

        Intent stIntent = new Intent(ctx, MediaNotificationService.class);
        stIntent.putExtra("widgetMode", mode);

        if ((MediaNotificationService.radio != null) && (!radio.getIpAddress().equals(MediaNotificationService.radio.getIpAddress()))) {
            MediaNotificationService.radio = null;
            ctx.stopService(stIntent);
        }
        MediaNotificationService.tmpRadio = radio;

        try {
            if (ctx.startService(stIntent) == null) {
                FsLogger.log(TAG + "Service failed to start");
            }
        } catch (Exception e){

        }
    }

    public static void removeNotification(){

        MediaNotificationService.tmpRadio = null;
        MediaNotificationService.radio = null;
        if (currentNotification != null) {
            currentNotification.stopForeground().remove();
            //currentNotification.dismissAllResources();
            currentNotification = null;
            closeRadioSessionIfAppIsInBackground();
        }
    }

    private static void closeRadioSessionIfAppIsInBackground() {
        if (!MainApplication.isInForeground()) {
            Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
            if (currentRadio != null) {
                currentRadio.close();
                currentRadio.closeRadioSession();
            }
        }
    }

    public static NotificationBase getNotification(){
        return currentNotification;
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        FsLogger.log(TAG + "onStartCommand");

        if (tmpRadio != null) {
            radio = tmpRadio;
            tmpRadio = null;
        }

        if (intent != null) {
            notificationMode = (NotificationMode) intent.getSerializableExtra("widgetMode");

            if ((notificationMode == null) || (radio == null)) {
                FsLogger.log(TAG + "radio(" + radio + ") or notificationMode (" + notificationMode + ") is null");
                radio = null;
                stopSelf();
            } else {
                int tintColor = GuiUtils.getColorFromAttribute(MainApplication.getContext(), R.attr.sources_icon_color);
                switch (notificationMode) {
                    case DMR:

                        // this should force it not to be closed when app stop
                        bindLocalMediaServices();
                        break;
                    case IR:
                        IRNotification instance = IRNotification.getInstance();
                        if (instance == null) {
                            instance = IRNotification.newInstance();
                            instance.setContext(this, radio);
                            try {
                                setNotificationDataAtCreationTime(instance);
                                instance
                                        .setPlayStarted(true)
                                        .setTint(tintColor)
                                        .create();
                                instance.startForeground(this);
                            } catch (NullPointerException e) {
                                FsLogger.log(TAG + " notification closed by system");
                                stopSelf();
                            }
                        } else {
                            instance.updateRadio(radio, false);
                        }

                        instance.requestTrackUpdate();
                        currentNotification = instance;
                        break;
                    case MP:
                    case Podcasts:
                        MPlayerNotification instance1 = MPlayerNotification.getInstance();

                        if (instance1 == null) {

                            instance1 = MPlayerNotification.newInstance();
                            instance1.setContext(this, radio);
                            setNotificationDataAtCreationTime(instance1);

                            instance1
                                    .setPlayStarted(true)
                                    .setTint(tintColor)
                                    .create();

                            MPlayerNotification noti = MPlayerNotification.getInstance();
                            if (noti != null) {
                                noti.startForeground(this);
                            }
                        }

                        if (instance1.updateRadio(radio, false)) {
                            instance1.requestTrackUpdate();
                        }
                        currentNotification = instance1;

                        break;
                }
            }
        } else {
            stopSelf();
        }

        return START_REDELIVER_INTENT;
    }

    private void setNotificationDataAtCreationTime(NotificationBase notification) {
        NetRemote netRemote = NetRemoteManager.getInstance().getNetRemote();

        if (MainApplication.isInForeground() && netRemote != null && netRemote.getCurrentRadio() != null) {
            NowPlayingDataModel nowPlayingDataModel = NowPlayingManager.getInstance().getNowPlayingDataModel();
            notification.setData(nowPlayingDataModel.playInfoName.get(), nowPlayingDataModel.playInfoText.get());
            notification.setPlayStatusFirstTime(nowPlayingDataModel.playStatus.get());
            notification.loadArtwork(notification.mContext, nowPlayingDataModel.graphicUri.get());
        }
    }


    @Override
    public void onCreate() {

    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        FsLogger.log(TAG + "onDestroy");

        notificationMode = null;
        removeNotification();
        try {
            if (mLocalMediaBound) {
                unbindService(mLocalMediaPlaybackConnection);
                mLocalMediaBound = false;
            }
        } catch (IllegalArgumentException e) {

        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);

        FsLogger.log(TAG + "onTaskRemoved ");

        // remove widget

        if (notificationMode != null) {
            switch (notificationMode) {
                case MP:
                case IR:
                    break;
                case DMR:
                    if (mLocalMediaBound) {
                        unbindService(mLocalMediaPlaybackConnection);
                        mLocalMediaBound = false;
                    }
                    break;
            }
        }

        notificationMode = null;
        removeNotification();
    }

    private void bindLocalMediaServices() {
        if (!mLocalMediaBound) {
            boolean result = bindService(
                    new Intent(this, Manager.class),
                    mLocalMediaPlaybackConnection,
                    Context.BIND_AUTO_CREATE
            );

            if (!result) {
                FsLogger.log(TAG + "Binding to Local Media Playback service failed", LogLevel.Error);
            }
        } else {
            // update radio
            NotificationBase notification = LocalMediaNotification.getInstance();
            if (notification != null) {
                if (notification.updateRadio(radio, false)) {
                    notification.requestTrackUpdate();
                }
            }
        }
    }

    public static boolean isServiceRunning(Context ctx) {

        if (ctx == null) {
            return false;
        }

        ActivityManager manager = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);

        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (MediaNotificationService.class.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }

        }
        return false;
    }
}
