package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import androidx.databinding.ObservableField;

/**
 * Created by hcostescu on 14/02/17.
 */

public class NavBrowseDataModel {
    public ObservableField<String> artistAlbumDescription = new ObservableField<>();
    public ObservableField<String> releaseDate = new ObservableField<>();

    public NavBrowseDataModel()
    {
        artistAlbumDescription.set("");
        releaseDate.set("");
    }


    public void clear() {
        artistAlbumDescription.set("");
        releaseDate.set("");
    }
}
