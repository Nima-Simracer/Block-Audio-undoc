package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;

/**
 * Created by lsuhov on 02/07/16.
 */

public class NavigateRunnable implements Runnable {

    private long mKey;
    private Radio mRadio;
    private INavigationListener mListener;

    public NavigateRunnable(long key, Radio radio, INavigationListener listener) {
        mKey = key;
        mRadio = radio;
        mListener = listener;
    }

    @Override
    public void run() {
        if (mRadio == null) {
            return;
        }

        boolean result;
        if (mKey == RadioNavigationUtil.INVALID_INT32_KEY) {
           result = RadioNavigationUtil.getInstance().navigateUp(mRadio);
        } else {
            result = RadioNavigationUtil.getInstance().navigateNavItem(mRadio, mKey);
        }

        if (!result) {
            notifyError();
        }

        EIRNavigationResult retrieveTotalNumberResult = NavBrowseManager.getInstance().retrieveTotalNumberOfItemsFromCurrentListSync(mRadio);

        if (retrieveTotalNumberResult != EIRNavigationResult.EmptyList) {
            if (retrieveTotalNumberResult == EIRNavigationResult.Success) {
                NavBrowseManager.getInstance().retrieveFirstPageSync(mRadio);
            } else {
                NavBrowseManager.getInstance().retrieveAllPagesSync(mRadio);
            }
        }
        if (mListener != null) {
            mListener.onNavigationCompleted(retrieveTotalNumberResult);
        }
        dispose();
    }

    private void dispose() {
        mRadio = null;
        mListener = null;
    }

    private void notifyError() {
        if (mListener != null) {
            mListener.onNavigationCompleted(EIRNavigationResult.NavigationFailed);
        }
    }
}
