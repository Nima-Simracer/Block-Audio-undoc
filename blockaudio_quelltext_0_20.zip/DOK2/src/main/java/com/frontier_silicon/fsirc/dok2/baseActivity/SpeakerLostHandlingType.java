package com.frontier_silicon.fsirc.dok2.baseActivity;

/**
 * Created by lsuhov on 19/10/2017.
 */

public enum SpeakerLostHandlingType {
    GoToHome,
    GoBack
}
