package com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable;

import com.frontier_silicon.NetRemoteLib.Node.NodeNavContextDepth;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.IContextListener;
import com.frontier_silicon.loggerlib.FsLogger;

/**
 * Created by adanaila on 30/01/2017.
 */

public class ContextNavUpRunnable implements Runnable {

    private IContextListener mListener;

    public ContextNavUpRunnable(IContextListener listener) {
        mListener = listener;
    }

    @Override
    public void run() {
        EIRNavigationResult result = EIRNavigationResult.NavigationFailed;
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        if (radio == null) {
            FsLogger.log("ContextNavUpRunnable: radio is null");
            return;
        }

        NodeNavContextDepth depthNode = (NodeNavContextDepth) radio.nodeSyncGetter(NodeNavContextDepth.class).get();
        if (depthNode != null) {
            if (depthNode.getValue() > 0){
                RadioNavigationUtil.getInstance().navigateContextUp(radio);
                result = EIRNavigationResult.Success;
            }else
            if(depthNode.getValue() == 0){
                //in this particular case we reached the root and should exit the context menu. 
                result = EIRNavigationResult.RootReached;
            }
        }

        if (mListener != null) {
            mListener.onNavigationCompleted(result);
        }
    }
}
