package com.frontier_silicon.fsirc.dok2.volume;

import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientMute0;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientMute1;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientMute2;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientMute3;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomGroupMasterVolume;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioMute;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioVolume;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomVolumeUtil;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;

/**
 * Created by cvladu on 20/10/16.
 */
public class VolumeManager implements IVolumeUpdatesListener, IMultiroomGroupingListener {
    private static VolumeManager mInstance = null;

    UpdateVolumeTask updateVolumeTask = null;
    private VolumeDataModel volumeDataModel = new VolumeDataModel();
    private INodeNotificationCallback mServerVolumeCallback = null;
    private INodeNotificationCallback mServerMuteCallback = null;
    private Radio mRadio;

    public static VolumeManager getInstance() {
        if (mInstance == null) {
            mInstance = new VolumeManager();
        }

        return mInstance;
    }

    public VolumeDataModel getVolumeDataModel() {
        return volumeDataModel;
    }

    private VolumeManager() {
    }

    public void updateVolumeTask() {
        if (updateVolumeTask == null || updateVolumeTask.getStatus() == AsyncTask.Status.FINISHED) {
            updateVolumeTask = new UpdateVolumeTask(this);
            TaskHelper.execute(updateVolumeTask);
        } else {
            updateVolumeTask.setInterfaceListener(this);
        }
    }

    public void bindToRadio(Radio radio) {
        unbindFromPreviousRadio();

        mRadio = radio;
        registerVolumeNotifCallback();
        registerMultiroomNotifCallback();

        updateVolumeTask();
    }

    private void unbindFromPreviousRadio() {
        if (mRadio != null) {
            unregisterVolumeNotifCallback();
        }
    }

    private void registerVolumeNotifCallback() {
        unregisterVolumeNotifCallback();


        if (NetRemoteManager.getInstance().checkConnection() && mRadio != null) {

            mServerVolumeCallback = node -> {

                if (node instanceof NodeSysAudioVolume) {
                    NodeSysAudioVolume serverVolNode = (NodeSysAudioVolume) node;
                    onVolumeUpdate(MultiroomVolumeUtil.SINGLE_DEVICE_VOLUME_ID, serverVolNode.getValue());
                } else if (node instanceof NodeMultiroomGroupMasterVolume) {
                    NodeMultiroomGroupMasterVolume masterVolNode = (NodeMultiroomGroupMasterVolume) node;
                    onVolumeUpdate(MultiroomVolumeUtil.MASTER_VOLUME_ID, masterVolNode.getValue());
                }
            };

            mRadio.addNotificationListener(mServerVolumeCallback);

            mServerMuteCallback = node -> {
                if (node instanceof NodeSysAudioMute) {
                    NodeSysAudioMute muteNode = (NodeSysAudioMute) node;
                    onMuteUpdate(muteNode.getValue());
                } else if (node instanceof NodeMultiroomClientMute0) {
                    NodeMultiroomClientMute0 mute0Node = (NodeMultiroomClientMute0) node;
                    onMuteUpdate(mute0Node.getValue());
                } else if (node instanceof NodeMultiroomClientMute1) {
                    NodeMultiroomClientMute1 mute1Node = (NodeMultiroomClientMute1) node;
                    onMuteUpdate(mute1Node.getValue());
                } else if (node instanceof NodeMultiroomClientMute2) {
                    NodeMultiroomClientMute2 mute2Node = (NodeMultiroomClientMute2) node;
                    onMuteUpdate(mute2Node.getValue());
                } else if (node instanceof NodeMultiroomClientMute3) {
                    NodeMultiroomClientMute3 mute3Node = (NodeMultiroomClientMute3) node;
                    onMuteUpdate(mute3Node.getValue());
                }
            };

            mRadio.addNotificationListener(mServerMuteCallback);
        }
    }

    public void mute(boolean mute) {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
        if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
            if (mute) {
                currentRadio.setNode(new NodeSysAudioMute(NodeSysAudioMute.Ord.MUTE), false);

                // mute all clients (master mute)
                if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {

                    NodeInfo[] nodes = new NodeInfo[]{new NodeMultiroomClientMute0(NodeMultiroomClientMute0.Ord.MUTE),
                            new NodeMultiroomClientMute1(NodeMultiroomClientMute1.Ord.MUTE),
                            new NodeMultiroomClientMute2(NodeMultiroomClientMute2.Ord.MUTE),
                            new NodeMultiroomClientMute3(NodeMultiroomClientMute3.Ord.MUTE)};

                    currentRadio.setNodes(nodes, false);
                }
            } else {
                currentRadio.setNode(new NodeSysAudioMute(NodeSysAudioMute.Ord.NOT_MUTE), false);

                // unmute all clients (master mute)
                if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {
                    NodeInfo[] nodes = new NodeInfo[]{new NodeMultiroomClientMute0(NodeMultiroomClientMute0.Ord.NOT_MUTE),
                            new NodeMultiroomClientMute1(NodeMultiroomClientMute1.Ord.NOT_MUTE),
                            new NodeMultiroomClientMute2(NodeMultiroomClientMute2.Ord.NOT_MUTE),
                            new NodeMultiroomClientMute3(NodeMultiroomClientMute3.Ord.NOT_MUTE)};

                    currentRadio.setNodes(nodes, false);
                }
            }
        }
    }

    private void unregisterVolumeNotifCallback() {

        if (NetRemoteManager.getInstance().checkConnection() && mRadio != null) {

            if (mServerVolumeCallback != null) {
                mRadio.removeNotificationListener(mServerVolumeCallback);
                mServerVolumeCallback = null;
            }

            if (mServerMuteCallback != null) {
                mRadio.removeNotificationListener(mServerMuteCallback);
                mServerMuteCallback = null;
            }
        }
    }

    private void onVolumeUpdate(int clientId, long volume) {

        final int volumeInPercent = RadioNodeUtil.convertValueToPercent(volume, MultiroomGroupManager.getInstance().getMaxVolumeSteps());

        boolean updateVolume = false;
        if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {
            if (clientId == MultiroomVolumeUtil.MASTER_VOLUME_ID) {
                updateVolume = true;
            }
        } else {
            if (clientId == MultiroomVolumeUtil.SINGLE_DEVICE_VOLUME_ID) {
                updateVolume = true;
            }
        }

        if (updateVolume) {

            volumeDataModel.volume.set(volumeInPercent);
        }
    }

    private void onMuteUpdate(final long isMute) {
        final boolean mute = (isMute == NodeSysAudioMute.Ord.MUTE.ordinal());

        volumeDataModel.muted.set(mute);
        if (MultiroomGroupManager.getInstance().isCurrentDeviceInAnyMultiroomGroup()) {
            updateVolumeTask();
        }
    }

    @Override
    public void onVolumeRetrieved(int volume, boolean isMuted) {
        volumeDataModel.volume.set(volume);
        volumeDataModel.muted.set(isMuted);
    }

    @Override
    public void onGroupingUpdate() {
        updateVolumeTask();
    }


    public void registerMultiroomNotifCallback() {
        unregisterMultiroomNotifiCallback();

        MultiroomGroupManager.getInstance().addListener(this);
    }

    public void unregisterMultiroomNotifiCallback() {
        MultiroomGroupManager.getInstance().removeListener(this);
    }
}

