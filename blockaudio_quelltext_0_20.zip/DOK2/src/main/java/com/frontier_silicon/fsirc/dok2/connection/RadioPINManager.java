package com.frontier_silicon.fsirc.dok2.connection;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoRadioPin;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.IButtonsResponseWithTextListener;
import com.frontier_silicon.components.common.IRadioPINManager;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.DialogsOpener;
import com.frontier_silicon.fsirc.dok2.R;

import java.util.HashMap;
import java.util.Map;

public class RadioPINManager implements IRadioPINManager {

	private static final String USER_PRIVATE_PREFS = "PRIVATE_SETTINGS";

	private static final String PREF_PINS = "PREF_PINS";

	private Map<String /* SN */, String /* PIN */> mSavedPINs = new HashMap<>();
	
	private static RadioPINManager mInstance = null;
	
	public static RadioPINManager getInstance() {
		if (mInstance == null) {
			mInstance = new RadioPINManager();
		}
		
		return mInstance;
	}
	
	private RadioPINManager() {
		
	}
	
	@Override
	public void setPIN(String radioSerialNumber, String PIN) {
		mSavedPINs.put(radioSerialNumber, PIN);
	}

	@Override
	public void removePIN(String radioSerialNumber) {
		mSavedPINs.remove(radioSerialNumber);
	}

	@Override
	public boolean isPINSaved(String radioSerialNumber) {
		return mSavedPINs.containsKey(radioSerialNumber);
	}

	@Override
	public String getPIN(String radioSerialNumber) {		
		return mSavedPINs.get(radioSerialNumber);
	}

	@Override
    public void savePINs(Context context) {		
    	SharedPreferences prefs = context.getSharedPreferences(USER_PRIVATE_PREFS, Context.MODE_PRIVATE);
    	SharedPreferences.Editor editor = prefs.edit();
    	
    	String serialised = "";
    	for (String sn : this.mSavedPINs.keySet()) {
    		serialised += (sn + " " + this.mSavedPINs.get(sn) + ",");
    	}
    	editor.putString(PREF_PINS, serialised);
    	    	
    	editor.commit();
    }

	@Override
	public void restorePINs(Context context) {
    	SharedPreferences prefs = context.getSharedPreferences(USER_PRIVATE_PREFS, Context.MODE_PRIVATE);

    	this.mSavedPINs = new HashMap<>();
    	String serialised = (String)(prefs.getAll().get(PREF_PINS));
    	if (serialised != null) {
	    	for (String pair : serialised.split(",")) {
	    		String[] item = pair.split(" ");
	    		if (item.length == 2) {
	    			this.mSavedPINs.put(item[0], item[1]);
	    		}
	    	}
    	}    	
    }

	public void showIncorrectPINDialog(final Activity activity, final Radio radio, final IButtonsResponseWithTextListener buttonsResponseListener) {
        if (activity == null || activity.isFinishing()) {
            return;
        }

        activity.runOnUiThread(() -> DialogsOpener.showEnterPinDialog(activity, radio.getFriendlyName(), new IButtonsResponseWithTextListener() {
			@Override
			public void onOkClicked(String response) {

				if (radio != null) {
					setPIN(radio.getSN(), response);

					radio.setPIN(response);

					savePINs(activity);
				}

				if (buttonsResponseListener != null) {
					buttonsResponseListener.onOkClicked(response);
				}
			}

			@Override
			public void onCancelClicked() {
				if (buttonsResponseListener != null) {
					buttonsResponseListener.onCancelClicked();
				}
			}
		}));
	}

	public void showChangePinForRadio(final Radio radio, final Activity activity) {
		DialogsOpener.showChangePinDialog(activity, radio.getFriendlyName(), new IButtonsResponseWithTextListener() {

			@Override
			public void onOkClicked(final String response) {
				(new Handler()).postDelayed(new Runnable() {
					public void run() {
						changePin(response, activity, radio);
					}
				}, 1000);
			}

			@Override
			public void onCancelClicked() {
			}

		});
	}
	
	private void changePin(final String newPin, final Activity activity, final Radio radio) {
		RadioNodeUtil.setNodeToRadioAsync(radio, new NodeSysInfoRadioPin(newPin), new RadioNodeUtil.INodeSetResultListener() {
			@Override
			public void onNodeSetResult(boolean success) {
				if (success) {
					setPIN(radio.getSN(), newPin);
					savePINs(activity);

                    radio.setPIN(newPin);
				} else {
					if (activity != null) {
						activity.runOnUiThread(new Runnable() {
							@Override
							public void run() {
								DialogsOpener.showMessageDialog(activity, R.string.error_title, R.string.error_on_changing_pin, null);
							}
						});
					}
				}
			}
		});
	}

}
