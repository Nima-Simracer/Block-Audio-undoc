package com.frontier_silicon.fsirc.dok2.browse.dmr;

import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.dmr.filter.LocalMediaMemento;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.List;

public class BrowseDMRAdapter extends ArrayAdapter<BrowseDMRItemModel> {
    private List<BrowseDMRItemModel> mItems;

    private String selectedUriStr = "";
    private int selectedTrackPosition = -1;

    public BrowseDMRAdapter(Context context, int resource, List<BrowseDMRItemModel> items) {
        super(context, resource);
        mItems = items;
    }

    public void selectTrack(String uri) {
        this.selectedUriStr = uri;
        selectedTrackPosition = updateTrackPositionByUri();
        this.notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BrowseDMRItemModel currentMedia = mItems.get(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.browse_list_item, parent, false);
        }

        ImageView selectionTick = (ImageView) convertView.findViewById(R.id.imageViewSelected);
        if (position == selectedTrackPosition) {
            if (mItems.get(position).getType() == BrowseDMRItemModel.Types.TRACK) {
                selectionTick.setVisibility(View.VISIBLE);
            } else {
                selectionTick.setVisibility(View.INVISIBLE);
            }

        } else {
            selectionTick.setVisibility(View.INVISIBLE);
        }

        TextView displayText = (TextView) convertView.findViewById(R.id.text1);
        displayText.setText(currentMedia.getDisplayText());

        return convertView;
    }

    private int updateTrackPositionByUri() {
        if (!TextUtils.isEmpty(selectedUriStr)) {
            Uri uri = Uri.parse(selectedUriStr);

            List<BrowseDMRItemModel> playlist = mItems;
            for (int i = 0; i < playlist.size(); i++) {
                Uri tmp = Uri.parse(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI.toString() + "/" + playlist.get(i).getItemId());

                if (tmp.equals(uri)) {
                    FsLogger.log("LocalMedia: Playing ... " + playlist.get(i).getDisplayText() + " - " + playlist.get(i).getArtistId());
                    FsLogger.log("LocalMedia: uri: " + uri + "\ntmp: " + tmp);
                    return i;
                }
            }
        }

        return -1;
    }

    @Override
    public int getCount() {
        return mItems.size();
    }

    /**
     * Removes all items from the adapter and replaces
     * its contents with the new <code>List</code>
     *
     * @param browseDMRItemModels The new contents to be used.
     */
    public void replaceContents(List<BrowseDMRItemModel> browseDMRItemModels) {
        mItems.clear();
        mItems.addAll(browseDMRItemModels);

        selectedTrackPosition = updateTrackPositionByUri();
        notifyDataSetChanged();
    }

    @Override
    public BrowseDMRItemModel getItem(int position) {
        if (mItems.size() > position) {
            return mItems.get(position);
        }

        return null;
    }

    /**
     * Returns a list of all <code>BrowseDMRItemModel</code>
     * objects current in the adapter.
     *
     * @return List of all media objects in the adapter
     */
    public List<BrowseDMRItemModel> getItems() {
        return mItems;
    }

    /**
     * Saves the current state of the adapter into a memento
     * object allowing it to be restored at a later date.
     *
     * @return A <code>LocalMediaMemento</code> object representing core adapter state
     */
    public LocalMediaMemento saveStateToMemento() {
        return new LocalMediaMemento(mItems);
    }

    /**
     * Allows the adapter data set to be restored to a previous
     * set of media items using the data stored in the memento
     *
     * @param previousState The previous state to restore
     * @return The number of items added to the adapters list
     */
    public int restoreStateFromMemento(LocalMediaMemento previousState) {
        mItems = previousState.getState();
        notifyDataSetChanged();

        return mItems.size();
    }
}
