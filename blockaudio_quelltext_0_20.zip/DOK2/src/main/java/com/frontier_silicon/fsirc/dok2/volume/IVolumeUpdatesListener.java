package com.frontier_silicon.fsirc.dok2.volume;

/**
 * Created by cvladu on 20/10/16.
 */

public interface IVolumeUpdatesListener {
    void onVolumeRetrieved(int volume, boolean isMuted);
}
