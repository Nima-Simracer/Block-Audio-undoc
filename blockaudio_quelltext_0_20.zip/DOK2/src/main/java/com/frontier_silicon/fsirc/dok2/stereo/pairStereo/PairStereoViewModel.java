package com.frontier_silicon.fsirc.dok2.stereo.pairStereo;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.ErrorSanitizerMessageType;
import com.frontier_silicon.components.common.FriendlyNameSanitizer;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.multiroom.MultiroomRescanUtil;
import com.frontier_silicon.components.stereo.IStereoOperationResult;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.components.stereo.StereoPairingData;
import com.frontier_silicon.fsirc.dok2.DialogsOpener;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.StereoPairActivityBinding;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.FriendlyNameSanitizerErrorHandler;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

/**
 * Created by lsuhov on 10/08/2017.
 */

public class PairStereoViewModel {

    public ObservableBoolean isPairing = new ObservableBoolean(false);
    public ObservableBoolean isNetworkOptimised = new ObservableBoolean(true);
    public ObservableBoolean differentFwTextIsVisible = new ObservableBoolean(false);

    private StereoSpeakerForPairingViewModel mPrimaryStereoViewModel;
    private StereoSpeakerForPairingViewModel mSecondaryStereoViewModel;
    private StereoPairActivityBinding mBinding;
    private Activity mActivity;
    private FriendlyNameSanitizer mSanitizer;

    PairStereoViewModel(StereoSpeakerForPairingViewModel primaryStereoViewModel,
                        StereoSpeakerForPairingViewModel secondaryStereoViewModel,
                        StereoPairActivityBinding binding, Activity activity) {

        mPrimaryStereoViewModel = primaryStereoViewModel;
        mSecondaryStereoViewModel = secondaryStereoViewModel;
        mBinding = binding;
        mActivity = activity;

        if (mPrimaryStereoViewModel.getDeviceModel() == null) {
            FsLogger.log("MultiroomDeviceModel from primary stereo viewModel is null", LogLevel.Error);
            return;
        }

        if (mSecondaryStereoViewModel.getDeviceModel() == null) {
            FsLogger.log("MultiroomDeviceModel from secondary stereo viewModel is null", LogLevel.Error);
            return;
        }

        init();
    }

    private void init() {
        updateSystemName();
        setFriendlyNameSanitizer();
        checkIfSecondaryHasDifferentFwThanPrimary();
    }

    private void setFriendlyNameSanitizer() {
        int maxLengthOfFriendlyName = getMaxLengthOfFriendlyNames();

        mSanitizer = new FriendlyNameSanitizer(maxLengthOfFriendlyName);
        final FriendlyNameSanitizerErrorHandler errorHandler = new FriendlyNameSanitizerErrorHandler(maxLengthOfFriendlyName);
        mSanitizer.appendSanitizerToEditText(mBinding.groupEditText, mActivity, new FriendlyNameSanitizer.IFriendlyNameSanitizerListener() {
            @Override
            public void onNewFriendlyName(String friendlyName) {

            }

            @Override
            public void onSubmitFriendlyName(String friendlyName) {

            }

            @Override
            public void onBadFriendlyName(ErrorSanitizerMessageType errorType) {
                errorHandler.handleMessageErrorType(mActivity, errorType, mBinding.groupEditText);
            }
        });
    }

    private int getMaxLengthOfFriendlyNames() {
        Radio primaryRadio = mPrimaryStereoViewModel.getDeviceModel().mRadio;
        if (primaryRadio == null) {
            return 0;
        }

        return primaryRadio.hasGoogleCast() ?
                FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME_WHEN_GOOGLE_CAST_IS_PRESENT :
                FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME;
    }

    private void updateSystemName() {
        String primarySpeakerName = mPrimaryStereoViewModel.speakerName.get();
        String stereoWord = mActivity.getString(R.string.stereo);

        String stereoSystemName = getStereoSystemName(primarySpeakerName, stereoWord);

        mBinding.groupEditText.setText(stereoSystemName);
    }

    private String getStereoSystemName(String primarySpeakerName, String stereoWord) {
        int maxStereoSystemNameLength = getMaxLengthOfFriendlyNames();

        int stereoWordLength = stereoWord.length();
        int speakerNameLength = primarySpeakerName.length();

        // we have to account for the space letter too
        int maxSpeakerNameLength = maxStereoSystemNameLength - stereoWordLength - 1;

        String clippedSpeakerName = primarySpeakerName;
        if (maxSpeakerNameLength < speakerNameLength) {
            clippedSpeakerName = primarySpeakerName.substring(0, maxSpeakerNameLength);
        }

        return stereoWord.toUpperCase() + " " + clippedSpeakerName;
    }

    private void checkIfSecondaryHasDifferentFwThanPrimary() {
        differentFwTextIsVisible.set(false);

        String primaryFwVersion = mPrimaryStereoViewModel.getDeviceModel().mRadio.getFirmwareVersion();
        String secondaryFwVersion = mSecondaryStereoViewModel.getDeviceModel().mRadio.getFirmwareVersion();

        if (TextUtils.isEmpty(primaryFwVersion) || TextUtils.isEmpty(secondaryFwVersion)) {
            return;
        }

        if (!primaryFwVersion.equals(secondaryFwVersion)) {
            differentFwTextIsVisible.set(true);
        }
    }

    public void onPairClicked(View v) {
        StereoPairingData pairingData = getPairingData();

        isPairing.set(true);

        StereoManager.getInstance().pairStereoSystem(pairingData, new IStereoOperationResult() {
            @Override
            public void onStereoOperationComplete(final boolean success) {

                MultiroomRescanUtil.getInstance().rescanMultiroomDevicesAndGroups();

                NetRemote.getMainThreadExecutor().execute(() -> {
                    if (DokUiUtils.isDestroyed(mActivity)) {
                        return;
                    }

                    isPairing.set(false);

                    if (success) {
                        navigateToHome();
                    } else {
                        showFailedToPairDialog();
                    }
                });
            }
        });
    }

    private StereoPairingData getPairingData() {
        StereoPairingData pairingData = new StereoPairingData();

        pairingData.primaryDeviceModel = mPrimaryStereoViewModel.getDeviceModel();
        pairingData.secondaryDeviceModel = mSecondaryStereoViewModel.getDeviceModel();

        pairingData.primaryChannel = mPrimaryStereoViewModel.getChannelMask();
        pairingData.secondaryChannel = mSecondaryStereoViewModel.getChannelMask();

        pairingData.systemName = mBinding.groupEditText.getText().toString();

        pairingData.isNetworkOptimised = isNetworkOptimised.get();

        return pairingData;
    }

    private void showFailedToPairDialog() {
        DialogsOpener.showMessageDialogWithOkButton(mActivity, "failed_to_pair", -1, R.string.pair_failed);
    }

    private void navigateToHome() {
        Toast.makeText(mActivity.getApplicationContext(), R.string.pair_successful, Toast.LENGTH_LONG).show();

        NavigationHelper.goToHomeAndClearActivityStack(mActivity);
    }

    public void dispose() {
        mPrimaryStereoViewModel = null;
        mSecondaryStereoViewModel = null;
        mBinding = null;
        mActivity = null;

        if (mSanitizer != null) {
            mSanitizer.dispose();
            mSanitizer = null;
        }
    }
}
