package com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware

interface IOnItemSelected {
    fun onItemSelected(position: Int)
}