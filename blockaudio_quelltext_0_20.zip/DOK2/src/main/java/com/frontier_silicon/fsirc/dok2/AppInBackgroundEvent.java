package com.frontier_silicon.fsirc.dok2;

/**
 * Created by lsuhov on 09/07/16.
 */

public class AppInBackgroundEvent {}
