package com.frontier_silicon.fsirc.dok2.notifications;

import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.text.TextUtils;

import com.coderus.localmediaplayback.LocalMediaDMR;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.BasePlayStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayCaps;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayControl;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoAlbum;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoArtist;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoGraphicUri;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoName;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoText;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingDataModel;
import com.frontier_silicon.fsirc.dok2.nowPlaying.NowPlayingManager;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import static com.frontier_silicon.fsirc.dok2.notifications.NotificationMode.IR;

public class NotificationManagerService extends IntentService {

    private final static String TAG = "NotiService ";
    private static final String PACKAGE_STR = NotificationManagerService.class.getPackage().toString();

    public static final String MEDIA_RECEIVER_PLAY = "NotificationManagerService.Receiver.Play";
    public static final String MEDIA_RECEIVER_PAUSE = "NotificationManagerService.Receiver.Pause";
    public static final String MEDIA_RECEIVER_STOP = "NotificationManagerService.Receiver.Stop";
    public static final String MEDIA_RECEIVER_NEXT = "NotificationManagerService.Receiver.Next";
    public static final String MEDIA_RECEIVER_PREV = "NotificationManagerService.Receiver.Prev";

    public static final String MEDIA_RECEIVER_DISMISS_NOTIFICATION = "NotificationManagerService.Receiver.DismissNotification";
    public static final String MEDIA_RECEIVER_TRACK_UPDATE = "NotificationManagerService.Receiver.TrackUpdate";
    public static final String MEDIA_RECEIVER_TRACK_ARTWORK_UPDATE = PACKAGE_STR + ".TrackArtworkUpdate";

    public NotificationManagerService() {
        super(TAG);
    }

    public static PendingIntent sendIntent(Context context, Actions action, NotificationMode mode) {

        Intent myIntent = new Intent(context, NotificationManagerService.class);

        myIntent.putExtra("widgetMode", mode);

        PendingIntent pendingIntent = null;

        switch (action) {
            case PLAY:
                myIntent.setAction(MEDIA_RECEIVER_PLAY);
                pendingIntent = PendingIntent.getService(context, 0, myIntent, PendingIntent.FLAG_IMMUTABLE);
                break;
            case PAUSE:
                myIntent.setAction(MEDIA_RECEIVER_PAUSE);
                pendingIntent = PendingIntent.getService(context, 0, myIntent, PendingIntent.FLAG_IMMUTABLE);
                break;
            case STOP:
                myIntent.setAction(MEDIA_RECEIVER_STOP);
                pendingIntent = PendingIntent.getService(context, 0, myIntent, PendingIntent.FLAG_IMMUTABLE);
                break;
            case PREV:
                myIntent.setAction(MEDIA_RECEIVER_PREV);
                pendingIntent = PendingIntent.getService(context, 0, myIntent, PendingIntent.FLAG_IMMUTABLE);
                break;
            case NEXT:
                myIntent.setAction(MEDIA_RECEIVER_NEXT);
                pendingIntent = PendingIntent.getService(context, 0, myIntent, PendingIntent.FLAG_IMMUTABLE);
                break;

            case DISMISS_NOTIFICATION:
                myIntent.setAction(MEDIA_RECEIVER_DISMISS_NOTIFICATION);
                pendingIntent = PendingIntent.getService(context, 0, myIntent, PendingIntent.FLAG_IMMUTABLE);
                break;
            case UPDATE_TRACK:
                myIntent.setAction(MEDIA_RECEIVER_TRACK_UPDATE);
                pendingIntent = PendingIntent.getService(context, 0, myIntent, PendingIntent.FLAG_IMMUTABLE);
                break;

            case UPDATE_TRACK_ARTWORK:
                myIntent.setAction(MEDIA_RECEIVER_TRACK_ARTWORK_UPDATE);
                pendingIntent = PendingIntent.getService(context, 0, myIntent, PendingIntent.FLAG_IMMUTABLE);
                break;
        }

        return pendingIntent;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    private NetRemote getNetRemote() {
        NetRemote netRemote = NetRemoteManager.getInstance().getNetRemote();

        if (netRemote != null) {
            FsLogger.log(TAG + "Current Radio: " + netRemote.getCurrentRadio());
        }

        return netRemote;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    private static Date lastIntent;

    @Override
    protected void onHandleIntent(final Intent intent) {
        if (intent == null) {
            return;
        }

        NetRemote netRemote = getNetRemote();
        final Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        if (radio != null) {

            if (MainApplication.isInForeground() && netRemote.getCurrentRadio() != null) {
                NodeSysCapsValidModes.Mode currentMode = SpeakerDataManager.getInstance().getCurrentMode();
                onHandleIntentResolverWithCurrentMode(intent, radio, currentMode, 1);
            } else {
                // handle intent based on current radio mode
                radio.getMode(new Radio.IRadioModeCallback() {
                    @Override
                    public void getCurrentMode(NodeSysCapsValidModes.Mode currentMode) {
                        onHandleIntentResolverWithCurrentMode(intent, radio, currentMode, 1);
                    }
                });
            }
        } else {
            removeNotification();
        }
    }

    private void onHandleIntentResolverWithCurrentMode(final Intent intent, Radio radio, NodeSysCapsValidModes.Mode currentMode, final int retryStep) {
        final String action = intent.getAction();
        final NotificationMode notificationMode = (NotificationMode) intent.getSerializableExtra("widgetMode");

        FsLogger.log(TAG + "Current Mode: " + currentMode + " action: " + action + " connection: " + radio.isConnectionOk());

        if (!Arrays.asList(
                NodeSysCapsValidModes.Mode.DMR,
                NodeSysCapsValidModes.Mode.IR,
                NodeSysCapsValidModes.Mode.MP,
                NodeSysCapsValidModes.Mode.PODCASTS
        ).contains(currentMode)){

            if (NodeSysCapsValidModes.Mode.UnknownMode == currentMode) {
                if (retryStep == 1){
                    onHandleIntentResolverWithCurrentMode(intent, radio, currentMode, retryStep + 1);

                    return;
                }
            }

            removeNotification();

            return;
        }

        if (MEDIA_RECEIVER_DISMISS_NOTIFICATION.equals(action)) {

            FsLogger.log(TAG + "dismiss notification");
            removeNotification();
        } else if (MEDIA_RECEIVER_TRACK_ARTWORK_UPDATE.equals(action)) {
            getArtworkUpdate(radio);
        } else if (MEDIA_RECEIVER_TRACK_UPDATE.equals(action)) {
            getTrackUpdates(radio, notificationMode);
        } else if (MEDIA_RECEIVER_PLAY.equals(action)) {
            sendNotificationUsageEvent();
            onPlayCommand(radio);
        } else if (MEDIA_RECEIVER_PAUSE.equals(action)) {
            sendNotificationUsageEvent();
            onPauseCommand(radio);
        } else if (MEDIA_RECEIVER_STOP.equals(action)) {
            sendNotificationUsageEvent();
            onStopCommand(radio, notificationMode);
        } else if (MEDIA_RECEIVER_PREV.equals(action)) {
            sendNotificationUsageEvent();
            onPreviousCommand(radio, currentMode);
        } else if (MEDIA_RECEIVER_NEXT.equals(action)) {
            sendNotificationUsageEvent();
            onNextCommand(radio, currentMode);
        }
    }

    private void sendNotificationUsageEvent() {
        if (!UndokPreferences.getInstance().wasNotificationUsageSent()) {
            AnalyticsSender.sendNotificationUsageOnce();
            UndokPreferences.getInstance().setNotificationUsageSent();
        }
    }

    private void onPlayCommand(Radio radio) {
        FsLogger.log(TAG + "Play pressed: ");

        if (!isWaitTimeExpired(lastIntent, 0.5f)) {
            FsLogger.log(TAG + "skip prev");
            return;
        }

        NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.PLAY);
        radio.setNode(playNode, false);

        // update notification controls
        NotificationBase notification = MediaNotificationService.getNotification();

        if (notification != null) {
            //notification.setPlayStarted(true).update().show();
           requestTrackUpdatesForBackgroundMode();
            // restart foreground for last service
            //notification.startForeground();
            lastIntent = new Date();
        }
    }

    private void onPauseCommand(Radio radio) {
        FsLogger.log(TAG + "Pause pressed: ");

        if (!isWaitTimeExpired(lastIntent, 0.5f)) {
            FsLogger.log(TAG + "skip pause");
            return;
        }

        NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.PAUSE);
        radio.setNode(playNode, false);

        // update notification controls
        NotificationBase notification = MediaNotificationService.getNotification();

        if (notification != null) {
//            notification
//                    .setPlayStarted(false)
//                    .update()
//                    .show();
            requestTrackUpdatesForBackgroundMode();
            // remove foreground service / let user to close local media service

            lastIntent = new Date();
        } else {
            FsLogger.log(TAG + "skip pause, notification is null");
        }
    }

    private void onStopCommand(Radio radio, NotificationMode notificationMode) {
        FsLogger.log(TAG + "Stop pressed: ");

        if (!isWaitTimeExpired(lastIntent, 0.5f)) {
            FsLogger.log(TAG + "skip stop");
            return;
        }

        NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.STOP);
        radio.setNode(playNode, false);

        // update notification controls

        boolean setPlayStarted = false;
        NotificationBase notification;
        if (notificationMode == IR) {
            notification = MediaNotificationService.getNotification();

            // for IR stop is toggle for play / pause
            if ((notification != null) && (!notification.isPlaying())) {
                setPlayStarted = true;
            }
        } else {
            //TODO: add other Notifications that use stop
            notification = null;
        }

        if (notification != null) {
            //notification.setPlayStarted(setPlayStarted).update();
            notification.show();
            requestTrackUpdatesForBackgroundMode();
            // remove foreground service / let user to close local media service

            lastIntent = new Date();
        }
    }

    private void onPreviousCommand(Radio radio, NodeSysCapsValidModes.Mode currentMode) {
        FsLogger.log(TAG + "Prev pressed: ");

        if (!isWaitTimeExpired(lastIntent, 1.0f)) {
            FsLogger.log(TAG + "skip prev");
            return;
        }

        if (NodeSysCapsValidModes.Mode.DMR == currentMode) {
            Intent newIntent = new Intent(LocalMediaDMR.LOCAL_MUSIC_CMD_RECEIVER);
            newIntent.putExtra("udn", radio.getUDN());
            newIntent.putExtra("cmd", LocalMediaDMR.CMD_PREV_PLAY);

            // send cmd to local media library
            sendBroadcast(newIntent);
        } else {
            NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.PREVIOUS);
            radio.setNode(playNode, false);
        }
        requestTrackUpdatesForBackgroundMode();
        lastIntent = new Date();
    }

    private void onNextCommand(Radio radio, NodeSysCapsValidModes.Mode currentMode) {
        FsLogger.log(TAG + "Next pressed: ");

        if (!isWaitTimeExpired(lastIntent, 1.0f)) {
            FsLogger.log(TAG + "skip next");
            return;
        }

        if (NodeSysCapsValidModes.Mode.DMR == currentMode) {
            Intent newIntent = new Intent(LocalMediaDMR.LOCAL_MUSIC_CMD_RECEIVER);
            newIntent.putExtra("udn", radio.getUDN());
            newIntent.putExtra("cmd", LocalMediaDMR.CMD_NEXT_PLAY);

            // send cmd to local media library
            sendBroadcast(newIntent);
        } else {
            NodePlayControl playNode = new NodePlayControl(NodePlayControl.Ord.NEXT);
            radio.setNode(playNode, false);
        }
        requestTrackUpdatesForBackgroundMode();
        lastIntent = new Date();
    }

    private void requestTrackUpdatesForBackgroundMode() {
        if (!MainApplication.isInForeground()) {
            NotificationBase notification = MediaNotificationService.getNotification();
            if (notification != null) {
                notification.requestTrackUpdate();
            }
        }
    }

    private void removeNotification(){
        // remove notification

        NotificationBase noti = MediaNotificationService.getNotification();

        if (noti != null) {
            noti.stopForeground().remove();
        }
    }

    private boolean isWaitTimeExpired(Date date, float waitSeconds) {
        return date == null || ((new Date().getTime() - date.getTime()) >= waitSeconds * 1000);

    }

    enum Actions {
        PLAY,
        PAUSE,
        STOP,
        NEXT,
        PREV,
        DISMISS_NOTIFICATION,
        UPDATE_TRACK,
        UPDATE_TRACK_ARTWORK,
    }

    /**
     * get track info from radio
     * @param radio from where to request Track updates
     */
    private void getTrackUpdates(Radio radio, final NotificationMode notificationMode) {
        switch (notificationMode) {
            case MP:
                FsLogger.log(TAG + "received track MP track update");
                getPlayerTrackUpdates(radio);
                break;
            case IR:
                FsLogger.log(TAG + "received track IR track update");
                getIrTrackUpdates(radio);
                break;
            case DMR:
                FsLogger.log(TAG + "received track DMR track update");
                getPlayerTrackUpdates(radio);
                break;
        }
    }

    private void getArtworkUpdate(Radio radio) {
        NetRemote netRemote = getNetRemote();

        if (MainApplication.isInForeground() && netRemote != null && netRemote.getCurrentRadio() != null) {
            NowPlayingDataModel nowPlayingDataModel = NowPlayingManager.getInstance().getNowPlayingDataModel();

            sendArtworkUpdate(nowPlayingDataModel.graphicUri.get());
        } else {
            RadioNodeUtil.getNodesFromRadio(radio, new Class[]{NodePlayInfoGraphicUri.class},
                    true, true, new RadioNodeUtil.INodesResultListener() {
                @Override
                public void onNodesResult(Map<Class, NodeInfo> nodes) {

                    String artworkURL = "";

                    if (nodes == null) {
                        return;
                    }

                    NodePlayInfoGraphicUri graphicUriNode = (NodePlayInfoGraphicUri) nodes.get(NodePlayInfoGraphicUri.class);
                    if (graphicUriNode != null) {
                        artworkURL = graphicUriNode.getValue();
                        FsLogger.log(TAG + "(" + artworkURL + ")");
                    }

                    sendArtworkUpdate(artworkURL);
                }
            });
        }
    }

    private void sendArtworkUpdate(String artworkURL) {
        // updating notification info
        NotificationBase notification  = MediaNotificationService.getNotification();

        if (notification == null) {
            FsLogger.log(TAG + "notification null, skip artwork update");
            return;
        }

        try {
            FsLogger.log(TAG + "update image with: " + artworkURL);
            notification
                    .loadArtwork(NotificationManagerService.this, artworkURL);

        } catch (ArrayIndexOutOfBoundsException e){
            FsLogger.log(TAG + "Not updated - ArrayIndexOutOfBoundsException");
        } catch (NullPointerException e) {
            FsLogger.log(TAG + "null pointer exception while trying to show");
        }
    }

    private void getIrTrackUpdates(final Radio radio){

        NetRemote netRemote = getNetRemote();
        if (MainApplication.isInForeground() && netRemote != null && netRemote.getCurrentRadio() != null) {
            NowPlayingDataModel nowPlayingDataModel = NowPlayingManager.getInstance().getNowPlayingDataModel();

            sendIRTrackUpdates(nowPlayingDataModel.playInfoName.get(),
                    nowPlayingDataModel.playInfoText.get(),
                    nowPlayingDataModel.graphicUri.get(),
                    nowPlayingDataModel.playStatus.get(),
                    nowPlayingDataModel.playCaps.get());

            FsLogger.log(TAG + "ir data source: NowPlayingDataModel " + nowPlayingDataModel.playInfoName.get());
        } else {
            RadioNodeUtil.getNodesFromRadio(
                    radio, new Class[]{NodePlayInfoName.class, NodePlayInfoText.class, NodePlayInfoGraphicUri.class, NodePlayCaps.class, NodePlayStatus.class},
                    true, true, new RadioNodeUtil.INodesResultListener() {

                        @Override
                        public void onNodesResult(Map<Class, NodeInfo> nodes) {
                            String infoNameStr = "";
                            String playInfoText = "";
                            String artworkURL = "";

                            if (nodes == null) {
                                return;
                            }

                            NodePlayInfoName infoNameNode = (NodePlayInfoName) nodes.get(NodePlayInfoName.class);
                            if (infoNameNode != null) {

                                infoNameStr = infoNameNode.getValue().trim();
                            }

                            NodePlayInfoText infoTextNode = (NodePlayInfoText) nodes.get(NodePlayInfoText.class);
                            if (infoTextNode != null) {
                                playInfoText = infoTextNode.getValue();
                            }

                            NodePlayInfoGraphicUri graphicUriNode = (NodePlayInfoGraphicUri) nodes.get(NodePlayInfoGraphicUri.class);
                            if (graphicUriNode != null) {
                                artworkURL = graphicUriNode.getValue();
                                FsLogger.log(TAG + "(" + artworkURL + ")");
                            }

                            FsLogger.log(TAG + "(" + infoNameStr + "\n" + playInfoText + ")");

                            NodePlayStatus nodePlayStatus = (NodePlayStatus) nodes.get(NodePlayStatus.class);
                            NodePlayCaps nodePlayCaps = (NodePlayCaps) nodes.get(NodePlayCaps.class);

                            sendIRTrackUpdates(infoNameStr, playInfoText, artworkURL, nodePlayStatus, nodePlayCaps);
                            FsLogger.log(TAG + "ir data source: getNodesFromRadio");
                        }
                    });
       }
    }

    private void sendIRTrackUpdates(String infoNameStr, String playInfoText, String artworkURL,
                                    NodePlayStatus nodePlayStatus, NodePlayCaps nodePlayCaps) {
        // updating notification info
        NotificationBase notification  = MediaNotificationService.getNotification();

        if (notification == null) {
            FsLogger.log(TAG + "received update for a null notification", LogLevel.Error);
            return;
        }

        try {
            if (!TextUtils.isEmpty(infoNameStr) && dataWasChanged(nodePlayStatus, infoNameStr, playInfoText)) {

                FsLogger.log(TAG + "update notification with: " + infoNameStr + ", " + playInfoText + ", " + nodePlayStatus);
                notification
                        .setData(infoNameStr, playInfoText)
                        .setPlayStatus(nodePlayStatus)
                        .playCaps(nodePlayCaps)
                        .update()
                        .show();
                if (!artworkURL.isEmpty()) {
                    // do artwork update here

                    FsLogger.log(TAG + "update image with: " + artworkURL);
                    notification
                            .loadArtwork(NotificationManagerService.this, artworkURL);
                }
            }
        } catch (ArrayIndexOutOfBoundsException e){
            FsLogger.log(TAG + "Not updated - ArrayIndexOutOfBoundsException");
        } catch (NullPointerException e) {
            FsLogger.log(TAG + "null pointer exception while trying to show");
        }
    }

    private boolean dataWasChanged(NodePlayStatus playStatus, String infoName, String infoText) {
        NotificationBase notification = MediaNotificationService.getNotification();

        if (notification == null) {
            return false;
        }
        return playStatus.getValueEnum() != notification.mPlayStatus.getValueEnum() ||
                infoName != notification.mTitle ||
                infoText != notification.mText;
    }

    /**
     * get track info from radio
     * @param radio from where to request Track updates
     */
    private void getPlayerTrackUpdates(Radio radio) {

        NetRemote netRemote = getNetRemote();
        if (MainApplication.isInForeground() && netRemote != null && netRemote.getCurrentRadio() != null) {

            NowPlayingDataModel nowPlayingDataModel = NowPlayingManager.getInstance().getNowPlayingDataModel();
            NotificationBase notification = MediaNotificationService.getNotification();

            if (notification != null) {
                notification.setPlayStatus(nowPlayingDataModel.playStatus.get());
            }

            sendPlayerTrackUpdates(
                    nowPlayingDataModel.playInfoName.get(),
                    nowPlayingDataModel.graphicUri.get(),
                    nowPlayingDataModel.artist.get(),
                    nowPlayingDataModel.album.get());

        } else {
            waitOneSecondToChangeInfosOnSpeakerBeforeRequesting();
            RadioNodeUtil.getNodesFromRadio(radio, new Class[]{NodePlayInfoName.class, NodePlayInfoGraphicUri.class, NodePlayInfoArtist.class,
                    NodePlayInfoAlbum.class, NodePlayStatus.class}, true, true, new RadioNodeUtil.INodesResultListener() {
                @Override
                public void onNodesResult(Map<Class, NodeInfo> nodes) {

                    String infoNameStr = "";
                    String artworkURL = "";
                    String artistStr = "";
                    String albumStr = "";

                    NodePlayInfoName infoNameNode = (NodePlayInfoName) nodes.get(NodePlayInfoName.class);
                    if (infoNameNode != null) {

                        infoNameStr = infoNameNode.getValue().trim();
                    }

                    NodePlayInfoGraphicUri graphicUriNode = (NodePlayInfoGraphicUri) nodes.get(NodePlayInfoGraphicUri.class);
                    if (graphicUriNode != null) {
                        artworkURL = graphicUriNode.getValue();
                    }

                    NodePlayInfoArtist infoArtistNode = (NodePlayInfoArtist) nodes.get(NodePlayInfoArtist.class);
                    if (infoArtistNode != null) {
                        artistStr = infoArtistNode.getValue();
                    }

                    NodePlayInfoAlbum infoAlbumNode = (NodePlayInfoAlbum) nodes.get(NodePlayInfoAlbum.class);
                    if (infoAlbumNode != null) {
                        albumStr = infoAlbumNode.getValue();
                    }

                    NodePlayStatus playStatus = (NodePlayStatus) nodes.get(NodePlayStatus.class);
                    if (playStatus != null) {
                        NotificationBase notification = MediaNotificationService.getNotification();

                        if (notification != null) {
                            notification.setPlayStatus(playStatus);
                        }
                    }

                    sendPlayerTrackUpdates(infoNameStr, artworkURL, artistStr, albumStr);
                }
            });
        }
    }

    private void waitOneSecondToChangeInfosOnSpeakerBeforeRequesting() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void sendPlayerTrackUpdates(String infoNameStr, String artworkURL,
                                        String artistStr, String albumStr) {

        // updating notification info
        NotificationBase notification = MediaNotificationService.getNotification();

        if (notification == null) {
            FsLogger.log(TAG + "received update for a null notification (sendPlayerTrackUpdates)", LogLevel.Error);
            return;
        }

        try {

            if (TextUtils.isEmpty(infoNameStr)) {
                notification.remove();
            } else {
                // updating notification info

                try {
                    if (TextUtils.isEmpty(albumStr)) {
                        notification.setData(infoNameStr, artistStr);
                    } else {
                        notification.setData(infoNameStr, artistStr + " (" + albumStr + ")");
                    }

                    notification
                            .update()
                            .show();

                } catch (ArrayIndexOutOfBoundsException e) {
                    FsLogger.log(TAG + "out of bounds exception (too much updates), update skipped");
                }

                // load artwork
                if (!artworkURL.isEmpty()) {
                    // do artwork update here

                    FsLogger.log(TAG + "update image with: " + artworkURL);
                    notification
                            .loadArtwork(NotificationManagerService.this, artworkURL);
                }
            }
        } catch (NullPointerException e) {
            FsLogger.log(TAG + "null pointer exception while trying to show");
        }
    }
}
