package com.frontier_silicon.fsirc.dok2.update;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoVersion;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuControl;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuMandatory;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuState;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuSummary;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuVersion;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.NetRemoteLib.Radio.TransportErrorDetail;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.Map;

public class CheckForUpdateRunnable implements Runnable {
	private final Object mLock = new Object();
	private ICheckForUpdateListener mUpdateListener;
	private Radio mRadio = null;

	private static final long MAX_WAIT_FOR_RESP_MS = 4000;
	private static final long WAIT_FOR_RESP_MS = 200;

	private int mNumResponses = 0;
    private boolean mStartedCheckForUpdate = false;
	private NodeSysIsuState mStateNode = null;
    private volatile int mCalledCallbacks = 0;

	public CheckForUpdateRunnable(ICheckForUpdateListener updateListener, Radio radio) {
		mRadio = radio;
		
		setNewListener(updateListener);
	}
	
	@Override
	public void run() {
		retrieveCurrentVersion(mRadio);

		boolean startedCheckForUpdate = checkUpdateState(mRadio, true);
		if (startedCheckForUpdate) {
			waitToCheckUpdateAndReturnState(mRadio);

			checkUpdateState(mRadio, false);

            if (mCalledCallbacks < 2) {
                onUpdateNotAvailable(mRadio);
            }
		}
	}

	public void retrieveCurrentVersion(final Radio radio) {
		RadioNodeUtil.getNodeFromRadioAsync(radio, NodeSysInfoVersion.class, new RadioNodeUtil.INodeResultListener() {
            @Override
            public void onNodeResult(NodeInfo node) {
                String currentVersion = "";
                if (node != null) {
                    currentVersion = ((NodeSysInfoVersion) node).getValue();
                }

                FsLogger.log(">>> CheckForUpdateRunnable: retrieveCurrentVersion " + radio + " " + currentVersion);

                synchronized (mLock) {
                    if (mUpdateListener != null) {
                        mUpdateListener.onCurrentVersionRetrieved(currentVersion);
                        mCalledCallbacks++;
                        disposeIfPossible();
                    }
                }
            }
        });
	}
	
	private boolean checkUpdateState(final Radio radio, final boolean startCheckIfNeeded) {
		FsLogger.log(">>> CheckForUpdateRunnable: ISU state check for " + radio);

		mNumResponses = 0;
		mStartedCheckForUpdate = false;

        radio.getNode(NodeSysIsuState.class, false, true, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    NodeSysIsuState stateNode = (NodeSysIsuState) node;

                    FsLogger.log(">>> CheckForUpdateRunnable: ISU state for " + radio + " " + stateNode.getValueEnum());

                    switch (stateNode.getValueEnum()) {
                        case UPDATE_AVAILABLE:
                            onAvailableUpdate(radio);
                            break;

                        case IDLE:
                        case UPDATE_NOT_AVAILABLE:
                            if (startCheckIfNeeded) {
                                startScanningForUpdate(radio);
                            } else {
                                onUpdateNotAvailable(radio);
                            }
                            break;

                        case CHECK_IN_PROGRESS:
                        case CHECK_FAILED:
                            if (startCheckIfNeeded) {
                                startScanningForUpdate(radio);
                            } else {
                                onCheckFailed(ICheckForUpdateListener.ErrorType.Unknown);
                            }
                            break;

                        default:
                            onCheckFailed(ICheckForUpdateListener.ErrorType.Unknown);
                            break;
                    }

                    mNumResponses++;
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    TransportErrorDetail transportErrorDetail = error.getTransportDetail();
                    if (transportErrorDetail != null && transportErrorDetail.getErrorCode() == TransportErrorDetail.ErrorCode.PinError) {
                        onCheckFailed(ICheckForUpdateListener.ErrorType.PinNotProvided);
                    } else {
                        onCheckFailed(ICheckForUpdateListener.ErrorType.Unknown);
                    }

                    mNumResponses++;
                }
            }
        );

		int cnt = 0;
		int maxCnt = (int) (MAX_WAIT_FOR_RESP_MS / WAIT_FOR_RESP_MS);
		int expectedResponses = 1;
		while (mNumResponses < expectedResponses && cnt < maxCnt) {
			try {
				Thread.sleep(WAIT_FOR_RESP_MS);
			} catch (InterruptedException e) {
			}

			cnt++;
		}

		return mStartedCheckForUpdate;
	}

	private void startScanningForUpdate(final Radio radio) {
		RadioNodeUtil.setNodeToRadioAsync(radio, new NodeSysIsuControl(NodeSysIsuControl.Ord.CHECK_FOR_UPDATE), new RadioNodeUtil.INodeSetResultListener() {
			@Override
			public void onNodeSetResult(boolean success) {
				if (success) {
					FsLogger.log(">>> CheckForUpdateRunnable: START ISU Update check for " + radio, LogLevel.Warning);
				} else {
					FsLogger.log(">>> CheckForUpdateRunnable: ERROR STARTING ISU Update check for " + radio, LogLevel.Error);
				}
			}
		});

		mStartedCheckForUpdate = true;
	}
	
	private NodeSysIsuState waitToCheckUpdateAndReturnState(Radio radio) {
		mStateNode = null;
		int count = 0;

		do {
			getUpdateState(radio);

			try {
				Thread.sleep(FsComponentsConfig.MILLISECONDS_TO_WAIT_BETWEEN_CHECKING_ISU);
			} catch (InterruptedException e) {
				if (count >= FsComponentsConfig.MAX_RETRIES_FOR_CHECKING_ISU)
					break;
			}

			FsLogger.log(">>> CheckForUpdateRunnable: wait checking " + radio + " " + count, LogLevel.Warning);

			count++;
		} while (isUpdateInProgress(mStateNode) && count < FsComponentsConfig.MAX_RETRIES_FOR_CHECKING_ISU);
		
		return mStateNode;
	}

	private boolean isUpdateInProgress(NodeSysIsuState stateNode) {
		boolean updateInProgress = true;

		if (stateNode != null) {
			updateInProgress = (mStateNode.getValueEnum() == NodeSysIsuState.Ord.CHECK_IN_PROGRESS);
		}

		return updateInProgress;
	}

	private void getUpdateState(final Radio radio) {
		RadioNodeUtil.getNodeFromRadioAsync(radio, NodeSysIsuState.class, new RadioNodeUtil.INodeResultListener() {
			@Override
			public void onNodeResult(NodeInfo node) {
				if (node != null) {
					mStateNode = (NodeSysIsuState) node;

					FsLogger.log(">>> CheckForUpdateRunnable: getUpdateState " + radio + " " + mStateNode.getValueEnum());
				}
			}
		});
	}
	
	private void onAvailableUpdate(final Radio radio) {
		boolean forceUncached = true;
		RadioNodeUtil.getNodesFromRadioAsync(radio, new Class[]{NodeSysIsuVersion.class, NodeSysIsuMandatory.class, NodeSysIsuSummary.class}, forceUncached, new RadioNodeUtil.INodesResultListener() {
			@Override
			public void onNodesResult(Map<Class, NodeInfo> nodes) {
				FsLogger.log(">>> CheckForUpdateRunnable: update available requests complete " + radio, LogLevel.Warning);

				if (nodes != null) {
					NodeSysIsuVersion versionNode = (NodeSysIsuVersion) nodes.get(NodeSysIsuVersion.class);
					NodeSysIsuMandatory mandatoryNode = (NodeSysIsuMandatory) nodes.get(NodeSysIsuMandatory.class);
					NodeSysIsuSummary summaryNode = (NodeSysIsuSummary) nodes.get(NodeSysIsuSummary.class);

					// ISU nodes must exist for update !
					if (versionNode == null) {
						onUpdateNotAvailable(radio);
						return;
					}

					// can work without these node
					long isMandatory = 0;
					if (mandatoryNode != null) {
						isMandatory = mandatoryNode.getValue();
					} else {
						isMandatory = 1;
					}
                    String summary = (summaryNode != null) ? summaryNode.getValue() : "";

					IsuBackgroundManager.getInstance().updateIsuInfoOfRadio(radio, true, isMandatory > 0);

					synchronized (mLock) {
						if (mUpdateListener != null) {
                            mUpdateListener.onAvailableUpdate(versionNode.getValue(), summary, isMandatory);
                            mCalledCallbacks++;
                            disposeIfPossible();
                        }
					}
				} else {
					onUpdateNotAvailable(radio);
				}

            }
		});
	}
	
	private void onUpdateNotAvailable(final Radio radio) {
		IsuBackgroundManager.getInstance().updateIsuInfoOfRadio(radio, false, false);
		
		synchronized (mLock) {
			if (mUpdateListener != null) {
                mUpdateListener.onNoAvailableUpdate();
                mCalledCallbacks++;
                disposeIfPossible();
            }
		}
	}
	
	private void onCheckFailed(ICheckForUpdateListener.ErrorType errorType) {
		synchronized (mLock) {
			if (mUpdateListener != null) {
                mUpdateListener.onCheckFailed(errorType);
                mCalledCallbacks++;
                disposeIfPossible();
            }
		}
	}

	public void setNewListener(ICheckForUpdateListener updateListener) {
		synchronized (mLock) {
			mUpdateListener = updateListener;
		}
	}
	
	private void disposeIfPossible() {
        if (mCalledCallbacks < 2)
            return;

		FsLogger.log(">>> CheckForUpdateRunnable: disposeIfPossible " + mRadio, LogLevel.Error);

		synchronized (mLock) {
			mUpdateListener = null;
			mRadio = null;
		}
	}
}
