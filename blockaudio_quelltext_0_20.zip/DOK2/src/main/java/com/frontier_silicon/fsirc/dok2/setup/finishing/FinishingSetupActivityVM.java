package com.frontier_silicon.fsirc.dok2.setup.finishing;

import android.app.Activity;
import androidx.databinding.ObservableField;

import com.frontier_silicon.NetRemoteLib.AccessPointUtil;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.setup.EStateOfCheckingHeadlessSetup;
import com.frontier_silicon.fsirc.dok2.setup.IStateOfCheckingHeadlessSetupListener;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.setupdone.SetupDoneActivity;
import com.frontier_silicon.fsirc.dok2.setup.technologies.TechnologiesActivity;

/**
 * Created by nbalazs on 21/03/2018.
 *
 */

public class FinishingSetupActivityVM {

    private Activity mActivity;

    public ObservableField<Boolean> isSkipButtonEnabled = new ObservableField<>(true);
    public ObservableField<Boolean> isSkipButtonVisible = new ObservableField<>(false);
    public ObservableField<String> skipButtonText = new ObservableField<>("");

    public ObservableField<Integer> setupProgress = new ObservableField<>(0);
    public ObservableField<Integer> setupProgressMaxValue = new ObservableField<>(165);

    public ObservableField<String> progressDescriptionText = new ObservableField<>("");

    FinishingSetupActivityVM(Activity activity) {
        mActivity = activity;
        progressDescriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.configuring_the_device, true));
        skipButtonText.set(mActivity.getResources().getString(R.string.hui_skip_searching_for_configured_device));
    }

    final void startSetupProcess(){
        setupNetwork();
    }

    public final void onSkipCheckingClicked() {
        SetupManager.getInstance().skipSearchingForConfiguredDevice();
    }

    synchronized private void setupNetwork() {
        SetupManager setupManager = SetupManager.getInstance();
        if (!setupManager.setupDeviceThreadIsRunning()) {
            resetProgressBar();
        }

        setupManager.setupDevice(new IStateOfCheckingHeadlessSetupListener() {

            @Override
            public void onStateOfCheckingHeadlessSetupChanged(final EStateOfCheckingHeadlessSetup state) {
                if (mActivity != null) {
                    mActivity.runOnUiThread(() -> onStateChanged(state));
                }
            }

            @Override
            public void onProgress(final int progress) {
                if (mActivity != null) {
                    mActivity.runOnUiThread(() -> setupProgress.set(progress));
                }
            }
        });
    }

    private void resetProgressBar() {
        setupProgress.set(0);
        setupProgressMaxValue.set(getMaxTimeOfNormalSetup());
    }

    private int getMaxTimeOfNormalSetup() {
        return FsComponentsConfig.MAX_SECONDS_TO_CONFIGURE_THE_DEVICE +
                2 * FsComponentsConfig.MAX_SECONDS_TO_WAIT_FOR_CONNECTING_TO_AP +
                FsComponentsConfig.MAX_SECONDS_TO_LOOK_FOR_CONFIGURED_RADIO;
    }

    private void onStateChanged(EStateOfCheckingHeadlessSetup configState) {

        if (mActivity == null) {
            return;
        }
        switch (configState) {
            case None:
                progressDescriptionText.set("");
                resetProgressBar();
                break;
            case ConfiguringAudioDevice:
                progressDescriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.configuring_the_device, true));
                break;
            case ConfiguringWithWPS:
                progressDescriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.configuring_with_wps, true));
                setupProgressMaxValue.set(FsComponentsConfig.MAX_SECOND_TO_CONFIG_WITH_WPS + FsComponentsConfig.MAX_SECONDS_TO_CONNECT_WITH_WPS);
                break;
            case NodesWereNotSetCorrectly:
                onSetupFailed();
                break;
            case ConnectingToSelectedWiFi:
                progressDescriptionText.set(mActivity.getResources().getString(R.string.connecting_to_selected_wifi));
                break;
            case WaitOnConnectingWithWPS:
                progressDescriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.configuring_with_wps, true));
                showSkipButtonForWPS();
                AccessPointUtil.startAccesPointsScan();
                break;
            case CouldntConnectToWiFi:
                onSetupCompleted();
                break;
            case SearchingTheAudioDevice:
                progressDescriptionText.set(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.searching_for_the_configured_device, true));
                // Set SkipChecking button visible only for speakers that don't have Cast
                // For Cast Speakers we need to connect to the radio to be able to send CastAcceptance node, thus button must be invisible
                if (!SetupManager.getInstance().getIsCastSupported()) {
                    showSkipButton();
                }
                AccessPointUtil.startAccesPointsScan();
                break;
            case CouldntFindDeviceWithSSDP:
                onSetupCompleted();
                break;
            case SuccesfullSetup:
                onSetupCompleted();
                AnalyticsSender.setupAudioSystemFinishedSuccessfully(SetupManager.getInstance().getFirmwareVersion());

                if (SetupManager.getInstance().isVeniceXDevice()) {
                    AnalyticsSender.sendVeniceXSetupSuccessfully(SetupManager.getInstance().getFirmwareVersion());
                }
                AccessPointUtil.startAccesPointsScan();
                break;
            default:
                break;
        }
    }

    private void showSkipButton() {
        isSkipButtonEnabled.set(!SetupManager.getInstance().getIsCastSupported());
        isSkipButtonVisible.set(!SetupManager.getInstance().getIsCastSupported());
        if (!SetupManager.getInstance().getIsCastSupported()) {
            skipButtonText.set(mActivity.getResources().getString(R.string.hui_skip_searching_for_configured_device));
        }
    }

    private void showSkipButtonForWPS() {
        isSkipButtonEnabled.set(!SetupManager.getInstance().getIsCastSupported());
        isSkipButtonVisible.set(!SetupManager.getInstance().getIsCastSupported());
        skipButtonText.set(mActivity.getResources().getString(R.string.hui_skip_waiting_wps));
    }

    private void onSetupFailed() {
        NavigationHelper.goToActivity(mActivity, SetupDoneActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    private void onSetupCompleted() {
        SetupManager setupManager = SetupManager.getInstance();
        if (setupManager.getIsCastSupported() || setupManager.getIsBluetoothSupported() || setupManager.getIsSpotifySupported() || setupManager.getIsAvsSupported()) {
            NavigationHelper.goToActivity(mActivity, TechnologiesActivity.class, NavigationHelper.AnimationType.SlideToLeft);
        } else {
            NavigationHelper.goToActivity(mActivity, SetupDoneActivity.class, NavigationHelper.AnimationType.SlideToLeft);
        }
    }
}
