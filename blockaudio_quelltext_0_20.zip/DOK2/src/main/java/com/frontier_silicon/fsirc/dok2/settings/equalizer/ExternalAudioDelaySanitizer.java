package com.frontier_silicon.fsirc.dok2.settings.equalizer;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import com.frontier_silicon.components.common.BaseSanitizer;
import com.frontier_silicon.fsirc.dok2.R;

public class ExternalAudioDelaySanitizer extends BaseSanitizer {

    final private long mMaxAudioDelay;
    final private long mMinAudioDelay;

    private IExternalAudioDelaySanitizerListener mSanitizerListener;

    public interface IExternalAudioDelaySanitizerListener {
        void onExternalAudioDelayValue(long audioDelayMSec);
    }

    public ExternalAudioDelaySanitizer(long maxAudioDelayMSec) {
        mMaxAudioDelay = maxAudioDelayMSec;
        mMinAudioDelay = 0;
    }

    public void appendSanitizerToEditText(EditText editText, Context context, IExternalAudioDelaySanitizerListener sanitizerListener) {
        mEditText = editText;
        mContext = context;
        mSanitizerListener = sanitizerListener;

        mEditText.addTextChangedListener(new TextWatcher() {
            int startIndexOfChange = 0;
            int numberOfAddedChars = 0;

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                startIndexOfChange = start;
                numberOfAddedChars = count;
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                hideError();
            }

            @Override
            public void afterTextChanged(Editable editableText) {

                try {
                    long audioDelayValueMS = Long.valueOf("" + editableText);
                    if (audioDelayValueMS > mMaxAudioDelay || audioDelayValueMS < mMinAudioDelay) {
                        showInvalidIntervalErrorMessage();
                    }

                    if (mSanitizerListener != null) {
                        mSanitizerListener.onExternalAudioDelayValue(audioDelayValueMS);
                    }
                } catch (NumberFormatException e) {
                    showInvalidIntegerErrorMessage();
                }
            }
        });
    }

    private void showInvalidIntegerErrorMessage() {
        mEditText.setError(mContext.getString(R.string.only_integer_allowed));
    }

    private void showInvalidIntervalErrorMessage() {
        mEditText.setError(mContext.getString(R.string.invalid_interval, Long.toString(mMinAudioDelay), Long.toString(mMaxAudioDelay)));
    }


}
