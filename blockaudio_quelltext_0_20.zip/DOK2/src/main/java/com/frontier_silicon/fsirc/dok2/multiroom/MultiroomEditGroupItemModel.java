package com.frontier_silicon.fsirc.dok2.multiroom;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

public class MultiroomEditGroupItemModel {

    private MultiroomDeviceModel mDeviceModel;
    private String mNewGroupId;
    private boolean mIsChecked;
    private boolean mGroupExists;
    private boolean mIsCheckboxEnabled;

    private String mGroupsMultiroomVersion = "";
    private boolean mIsSameMultiroomVersion = true;

    public MultiroomEditGroupItemModel(MultiroomDeviceModel deviceModel, String groupId, String groupsMultiroomVersion,
                                       boolean groupExists, boolean isSelected) {
        mDeviceModel = deviceModel;
        mNewGroupId = groupId;
        mIsCheckboxEnabled = true;

        mGroupExists = groupExists;

        if (mGroupExists) {
            mIsChecked = isSelected;
        } else {
            mIsChecked = isSelected;
            mIsCheckboxEnabled = !isSelected;
        }

        mGroupsMultiroomVersion = groupsMultiroomVersion;
        mIsSameMultiroomVersion = mGroupsMultiroomVersion.equals(deviceModel.mRadio.getMultiroomVersion());
    }

    public String getNewGroupId() {
        return mNewGroupId;
    }

    public boolean isChecked() {
        return mIsChecked;
    }

    public void setChecked(boolean checked) {
        mIsChecked = checked;
    }

    public MultiroomDeviceModel getDeviceModel() {
        return mDeviceModel;
    }

    public boolean isInCurrentGroup() {
        if (mGroupExists) {
            return mNewGroupId.equals(mDeviceModel.mGroupId);
        } else {
            return false;
        }
    }

    public String getGroupName() {
        return mDeviceModel.mGroupName;
    }

    public boolean isCheckboxEnabled() {
        return mIsCheckboxEnabled;
    }

    public boolean isMasterOfNewGroup() {
        return !mIsCheckboxEnabled;
    }

    public boolean isSameMultiroomVersion() {
        return mIsSameMultiroomVersion;
    }

    public boolean isAvailableOnTheNetwork() {
        boolean isAvailable = true;

        Radio radio = mDeviceModel.mRadio;
        if (radio != null) {
            isAvailable = (!radio.isCheckingAvailability() && radio.isAvailable());
        }

        return isAvailable;
    }

    public String toString() {
        return mDeviceModel.toString();
    }
}
