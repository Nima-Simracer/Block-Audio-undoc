package com.frontier_silicon.fsirc.dok2.settings.speakerList;

import android.app.Activity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SettingsSpeakerListItemBinding;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 12/10/2017.
 */

public class SpeakerListSettingsAdapter extends RecyclerView.Adapter<SpeakerListSettingsAdapter.SpeakerListItemSettingViewHolder> {

    private EmptyState listener;
    class SpeakerListItemSettingViewHolder extends RecyclerView.ViewHolder {
        SettingsSpeakerListItemBinding mBinding;

        public SpeakerListItemSettingViewHolder(SettingsSpeakerListItemBinding binding) {
            super(binding.getRoot());

            mBinding = binding;
        }
    }

    public interface EmptyState{
        void onEmptyState(boolean isEmptyState);
    }

    private Activity mActivity;
    private List<MultiroomItemModel> mItemModels = new ArrayList<>();

    public SpeakerListSettingsAdapter(Activity activity) {
        mActivity = activity;
    }

    public void setEmptyStateListener(EmptyState callback){
        this.listener = callback;
    }

    public void swapItems(List<MultiroomItemModel> itemModels) {
        SpeakerListSettingsDiffCallback diffCallback = new SpeakerListSettingsDiffCallback(mItemModels, itemModels);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        mItemModels.clear();
        mItemModels.addAll(itemModels);
        listener.onEmptyState(mItemModels.size() == 0);

        diffResult.dispatchUpdatesTo(this);
    }

    @Override
    public SpeakerListItemSettingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        SettingsSpeakerListItemBinding binding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                R.layout.settings_speaker_list_item,
                parent, false);

        return new SpeakerListItemSettingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(SpeakerListItemSettingViewHolder speakerListItemSettingViewHolder, int position) {
        MultiroomItemModel itemModel = mItemModels.get(position);
        SpeakerListItemSettingsViewModel viewModel = new SpeakerListItemSettingsViewModel(itemModel, mActivity);

        SettingsSpeakerListItemBinding binding = speakerListItemSettingViewHolder.mBinding;
        binding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(SpeakerListItemSettingViewHolder holder) {
        SpeakerListItemSettingsViewModel viewModel = holder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            holder.mBinding.setViewModel(null);
        }

        super.onViewRecycled(holder);
    }

    @Override
    public int getItemCount() {
        return mItemModels.size();
    }

    public void dispose() {
        mItemModels.clear();
        mActivity = null;
    }
}
