package com.frontier_silicon.fsirc.dok2.presets;

import android.content.res.Configuration;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;

/**
 * Created by lsuhov on 02/05/2017.
 */

public class PresetsActivity extends UndokActivityBase {
    public final static int RESULT_CODE_LANDSCAPE = 123123;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.presets_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.presets);

        initSpeakerConnectionLostWatcher();
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setResult(RESULT_CODE_LANDSCAPE);
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
