package com.frontier_silicon.fsirc.dok2.settings.avs;

import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.SeekBar;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.RadioFromBundleExtractor;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.settings.SettingsItemModel;
import com.frontier_silicon.fsirc.dok2.settings.SettingsType;
import com.frontier_silicon.fsirc.dok2.settings.avs.locales.AvsLocaleActivity;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import java.util.ArrayList;
import java.util.List;

public class AvsSettingsActivity extends UndokActivityBase {
    private static final int MAX_VOLUME = 31;
    private Radio mClientRadio;
    private AvsSettingsViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.avs_settings_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.amazon_alexa);
        viewModel = new AvsSettingsViewModel();

        Bundle bundle = getIntent().getExtras();
        // get attached data to this intent

        mClientRadio = RadioFromBundleExtractor.extractRadio(getIntent().getExtras(), AvsLocaleActivity.class);
        viewModel.setRadio(mClientRadio);

        if (bundle != null) {
            initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
            addUdnToSpeakerLostWatcher(bundle.getString(NavigationHelper.RADIO_UDN_ARG));
        }

        setupControls();
    }

    private void setupControls() {
        RecyclerView lv = findViewById(R.id.recycler_view);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);

        lv.setLayoutManager(mLayoutManager);
        lv.setItemAnimator(new DefaultItemAnimator());

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, LinearLayoutManager.VERTICAL);
        lv.addItemDecoration(dividerItemDecoration);

        List<SettingsItemModel> settingsItemsList = getAvsSettingsItems();

        AvsSettingsAdapter adapter = new AvsSettingsAdapter(settingsItemsList, item -> {
            switch (item.mType) {
                case AVS_LOCALES:
                    Bundle bundle = new Bundle();
                    bundle.putString(NavigationHelper.RADIO_UDN_ARG, mClientRadio.getUDN());


                    NavigationHelper.goToActivity(AvsSettingsActivity.this, AvsLocaleActivity.class,
                            NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                    break;
                case AVS_ALARMS_VOLUME:
                    openAlarmsVolumeDialog();
                    break;
            }
        });

        lv.setAdapter(adapter);
    }

    private List<SettingsItemModel> getAvsSettingsItems(){

        List<SettingsItemModel> list = new ArrayList<>();

        list.add(new SettingsItemModel(SettingsType.AVS_ALARMS_VOLUME, getString(R.string.settings_avs_alarms_volume), true));
        list.add(new SettingsItemModel(SettingsType.AVS_LOCALES, getString(R.string.settings_avs_locale), true));

        return list;
    }

    @Override
    protected void onResume() {
        super.onResume();
        viewModel.getCurrentVolume();
    }

    private void openAlarmsVolumeDialog() {
        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.layout_prefs_seekbar, null);

        SeekBar bar = alertLayout.findViewById(R.id.seekBar);
        bar.setMax(MAX_VOLUME);
        bar.setProgress(Math.round(viewModel.getCurrentVolume().getValue()));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                viewModel.setSpeakerVolume(seekBar.getProgress());
            }
        });


        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(this);
        builder.setView(alertLayout);

        AlertDialog dialog = builder.create();
        DialogsHolder.addDialogToCollection("avs_volume_dialog", dialog);

        dialog.show();
    }
}
