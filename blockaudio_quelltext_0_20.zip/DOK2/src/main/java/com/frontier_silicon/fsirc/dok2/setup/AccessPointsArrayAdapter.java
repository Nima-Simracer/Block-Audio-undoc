package com.frontier_silicon.fsirc.dok2.setup;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.setup.AccessPointConfig.AccessPointModel;

import java.util.List;

public class AccessPointsArrayAdapter extends ArrayAdapter<AccessPointModel> {

	private Context mContext = null;
	
	public AccessPointsArrayAdapter(Context context, int resource, List<AccessPointModel> objects) {
		super(context, resource, objects);
		
		mContext = context;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View v = convertView;
		LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		AccessPointModel device = getItem(position);
		
		if (device.getIsGroupHeader()) {
			if (v == null || v.getTag() == null || !((AccessPointModel)v.getTag()).getIsGroupHeader())
				v = li.inflate(R.layout.group_header_list_item, null);
			
			TextView tv = (TextView) v.findViewById(R.id.text1);
			tv.setText(device.getTitle());
		}
		else {
			if (v == null || v.getTag() == null || ((AccessPointModel)v.getTag()).getIsGroupHeader())
				v = li.inflate(R.layout.setup_list_item_connect_to_headless, null);
			
			ScanResult scanResult = device.getScanResult();
			
			TextView tv = (TextView) v.findViewById(R.id.text1);
			String text = "";
			
			if (scanResult != null)
				text = scanResult.SSID;
			else
				text = device.getTitle();
			
			tv.setText(text);
			
			if (scanResult == null)
				return v;
			
			SetupManager setupManager = SetupManager.getInstance();
			
			boolean isConnectedToRadio = setupManager.isConnectedToGivenRadio(scanResult);
			ImageView checkMarkImgView = (ImageView) v.findViewById(R.id.imageView1);
			checkMarkImgView.setVisibility(isConnectedToRadio ? View.VISIBLE : View.GONE);
			
			boolean isConnectingToRadio = setupManager.isConnectingToGivenRadio(scanResult);
			ProgressBar progressBar = (ProgressBar) v.findViewById(R.id.progressBarConnecting);
			progressBar.setVisibility(isConnectingToRadio ? View.VISIBLE : View.GONE);

			ImageView signalStrength = (ImageView) v.findViewById(R.id.imageViewSignalStrength);

			if ( scanResult != null) {
				switch (device.getSignalStrength()) {
					case 0:
						signalStrength.setImageResource(R.drawable.ic_wifi_strength_0);
						break;
					case 1 :
						signalStrength.setImageResource(R.drawable.ic_wifi_strength_1);
						break;
					case 2:
						signalStrength.setImageResource(R.drawable.ic_wifi_strength_2);
						break;
					case 3:
						signalStrength.setImageResource(R.drawable.ic_wifi_strength_3);
						break;
				}
			}
		}
		
		v.setTag(device);
		
		return v;
	}
}
