package com.frontier_silicon.fsirc.dok2.multiroom;

import android.app.Activity;
import android.content.Context;

import androidx.appcompat.app.AlertDialog;
import android.view.WindowManager;

import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomCapsMaxClients;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomGroupState;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomGroupStreamable;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.IDialogButtonsResponse;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.multiroom.MultiroomOperation;
import com.frontier_silicon.components.connection.AfterConnectionNodesSetter;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;
import java.util.List;

public class MultiroomEditGroupUtil {

    private static final int FIRST_IDX = 0;
    private static final int NUM_MIN_SPEAKERS_IN_GROUP = 2;

    public List<MultiroomOperation> getOperationsList(List<MultiroomEditGroupItemModel> radioList, boolean renameGroup, String newGroupName, MultiroomItemModel multiroomItemModel) {
        ArrayList<MultiroomOperation> operationsList = new ArrayList<>();
        Boolean isTransportOptimised = isTransportOptimised(multiroomItemModel);

        int numDevicesLeftInGroup = 0;

        if (!renameGroup) { // edit group without renaming or create new group
            if (multiroomItemModel.getIsGroupHeader()) {
                numDevicesLeftInGroup = MultiroomGroupManager.getInstance().getNumDevicesInGroup(multiroomItemModel.getGroupId());
            }

            for (MultiroomEditGroupItemModel item : radioList) {
                boolean needsToBeAdded = (item.isChecked() && !item.isInCurrentGroup());
                boolean needsToBeRemoved = (!item.isChecked() && item.isInCurrentGroup());

                if (needsToBeAdded) {

                    if (item.isMasterOfNewGroup()) {

                        // creating group with this speaker as master
                        operationsList.add(FIRST_IDX,
                                getCreateOperation(
                                        item.getDeviceModel().mRadio.getUDN(),
                                        item.getNewGroupId(),
                                        item.getDeviceModel().mGroupId,
                                        newGroupName,
                                        item.getGroupName())
                        );
                    } else {

                        // adding this speaker to group
                        operationsList.add(
                                getAddRemoveOperation(
                                        item.getDeviceModel().mRadio.getUDN(),
                                        item.getNewGroupId(),
                                        item.getDeviceModel().mGroupId,
                                        newGroupName,
                                        item.getGroupName(),
                                        isTransportOptimised)
                        );
                    }

                    numDevicesLeftInGroup++;
                } else if (needsToBeRemoved) {

                    operationsList.add(
                            getAddRemoveOperation(
                                    item.getDeviceModel().mRadio.getUDN(),
                                    MultiroomGroupManager.NO_GROUP_ID,
                                    item.getDeviceModel().mGroupId,
                                    MultiroomGroupManager.NO_GROUP_NAME,
                                    item.getGroupName(),
                                    null)
                    );

                    numDevicesLeftInGroup--;
                }
            }

        } else {
            // rename => create new group/add selected radios to new group
            String oldGroupName = multiroomItemModel.getGroupName();

            // sort with masters first => recreate group with same master
            /*
            Collections.sort(radioList, new Comparator<MultiroomEditGroupItemModel>() {
                @Override
                public int compare(MultiroomEditGroupItemModel lhs, MultiroomEditGroupItemModel rhs) {
                    MultiroomItemModel leftItem = lhs.getDeviceModel();
                    MultiroomItemModel rightItem = rhs.getDeviceModel();

                    if (leftItem != null && rightItem != null) {
                        return (int) (rightItem.getGroupRole() - leftItem.getGroupRole());
                    }

                    return 0;
                }
            });
            */

            //destroy group before creating new group
            operationsList.add(FIRST_IDX,
                    getDeleteOperation(
                            multiroomItemModel.getGroupId(),
                            multiroomItemModel.getGroupName())
            );

            List<MultiroomEditGroupItemModel> groupSpeakerClientsList = new ArrayList<>();
            for (MultiroomEditGroupItemModel item : radioList) {
                if (item.isChecked()) {

                    if (item.getDeviceModel().mGroupRole == NodeMultiroomGroupState.Ord.SERVER) {

                        // we found a server
                        if (item.getDeviceModel().mGroupId.equals(multiroomItemModel.getGroupId())) {

                            // this is this group server
                            operationsList.add(FIRST_IDX + 1,
                                    getCreateOperation(
                                            item.getDeviceModel().mRadio.getUDN(),
                                            MultiroomGroupManager.TEMP_GROUP_ID,
                                            item.getDeviceModel().mGroupId,
                                            newGroupName,
                                            oldGroupName)
                            );
                            numDevicesLeftInGroup++;
                        } else {

                            // adding in new group
                            groupSpeakerClientsList.add(item);
                        }
                    } else {
                        groupSpeakerClientsList.add(item);
                    }
                }
            }

            for (MultiroomEditGroupItemModel item : groupSpeakerClientsList) {
                operationsList.add(
                        getAddRemoveOperation(
                                item.getDeviceModel().mRadio.getUDN(),
                                MultiroomGroupManager.TEMP_GROUP_ID,
                                item.getDeviceModel().mGroupId,
                                newGroupName,
                                oldGroupName,
                                isTransportOptimised)
                );

                numDevicesLeftInGroup++;
            }
        }

        // replace all operations with group destroy if no radios left in group
        if (multiroomItemModel.getIsGroupHeader() && numDevicesLeftInGroup < NUM_MIN_SPEAKERS_IN_GROUP) {
            operationsList.clear();

            operationsList.add(
                    getDeleteOperation(
                            multiroomItemModel.getGroupId(),
                            multiroomItemModel.getGroupName())
            );
        }

        return operationsList;
    }

    private MultiroomOperation getDeleteOperation(String groupId, String groupName){
        MultiroomOperation deleteGroupOp = new MultiroomOperation();
        deleteGroupOp.mMultiroomDeviceUDN = "";
        deleteGroupOp.mGroupId = groupId;
        deleteGroupOp.mOldGroupId = groupId;
        deleteGroupOp.mGroupName = groupName;
        deleteGroupOp.mOldGroupName = groupName;
        deleteGroupOp.mOperationType = MultiroomOperation.MultiroomGroupEditOperation.DESTROY_GROUP;

        FsLogger.log("Operation: Queue add: " + MultiroomOperation.MultiroomGroupEditOperation.DESTROY_GROUP);

        return deleteGroupOp;
    }

    private MultiroomOperation getAddRemoveOperation(String udn, String groupId, String oldGroupId, String groupName, String oldGroupName, Boolean isTransportOptimised) {
        MultiroomOperation operation = new MultiroomOperation();
        operation.mMultiroomDeviceUDN = udn;
        operation.mGroupId = groupId;
        operation.mOldGroupId = oldGroupId;
        operation.mGroupName = groupName;
        operation.mOldGroupName = oldGroupName;

        operation.mOperationType = MultiroomOperation.MultiroomGroupEditOperation.ADD_REMOVE_SPEAKER_TO_FROM_GROUP;
        operation.mTransportOptimisation = isTransportOptimised;

        FsLogger.log("Operation: Queue add: " + MultiroomOperation.MultiroomGroupEditOperation.ADD_REMOVE_SPEAKER_TO_FROM_GROUP);

        return operation;
    }

    private MultiroomOperation getCreateOperation(String udn, String groupId, String oldGroupId, String groupName, String oldGroupName){
        MultiroomOperation operation = new MultiroomOperation();
        operation.mMultiroomDeviceUDN = udn;
        operation.mGroupId = groupId;
        operation.mOldGroupId = oldGroupId;
        operation.mGroupName = groupName;
        operation.mOldGroupName = oldGroupName;

        operation.mOperationType = MultiroomOperation.MultiroomGroupEditOperation.CREATE_GROUP;

        FsLogger.log("Operation: Queue add: " + MultiroomOperation.MultiroomGroupEditOperation.CREATE_GROUP);

        return operation;
    }

    public int getNumFinalClientsInGroup(List<MultiroomEditGroupItemModel> radioList, boolean renameGroup, MultiroomItemModel multiroomItemModel) {
        int numDevicesLeftInGroup = 0;

        if (!renameGroup) { // edit group without renaming or create new group
            if (multiroomItemModel.getIsGroupHeader()) {
                numDevicesLeftInGroup = MultiroomGroupManager.getInstance().getNumDevicesInGroup(multiroomItemModel.getGroupId());
            }

            for (MultiroomEditGroupItemModel item : radioList) {
                boolean needsToBeAdded = (item.isChecked() && !item.isInCurrentGroup());
                boolean needsToBeRemoved = (!item.isChecked() && item.isInCurrentGroup());

                if (needsToBeAdded) {
                    numDevicesLeftInGroup++;
                } else if (needsToBeRemoved) {
                    numDevicesLeftInGroup--;
                }
            }

        } else {
            // rename => destroy group/create new group/add selected radios to new group
            for (MultiroomEditGroupItemModel item : radioList) {
                if (item.isChecked()) {
                    numDevicesLeftInGroup++;
                }
            }
        }

        return numDevicesLeftInGroup - 1;
    }

    public boolean checkNumClientsInGroup(MultiroomItemModel multiroomItemModel, final int numClients) {
        boolean tooManyClientsInGroup = false;
        Radio radio = getMasterRadio(multiroomItemModel);

        if (radio != null) {
            NodeMultiroomCapsMaxClients maxClientsNode = (NodeMultiroomCapsMaxClients) radio.
                    nodeSyncGetter(NodeMultiroomCapsMaxClients.class).get();
            if (maxClientsNode != null) {
                tooManyClientsInGroup = (numClients > maxClientsNode.getValue());
            }
        }

        return (!tooManyClientsInGroup);
    }

    public void notifyTooManyClientsInGroup(Context context) {
        MultiroomDialogsUtil.showMaxClientsErrorDlg((Activity) context);
    }

    public boolean isCurrentModeStreamable(Radio radio) {
        boolean isStreamableMode = false;

        if (radio != null) {
            boolean forceUncached = true;
            NodeMultiroomGroupStreamable streamableNode = (NodeMultiroomGroupStreamable) radio.
                    nodeSyncGetter(NodeMultiroomGroupStreamable.class, forceUncached).get();
            if (streamableNode != null) {
                isStreamableMode = (streamableNode.getValueEnum() == NodeMultiroomGroupStreamable.Ord.TRUE);
            }
        }

        return isStreamableMode;
    }

    public Boolean isTransportOptimised(MultiroomItemModel device) {
        Radio radio = getMasterRadio(device);

        return AfterConnectionNodesSetter.isTransportOptimisedSync(radio);
    }

    public Radio getMasterRadio(MultiroomItemModel itemModel) {
        Radio radio = null;

        if (itemModel.getIsGroupHeader()) {
            MultiroomDeviceModel serverDevice = MultiroomGroupManager.getInstance().getServerDeviceFromGroupId(itemModel.getGroupId());
            if (serverDevice != null) {
                radio = serverDevice.mRadio;
            }
        } else {
            radio = itemModel.getRadio();
        }

        return radio;
    }

    static public List<MultiroomOperation> getDestroyGroupOperationsList(MultiroomItemModel multiroomItemModel) {
        ArrayList<MultiroomOperation> operationsList = new ArrayList<>();

        MultiroomOperation deleteGroupOp = new MultiroomOperation();
        deleteGroupOp.mMultiroomDeviceUDN = "";
        deleteGroupOp.mGroupId = multiroomItemModel.getGroupId();
        deleteGroupOp.mOldGroupId = multiroomItemModel.getGroupId();
        deleteGroupOp.mGroupName = multiroomItemModel.getGroupName();
        deleteGroupOp.mOldGroupName = multiroomItemModel.getGroupName();
        deleteGroupOp.mOperationType = MultiroomOperation.MultiroomGroupEditOperation.DESTROY_GROUP;

        operationsList.add(deleteGroupOp);

        return operationsList;
    }

    public void showDuplicateGroupDialog(Context context, final String newGroupName, final IDialogButtonsResponse listener) {
        String dialogKey = "duplicate_group";
        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, (Activity) context))
            return;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(context);

        builder.setTitle(context.getResources().getString(R.string.duplicate_group_dlg_title, newGroupName));

        builder.setMessage(R.string.duplicate_group_name);

        builder.setPositiveButton(android.R.string.ok, (dialog, which) -> {
            if (listener != null) {
                listener.onPositiveClicked();
            }
        });

        builder.setNegativeButton(android.R.string.cancel, (dialog, which) -> {
            if (listener != null) {
                listener.onNegativeClicked();
            }
        });

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);
        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        dlg.show();
    }

}
