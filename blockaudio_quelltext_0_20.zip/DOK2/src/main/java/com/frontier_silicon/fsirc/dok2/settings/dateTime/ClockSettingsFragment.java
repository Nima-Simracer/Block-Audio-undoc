package com.frontier_silicon.fsirc.dok2.settings.dateTime;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsUtcSettingsList;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.DateTimeNodesSender;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.DateTimeParams;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.GetDateTimeIsSupportedTask;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.GetDateTimeStateTask;
import com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig.IDateTimeCapsListener;

import java.util.List;

public class ClockSettingsFragment extends ConfigureClockBaseFragment {

    private NodeSysCapsClockSourceList mClockSourceList;
    private List<NodeSysCapsUtcSettingsList.ListItem> mUTCTimeZoneList;

    private Button mSaveButton;
    private Radio mClientRadio;
    private ProgressBar mProgressBar;

    @Override
    public void onActivityCreated (Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        setupOwnControls();
    }

    @Override
    public void onResume() {
        super.onResume();

        mDateTimeParams = new DateTimeParams(getActivity());

        if (mClientRadio != null) {
            getDateTimeSupportedForRadio(mClientRadio);
        }
    }

    private void getDateTimeSupportedForRadio(final Radio radio) {
        Activity parentActivity = getActivity();
        if (parentActivity != null) {
            parentActivity.runOnUiThread(() -> {
                GetDateTimeIsSupportedTask dateTimeTask = new GetDateTimeIsSupportedTask(radio, new IDateTimeCapsListener() {
                    @Override
                    public void onDateTimeSupportUpdate(boolean isDateTimeSupported) {
                        setupDateTimeControls(isDateTimeSupported);
                    }

                    @Override
                    public void onDateTimeCapsUpdate(NodeSysCapsClockSourceList clockSourceList, List<NodeSysCapsUtcSettingsList.ListItem> utcTimeZoneList) {
                        mClockSourceList = clockSourceList;
                        mUTCTimeZoneList = utcTimeZoneList;
                    }
                });

                TaskHelper.execute(dateTimeTask);
            });
        }
    }

    private void setupDateTimeControls(boolean isDateTimeSupported) {
        if (getActivity() != null && getView() != null) {
            if (isDateTimeSupported) {

                if (mClientRadio != null) {
                    getDateTimeStateForRadio(mClientRadio,isDateTimeSupported);
                }
            }
        }
    }

    private void getDateTimeStateForRadio(final Radio radio,final boolean isDateTimeSupported) {
        // show progress
        mProgressBar.setVisibility(ProgressBar.VISIBLE);
        final Activity parentActivity = getActivity();
        if (parentActivity != null) {
            parentActivity.runOnUiThread(() -> {
                GetDateTimeStateTask dateTimeSettingsTask = new GetDateTimeStateTask(parentActivity, radio, dateTimeParams -> {
                    if (getView() == null) {
                        return;
                    }

                    if (dateTimeParams != null) {
                        mDateTimeParams = dateTimeParams;
                    }

                    if (isDateTimeSupported)
                        setupControls();

                    updateDateTimeControls();
                    // close progress
                    mProgressBar.setVisibility(ProgressBar.GONE);
                });

                TaskHelper.execute(dateTimeSettingsTask);
            });
        }
    }

    private void updateDateTimeControls() {
        Activity parentActivity = getActivity();
        if (parentActivity != null) {
            updateHourFormatSelectionFromParams();
            updateClockSourceSelectionFromParams();
            updateDaylightSavingFromParams();
        }
    }

    private void setupOwnControls() {
        mSaveButton = getView().findViewById(R.id.buttonSave);
        mSaveButton.setOnClickListener(view -> saveDateTimeSettings());
        mSaveButton.setVisibility(View.VISIBLE);
        mProgressBar = getView().findViewById(R.id.progressBarDateTime);
    }

    private void saveDateTimeSettings() {
        if (mClientRadio != null) {
            mSaveButton.setVisibility(View.INVISIBLE);
            mProgressBar.setVisibility(View.VISIBLE);

            DateTimeNodesSenderTask task = new DateTimeNodesSenderTask(mClientRadio, mDateTimeParams);
            TaskHelper.execute(task);
        }
    }

    @Override
    protected List<NodeSysCapsClockSourceList.ListItem> getNodeClockSourceListItems() {
        if (mClockSourceList != null) {
            return mClockSourceList.getEntries();
        } else {
            return null;
        }
    }

    @Override
    protected List<NodeSysCapsUtcSettingsList.ListItem> getUTCTimeZoneList() {
        return mUTCTimeZoneList;
    }

    public void setUseRadio(Radio clientRadio) {
        mClientRadio = clientRadio;
    }

    private class DateTimeNodesSenderTask extends AsyncTask<Void, Integer, Void> {
        private Radio mRadio;
        private DateTimeParams mDateTimeParams;

        public DateTimeNodesSenderTask(Radio radio, DateTimeParams dateTimeParams) {
            mRadio = radio;
            mDateTimeParams = dateTimeParams;
        }

        @Override
        protected Void doInBackground(Void... params) {

            DateTimeNodesSender dateTimeSender = new DateTimeNodesSender(mRadio, false);
            dateTimeSender.setup(mDateTimeParams);

            mRadio = null;
            mDateTimeParams = null;

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            super.onPostExecute(aVoid);

            mSaveButton.setVisibility(View.VISIBLE);
            mProgressBar.setVisibility(View.GONE);
            displayMessage();
            MainApplication.getCurrentActivity().onBackPressed();
        }
    }

    private void displayMessage() {
        Toast.makeText(MainApplication.getCurrentActivity(), MainApplication.getCurrentActivity().getString(R.string.settings_saved), Toast.LENGTH_LONG).show();
    }
}
