package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.app.Activity;
import android.content.Intent;

import androidx.databinding.Observable;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;

import android.net.Uri;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.LayoutDecider;
import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.QobuzAlbumArtistDetailedInfo;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable.ContextMessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.ContextBrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.OAuthLoginEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.AmazonSignUpEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextMenuButtonClickedEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.FormFailedAirableEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.HideErrorMessageEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.HideKeyboardEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavRefreshEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavResultEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.PlayStationEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ResetFormManagerEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ShowLoadingProgressEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.navAirable.NavFormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseDataModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseManager;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.FragmentFactory;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IParentActivity;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseIrFragmentBinding;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

/**
 * Created by lsuhov on 18/10/2016.
 */

public class BrowseNavViewModel extends Observable.OnPropertyChangedCallback implements
        IConnectionStateListener, IRegisterLinkListener {
    private final String OAUTH_REDIRECT = "undok_airable";
    private final String OAUTH_REPLACE_SEQUENCE = ":return:";

    public ObservableBoolean showLoading = new ObservableBoolean(false);
    public ObservableBoolean showListview = new ObservableBoolean(false);
    public ObservableBoolean showNoConnection = new ObservableBoolean(false);
    public ObservableBoolean showNoBrowseAvailable = new ObservableBoolean(false);
    public ObservableBoolean showNoResult = new ObservableBoolean(false);
    public ObservableBoolean showSearchLayout = new ObservableBoolean(false);
    public ObservableBoolean showAmazonLoginLayout = new ObservableBoolean(false);
    public ObservableBoolean showTidalLoginLayout = new ObservableBoolean(false);
    public ObservableBoolean showQobuzLoginLayout = new ObservableBoolean(false);
    public ObservableBoolean showSaavnLoginLayout = new ObservableBoolean(false);
    public ObservableBoolean showGoTopButton = new ObservableBoolean(false);
    public ObservableBoolean showGoBottomButton = new ObservableBoolean(false);


    public ObservableField<String> searchTextValue = new ObservableField<>("");
    public ObservableBoolean showArtistAlbumDetailsInfoButton = new ObservableBoolean(false);
    public ObservableBoolean showRegisterLink = new ObservableBoolean(false);
    public ObservableField<String> registerLinkText = new ObservableField<>();
    public ObservableField<String> registerLinkUrl = new ObservableField<>();


    private Fragment mFragment;
    private BrowseIrFragmentBinding mBinding;
    private Activity mActivity;
    private NavBrowseAdapter mAdapter;

    private String mContextMenuDialogTag = "contexMenuDialog";
    NavBrowseDataModel mNavBrowseDataModel;

    public BrowseNavViewModel(Fragment fragment, BrowseIrFragmentBinding binding, Activity activity) {
        mFragment = fragment;
        mBinding = binding;
        mActivity = activity;
        mAdapter = new NavBrowseAdapter(mActivity);

        EventBus.getDefault().register(this);
        //trigger reset of FormManager when the ViewModel is recreated.
        EventBus.getDefault().post(new ResetFormManagerEvent());
        //TODO only temporary, we should not reset view when changing landscape to portrait, but as
        //TODO this is done, the context must be removed.
        ContextBrowseManager.getInstance().CloseContextDialog(false);

        mNavBrowseDataModel = NavBrowseManager.getInstance().getNavBrowseDataModel();

        NavFormManager.getInstance().addRegisterLinkListener(this);
    }

    void fragmentActivated() {
        NavBrowseManager.getInstance().navigateToCurrentList();

        ConnectionStateUtil.getInstance().addListener(this, false);

        removePropertyListeners();

        addPropertyListeners();

        setAlbumDetailInfoButtonVisibility();
    }

    private void addPropertyListeners() {
        mNavBrowseDataModel.artistAlbumDescription.addOnPropertyChangedCallback(this);
        mNavBrowseDataModel.releaseDate.addOnPropertyChangedCallback(this);

        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.addOnPropertyChangedCallback(this);
    }

    @Override
    public void onPropertyChanged(Observable sender, int propertyId) {
        if (sender == mNavBrowseDataModel.artistAlbumDescription || sender == mNavBrowseDataModel.releaseDate) {
            setAlbumDetailInfoButtonVisibility();

        } else if (sender == SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode) {
            onModeSwitched(SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.get());
        }
    }

    private void SetQobuzButtonInvisible() {
        showArtistAlbumDetailsInfoButton.set(false);
    }

    void fragmentDeactivated() {
        GuiUtils.hideKeyboard(mFragment.getActivity());
        ConnectionStateUtil.getInstance().removeListener(this);
        removePropertyListeners();
    }

    private void removePropertyListeners() {
        mNavBrowseDataModel.artistAlbumDescription.removeOnPropertyChangedCallback(this);
        mNavBrowseDataModel.releaseDate.removeOnPropertyChangedCallback(this);

        SpeakerDataManager.getInstance().getSpeakerDataModel().currentMode.removeOnPropertyChangedCallback(this);
    }

    public NavBrowseAdapter getAdapter() {
        return mAdapter;
    }

    public void setIsStopping(boolean isStopping) {
    }

    @Subscribe
    public void onShowLoadingProgress(ShowLoadingProgressEvent event) {
        if (!GuiUtils.isClosed(mFragment)) {
            mFragment.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showLoadingScreen();
                }
            });
        }
    }

    @Subscribe
    public void onNavigationResult(final NavResultEvent event) {

        if (!GuiUtils.isClosed(mFragment)) {
            mFragment.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    onNavigationImpl(event.result);
                }
            });
        }
    }

    @Subscribe
    public void onRefreshEventCompleted(NavRefreshEvent event) {
        NavBrowseManager.getInstance().refreshCurrentList(event.getNavId());
    }

    @Subscribe
    public void onFailedFormEventCompleted(FormFailedAirableEvent event) {
        showNoResultsLayout();
    }

    @Subscribe
    public void onHideKeyboardEventCompleted(HideKeyboardEvent event) {
        GuiUtils.hideKeyboard(mFragment.getView(), mFragment.getActivity());
    }

    private void onNavigationImpl(EIRNavigationResult result) {

        if (result == EIRNavigationResult.Success || result == EIRNavigationResult.TotalItemsNotRetrieved
                || result == EIRNavigationResult.AlreadyLoaded) {
            //showSearchLayout.set(NavBrowseManager.getInstance().searchIsAvailable());

            boolean shouldHaveSearch = NavBrowseManager.getInstance().searchIsAvailable();
            this.showSearchLayout.set(shouldHaveSearch);
            this.searchTextValue.set(shouldHaveSearch ? NavBrowseManager.getInstance().getSearch() : "");

            //trying to fix crash #1503, #1959, #1961
            RecyclerView recyclerView = mAdapter.getRecyclerView();
            if (recyclerView != null) {
                recyclerView.getRecycledViewPool().clear();
            }

            FirebaseCrashlytics.getInstance().log("BrowseNavViewModel onNavigationImpl");
            mAdapter.notifyDataSetChanged();
            showListViewLayout();

        } else {
            showNoResultsLayout();
        }
        EventBus.getDefault().post(new HideErrorMessageEvent());
    }

    private void setAlbumDetailInfoButtonVisibility() {
        if (mNavBrowseDataModel.artistAlbumDescription.get().isEmpty() && mNavBrowseDataModel.releaseDate.get().isEmpty() || isNapster()) {
            showArtistAlbumDetailsInfoButton.set(false);
        } else {
            showArtistAlbumDetailsInfoButton.set(true);
        }
    }

    private boolean isNapster() {
        return SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.AIRABLE_NAPSTER;
    }

    public void OnArtistAlbumInfoButton(View view) {

        Activity activity = mFragment.getActivity();

        QobuzAlbumArtistDetailedInfo.showBrowseDialogInfo(activity,
                mNavBrowseDataModel.artistAlbumDescription.get(),
                mNavBrowseDataModel.releaseDate.get());
    }

    public boolean search(String searchText) {
        if (!TextUtils.isEmpty(searchText)) {
            GuiUtils.hideKeyboard(mFragment.getActivity());

            NavBrowseManager.getInstance().search(searchText);
            return true;
        }
        return false;
    }

    private void showLoadingScreen() {
        showLoading.set(true);
        showNoResult.set(false);
        showListview.set(false);
        showNoConnection.set(false);
        showNoBrowseAvailable.set(false);
        showAmazonLoginLayout.set(false);
        showTidalLoginLayout.set(false);
        showQobuzLoginLayout.set(false);
        showSaavnLoginLayout.set(false);
        showGoTopButton.set(false);
        showGoBottomButton.set(false);
    }

    private void showNoConnectionLayout() {
        showNoConnection.set(true);
        showLoading.set(false);
        showNoResult.set(false);
        showListview.set(false);
        showNoBrowseAvailable.set(false);
        showAmazonLoginLayout.set(false);
        showTidalLoginLayout.set(false);
        showQobuzLoginLayout.set(false);
        showSaavnLoginLayout.set(false);
        showGoTopButton.set(false);
        showGoBottomButton.set(false);
    }

    private void showListViewLayout() {
        showListview.set(true);
        showNoConnection.set(false);
        showLoading.set(false);
        showNoResult.set(false);
        showNoBrowseAvailable.set(false);
        showAmazonLoginLayout.set(false);
        showTidalLoginLayout.set(false);
        showQobuzLoginLayout.set(false);
        showSaavnLoginLayout.set(false);
    }

    private void showNoResultsLayout() {
        showNoResult.set(true);
        showListview.set(false);
        showNoConnection.set(false);
        showLoading.set(false);
        showNoBrowseAvailable.set(false);
        showAmazonLoginLayout.set(false);
        showTidalLoginLayout.set(false);
        showQobuzLoginLayout.set(false);
        showSaavnLoginLayout.set(false);
        showGoTopButton.set(false);
        showGoBottomButton.set(false);
    }

    private void showAmazonLoginLayout() {
        showAmazonLoginLayout.set(true);
        showTidalLoginLayout.set(false);
        showQobuzLoginLayout.set(false);
        showSaavnLoginLayout.set(false);
        showNoResult.set(false);
        showListview.set(false);
        showNoConnection.set(false);
        showLoading.set(false);
        showNoBrowseAvailable.set(false);
        showGoTopButton.set(false);
        showGoBottomButton.set(false);

    }

    private void showTidalLoginLayout() {
        showTidalLoginLayout.set(true);
        showAmazonLoginLayout.set(false);
        showQobuzLoginLayout.set(false);
        showSaavnLoginLayout.set(false);
        showNoResult.set(false);
        showListview.set(false);
        showNoConnection.set(false);
        showLoading.set(false);
        showNoBrowseAvailable.set(false);
        showGoTopButton.set(false);
        showGoBottomButton.set(false);

    }

    private void showQobuzLoginLayout() {
        showQobuzLoginLayout.set(true);
        showTidalLoginLayout.set(false);
        showAmazonLoginLayout.set(false);
        showSaavnLoginLayout.set(false);
        showNoResult.set(false);
        showListview.set(false);
        showNoConnection.set(false);
        showLoading.set(false);
        showNoBrowseAvailable.set(false);
        showGoTopButton.set(false);
        showGoBottomButton.set(false);
    }

    private void showSaavnLoginLayout() {
        showSaavnLoginLayout.set(true);
        showQobuzLoginLayout.set(false);
        showTidalLoginLayout.set(false);
        showAmazonLoginLayout.set(false);
        showNoResult.set(false);
        showListview.set(false);
        showNoConnection.set(false);
        showLoading.set(false);
        showNoBrowseAvailable.set(false);
        showGoTopButton.set(false);
        showGoBottomButton.set(false);
    }

    @Subscribe
    public void onOAuthLoginEvent(final OAuthLoginEvent event) {
        if (getEventType(event) == OAuthLoginEvent.OAuthType.Amazon) {
            handleAmazonLogin(event);
        } else if (getEventType(event) == OAuthLoginEvent.OAuthType.Tidal) {
            handleTidalLogin(event);
        } else if (getEventType(event) == OAuthLoginEvent.OAuthType.Qobuz) {
            handleQobuzLogin(event);
        } else if (getEventType(event) == OAuthLoginEvent.OAuthType.SAAVN) {
            handleSaavnLogin(event);
        }

        if (event.mBrowseItemModel == null) {
            return;
        }


    }

    private void handleAmazonLogin(final OAuthLoginEvent event) {
        showAmazonLoginLayout();
        mBinding.amazonLayout.amazonLoginButton.setOnClickListener(view -> {
            FsLogger.log("Amazon Login button pressed", LogLevel.Info);
            if (mActivity == null) {
                FsLogger.log("Activity empty when trying to open Amazon Login ", LogLevel.Info);
                return;
            }
            String url = event.mBrowseItemModel.getArtwork();

            if (url.contains(OAUTH_REPLACE_SEQUENCE)) {
                FsLogger.log("Amazon Login OAuth browser ", LogLevel.Info);
                String urlOauth = event.mBrowseItemModel.getArtwork().replace(OAUTH_REPLACE_SEQUENCE, OAUTH_REDIRECT);
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlOauth));
                mActivity.startActivity(intent);

            } else {
                FsLogger.log("Amazon Login WebView authentication ", LogLevel.Info);
                Intent intent = new Intent(mActivity, AmazonLoginActivity.class);
                intent.putExtra("AmazonLoginURL", url);
                mActivity.startActivity(intent);
            }
        });
    }

    private void handleTidalLogin(final OAuthLoginEvent event) {
        showTidalLoginLayout();
        if (DokUiUtils.isLightTheme()) {
            mBinding.tidalLayout.tidalLogo.setImageDrawable(MainApplication.getContext().getResources().getDrawable(R.drawable.ic_tidal_black));
        } else {
            mBinding.tidalLayout.tidalLogo.setImageDrawable(MainApplication.getContext().getResources().getDrawable(R.drawable.ic_tidal_white));
        }

        mBinding.tidalLayout.tidalLoginButton.setOnClickListener(view -> {
            if (mActivity == null || event.mBrowseItemModel == null) {
                return;
            }

            String url = event.mBrowseItemModel.getArtwork().replace(OAUTH_REPLACE_SEQUENCE, OAUTH_REDIRECT);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            mActivity.startActivity(intent);
        });
    }

    private void handleQobuzLogin(final OAuthLoginEvent event) {
        showQobuzLoginLayout();

        if (DokUiUtils.isLightTheme()) {
            mBinding.qobuzLayout.qubuzLogo.setImageDrawable(MainApplication.getContext().getResources().getDrawable(R.drawable.ic_qobuz_np_black));
        } else {
            mBinding.qobuzLayout.qubuzLogo.setImageDrawable(MainApplication.getContext().getResources().getDrawable(R.drawable.ic_qobuz_np_white));
        }

        mBinding.qobuzLayout.qobuzLoginButton.setOnClickListener(view -> {
            if (mActivity == null || event.mBrowseItemModel == null) {
                return;
            }

            String url = event.mBrowseItemModel.getArtwork().replace(OAUTH_REPLACE_SEQUENCE, OAUTH_REDIRECT);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            mActivity.startActivity(intent);
        });
    }

    private void handleSaavnLogin(final OAuthLoginEvent event) {
        showSaavnLoginLayout();

        if (DokUiUtils.isLightTheme()) {
            mBinding.saavnLayout.saavnLogo.setImageDrawable(MainApplication.getContext().getResources().getDrawable(R.drawable.ic_saavn_np_black));
        } else {
            mBinding.saavnLayout.saavnLogo.setImageDrawable(MainApplication.getContext().getResources().getDrawable(R.drawable.ic_saavn_np_white));
        }

        mBinding.saavnLayout.saavnLoginButton.setOnClickListener(view -> {
            if (mActivity == null || event.mBrowseItemModel == null) {
                return;
            }

            String url = event.mBrowseItemModel.getArtwork();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            mActivity.startActivity(intent);
        });
    }

    private OAuthLoginEvent.OAuthType getEventType(final OAuthLoginEvent event) {
        if (event.mBrowseItemModel.getArtwork().contains("amazon")) {
            return OAuthLoginEvent.OAuthType.Amazon;
        } else if (event.mBrowseItemModel.getArtwork().contains("tidal")) {
            return OAuthLoginEvent.OAuthType.Tidal;
        } else if (event.mBrowseItemModel.getArtwork().contains("qobuz")) {
            return OAuthLoginEvent.OAuthType.Qobuz;
        } else if (event.mBrowseItemModel.getArtwork().contains("saavn")) {
            return OAuthLoginEvent.OAuthType.SAAVN;
        }

        return OAuthLoginEvent.OAuthType.Amazon;
    }

    @Subscribe
    public void onAmazonSignUpEvent(final AmazonSignUpEvent event) {
        showAmazonLoginLayout();

        if (event.mBrowseItemModel == null) {
            return;
        }

        mBinding.amazonLayout.amazonSignUp.setText(event.mBrowseItemModel.getName());

        mBinding.amazonLayout.amazonSignUp.setOnClickListener(view -> {
            if (mActivity == null) {
                return;
            }

            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(event.mBrowseItemModel.getArtwork()));
            mActivity.startActivity(browserIntent);
        });
    }

    @Subscribe
    public void onPlaybackNavigationCompleted(PlayStationEvent event) {
        switchToNowPlayingFragment();
    }

    @Subscribe
    public void onContextMenuButtonClicked(ContextMenuButtonClickedEvent event) {

        FirebaseCrashlytics.getInstance().log("BrowseNavViewModel onContextMenuButtonClicked");
        ContextBrowseManager.getInstance().clearAll();
        showContextMenuDialog(event.position, event.browseItemModel);

        event.dispose();
    }

    private void showContextMenuDialog(int browseItemPosition, BrowseItemModel browseItemModel) {
        FragmentManager fragmentManager = mFragment.getActivity().getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentByTag(mContextMenuDialogTag);

        ContextMenuDialogFragment dialogFragment;
        if (fragment == null) {
            dialogFragment = new ContextMenuDialogFragment();
        } else {
            dialogFragment = (ContextMenuDialogFragment) fragment;
        }

        ContextMessageManager.getInstance().updateSelectedNavItem(browseItemPosition, browseItemModel);
        //dialogFragment.setBrowseItemData(browseItemPosition, browseItemModel);

        dialogFragment.show(fragmentManager, mContextMenuDialogTag);
    }

    void onBackButton() {
        GuiUtils.hideKeyboard(mFragment.getActivity());

        NavBrowseManager.getInstance().navigateUp();
    }

    boolean isBackButtonHandledByFragment(boolean upButton) {
        // hide the "up" btn (always)
        if (upButton) {
            return false;
        }

        // use the default back behaviour if root level
        if (NavBrowseManager.getInstance().getNavDepth() == 0) {
            return false;
        }

        return true;
    }

    private void switchToNowPlayingFragment() {
        if (LayoutDecider.isTabletAndLandscape(mFragment.getActivity()))
            return;

        try {
            IParentActivity parentActivity = (IParentActivity) mFragment.getActivity();
            parentActivity.switchFragment(FragmentFactory.NOW_PLAYING_TAG);
        } catch (Exception e) {
        }
    }

    public void onModeSwitched(NodeSysCapsValidModes.Mode currentMode) {

        //TODO check navigation caps

        //TODO check the mode and show directly not supported messages
        FirebaseCrashlytics.getInstance().log("BrowseNavViewModel mode changed to " + currentMode);
        NavBrowseManager.getInstance().navigateToCurrentList();
    }

    public void dispose() {
        mFragment = null;
        mActivity = null;
        NavFormManager.getInstance().removeRegisterLinkListener();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onStateUpdate(ConnectionState newState) {
        switch (newState) {
            case DISCONNECTED:
            case DISCONNECTED_PIN_ERROR:
            case INVALID_SESSION:
            case NO_WIFI_OR_ETHERNET:
                FirebaseCrashlytics.getInstance().log("BrowseNavViewModel onStateUpdate - state: " + newState);
                showNoConnectionLayout();
                SetQobuzButtonInvisible();
                break;
            case CONNECTED_TO_RADIO:
                FirebaseCrashlytics.getInstance().log("BrowseNavViewModel onStateUpdate - state: " + newState);
                NavBrowseManager.getInstance().navigateToCurrentList();
                break;
        }
    }

    public void onRegisterLinkClick(View view) {
        openWebURL();
    }

    public void openWebURL() {
        String uri = "";
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        NodeSysCapsValidModes.Mode mode = radio.getModeSync();
        if (mode != null) {
            switch (mode) {
                case AIRABLE_QOBUZ:
                    uri = mFragment.getString(R.string.airable_qobuz_register_link);
                    break;
                case AIRABLE_DEEZER:
                    uri = mFragment.getString(R.string.airable_deezer_register_link);
                    break;
                case AIRABLE_TIDAL:
                    uri = mFragment.getString(R.string.airable_tidal_register_link);
                    break;
                case AIRABLE_NAPSTER:
                    uri = mFragment.getString(R.string.airable_napster_register_link);
                    break;
                case AIRABLE_ALDI:
                    uri = mFragment.getString(R.string.airable_aldi_register_link);
                    break;
                case AIRABLE_HOFER:
                    uri = mFragment.getString(R.string.airable_hofer_register_link);
                    break;

                default:
                    uri = registerLinkUrl.get();
                    break;
            }
        }
        if (!uri.isEmpty()) {
            Intent browseIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            if (browseIntent.resolveActivity(mFragment.getActivity().getPackageManager()) != null) {
                mFragment.startActivity(browseIntent);
            } else {
                mActivity.startActivity(browseIntent);
            }
        }
    }

    @Override
    public void setRegisterLinkVisibility(boolean visibility) {
        if (visibility) {
            if (mFragment == null) {
                return;
            }

            int stringId = SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.AIRABLE_QOBUZ ?
                    R.string.free_trial_caps : R.string.register_link;

            registerLinkText.set(mFragment.getString(stringId));
        }

        showRegisterLink.set(visibility);
    }

    @Override
    public void setRegisterLinkUrl(String url) {
        registerLinkUrl.set(url);
    }
}
