package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.di

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class ConnectivityAssistantScope

