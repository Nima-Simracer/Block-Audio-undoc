package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseItemParentViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseListItemParentBinding;

/**
 * Created by lsuhov on 06/11/2016.
 */

public class BrowseItemDirectoryDelegate extends RecyclerViewListItemDelegate {

    private int mBrowseType;

    public BrowseItemDirectoryDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseListItemParentBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_list_item_parent,
                parent, false);

        return new BrowseItemDirectoryViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(mBrowseType);

        BrowseItemModel mNavBrowseItemModel = browseManager.tryGetBrowseItemModel(position);

        BrowseItemDirectoryViewHolder parentViewHolder = (BrowseItemDirectoryViewHolder) holder;
        BrowseListItemParentBinding binding = parentViewHolder.mBinding;

        if ((mNavBrowseItemModel != null) && mNavBrowseItemModel.hasArtwork()) {
            Glide.with(parentViewHolder.itemView.getContext())
                    .load(mNavBrowseItemModel.getArtwork())
                    .into(binding.artworkInList);
        }

        BrowseItemParentViewModel viewModel = new BrowseItemParentViewModel(position, mNavBrowseItemModel, browseManager);
        binding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseItemDirectoryViewHolder itemParentViewHolder = (BrowseItemDirectoryViewHolder)holder;

        BrowseItemParentViewModel viewModel = itemParentViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            itemParentViewHolder.mBinding.setViewModel(null);
        }
    }

    private static class BrowseItemDirectoryViewHolder extends ListItemViewHolder {

        BrowseListItemParentBinding mBinding;

        BrowseItemDirectoryViewHolder(BrowseListItemParentBinding binding, BrowseItemDirectoryDelegate browseItemDirectoryDelegate) {
            super(binding.getRoot(), browseItemDirectoryDelegate);

            mBinding = binding;
        }
    }
}
