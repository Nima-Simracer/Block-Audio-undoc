package com.frontier_silicon.fsirc.dok2.setup.welcome;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import androidx.core.app.ActivityCompat;

import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.setup.EStateOfCheckingHeadlessSetup;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.listOfAP.ListOfAccessPointActivity;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.manualAPSelection.ManualAccessPointSelectionActivity;
import com.frontier_silicon.fsirc.dok2.setup.location.LocationAccessActivity;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;

/**
 * Created by nbalazs on 08/03/2018.
 */

public final class WelcomeActivityVM {

    private Activity mActivity;

    WelcomeActivityVM(Activity activity) {
        mActivity = activity;
        SetupManager.getInstance().setStateOfSetup(EStateOfCheckingHeadlessSetup.None);
    }

    public void onNextPressed() {
        if (PermissionsUtil.requestLocationPermission(mActivity, false)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NavigationHelper.goToActivity(mActivity, ManualAccessPointSelectionActivity.class);
            } else {
                NavigationHelper.goToActivity(mActivity, ListOfAccessPointActivity.class);
            }
        } else if (isPermissionDeniedByUserForApiLowerThanOreo()) {
            NavigationHelper.goToActivity(mActivity, ManualAccessPointSelectionActivity.class);
        } else {
            NavigationHelper.goToActivity(mActivity, LocationAccessActivity.class);
        }
    }

    private boolean isPermissionDeniedByUserForApiLowerThanOreo() {
        return ActivityCompat.shouldShowRequestPermissionRationale(mActivity, Manifest.permission.ACCESS_FINE_LOCATION) && Build.VERSION.SDK_INT < Build.VERSION_CODES.O;
    }
}
