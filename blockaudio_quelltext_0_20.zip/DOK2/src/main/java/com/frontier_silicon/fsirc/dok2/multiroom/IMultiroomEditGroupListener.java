package com.frontier_silicon.fsirc.dok2.multiroom;

public interface IMultiroomEditGroupListener {

    void onDeviceSelectionChanged(MultiroomEditGroupItemModel deviceItem, boolean isSelected);

}
