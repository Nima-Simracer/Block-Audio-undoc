package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseFormMultiselViewModel
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory
import com.frontier_silicon.fsirc.dok2.databinding.BrowseFormItemMultiselBinding

class BrowseFormItemMultiselDelegate(val browseType: Int): RecyclerViewListItemDelegate() {

    override fun onCreateViewHolder(parent: ViewGroup?): ListItemViewHolder {
        val layoutInflater = LayoutInflater.from(parent!!.context)

        val binding: BrowseFormItemMultiselBinding = DataBindingUtil.inflate(
            layoutInflater,
            R.layout.browse_form_item_multisel,
            parent, false
        )

        return BrowseFormItemMultieselViewHolder(binding, this)
    }

    override fun onBindViewHolder(
        holder: ListItemViewHolder?,
        position: Int,
        adapter: RecyclerView.Adapter<ListItemViewHolder>?
    ) {
        val formManager = BrowseManagerFactory.getFormManager(browseType)
        val formItem = formManager.getItemByPosition(position)

        val multisel = holder as BrowseFormItemMultieselViewHolder
        val viewModel = BrowseFormMultiselViewModel(position, formItem, mContext)
        multisel.binding.viewModel = viewModel

        multisel.binding.multiselItem.setOnClickListener {
            viewModel.onMultiSelItemCLicked()
        }

    }

    override fun onViewRecycled(holder: ListItemViewHolder?) {
        val viewHolder = holder as BrowseFormItemMultieselViewHolder
        val vm = viewHolder.binding.viewModel
        viewHolder.binding.viewModel = null
        vm?.let {
            vm.dispose()
        }
    }

    private class BrowseFormItemMultieselViewHolder (
       val binding: BrowseFormItemMultiselBinding,
       val delegate: RecyclerViewListItemDelegate?
    ) : ListItemViewHolder(binding.getRoot(), delegate)
}