package com.frontier_silicon.fsirc.dok2.sources;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes.Mode;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

public class SourceIconsResourceIdFactory {

    public static int getModeIconResId(SourceItemModel.CastApp castAppEnum) {
        int iconResId = -1;

        if (castAppEnum == SourceItemModel.CastApp.PlayMusic) {
            iconResId = R.drawable.ic_google_music_app;
        }
        if (castAppEnum == SourceItemModel.CastApp.Spotify) {
            iconResId = getSpotifyLogo();
        }
        if (castAppEnum == SourceItemModel.CastApp.TuneIn) {
            iconResId = R.drawable.ic_tunein_app;
        }
        if (castAppEnum == SourceItemModel.CastApp.NPROne) {
            iconResId = R.drawable.ic_nprone_app;
        }
        if (castAppEnum == SourceItemModel.CastApp.MoreApps) {
            iconResId = R.drawable.ic_more_dots;
        }
        return iconResId;
    }

    public static int getModeIconResId(Mode modeEnum) {
        int iconResId = R.drawable.ic_dynamicmode;

        if (modeEnum == NodeSysCapsValidModes.Mode.IR) {
            iconResId = R.drawable.ic_modes_internetradio;
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.Spotify) {
            iconResId = getSpotifyLogo();
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.FM) {
            iconResId = R.drawable.ic_modes_fmradio;
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.MP) {
            iconResId = R.drawable.ic_modes_musicplayer;
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.DAB) {
            iconResId = getDabLogo();
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.iPod) {
            iconResId = R.drawable.ic_modes_ipod;
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.AuxIn) {
            iconResId = R.drawable.ic_modes_auxin;
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.DMR) {
            iconResId = R.drawable.ic_modes_dmr;
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.Bluetooth) {
            iconResId = R.drawable.ic_bluetooth;
        }

        if (modeEnum == NodeSysCapsValidModes.Mode.Cast) {
            iconResId = R.drawable.ic_modes_cast;
        }

        if (modeEnum == Mode.AIRABLE_DEEZER) {
            if (DokUiUtils.isLightTheme()) {
                iconResId = R.drawable.ic_deezer_modes_black;
            } else {
                iconResId = R.drawable.ic_deezer_modes_white;
            }
        }

        if (modeEnum == Mode.AIRABLE_NAPSTER) {
            iconResId = R.drawable.ic_modes_napster;
        }

        if (modeEnum == Mode.AIRABLE_QOBUZ) {
            iconResId = R.drawable.ic_modes_qobuz;
        }

        if (modeEnum == Mode.AIRABLE_TIDAL) {
            if (DokUiUtils.isLightTheme()) {
                iconResId = R.drawable.ic_modes_tidal;
            } else {
                iconResId = R.drawable.ic_modes_tidal_white;
            }
        }

        if (modeEnum == Mode.AIRABLE_ALDI) {
            iconResId = R.drawable.ic_modes_aldi;
        }

        if (modeEnum == Mode.AIRABLE_HOFER) {
            iconResId = R.drawable.ic_modes_hofer;
        }

        if (modeEnum == Mode.AIRABLE_AMAZON_MP) {
            if (DokUiUtils.isLightTheme()) {
                iconResId = R.drawable.ic_modes_amazon_indigo;
            } else {
                iconResId = R.drawable.ic_modes_amazon_white;
            }
        }

        if (modeEnum == Mode.AIRABLE_CALM) {
            if (DokUiUtils.isLightTheme()) {
                iconResId = R.drawable.ic_modes_calm_black;
            } else {
                iconResId = R.drawable.ic_modes_calm_white;
            }
        }

        if (modeEnum == Mode.AIRABLE_SAAVN) {
            if (DokUiUtils.isLightTheme()) {
                iconResId = R.drawable.ic_modes_saavn_black;
            } else {
                iconResId = R.drawable.ic_modes_saavn_white;
            }
        }

        if (modeEnum == Mode.AIRABLE_KLASSIK) {
            if (DokUiUtils.isLightTheme()) {
                iconResId = R.drawable.ic_modes_klassik_black;
            } else {
                iconResId = R.drawable.ic_modes_klassik_white;
            }
        }

        if (modeEnum == Mode.CD) {
            iconResId = R.drawable.ic_cd_source;
        }

        if (modeEnum == Mode.SD) {
            iconResId = R.drawable.ic_sd_source;
        }

        return iconResId;
    }

    private static int getSpotifyLogo() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_spotify_green;
        } else {
            return R.drawable.ic_spotify_white_modes;
        }
    }

    private static int getDabLogo() {
        if (DokUiUtils.isLightTheme()) {
            return R.drawable.ic_dab_light;
        } else {
            return R.drawable.ic_dab_white_modes;
        }
    }

    public static boolean modeHasIconWithColor(Mode modeEnum) {
        if (modeEnum == null) {
            return false;
        }

        switch (modeEnum) {
            case AIRABLE_DEEZER:
            case AIRABLE_ALDI:
            case AIRABLE_AMAZON_MP:
            case AIRABLE_HOFER:
            case AIRABLE_QOBUZ:
            case AIRABLE_TIDAL:
            case AIRABLE_NAPSTER:
            case AIRABLE_CALM:
            case AIRABLE_KLASSIK:
            case AIRABLE_SAAVN:
            case Spotify:
            case DAB:

                return true;
            default:
                return false;
        }
    }
}
