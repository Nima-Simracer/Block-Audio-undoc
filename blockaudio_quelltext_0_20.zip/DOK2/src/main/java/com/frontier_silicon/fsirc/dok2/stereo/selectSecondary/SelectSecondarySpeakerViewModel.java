package com.frontier_silicon.fsirc.dok2.stereo.selectSecondary;

import android.app.Activity;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.graphics.drawable.BitmapDrawable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.fsirc.dok2.widgets.DividerItemDecoration;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 06/08/2017.
 */

public class SelectSecondarySpeakerViewModel implements IMultiroomGroupingListener {

    public ObservableField<String> primarySpeakerName = new ObservableField<>();
    public ObservableField<BitmapDrawable> primarySpeakerImage = new ObservableField<>();
    public ObservableBoolean showEmptyListMessage = new ObservableBoolean(false);

    private StereoItemModel mPrimaryStereoItemModel;
    private Activity mActivity;
    private RecyclerView mRecyclerView;
    private SelectSecondarySpeakerAdapter mAdapter;

    public SelectSecondarySpeakerViewModel(StereoItemModel primaryStereoItemModel, Activity activity, RecyclerView recyclerView) {
        mPrimaryStereoItemModel = primaryStereoItemModel;
        mActivity = activity;
        mRecyclerView = recyclerView;

        if (mPrimaryStereoItemModel.deviceModel == null) {
            return;
        }

        init();
    }

    private void init() {
        updatePrimarySpeakerName();
        updatePrimarySpeakerImage();

        initList();
    }

    private void initList() {
        mAdapter = new SelectSecondarySpeakerAdapter(mPrimaryStereoItemModel, mActivity);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity.getApplicationContext());
        DividerItemDecoration itemDecoration = new DividerItemDecoration(mActivity.getApplicationContext(), LinearLayoutManager.VERTICAL);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.addItemDecoration(itemDecoration);
        mRecyclerView.setAdapter(mAdapter);
    }

    private void updatePrimarySpeakerName() {
        MultiroomDeviceModel deviceModel = mPrimaryStereoItemModel.deviceModel;

        primarySpeakerName.set(deviceModel.mRadio.getFriendlyName());
    }

    private void updatePrimarySpeakerImage() {
        DokUiUtils.setImageIntoObservableDrawable(primarySpeakerImage,
                mPrimaryStereoItemModel.deviceModel.mRadio, mActivity);
    }

    public void onResume() {
        MultiroomGroupManager.getInstance().addListener(this);

        updateStereoList();
    }

    public void onPause() {
        MultiroomGroupManager.getInstance().removeListener(this);
    }

    @Override
    public void onGroupingUpdate() {
        if (mActivity == null) {
            return;
        }

        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mActivity == null) {
                    return;
                }

                updateStereoList();
            }
        });
    }

    public void updateStereoList() {
        List<StereoItemModel> stereoItemModels = StereoManager.getInstance().getStereoList();
        List<StereoItemModel> filteredStereoItemModels = new ArrayList<>();
        Radio primaryRadio = mPrimaryStereoItemModel.deviceModel.mRadio;

        for (StereoItemModel stereoItemModel : stereoItemModels) {
            if (!stereoItemModel.isSpeaker()) {
                continue;
            }

            Radio otherRadio = stereoItemModel.deviceModel.mRadio;

            if (otherRadio.equals(primaryRadio)) {
                continue;
            }

            if (!otherRadio.getMultiroomVersion().equals(primaryRadio.getMultiroomVersion())) {
                continue;
            }

            if (!TextUtils.isEmpty(otherRadio.getMultichannelCompatibilityId()) &&
                    !otherRadio.getMultichannelCompatibilityId().equals(primaryRadio.getMultichannelCompatibilityId())) {
                continue;
            }

            filteredStereoItemModels.add(stereoItemModel);
        }

        mAdapter.swapItems(filteredStereoItemModels);

        showEmptyListMessage.set(filteredStereoItemModels.size() == 0);
    }


    public void onPlayAlertToneClicked(View v) {
        StereoManager.getInstance().playAlertTone(mPrimaryStereoItemModel.deviceModel.mRadio);
    }

    public void dispose() {
        mPrimaryStereoItemModel = null;
        mActivity = null;
    }
}
