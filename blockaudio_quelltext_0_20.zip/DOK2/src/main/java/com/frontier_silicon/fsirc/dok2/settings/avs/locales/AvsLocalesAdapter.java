package com.frontier_silicon.fsirc.dok2.settings.avs.locales;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Node.BaseAvsValidLocales;
import com.frontier_silicon.fsirc.dok2.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mnisipeanu on 05/06/2018.
 */

public class AvsLocalesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<BaseAvsValidLocales.ListItem> items = new ArrayList<>();
    private OnTouchListener listener;
    private long selectedItem;

    public interface OnTouchListener {
        void onLayoutClick(BaseAvsValidLocales.ListItem item);
    }

    public void setSelected(long selectedKey){
        this.selectedItem = selectedKey;
        this.notifyDataSetChanged();
    }

    public AvsLocalesAdapter(OnTouchListener listener) {
        this.listener = listener;
    }

    public void swapItems(List<BaseAvsValidLocales.ListItem> langItems) {
        if (items.size() > 0) {
            items.clear();
        }
        items.addAll(langItems);
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView text1;
        private ImageView imageViewSelected;
        private BaseAvsValidLocales.ListItem rowData;

        public ViewHolder(View itemView) {
            super(itemView);

            text1 = itemView.findViewById(R.id.text1);
            imageViewSelected = itemView.findViewById(R.id.imageViewSelected);

            itemView.setOnClickListener(v -> listener.onLayoutClick(rowData));
        }

        public void setRow(BaseAvsValidLocales.ListItem item, final int position) {
            rowData = item;
            text1.setText(String.format("%s (%s)", item.getName(), item.getCode()));

            if (item.getKey() == selectedItem) {
                imageViewSelected.setVisibility(View.VISIBLE);
            } else {
                imageViewSelected.setVisibility(View.INVISIBLE);
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View v;
        v = inflater.inflate(R.layout.avs_language_list_item, parent, false);
        viewHolder = new ViewHolder(v);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        BaseAvsValidLocales.ListItem item = items.get(position);

        ((ViewHolder) holder).setRow(item, position);
    }
}
