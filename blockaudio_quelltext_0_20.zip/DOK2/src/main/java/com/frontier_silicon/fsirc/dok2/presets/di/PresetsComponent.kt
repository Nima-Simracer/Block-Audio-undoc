package com.frontier_silicon.fsirc.dok2.presets.di

import com.frontier_silicon.fsirc.dok2.presets.IPresetsControlListener
import com.frontier_silicon.fsirc.dok2.presets.PresetsFragment
import dagger.BindsInstance
import dagger.Subcomponent

@PresetsScope
@Subcomponent(modules = [PresetsModule::class])
interface PresetsComponent {

    @Subcomponent.Builder
    interface Builder {

        @BindsInstance
        fun presetsModule(listener: IPresetsControlListener): Builder
        fun build() : PresetsComponent
    }

    fun inject(fragment: PresetsFragment)
}