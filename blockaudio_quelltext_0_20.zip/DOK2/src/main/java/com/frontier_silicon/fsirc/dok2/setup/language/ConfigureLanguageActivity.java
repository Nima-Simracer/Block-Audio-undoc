package com.frontier_silicon.fsirc.dok2.setup.language;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SetupConfigureLanguageActivityBinding;
import com.frontier_silicon.fsirc.dok2.settings.language.ILanguageSettingClickListener;
import com.frontier_silicon.fsirc.dok2.settings.language.LanguageArrayAdapter;
import com.frontier_silicon.fsirc.dok2.settings.language.LanguageItemModel;
import com.frontier_silicon.fsirc.dok2.settings.language.LanguageUtil;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by nbalazs on 19/03/2018.
 *
 */

public class ConfigureLanguageActivity extends SetupActivityBase implements ILanguageSettingClickListener {

    private SetupConfigureLanguageActivityBinding mBinding;

    private LanguageArrayAdapter mListAdapter;

    private LanguageItemModel mLanguageItemModel;

    private List<LanguageItemModel> mListOfSupportedLanguages;

    private LanguageUtil languageUtil;
    private ConfigureLanguageActivityVM mViewModel;
    private LanguageItemModel autoDetectedLanguage;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.setup_configure_language_activity);

        mViewModel = new ConfigureLanguageActivityVM(this);

        mBinding.setViewModel(mViewModel);

        configureToolbarWithExitButton(R.string.undok_language);

        init();
    }

    private void init() {
        languageUtil = new LanguageUtil(SetupManager.getInstance().getCurrentRadio());
        mListOfSupportedLanguages = SetupManager.getInstance().getLanguageList();
        if (mListOfSupportedLanguages == null) {
            mListOfSupportedLanguages = new ArrayList<>();
        }

        mListAdapter = new LanguageArrayAdapter(this, R.layout.language_settings_list_item, R.id.text1, mListOfSupportedLanguages, this);
        mBinding.languagesAvailableListView.setAdapter(mListAdapter);

        // preset default language in list
        String phoneLanguage = Locale.getDefault().getDisplayLanguage();
        setAutoLanguage(phoneLanguage);
    }

    @Override
    protected void onStart() {
        super.onStart();
        enableRadioConnectionCallbackAndWiFiMonitor();
    }

    @Override
    public void onListItemClick(LanguageItemModel item) {
        mLanguageItemModel = item;
        updateLanguageList(item);
    }

    public final void saveLanguage() {
        if (mViewModel.isDetectAutomaticallyLanguageChacked.get()) {
            if (autoDetectedLanguage != null) {
                languageUtil.setLanguage(autoDetectedLanguage.mKeyId, null);
                updateLanguageList(autoDetectedLanguage);
                SetupManager.getInstance().setLanguageList(mListOfSupportedLanguages);
            }
        } else {

            if (mLanguageItemModel != null) {
                languageUtil.setLanguage(mLanguageItemModel.mKeyId, null);
                updateLanguageList(mLanguageItemModel);
                SetupManager.getInstance().setLanguageList(mListOfSupportedLanguages);
            }
        }
    }

    private void updateLanguageList(LanguageItemModel item)
    {
        try {
            if (item != null && mListAdapter != null) {
                for (LanguageItemModel lItem : mListOfSupportedLanguages) {
                    lItem.mIsSet = lItem.mKeyId == item.mKeyId;
                }
                mListAdapter.notifyDataSetChanged();
            }
        } catch (Exception ignored) {}
    }

    public LanguageItemModel setAutoLanguage(String phoneLanguage) {
        if (phoneLanguage.equals("Deutsch")) {
            phoneLanguage = "German";
        }

        for (LanguageItemModel lItem : mListOfSupportedLanguages) {
            if (lItem.mName.equalsIgnoreCase(phoneLanguage)) {

                mViewModel.detectedLanguage.set(lItem.mName);
                autoDetectedLanguage = lItem;
                updateLanguageList(lItem);

                return lItem;
            }
        }

        return null;
    }
}
