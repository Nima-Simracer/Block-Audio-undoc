package com.frontier_silicon.fsirc.dok2.settings.language;

/**
 * Created by hcostescu on 17/01/17.
 */

public class LanguageItemModel {
    public String mName;
    public boolean mIsSet;
    public boolean mIsProgressVisible;
    public long mKeyId;

    public LanguageItemModel(String name, boolean isSet, boolean isProgressVisible, long keyId) {
        mName = name;
        mIsSet = isSet;
        mKeyId = keyId;
        mIsProgressVisible = isProgressVisible;
    }
}
