package com.frontier_silicon.fsirc.dok2.setup;

import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoFriendlyName;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 4/14/2015.
 */
public class GetRadioFriendlyNameTask extends AsyncTask<Void, Integer, String> {
    List<SetupManager.IGetFriendlyNameAsync> mGetFriendlyNameInterfaces = new ArrayList<>();

    GetRadioFriendlyNameTask(SetupManager.IGetFriendlyNameAsync getFriendlyNameInterface) {
        setInterfaceListener(getFriendlyNameInterface);
    }

    @Override
    protected String doInBackground(Void... params) {
        return getRadioFriendlyNameFromDeviceSync();
    }

    @Override
    protected void onPostExecute(String friendlyName) {
        SetupManager.getInstance().setFriendlyName(friendlyName);

        for (int i = 0; i < mGetFriendlyNameInterfaces.size(); i++) {
            SetupManager.IGetFriendlyNameAsync friendlyNameInterface = mGetFriendlyNameInterfaces.get(i);
            friendlyNameInterface.onFriendlyNameRetrieved(friendlyName);
        }

        mGetFriendlyNameInterfaces.clear();
        SetupManager.getInstance().removeFriendlyNameTask();
    }

    public void setInterfaceListener(SetupManager.IGetFriendlyNameAsync getFriendlyNameInterface) {
        if (getFriendlyNameInterface != null)
            mGetFriendlyNameInterfaces.add(getFriendlyNameInterface);
    }

    public String getRadioFriendlyNameFromDeviceSync() {
        String radioName = "";
        Radio radio = SetupManager.getInstance().getCurrentRadio();
        if (radio != null) {
            NodeSysInfoFriendlyName nameNode = (NodeSysInfoFriendlyName) radio.
                    nodeSyncGetter(NodeSysInfoFriendlyName.class, true).get();

            if (nameNode != null)
                radioName = nameNode.getValue();
        }

        return radioName;
    }
}
