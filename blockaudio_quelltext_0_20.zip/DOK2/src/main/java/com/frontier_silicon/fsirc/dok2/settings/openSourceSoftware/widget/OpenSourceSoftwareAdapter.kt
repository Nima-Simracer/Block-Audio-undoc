package com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.widget

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.databinding.OpenSourceListItemBinding
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.IOnItemSelected
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.OpenSourceSoftwareModel

class OpenSourceSoftwareAdapter(val listener: IOnItemSelected): RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var openSourceLibraries: ArrayList<OpenSourceSoftwareModel> = ArrayList()

    fun swapItems(list: List<OpenSourceSoftwareModel>) {
        openSourceLibraries.clear()
        openSourceLibraries.addAll(list)
        notifyDataSetChanged()
    }

      inner class  OpenSourceViewHolder(val binding: OpenSourceListItemBinding): RecyclerView.ViewHolder(binding.root) {

        fun loadData(pos: Int) {
            val model = openSourceLibraries[pos]
            binding.libraryName.text = model.name

            if (model.selectable) {
                binding.rightImageIcon.visibility = View.VISIBLE
                binding.cardView.setOnClickListener {
                    listener?.let {
                        it.onItemSelected(pos)
                    }
                }
            } else {
                binding.rightImageIcon.visibility = View.GONE
            }

            binding.licenseType.text = model.license
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
       var binding = DataBindingUtil.inflate<OpenSourceListItemBinding>(LayoutInflater.from(parent.context), R.layout.open_source_list_item, parent, false)
        return  OpenSourceViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as OpenSourceViewHolder).loadData(position)
    }

    override fun getItemCount(): Int {
        return openSourceLibraries.count()
    }

}