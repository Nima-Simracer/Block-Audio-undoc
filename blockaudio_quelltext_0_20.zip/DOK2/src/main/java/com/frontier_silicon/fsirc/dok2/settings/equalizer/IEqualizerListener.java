package com.frontier_silicon.fsirc.dok2.settings.equalizer;

import java.util.ArrayList;

public interface IEqualizerListener {

	void onEqualizerPresetsUpdate(ArrayList<EqualizerItemModel> eqList);
	
}
