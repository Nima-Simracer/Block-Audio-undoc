package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by hcostescu on 11/19/2016.
 */

public class ReleaseDate {
    private final String message;
    public ReleaseDate(String message)
    {
        this.message = message;
    }
    public String getMessage()
    {return message;}
}
