package com.frontier_silicon.fsirc.dok2.settings.account;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.FsdcaMainActivityBinding;
import com.frontier_silicon.fsirc.dok2.settings.account.addDevice.FSDCAAddDeviceActivity;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by cvladu on 27/02/2018.
 */

public class FSDCAMainViewModel implements IFSDCAAuthenticationStatus {
    private static final String URL_TO_OPEN_IN_WEBVIEW = "URL_TO_OPEN_IN_WEBVIEW";

    private FSDCAEndpoints endpoints = new FSDCAEndpoints();
    private FsdcaMainActivityBinding mBinding = null;
    private Activity mActivity = null;
    private FSAuthManager mAuthManager = FSAuthManager.getInstance();
    private long mPostDelayedId;
    private ProgressDialog mProgressDialog;

    public FSDCAMainViewModel(FsdcaMainActivityBinding binding, Activity activity) {
        mBinding = binding;
        mActivity = activity;
    }

    public void loadUserDataFromServer() {
        mAuthManager.getUser(data -> {
            if (mBinding == null) {
                return;
            }
            
            try {
                JSONObject attributes = data.getJSONObject("data").getJSONObject("attributes");

                mBinding.userName.setText(attributes.getString("name"));
                mBinding.userEmail.setText(attributes.getString("email"));

            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public void onResume() {
        FSAuthManager.getInstance().setAuthenticationListener(this);
    }


    public void onEditButtonClicked(View view) {
        goToWebView(endpoints.getMyAccountUrl());
    }

    public void onAddDeviceClicked(View view) {
        NavigationHelper.goToActivity(mActivity, FSDCAAddDeviceActivity.class,
                NavigationHelper.AnimationType.SlideToLeft, false);
    }

    public void onMyDevicesClicked(View view) {
        goToWebView(endpoints.getMyDevicesUrl());
    }

    public void onFAQClicked(View view) {
        goToWebView(endpoints.getFAQUrl());
    }

    private void goToWebView(final String url) {
        startProgressDialogWithDelay();

        FSAuthManager.getInstance().getToken(new FSAuthManager.OnToken() {
            @Override
            public void onToken(OAuthToken token) {
                stopProgressDialog();

                Bundle bundle = new Bundle();
                bundle.putString(URL_TO_OPEN_IN_WEBVIEW, url);

                NavigationHelper.goToActivity(mActivity, AccountWebviewActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
            }

            @Override
            public void onFailed(FSAuthManager.Error error) {
                Log.d("FsAuthManager", error.description);
            }
        });
    }

    public void onLogoutClicked(View view) {
        mAuthManager.logout();
    }


    @Override
    public void notAuthenticated() {
        NavigationHelper.goToActivityClearingCurrentStack(MainApplication.getCurrentActivity(), FSDCALoginActivity.class,
                NavigationHelper.AnimationType.SlideToRight);
    }

    private void startProgressDialogWithDelay() {
        Runnable runnable = () ->
            displayProgressDialog();

        mPostDelayedId = DelayedPostsManager.getInstance().registerNewCallbackID();
        DelayedPostsManager.getInstance().postDelayed(runnable, mPostDelayedId, 1000);

    }

    private void stopProgressDialog() {
        DelayedPostsManager.getInstance().removeCallbackId(mPostDelayedId);

        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }

    private void displayProgressDialog() {
        if (!DokUiUtils.isDestroyed(mActivity)) {
            mProgressDialog = new ProgressDialog(mActivity);
            mProgressDialog.setMessage(mActivity.getString(R.string.please_wait));
            mProgressDialog.setIndeterminate(true);
            mProgressDialog.show();
        }
    }

    public void onPause() {
        FSAuthManager.getInstance().setAuthenticationListener(null);
    }

    public void dispose() {
        mBinding = null;
        mActivity = null;
        endpoints = null;
    }

}
