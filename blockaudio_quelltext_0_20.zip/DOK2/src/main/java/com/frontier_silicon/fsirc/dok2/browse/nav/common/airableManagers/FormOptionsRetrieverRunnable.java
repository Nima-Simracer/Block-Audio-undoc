package com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.UnifiedFormOptionsListItem;

import java.util.List;

public abstract class FormOptionsRetrieverRunnable implements Runnable {

    public interface INavFormOptionRetrieverListener {
        void onNavFormOptionRetrieved(List<UnifiedFormOptionsListItem> listItems);
    }

    protected Radio mRadio;
    protected INavFormOptionRetrieverListener mListener;

    public FormOptionsRetrieverRunnable(Radio radio, INavFormOptionRetrieverListener listener) {
        mRadio = radio;
        mListener = listener;
    }

    protected void sendNavListToListener(List<UnifiedFormOptionsListItem> listItems) {
        if (mListener != null) {
            mListener.onNavFormOptionRetrieved(listItems);
        }
    }

    protected void dispose() {
        mRadio = null;
        mListener = null;
    }
}
