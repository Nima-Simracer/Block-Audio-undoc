package com.frontier_silicon.fsirc.dok2.browse.nav.events;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;

/**
 * Created by lsuhov on 23/11/2016.
 */

public class ContextMenuButtonClickedEvent {
    public int position;
    public BrowseItemModel browseItemModel;

    public ContextMenuButtonClickedEvent(int position, BrowseItemModel browseItemModel) {
        this.position = position;
        this.browseItemModel = browseItemModel;
    }

    public void dispose() {
        browseItemModel = null;
    }
}
