package com.frontier_silicon.fsirc.dok2.setup.clock;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.databinding.BindingAdapter;
import androidx.databinding.InverseBindingAdapter;
import androidx.databinding.InverseBindingListener;
import androidx.databinding.InverseBindingMethod;
import androidx.databinding.InverseBindingMethods;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;

import com.frontier_silicon.fsirc.dok2.BR;

/**
 * Created by nbalazs on 20/03/2018.
 */

@InverseBindingMethods({
        @InverseBindingMethod(type = Spinner.class, attribute = "android:selectedItemPosition")
})
@SuppressWarnings("unused")
public class SpinnerData extends BaseObservable{
    public final String[] values;

    private String currentValue;

    private Integer selectedValuePosition;

    public interface IOnDataChangedListener {
        void onDataChanged(Integer position, String currentValue);
    }

    SpinnerData(String[] values) {
        this.values = values;
    }

    @Bindable
    public String getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(String currentValue) {
        this.currentValue = currentValue;
        notifyPropertyChanged(BR.currentValue);
    }

    @Bindable
    public Integer getSelectedValuePosition() {
        return selectedValuePosition;
    }

    public void setSelectedValuePosition(Integer selectedValuePosition) {
        this.selectedValuePosition = selectedValuePosition;
        currentValue = values[selectedValuePosition];
        notifyPropertyChanged(BR.selectedValuePosition);
    }

    @BindingAdapter("selectedItemPositionAttrChanged")
    public void setSelectedItemPositionListener(Spinner view, final InverseBindingListener selectedItemPositionChangeListener) {
        if (selectedItemPositionChangeListener == null) {
            view.setOnItemSelectedListener(null);
        } else {
            view.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    selectedItemPositionChangeListener.onChange();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }

    @InverseBindingAdapter(attribute = "selectedItemPosition")
    public Integer getSelectedItemPosition(Spinner spinner) {
        return spinner.getSelectedItemPosition();
    }
}
