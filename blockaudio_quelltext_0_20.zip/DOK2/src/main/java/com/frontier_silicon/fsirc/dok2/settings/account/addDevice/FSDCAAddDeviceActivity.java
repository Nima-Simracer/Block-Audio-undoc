package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.FsdcaAddSpeakersActivityBinding;


/**
 * Created by cvladu on 28/02/2018.
 */

public class FSDCAAddDeviceActivity extends UndokActivityBase {
    private FsdcaAddSpeakersActivityBinding mBinding;
    private FSDCAAddDeviceViewModel mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.fsdca_add_speakers_activity);
        mViewModel = new FSDCAAddDeviceViewModel(getLifecycle(), mBinding);
        mBinding.setViewModel(mViewModel);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.account_management);


        setupControls();
        mBinding.noItemsInTheList.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.no_compatible_device_found, false));
    }

    @Override
    protected void onResume() {
        super.onResume();
        mViewModel.onResume();
    }

    private void setupControls() {
        mBinding.listOfSpeakers.setLayoutManager(new LinearLayoutManager(this));
        mBinding.listOfSpeakers.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        mBinding.listOfSpeakers.setAdapter(mViewModel.getAdapter());

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mViewModel != null) {
            mViewModel.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }
    }

}
