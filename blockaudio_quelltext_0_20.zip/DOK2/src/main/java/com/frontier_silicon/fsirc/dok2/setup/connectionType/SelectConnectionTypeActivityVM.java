package com.frontier_silicon.fsirc.dok2.setup.connectionType;

import android.app.Activity;
import androidx.databinding.ObservableField;

import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.connectionType.ethernet.ConfigureEthernetActivity;
import com.frontier_silicon.fsirc.dok2.setup.connectionType.wifi.ConfigureWiFiActivity;
import com.frontier_silicon.fsirc.dok2.setup.connectionType.wps.ConfigureWPSActivity;

/**
 * Created by nbalazs on 08/03/2018.
 *
 */

public final class SelectConnectionTypeActivityVM {

    private Activity mActivity;
    
    SelectConnectionTypeActivityVM(Activity activity) {
        mActivity = activity;
    }
    
    public ObservableField<Boolean> isEthernetSupported = new ObservableField<>(SetupManager.getInstance().getEthernetIsSupported());

    public void onWifiSelected() {
        NavigationHelper.goToActivity(mActivity, ConfigureWiFiActivity.class);
    }

//    public void onWPSSelected() {
//        NavigationHelper.goToActivity(mActivity, ConfigureWPSActivity.class);
//    }

    public void onEthernetSelected() {
        NavigationHelper.goToActivity(mActivity, ConfigureEthernetActivity.class);
    }

    public void onBackPressed() {
        mActivity.onBackPressed();
    }
}
