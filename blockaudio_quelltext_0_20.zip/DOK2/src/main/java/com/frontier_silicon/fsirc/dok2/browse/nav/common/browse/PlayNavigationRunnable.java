package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavActionSelectItem;
import com.frontier_silicon.NetRemoteLib.Radio.ErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.NetRemoteLib.Radio.nodeCommunication.NodeSyncSetter;
import com.frontier_silicon.components.common.RadioNavigationUtil;

/**
 * Created by lsuhov on 15/02/2018.
 *
 * On IR2.13 we need to wait for nav.status to become ready before being allowed to initiate play
 */

public class PlayNavigationRunnable implements Runnable {

    private Long mKey;
    private Radio mRadio;
    private IPlayNavigationListener mListener;

    public PlayNavigationRunnable(Long key, Radio radio, IPlayNavigationListener listener) {
        mKey = key;
        mRadio = radio;
        mListener = listener;
    }

    @Override
    public void run() {

        RadioNavigationUtil.waitForNavStatusReady(mRadio);

        NodeSyncSetter nodeSyncSetter = mRadio.nodeSyncSetter(new NodeNavActionSelectItem(mKey));
        boolean success = nodeSyncSetter.set();

        if (!success && nodeSyncSetter.mErrorResponse.getFSStatus() == ErrorResponse.FSStatusCode.FS_TRY_AGAIN) {
            RadioNavigationUtil.waitForNavStatusReady(mRadio);
            success = mRadio.nodeSyncSetter(new NodeNavActionSelectItem(mKey)).set();
        }

        sendPlayResultOnMainThread(success);
    }

    private void sendPlayResultOnMainThread(boolean success) {
        NetRemote.getMainThreadExecutor().execute(() -> {
            if (mListener != null) {
                mListener.onPlayInitiationResult(success);
            }

            dispose();
        });
    }

    private void dispose() {
        mRadio = null;
        mListener = null;
    }
}
