package com.frontier_silicon.fsirc.dok2.connectedSpeaker

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener
import com.frontier_silicon.NetRemoteLib.Node.BaseNavAmazonMpLoginComplete
import com.frontier_silicon.NetRemoteLib.Node.NodeNavAmazonMpLoginComplete
import com.frontier_silicon.NetRemoteLib.Node.NodeNavLoginComplete
import com.frontier_silicon.NetRemoteLib.Radio.Radio
import com.frontier_silicon.components.NetRemoteManager
import com.frontier_silicon.components.common.RadioNodeUtil
import com.frontier_silicon.fsirc.dok2.RemoteConfigModel.RemoteConfigUtils
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseManager
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences
import com.frontier_silicon.loggerlib.FsLogger
import com.frontier_silicon.loggerlib.LogLevel

class ConnectedSpeakerViewModel : ViewModel(), IRadioDiscoveryListener {
    companion object {
        const val REDIRECT_URL = "undokairable://auth_response"
        const val OKTIV_PACKAGE= "com.frontiersmart.oktiv"
    }

      var shouldShowOktivPromo = MutableLiveData<Boolean>(false)
        init {
            trySendSmartRadioNumberEvent()
            trySendMoreThan1VeniceXDevices()
        }
    fun setLoginCompleteNode() {
        var radio = NetRemoteManager.getInstance().currentRadio

        radio?.let { radio ->
            radio.getCurrentModeAsListItem(false) { currentMode ->
                if (currentMode == null) {
                    return@getCurrentModeAsListItem
                }
                RadioNodeUtil.setNodeToRadioAsync(radio, NodeNavLoginComplete(currentMode.key)) {
                    if (!it) {
                        //try set the old node for backward compatibility
                        RadioNodeUtil.setNodeToRadioAsync(
                            radio,
                            NodeNavAmazonMpLoginComplete(BaseNavAmazonMpLoginComplete.Ord.TRUE)
                        ) {
                            NavBrowseManager.getInstance().resetNavToRoot()
                            FsLogger.log(
                                "Node Nav Amazon Login Complete $currentMode",
                                LogLevel.Info
                            )
                        }
                    } else {
                        NavBrowseManager.getInstance().resetNavToRoot()
                        FsLogger.log("Generic Node Nav Login Complete $currentMode", LogLevel.Info)

                    }
                }
            }
        }
    }

    fun registerDicoveryListener() {
        NetRemoteManager.getInstance().addRadioDiscoveryListener(this)
    }

    fun removeDiscoveryListner() {
        NetRemoteManager.getInstance().removeRadioDiscoveryListener(this)
    }

    override fun onRadioFound(radio: Radio?) {
        trySendSmartRadioNumberEvent()
        trySendMoreThan1VeniceXDevices()
    }

    override fun onRadioLost(radio: Radio?, rescanInProgress: Boolean) {
    }

    override fun onRadioUpdated(radio: Radio?) {
    }

    fun trySendSmartRadioNumberEvent() {
        val listSize = NetRemoteManager.getInstance().radios.size
        if (!UndokPreferences.getInstance().wasNumberOfSpeakersSent() &&
            listSize > 1) {
            AnalyticsSender.sendSmartRadioNumberEvent(listSize)
            UndokPreferences.getInstance().setNumberOfSpeakersSent(listSize)
        }
    }

    private fun trySendMoreThan1VeniceXDevices() {
        val listSize = NetRemoteManager.getInstance().radios.size
        if (!UndokPreferences.getInstance().wasMoreThanOneVeniceXDeviceSent() &&
            listSize > 1 && areMoreThan1VeniceXDevicesOnTheNetwork()) {
            AnalyticsSender.sendMoreThenOneVeniceXDevices(listSize)
            UndokPreferences.getInstance().setMoreThanOneVeniceXDevice(listSize)
        }
    }

    fun shouldShowOktivPromo() {
        if (!UndokPreferences.getInstance().wasOktivPromoShowed() &&
            canShowPopupForVenicexDevices() &&
            RemoteConfigUtils().shouldDisplayOktivPromoBasedOnCountry() &&
                !isAnyVeniceXFirmwareInBlacklist()) {
            shouldShowOktivPromo.value = true
        }
    }

    private fun areMoreThan1VeniceXDevicesOnTheNetwork(): Boolean {
        var numberOfVEniceXDevicesOnTheNetwork = 0

        val list = NetRemoteManager.getInstance().radios

        for (radio in list) {
            if (radio.isVeniceXDevice) {
                numberOfVEniceXDevicesOnTheNetwork += 1
            }
        }

        return numberOfVEniceXDevicesOnTheNetwork > 1
    }

    private fun canShowPopupForVenicexDevices(): Boolean {
        val list = NetRemoteManager.getInstance().radios

        for (radio in list) {
            radio?.let {
                if (!radio.isVeniceXDevice || !radio.isVeniceXFirmwareCompatibleWithOktivApp) {
                    return false
                }
            }

        }

        return  true
    }

    private fun isAnyVeniceXFirmwareInBlacklist(): Boolean {
        val list = NetRemoteManager.getInstance().radios
        val firmwareBlackList = RemoteConfigUtils().getFirmwareBlacklist()

        list.forEach() {radio ->
            radio?.let {
                firmwareBlackList.forEach {firmwareVersion->
                    if (radio.firmwareVersion !=null && radio.firmwareVersion.lowercase().contains(firmwareVersion.version.lowercase())) {
                        return true
                    }
                }
            }
        }
        return false
    }
}