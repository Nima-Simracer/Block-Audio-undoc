package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;


import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import android.content.Context;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Node.BaseFsdcaState;
import com.frontier_silicon.NetRemoteLib.Node.NodeFsdcaState;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoFriendlyName;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.BaseSanitizer;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.ErrorSanitizerMessageType;
import com.frontier_silicon.components.common.FriendlyNameSanitizer;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.settings.account.AccountWebviewActivity;
import com.frontier_silicon.fsirc.dok2.settings.account.FSAuthManager;
import com.frontier_silicon.fsirc.dok2.settings.account.FSDCAEndpoints;
import com.frontier_silicon.fsirc.dok2.settings.account.OAuthToken;
import com.frontier_silicon.fsirc.dok2.util.FriendlyNameSanitizerErrorHandler;
import com.frontier_silicon.fsirc.dok2.util.SpeakerImageDownloader;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import org.greenrobot.eventbus.EventBus;


/**
 * Created by cvladu on 28/02/2018.
 */

public class AddDevicesListItemViewModel implements IAddDeviceState, LifecycleObserver {
    private static final String URL_TO_OPEN_IN_WEBVIEW = "URL_TO_OPEN_IN_WEBVIEW";

    private final int TIMER_TIMEOUT = 30 * 1000;
    public ObservableField<String> speakerName = new ObservableField<>();
    public ObservableField<BitmapDrawable> speakerImage = new ObservableField<>();
    public ObservableBoolean isLoadingVisible = new ObservableBoolean(false);

    private AddDeviceStateRetrieverTimer mAddDeviceStateRetriever;
    private Long mPostDelayedId;
    private Radio mRadio;
    private Lifecycle mLifecycle;
    private int check;


    public AddDevicesListItemViewModel(Radio radio, Lifecycle lifecycle) {
        mRadio = radio;
        mLifecycle = lifecycle;
        init();
    }

    private void init() {
        updateSpeakerImage();
        updateSpeakerName();

        mLifecycle.addObserver(this);
    }

    private void updateSpeakerImage() {
        if (mRadio == null) {
            return;
        }

        SpeakerImageDownloader downloader = new SpeakerImageDownloader(mRadio, MainApplication.getCurrentActivity(),
                bitmapDrawable -> speakerImage.set(bitmapDrawable));

        downloader.download();
    }

    private void updateSpeakerName() {
        if (mRadio == null) {
            return;
        }

        speakerName.set(mRadio.getFriendlyName());
    }

    public void onAssociateSpeakerClicked(View v) {
        if (!AddDeviceManager.getInstance().isASpeakerWithTheSameNameAlreadyAssociated(mRadio)) {
            displayAlertDialogForAssociation();
        } else {
            displayAlertDialogForExistingSpeaker();
        }
    }

    private void displayAlertDialogForAssociation() {
        if (mRadio == null) {
            return;
        }

        View view = MainApplication.getCurrentActivity().getLayoutInflater().inflate(R.layout.fsdca_add_device_dialog, null);
        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(MainApplication.getCurrentActivity());
        builder.setView(view);
        ImageView speakerImage = view.findViewById(R.id.speakerImage);
        TextView speakerName = view.findViewById(R.id.speakerName);
        TextView associateSpeaker = view.findViewById(R.id.associateSpeakerTextView);
        associateSpeaker.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.associate_speaker, true));
        speakerName.setText(mRadio.getFriendlyName());
        speakerImage.setImageDrawable(this.speakerImage.get());
        builder.setPositiveButton(android.R.string.ok, (dialog, which) -> {
            associateSpeakerWithUndokAccount();
            isLoadingVisible.set(true);
        })
                .setNegativeButton(android.R.string.cancel, null);
        builder.create().show();
    }

    private void displayAlertDialogForExistingSpeaker() {

        Context context = MainApplication.getContext();

        AlertDialog.Builder builder =ThemedAlertDialogBuilder.create(MainApplication.getCurrentActivity());
        builder.setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.fsdca_speaker_already_associated_title, true))
                .setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.fsdca_speaker_already_associated_new_message, true))
                .setPositiveButton(R.string.rename, (dialogInterface, i) -> {
                    displayRenameSpeakerDialog();
                })
                .setNegativeButton(R.string.fsdca_delete, (dialogInterface, i) -> {
                    goToMyDevicesWebView();
                })
                .setNeutralButton(android.R.string.cancel, null);

        AlertDialog nameConflictDialog = builder.create();
        nameConflictDialog.show();

        DialogsHolder.addDialogToCollection("3PDANameConflict", nameConflictDialog);
    }

    private void displayRenameSpeakerDialog() {
        if (mRadio == null) {
            return;
        }

        View view = MainApplication.getCurrentActivity().getLayoutInflater().inflate(R.layout.rename_speaker_with_sugestied_names, null);
        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(MainApplication.getCurrentActivity());
        builder.setView(view);
        EditText speakerNameEditText = view.findViewById(R.id.speakerName);
        Spinner suggestedNameSpinner = view.findViewById(R.id.speakerNameSugestion);
        TextView renameSpeakerTextView = view.findViewById(R.id.dialogMessage);
        renameSpeakerTextView.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.change_friendly_name_title, true));
        populateSpinner(suggestedNameSpinner, speakerNameEditText);
        addSanitizer(speakerNameEditText);

        builder.setPositiveButton(R.string.rename, (dialogInterface, i) -> {
            renameSpeaker(speakerNameEditText.getText().toString());
        })
                .setNegativeButton(android.R.string.cancel, null);

        AlertDialog renameSpeakerDialog = builder.create();
        renameSpeakerDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        renameSpeakerDialog.show();

        DialogsHolder.addDialogToCollection("3PDARenameSpeaker", renameSpeakerDialog);
    }

    private void renameSpeaker(String newFriendlyName) {
        if (mRadio == null || TextUtils.isEmpty(newFriendlyName) || mRadio.getFriendlyName().equals(newFriendlyName)) {
            return;
        }

        RadioNodeUtil.setNodeToRadioAsync(mRadio, new NodeSysInfoFriendlyName(newFriendlyName), success -> {
            if (success && mRadio != null) {
                onFriendlyNameChanged(newFriendlyName);
            }
        });
    }

    private void onFriendlyNameChanged(String friendlyName) {
        mRadio.setFriendlyName(friendlyName);
        EventBus.getDefault().post(new RefreshFsdcaListEvent());
    }

    private void addSanitizer(EditText speakerNameEditText) {
        BaseSanitizer sanitizer;
        final int maxLengthOfFriendlyName = mRadio.hasGoogleCast() ?
                FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME_WHEN_GOOGLE_CAST_IS_PRESENT :
                FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME;

        sanitizer = new FriendlyNameSanitizer(maxLengthOfFriendlyName);
        FriendlyNameSanitizerErrorHandler errorHandler = new FriendlyNameSanitizerErrorHandler(maxLengthOfFriendlyName);
        ((FriendlyNameSanitizer) sanitizer).appendSanitizerToEditText(speakerNameEditText, MainApplication.getCurrentActivity(), new FriendlyNameSanitizer.IFriendlyNameSanitizerListener() {
            @Override
            public void onNewFriendlyName(String friendlyName) {

            }

            @Override
            public void onSubmitFriendlyName(String friendlyName) {

            }

            @Override
            public void onBadFriendlyName(ErrorSanitizerMessageType errorType) {
                errorHandler.handleMessageErrorType(MainApplication.getCurrentActivity(), errorType, speakerNameEditText);
            }
        });
    }

    private void populateSpinner(Spinner suggestedNameSpinner, final EditText speakerNameEditText) {
        ArrayAdapter<String> adapter;
        check = 0;
        String [] sugestedNames = MainApplication.getContext().getResources().getStringArray(R.array.group_names_array);
        adapter = new ArrayAdapter<>(MainApplication.getCurrentActivity(), android.R.layout.simple_list_item_1, sugestedNames);
        suggestedNameSpinner.setAdapter(adapter);
        suggestedNameSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (++check > 1) {
                    String name = (String) adapterView.getItemAtPosition(i);
                    speakerNameEditText.setText(name);
                } else {
                    speakerNameEditText.setText(mRadio.getFriendlyName());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }


    private void goToMyDevicesWebView() {
        FSAuthManager.getInstance().getToken(new FSAuthManager.OnToken() {
            @Override
            public void onToken(OAuthToken token) {

                Bundle bundle = new Bundle();
                bundle.putString(URL_TO_OPEN_IN_WEBVIEW, new FSDCAEndpoints().getMyDevicesUrl());

                NavigationHelper.goToActivity(MainApplication.getCurrentActivity(), AccountWebviewActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
            }

            @Override
            public void onFailed(FSAuthManager.Error error) {
                Log.d("FsAuthManager", error.description);
            }
        });
    }

    private void associateSpeakerWithUndokAccount() {
        AddDeviceManager.getInstance().associateSpeakerWithUndokAccount(mRadio, success -> {
            if (success) {
                startFSDCAStateTimerRetriever();
            } else {
                stopLoadingAndDisplayErrorMessage();
            }
        });
    }

    private void startFSDCAStateTimerRetriever() {
        mAddDeviceStateRetriever = new AddDeviceStateRetrieverTimer();
        mAddDeviceStateRetriever.startFsdcaStateRetriverTimer(mRadio, this);
        startTimeoutTimer();
    }

    private void startTimeoutTimer() {
        mPostDelayedId = DelayedPostsManager.getInstance().registerNewCallbackID();

        DelayedPostsManager.getInstance().postDelayed(()-> {
            stopLoadingAndDisplayErrorMessage();
            stopFsdcaStateTimerRetriever();
        }, mPostDelayedId, TIMER_TIMEOUT);
    }

    private void stopTimeoutTimer() {
        DelayedPostsManager.getInstance().removeCallbackId(mPostDelayedId);
    }

    private void refreshAssociatedSpeakerList() {
        EventBus.getDefault().post(new RefreshFsdcaListEvent());
    }

    private void onSuccess() {
        isLoadingVisible.set(false);
        stopTimeoutTimer();
        Toast.makeText(MainApplication.getCurrentActivity(), MainApplication.getCurrentActivity().getString(R.string.fsdca_associated_successfully),
                Toast.LENGTH_SHORT).show();

        dispose();
        refreshAssociatedSpeakerList();

    }

    private void stopLoadingAndDisplayErrorMessage() {

        isLoadingVisible.set(false);
        Toast.makeText(MainApplication.getCurrentActivity(), MainApplication.getCurrentActivity().getString(R.string.something_went_wrong),
                Toast.LENGTH_SHORT).show();

    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void dispose() {
        stopFsdcaStateTimerRetriever();
        if (mPostDelayedId != null) {
            stopTimeoutTimer();
        }
        mRadio = null;
        if (mLifecycle != null) {
            mLifecycle.removeObserver(this);
            mLifecycle = null;
        }

        mAddDeviceStateRetriever = null;
    }

    private void stopFsdcaStateTimerRetriever() {
        if (mAddDeviceStateRetriever != null) {
            mAddDeviceStateRetriever.stopFsdcaTimer();
        }
    }

    @Override
    public void onFSDCAState(NodeFsdcaState node) {
        if (node.getValueEnum() == BaseFsdcaState.Ord.FSDCA_STATE_CONNECTING) {
            onSuccess();
        }
    }
}
