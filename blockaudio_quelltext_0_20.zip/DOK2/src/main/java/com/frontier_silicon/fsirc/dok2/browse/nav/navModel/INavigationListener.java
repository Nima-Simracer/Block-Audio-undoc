package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;

/**
 * Created by lsuhov on 20/10/2016.
 */

public interface INavigationListener {
    void onNavigationCompleted(EIRNavigationResult result);
}
