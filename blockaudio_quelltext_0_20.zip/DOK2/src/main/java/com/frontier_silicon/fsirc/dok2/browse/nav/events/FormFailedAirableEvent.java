package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by lsuhov on 02/07/16.
 */

public class FormFailedAirableEvent {}
