package com.frontier_silicon.fsirc.dok2.notifications;

import android.app.Notification;
import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import android.view.View;
import android.widget.RemoteViews;

import com.frontier_silicon.NetRemoteLib.Node.NodePlayStatus;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

/**
 * Created by mnisipeanu on 15/05/2017.
 */

public class MPlayerNotification extends NotificationBase{
    public final static int NOTIFICATION_ID = 27910;
    private static final String TAG = "MPNotification ";
    private final static int DEFAULT_ARTWORK = R.drawable.ic_musicplayerdisplay;

    private static MPlayerNotification instance;

    //private PendingIntent mStopIntent = null;

    private Bitmap playBtn;
    private Bitmap pauseBtn;

    private PendingIntent mPreviousIntent = null;
    private PendingIntent mNextIntent = null;

    private PendingIntent closeBtn;
    private long mLastForceUpdateRequestTime = 0L;
    private final long MIN_REQUEST_TIME = 10_000L;

    public static MPlayerNotification newInstance() {
        if (instance == null) {
            instance = new MPlayerNotification();
        }

        return instance;
    }

    public static MPlayerNotification getInstance() {
        return instance;
    }

    public MPlayerNotification(){
        //super(42/*int imgSmallSize*/, 96/*int imgBigSize*/);
        super(NotificationMode.MP, NOTIFICATION_ID, 32/*int imgSmallSize*/, 55/*int imgBigSize*/);
        this.defaultArtWork = DEFAULT_ARTWORK;
    }

    /**
     * create a new notification and update return it
     * @return
     */
    public Notification create() {
        if (notiBuilder == null) {
            notiBuilder = new NotificationCompat.Builder(mContext, NOTIFICATION_CHANNEL_ID);
            notiBuilder
                    .setSmallIcon(R.drawable.ic_notificationicon)
                    .setDeleteIntent(mSwipeDismissIntent)
                    .setCategory(NotificationCompat.CATEGORY_SERVICE)
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setShowWhen(false);

            notiBuilder.setContentIntent(getOpenAppIntent());

            if (Build.VERSION.SDK_INT > 23) {
                notiBuilder.setStyle(new NotificationCompat.DecoratedCustomViewStyle());
            } else {
                notiBuilder.setStyle(new androidx.core.app.NotificationCompat.Style() {
                    @Override
                    public void setBuilder(androidx.core.app.NotificationCompat.Builder builder) {
                        super.setBuilder(builder);
                    }
                });
            }
            notiBuilder.setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            notiBuilder.setColor(this.colorTintRes);

            contentView = new RemoteViews(mContext.getPackageName(), R.layout.notification_custom_media);
            contentCompactView = new RemoteViews(mContext.getPackageName(), R.layout.notification_custom_media_compact);


           // notiBuilder.setCustomBigContentView(contentView);
            notiBuilder.setCustomContentView(contentCompactView);

            // setup layout
            /* expanded next/prev setup */
            contentView.setImageViewBitmap(R.id.prev, tintResource(R.drawable.ic_skip_prev, this.colorTintRes));
            contentView.setImageViewBitmap(R.id.next, tintResource(R.drawable.ic_skip_next, this.colorTintRes));

            contentView.setOnClickPendingIntent(R.id.prev, mPreviousIntent);
            contentView.setOnClickPendingIntent(R.id.next, mNextIntent);

            contentView.setOnClickPendingIntent(R.id.closeView, closeBtn);
            contentView.setTextColor(R.id.closeView, this.colorTintRes);

            /* compact next/prev setup */
            contentCompactView.setImageViewBitmap(R.id.prev, tintResource(R.drawable.ic_skip_prev, this.colorTintRes));
            contentCompactView.setImageViewBitmap(R.id.next, tintResource(R.drawable.ic_skip_next, this.colorTintRes));

            contentCompactView.setOnClickPendingIntent(R.id.prev, mPreviousIntent);
            contentCompactView.setOnClickPendingIntent(R.id.next, mNextIntent);

            // other setups
            playBtn = tintResource(R.drawable.ic_play, this.colorTintRes);
            pauseBtn = tintResource(R.drawable.ic_pause, this.colorTintRes);

            contentCompactView.setProgressBar(R.id.progressBar, 100, 100, true);
            contentView.setProgressBar(R.id.progressBar, 100, 100, true);
        }

        this.update();
        return this.notification;
    }

    @Override
    public NotificationBase setRadio(Radio radio){
        super.setRadio(radio);

        if (radio == null) {
            return this;
        }

        mPlayIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.PLAY, mode);;

        mPreviousIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.PREV, mode);
        mNextIntent = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.NEXT, mode);

        closeBtn = NotificationManagerService.sendIntent(mContext, NotificationManagerService.Actions.DISMISS_NOTIFICATION, mode);

        return this;
    }

    @Override
    public NotificationBase remove() {
        super.remove();

        instance = null;

        return this;
    }

    /**
     * update a notification, after update you have to invoke show to update screen with new notification
     * @return
     */
    public MPlayerNotification update() {
        if (notiBuilder == null) {
            return null;
        }

        if (mTitle.equals("")) {
            mTitle = mContext.getString(R.string.bluetooth_idle);

            visibleProgress = true;
           // contentCompactView.setViewVisibility(R.id.progressBar, View.VISIBLE);
           // contentCompactView.setViewVisibility(R.id.text, View.GONE);

           // contentView.setViewVisibility(R.id.progressBar, View.VISIBLE);
           // contentView.setViewVisibility(R.id.text, View.GONE);

            // expanded view
            contentView.setBoolean(R.id.prev, "setEnabled", false);
            contentView.setBoolean(R.id.next, "setEnabled", false);

            contentView.setInt(R.id.prev, "setAlpha", 100);
            contentView.setInt(R.id.next, "setAlpha", 100);

            // compact view
            contentCompactView.setBoolean(R.id.prev, "setEnabled", false);
            contentCompactView.setBoolean(R.id.next, "setEnabled", false);

            contentCompactView.setInt(R.id.prev, "setAlpha", 100);
            contentCompactView.setInt(R.id.next, "setAlpha", 100);
        } else if (visibleProgress) {
            visibleProgress = false;

            contentCompactView.setViewVisibility(R.id.progressBar, View.GONE);
            contentCompactView.setViewVisibility(R.id.text, View.VISIBLE);

            contentView.setViewVisibility(R.id.progressBar, View.GONE);
            contentView.setViewVisibility(R.id.text, View.VISIBLE);

            contentView.setBoolean(R.id.prev, "setEnabled", true);
            contentView.setBoolean(R.id.next, "setEnabled", true);

            contentView.setInt(R.id.prev, "setAlpha", 255);
            contentView.setInt(R.id.next, "setAlpha", 255);

            contentCompactView.setBoolean(R.id.prev, "setEnabled", true);
            contentCompactView.setBoolean(R.id.next, "setEnabled", true);

            contentCompactView.setInt(R.id.prev, "setAlpha", 255);
            contentCompactView.setInt(R.id.next, "setAlpha", 255);
        }

        // update normal notification view
        contentView.setImageViewBitmap(R.id.imageView, artworkNormal);
        contentView.setTextViewText(R.id.title, mTitle);
        contentView.setTextViewText(R.id.text, mText);

        // update compact notification view
        contentCompactView.setImageViewBitmap(R.id.imageView, artworkSmall);
        contentCompactView.setTextViewText(R.id.title, mTitle);
        contentCompactView.setTextViewText(R.id.text, mText);
        // if (playbackStarted) // old condition for MP
        if (mPlayStatus!= null &&  mPlayStatus.getValueEnum() == NodePlayStatus.Ord.PLAYING) {
            // update in custom view
            contentView.setImageViewBitmap(R.id.play_pause, pauseBtn);
            contentView.setOnClickPendingIntent(R.id.play_pause, mPauseIntent);

            // update in custom view
            contentCompactView.setImageViewBitmap(R.id.play_pause, pauseBtn);
            contentCompactView.setOnClickPendingIntent(R.id.play_pause, mPauseIntent);

            // if playing started but title and text is empty force refresh
            if (mText.isEmpty() && canRequestForceUpdatesAtEach10Seconds()) {
                // update track info to widget
                mLastForceUpdateRequestTime = System.currentTimeMillis();
                requestTrackUpdate();
                FsLogger.log(TAG + "request track info forced");
            }

        } else {
            // update in custom view
            contentView.setImageViewBitmap(R.id.play_pause, playBtn);
            contentView.setOnClickPendingIntent(R.id.play_pause, mPlayIntent);

            // update in custom view
            contentCompactView.setImageViewBitmap(R.id.play_pause, playBtn);
            contentCompactView.setOnClickPendingIntent(R.id.play_pause, mPlayIntent);
        }

        notification = notiBuilder.build();

        return this;
    }

    private boolean canRequestForceUpdatesAtEach10Seconds() {
        return System.currentTimeMillis() - mLastForceUpdateRequestTime > MIN_REQUEST_TIME;
    }

    public void updateArtwork(Bitmap bitmap) {
        FsLogger.log(TAG + "try to update artwork to notification ");

        if ((!visibleProgress) && (contentCompactView != null) && (contentView != null) && (notiBuilder != null)) {

            Bitmap tmp = getAlbumArtwork(bitmap);
            tmp = scaleDownBitmap(tmp, sizeBigImage);

            // update only if image changed
            if (!artworkNormal.sameAs(tmp)) {
                artworkNormal = tmp;
                artworkSmall = scaleDownBitmap(tmp, sizeSmallImage);

                contentView.setImageViewBitmap(R.id.imageView, artworkNormal);
                contentCompactView.setImageViewBitmap(R.id.imageView, artworkSmall);

                try {
                    notificationManager.notify(notificationId, notiBuilder.build());
                } catch (RuntimeException e) {
                    FsLogger.log(TAG + "updateArtwork->TransactionTooLargeException: " + e, LogLevel.Error);
                }
                FsLogger.log(TAG + "notification artwork updated");
            } else {
                FsLogger.log(TAG + "notification artwork NOT updated - is same");
            }
        } else {
            FsLogger.log(TAG + "contentView: " + contentView + " - notiBuilder: " + notiBuilder);
        }
    }

}
