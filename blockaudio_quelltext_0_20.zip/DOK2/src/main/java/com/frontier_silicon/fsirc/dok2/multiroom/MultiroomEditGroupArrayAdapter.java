package com.frontier_silicon.fsirc.dok2.multiroom;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.R;

import java.util.List;

public class MultiroomEditGroupArrayAdapter extends ArrayAdapter<MultiroomEditGroupItemModel> {

    private Context mContext;

    private IMultiroomEditGroupListener mListener;

    public MultiroomEditGroupArrayAdapter(Context context, int textViewResourceId, List<MultiroomEditGroupItemModel> objects, IMultiroomEditGroupListener listener) {
        super(context, textViewResourceId, objects);

        mContext = context;

        mListener = listener;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final MultiroomEditGroupItemModel device = getItem(position);

        if (v == null) {
            v = li.inflate(R.layout.edit_group_list_item, parent, false);
        }

        TextView tv = (TextView) v.findViewById(R.id.text1);
        tv.setText(device.toString());

        CheckBox checkBox = (CheckBox) v.findViewById(R.id.checkBoxInCurrentGroup);
        CheckBox checkBoxIncompatibleMRVer = (CheckBox) v.findViewById(R.id.checkBoxIncompatibleMRVer);
        CheckBox checkBoxRadioNotAvailable = (CheckBox) v.findViewById(R.id.checkBoxNotAvailable);

        if (device.isAvailableOnTheNetwork()) {
            checkBox.setOnCheckedChangeListener(null);

            checkBox.setChecked(device.isChecked());
            notifyDeviceSelectionChanged(device, device.isChecked());

            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    device.setChecked(isChecked);

                    notifyDeviceSelectionChanged(device, isChecked);
                }
            });

            checkBox.setEnabled(device.isCheckboxEnabled());



            if (device.isSameMultiroomVersion()) {
                checkBoxIncompatibleMRVer.setVisibility(View.GONE);
                checkBoxIncompatibleMRVer.setOnCheckedChangeListener(null);

                checkBox.setVisibility(View.VISIBLE);
            } else {
                checkBoxIncompatibleMRVer.setVisibility(View.VISIBLE);

                checkBoxIncompatibleMRVer.setOnCheckedChangeListener(null);
                checkBoxIncompatibleMRVer.setChecked(device.isChecked());
                checkBoxIncompatibleMRVer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        device.setChecked(isChecked);
                        notifyDeviceSelectionChanged(device, isChecked);
                    }
                });

                checkBox.setVisibility(View.GONE);
            }

            checkBoxRadioNotAvailable.setVisibility(View.GONE);
            checkBoxRadioNotAvailable.setOnCheckedChangeListener(null);
        } else {
            checkBoxRadioNotAvailable.setVisibility(View.VISIBLE);
            checkBoxRadioNotAvailable.setOnCheckedChangeListener(null);
            checkBoxRadioNotAvailable.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    notifyDeviceSelectionChanged(device, false);
                }
            });

            checkBoxIncompatibleMRVer.setVisibility(View.GONE);
            checkBox.setVisibility(View.GONE);
        }

        return v;
    }

    private void notifyDeviceSelectionChanged(MultiroomEditGroupItemModel device, boolean isChecked) {
        if (mListener != null) {
            mListener.onDeviceSelectionChanged(device, isChecked);
        }
    }

}
