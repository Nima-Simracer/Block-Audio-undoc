package com.frontier_silicon.fsirc.dok2.gdpr;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import androidx.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.GdprActivityBinding;

/**
 * Created by nbalazs on 18/04/2018.
 */

public class GDPRActivity extends UndokActivityBase {

    private GdprActivityBinding mBinding;

    private static long sayBackPress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.gdpr_activity);

        mBinding.setViewModel(new GDPRActivityVM(GDPRActivity.this));

        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }

        setupControls();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (mBinding.webView.canGoBack()) {
                        mBinding.webView.goBack();
                    } else {
                        if (sayBackPress + 1500 > System.currentTimeMillis()) {
                            finish();
                        } else {
                            Toast.makeText(this, getResources().getString(R.string.press_back_again), Toast.LENGTH_SHORT).show();
                            sayBackPress = System.currentTimeMillis();
                        }
                    }
                    return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupControls() {
        String url = getResources().getString(R.string.gdpr_website);

        WebSettings webSettings = mBinding.webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        mBinding.webView.setBackgroundColor(Color.TRANSPARENT);
        mBinding.webView.getSettings().setSupportZoom(true);
        mBinding.webView.getSettings().setBuiltInZoomControls(true);
        mBinding.webView.getSettings().setDisplayZoomControls(false);
        mBinding.webView.getSettings().setLoadWithOverviewMode(true);
        mBinding.webView.setWebViewClient(new EmbeddedWebViewClient());
        mBinding.webView.setWebChromeClient(new EmbeddedWebChromeClient());
        mBinding.webView.getSettings().setDefaultZoom(WebSettings.ZoomDensity.MEDIUM);
        mBinding.webView.clearHistory();
        mBinding.webView.clearFormData();
        mBinding.webView.clearCache(true);
        if (GDPRVersionManager.getLoadLocalVersion()) {
            mBinding.webView.loadUrl("file:///android_asset/UNDOK_GDPR-en.html");
        } else {
            mBinding.webView.loadUrl(url);
        }
    }

    @SuppressWarnings("all")
    private class EmbeddedWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            mBinding.webView.setInitialScale(0);
            if (url.startsWith("mailto:")) {
                startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse(url)));
            } else {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
            }
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            mBinding.progressLoading.setProgress(0);
            mBinding.progressLoading.setVisibility(View.VISIBLE);
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            mBinding.progressLoading.setVisibility(View.INVISIBLE);
            mBinding.webView.setInitialScale(0);
            super.onPageFinished(view, url);
        }
    }

    private class EmbeddedWebChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            mBinding.progressLoading.setProgress(newProgress);
        }
    }
}
