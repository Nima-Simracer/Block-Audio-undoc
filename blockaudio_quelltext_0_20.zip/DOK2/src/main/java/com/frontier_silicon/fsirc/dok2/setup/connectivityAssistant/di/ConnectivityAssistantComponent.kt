package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.di

import com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.ConnectivityAssistantActivity
import dagger.Subcomponent

@ConnectivityAssistantScope
@Subcomponent(modules = [ConnectivityAssistantProvideModule::class])
interface ConnectivityAssistantComponent {

    @Subcomponent.Factory
    interface Factory{
        fun create(): ConnectivityAssistantComponent
    }

    fun inject(activity: ConnectivityAssistantActivity)
}