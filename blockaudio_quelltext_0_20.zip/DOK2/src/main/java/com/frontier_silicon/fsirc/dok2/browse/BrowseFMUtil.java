package com.frontier_silicon.fsirc.dok2.browse;

import java.util.Map;
import java.util.Vector;

import com.frontier_silicon.loggerlib.LogLevel;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayFrequency;
import com.frontier_silicon.NetRemoteLib.Node.NodePlayInfoName;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsFmFreqRangeLower;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsFmFreqRangeStepSize;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsFmFreqRangeUpper;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.NetRemoteManager;

public class BrowseFMUtil {

	private static final String MHZ_TXT = "mhz";
	private long mMinFreqKHz = 0;
	private long mMaxFreqKHz = 0;
	private long mFreqStepKHz = 0;
	private long mCurrentFreqKHz = 0;

	private Vector<IFMRadioInfoListener> mListeners;

	private INodeNotificationCallback mFMPlaybackNodesCallback;
	
	public BrowseFMUtil() {
		mListeners = new Vector<>();
	}
	
	synchronized public boolean addListener(IFMRadioInfoListener listener) {
		return mListeners.add(listener);
	}
	
	synchronized public boolean removeListener(IFMRadioInfoListener listener) {
		return mListeners.remove(listener);
	}
	
	synchronized public void notifyUpdateFrequencyInfo(boolean fmFreqChanged) {
		for (IFMRadioInfoListener listener : mListeners) {
				listener.onUpdateFrequencyInfo(fmFreqChanged);
		}
	}	
	
	public void updateFMFrequencyInfo() {
		boolean forceUncached = false;
		Radio currRadio = NetRemoteManager.getInstance().getCurrentRadio();

		if (NetRemoteManager.getInstance().checkConnection()) {

			RadioNodeUtil.getNodesFromRadioAsync(currRadio, new Class[]{NodeSysCapsFmFreqRangeLower.class, NodeSysCapsFmFreqRangeUpper.class, NodeSysCapsFmFreqRangeStepSize.class, NodePlayFrequency.class}, forceUncached, new RadioNodeUtil.INodesResultListener() {
						@Override
						public void onNodesResult(Map<Class, NodeInfo> nodes) {
							NodeSysCapsFmFreqRangeLower nodeSysCapsFmFreqRangeLower = (NodeSysCapsFmFreqRangeLower) nodes.get(NodeSysCapsFmFreqRangeLower.class);
							if (nodeSysCapsFmFreqRangeLower != null) {
								mMinFreqKHz = nodeSysCapsFmFreqRangeLower.getValue();
								FsLogger.log("getNodeResult: " + nodeSysCapsFmFreqRangeLower.getName() + " value= " + nodeSysCapsFmFreqRangeLower.toString());
								onFMFrequencyInfoResponse();
							} else {
								FsLogger.log("Node does not exist: NodeSysCapsFmFreqRangeLower", LogLevel.Error);
								mMinFreqKHz = 0;
								onFMFrequencyInfoResponse();
							}

							NodeSysCapsFmFreqRangeUpper nodeSysCapsFmFreqRangeUpper = (NodeSysCapsFmFreqRangeUpper) nodes.get(NodeSysCapsFmFreqRangeUpper.class);
							if (nodeSysCapsFmFreqRangeUpper != null) {
								mMaxFreqKHz = nodeSysCapsFmFreqRangeUpper.getValue();
								FsLogger.log("getNodeResult: " + nodeSysCapsFmFreqRangeUpper.getName() + " value= " + nodeSysCapsFmFreqRangeUpper.toString());
								onFMFrequencyInfoResponse();
							} else {
								mMaxFreqKHz = 0;
								FsLogger.log("Node does not exist: NodeSysCapsFmFreqRangeUpper", LogLevel.Error);
								onFMFrequencyInfoResponse();
							}

							NodeSysCapsFmFreqRangeStepSize nodeSysCapsFmFreqRangeStepSize = (NodeSysCapsFmFreqRangeStepSize) nodes.get(NodeSysCapsFmFreqRangeStepSize.class);
							if (nodeSysCapsFmFreqRangeStepSize != null) {
								mFreqStepKHz = nodeSysCapsFmFreqRangeStepSize.getValue();
								FsLogger.log("getNodeResult: " + nodeSysCapsFmFreqRangeStepSize.getName() + " value= " + nodeSysCapsFmFreqRangeStepSize.toString());
								onFMFrequencyInfoResponse();
							} else {
								mFreqStepKHz = 0;
								FsLogger.log("Node does not exist: NodeSysCapsFmFreqRangeStepSize", LogLevel.Error);
								onFMFrequencyInfoResponse();
							}

							NodePlayFrequency nodePlayFrequency = (NodePlayFrequency) nodes.get(NodePlayFrequency.class);
							if (nodePlayFrequency != null) {
								mCurrentFreqKHz = nodePlayFrequency.getValue();
								onFMFrequencyInfoResponse();
								FsLogger.log("getNodeResult: " + nodePlayFrequency.getName() + " value= " + nodePlayFrequency.toString());
							} else {
								FsLogger.log("Node does not exist: NodePlayFrequency", LogLevel.Error);
								mCurrentFreqKHz = 0;
								onFMFrequencyInfoResponse();
							}
						}
					});
		}
		 else {
			mMinFreqKHz = 0;
			mMaxFreqKHz = 0;
			mFreqStepKHz = 0;
			mCurrentFreqKHz = 0;

			notifyUpdateFrequencyInfo(true);
		}
	}

	static private final int NUM_FM_FREQ_INFO_RESP_EXPECTED = 4;
	private int mCntFMFreqInfoResponses = 0;

	private void onFMFrequencyInfoResponse() {
		mCntFMFreqInfoResponses++;
		if (mCntFMFreqInfoResponses >= NUM_FM_FREQ_INFO_RESP_EXPECTED) {
			notifyUpdateFrequencyInfo(true);
		}
	}

	public long getMinFrequencyKHz() {
		return mMinFreqKHz;
	}
	
	public long getMaxFrequencyKHz() {
		return mMaxFreqKHz;
	}
	
	public long getFrequencyStepKHz() {
		return mFreqStepKHz;
	}
	
	public long getCurrentFrequencyKHz() {
		return mCurrentFreqKHz;
	}
	
	public String getFrequencyDisplayTxt(long freqValue) {
		NodePlayFrequency nodePlayFreq = new NodePlayFrequency(freqValue);
		
		return nodePlayFreq.getFrequencyInMHzAsString();
	}

	public long getValueFromPercent(int percent) {
		float p = (float)percent/100.0f;		
		float value = (long) ((p * (mMaxFreqKHz - mMinFreqKHz)) + mMinFreqKHz);		
		// round to freq. step multiplier
		long freqValue =  (long) ((Math.floor(value / mFreqStepKHz)) * mFreqStepKHz);
		return freqValue;
	}
	
	public int getPercentValue(long freqValueKHz) {
		float percent = 100.0f * ((float)(freqValueKHz - mMinFreqKHz) / (float)(mMaxFreqKHz - mMinFreqKHz));
		return (int)percent;
	}

	public void setFMRadioFrequency(long freqValue) {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
		if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
			freqValue = sanitizeFrequency(freqValue);
			currentRadio.setNode(new NodePlayFrequency(freqValue), false);
		}
	}
	
	public void registerFrequencyInfoNotifCallback() {
		unregisterFrequencyInfoNotifCallback();

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
		if (NetRemoteManager.getInstance().checkConnection(radio)) {
			mFMPlaybackNodesCallback = new INodeNotificationCallback() {
				@Override
				public void onNodeUpdated(NodeInfo node) {
					if (node instanceof NodePlayFrequency) {
						onPlayFrequencyChanged((NodePlayFrequency) node);
					} else if (node instanceof NodePlayInfoName) {
						notifyUpdateFrequencyInfo(false);
					}
				}	 
			};

			radio.addNotificationListener(mFMPlaybackNodesCallback);
		}
	}

	private void onPlayFrequencyChanged(NodePlayFrequency currFreqNode) {
		if (currFreqNode != null) {
			mCurrentFreqKHz = currFreqNode.getValue();
		}

		notifyUpdateFrequencyInfo(true);
	}

	public void unregisterFrequencyInfoNotifCallback() {
		if (mFMPlaybackNodesCallback != null) {
            Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
			if (NetRemoteManager.getInstance().checkConnection(radio)) {
				radio.removeNotificationListener(mFMPlaybackNodesCallback);
				mFMPlaybackNodesCallback = null;
			}
		}
	}

	public void changeFrequencyByStep(long freqStep) {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
		if (NetRemoteManager.getInstance().checkConnection(currentRadio)) {
			long freqValue = mCurrentFreqKHz + freqStep;
			freqValue = sanitizeFrequency(freqValue);
			
			currentRadio.setNode(new NodePlayFrequency(freqValue), false);
		}
	}

	private long sanitizeFrequency(long freqValue) {
		if (freqValue > mMaxFreqKHz) {
			freqValue = mMaxFreqKHz;
		}
		
		if (freqValue < mMinFreqKHz) {
			freqValue = mMinFreqKHz;
		}
		return freqValue;
	}

	public long getValueFromStringMHz(String frequencyMHz) {
		long freqValue = 0;
		
		try {
			float freqMHz = Float.valueOf(frequencyMHz);
			freqValue = roundFrequencyToStep((long) (freqMHz * 1000), mFreqStepKHz);
		} catch (NumberFormatException e) {
		}
		
		return freqValue;
	}
	
	public long roundFrequencyToStep(long frequencyKHz, long freqStep) {
		return (long) ((Math.floor(frequencyKHz / freqStep)) * freqStep);
	}

}
