package com.frontier_silicon.fsirc.dok2.browse.nav.contextAirable;


import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.UnifiedFormListItem;
import com.frontier_silicon.components.common.UnifiedFormOptionsListItem;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.contextModel.ContextBrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ComboboxItemsLoadedEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextRefreshEvent;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * Created by adanaila on 10/4/2016.
 */

public class ContextFormManager extends FormManager{
    private static ContextFormManager mInstance;

    public static ContextFormManager getInstance() {
        if (mInstance == null) {
            mInstance = new ContextFormManager();
        }
        return mInstance;
    }

    private ContextFormManager() {
        super();
        EventBus.getDefault().register(this);
    }

    @Override
    public void sendDataCompletedEvent() {
        //TODO implement for context manager
    }

    @Override
    public void sendValidationFailedEvent() {
        //TODO implement for context manager
    }

    @Override
    public void startRetrievingForm() {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        ContextFormRetrieverRunnable runnable = new ContextFormRetrieverRunnable(radio, new ContextFormRetrieverRunnable.INavFormRetrieverListener() {
            @Override
            public void onNavFormRetrieved(final List<UnifiedFormListItem> listItems) {
                NetRemote.getMainThreadExecutor().execute(() -> parseForm(listItems));
            }
        });

        FsLogger.log("adding form navigation runnable ", LogLevel.Info);
        mThreadPoolExecutor.submit(runnable);
    }

    @Override
    protected void startRetrievingOptions() {
        //add a combo-box item, not a normal one
        //the call should be in a runnable item, but as it is not used for login
        //this is left for a future cycle of dev.
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        ContextFormOptionsRetrieverRunnable runnable = new ContextFormOptionsRetrieverRunnable(radio, new ContextFormOptionsRetrieverRunnable.INavFormOptionRetrieverListener() {
            @Override
            public void onNavFormOptionRetrieved(final List<UnifiedFormOptionsListItem> listItems) {
                NetRemote.getMainThreadExecutor().execute(() -> parseFormOptions(listItems));
            }
        });

        FsLogger.log("adding form OPTIONS navigation runnable ", LogLevel.Info);
        this.mThreadPoolExecutor.submit(runnable);
    }

    @Override
    protected void callFormDataSet(long id, String params) {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        ContextFormSetRunnable runnable = new ContextFormSetRunnable(radio, params, id, new ContextFormSetRunnable.INavFormDataSendListener() {
            @Override
            public void onNavFormSend(final boolean result) {
                if (result) {
                    clearItemsLoaded();
                    EventBus.getDefault().post(new ContextRefreshEvent());
                } else {
                    ContextBrowseManager.getInstance().CloseContextDialog(true);
                }
            }
        });
        mThreadPoolExecutor.submit(runnable);
    }

    @Override
    protected void sendFailedEvent(){
        ContextBrowseManager.getInstance().CloseContextDialog(true);
    }

    @Override
    protected void sendComboboxItemsLoadedEvent(){
        EventBus.getDefault().post(new ComboboxItemsLoadedEvent());
    }
}
