package com.frontier_silicon.fsirc.dok2.settings.staticRadioSearch

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ViewModelProviders
import com.frontier_silicon.NetRemoteLib.Discovery.DeviceRecord
import com.frontier_silicon.NetRemoteLib.Discovery.staticRadioDiscovery.IStaticRadioDiscoveryListener
import com.frontier_silicon.components.NetRemoteManager
import com.frontier_silicon.components.common.GuiUtils
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase
import com.frontier_silicon.fsirc.dok2.databinding.SearchStaticRadioActivityBinding
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender

class ActivityStaticRadio : UndokActivityBase(), IStaticRadioDiscoveryListener, LifecycleObserver {
    private lateinit var binding: SearchStaticRadioActivityBinding
    private lateinit var viewModel: StaticRadioViewModel
    private var mIpAddress: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.search_static_radio_activity)
        viewModel = ViewModelProviders.of(this).get(StaticRadioViewModel::class.java)

        lifecycle.addObserver(this)
        setupAppBar()
        enableUpNavigation()
        setTitle(SmartRadioStringsManager.getSmartRadioString(R.string.static_radio_search_title, true))
        binding.textView8.setText(SmartRadioStringsManager.getSmartRadioString(R.string.static_radio_search_message, true))
        binding.searchRadioButton.setText(SmartRadioStringsManager.getSmartRadioString(R.string.search_radio, true))
        binding.ipAddressToSearch.setHint(SmartRadioStringsManager.getSmartRadioString(R.string.static_radio_ip_address, true))
        search()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    fun registerListener() {
        NetRemoteManager.getInstance().netRemote.staticRadioDiscovery.setListener(this)
        addSearchButtonTextWacher()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    fun removeObserver() {
        NetRemoteManager.getInstance().netRemote.staticRadioDiscovery.removeListeners()
    }

    private fun addSearchButtonTextWacher() {
        binding.ipAddressToSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val speakerIp = binding.ipAddressToSearch.text
                binding.searchRadioButton.isEnabled = shouldEnableSearchButton(speakerIp = speakerIp.toString())
                if (speakerIp?.isEmpty() == true) {
                    binding.editTextLayout.error = getString(R.string.static_radio_empty_ip_address)
                } else if (!Patterns.IP_ADDRESS.matcher(speakerIp).matches()) {
                    binding.editTextLayout.error = getString(R.string.static_radio_ip_address_not_maching)
                } else {
                    binding.editTextLayout.isErrorEnabled = false
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })
    }

    fun search() {
        binding.ipAddressToSearch.setOnKeyListener(View.OnKeyListener { v, keyCode, event -> // If the event is a key-down event on the "enter" button
            if (event.action == KeyEvent.ACTION_DOWN &&
                    keyCode == KeyEvent.KEYCODE_ENTER) {
                if (binding.searchRadioButton.isEnabled) {
                    searchForSpeaker()
                }
                return@OnKeyListener true
            }
            false
        })
    }

    fun onSearchButtonClick(view: View) {
        searchForSpeaker()
    }

    private fun searchForSpeaker() {
        val speakerIp = binding.ipAddressToSearch.text
        if (shouldEnableSearchButton(speakerIp = speakerIp.toString())) {
            mIpAddress = speakerIp.toString()
            viewModel.searchRadioByIp(speakerIp.toString())
            setSearchingState()
        }
    }

    private fun setSearchingState() {
        binding.searchRadioButton.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
    }

    private fun dismissSearchingState() {
        binding.searchRadioButton.isEnabled = true
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun shouldEnableSearchButton(speakerIp: String): Boolean {
        return speakerIp.isNotEmpty() && Patterns.IP_ADDRESS.matcher(speakerIp).matches()
    }

    private fun showBottomSheetDialogFragment(deviceRecord: DeviceRecord) {
        val staticRadioFragment = FragmentStaticRadioFound(deviceRecord, mIpAddress)
        staticRadioFragment.show(supportFragmentManager, "FRAGMENT_STATIC_RADIO")
    }

    override fun onStaticRadioDiscovered(deviceRecord: DeviceRecord) {
        this.runOnUiThread {
            viewModel.cacheDeviceRecord(this, record = deviceRecord)
            AnalyticsSender.sendFoundRadioByIpEvent()
            showBottomSheetDialogFragment(deviceRecord)
            dismissSearchingState()
        }
    }

    override fun onStaticRadioNotFound(deviceRecord: DeviceRecord) {
        this.runOnUiThread {
            AnalyticsSender.sendNOTFoundRadioByIpEvent()
            Toast.makeText(this, SmartRadioStringsManager.getSmartRadioString(R.string.search_by_ip_not_found, true, true), Toast.LENGTH_LONG).show()
            dismissSearchingState()
        }
    }
}