package com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.di

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import androidx.recyclerview.widget.LinearLayoutManager
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.IOnItemSelected
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.OpenSourceSoftwareActivity
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.OpenSourceSoftwareVM
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.widget.OpenSourceSoftwareAdapter
import dagger.Module
import dagger.Provides

@Module
class OpenSourceSoftwareModule {

    @Provides
    fun provideOpenSourceSoftwareAdapter(listener: IOnItemSelected) : OpenSourceSoftwareAdapter {
        return OpenSourceSoftwareAdapter(listener)
    }

    @Provides
    fun provideViewModel(viewModelStoreOwner: ViewModelStoreOwner): OpenSourceSoftwareVM {
        return ViewModelProvider(viewModelStoreOwner).get(OpenSourceSoftwareVM::class.java)
    }

    @Provides
    fun provideLinearLayoutManager(activity: OpenSourceSoftwareActivity) : LinearLayoutManager {
        return LinearLayoutManager(activity)
    }
}