package com.frontier_silicon.fsirc.dok2.nowPlaying.standby;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.databinding.NowPlayingStandbyBinding;

public class NowPlayingStandbyFragment extends BaseFragment implements IChildFragment, IPageSwitchListener {

    public static final String FRAGMENT_TAG = "TAG_NOW_PLAYING_STANDBY_FRAGMENT";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        NowPlayingStandbyBinding binding = DataBindingUtil.inflate(inflater, R.layout.now_playing_standby, container, false);

        binding.setViewModel(new NowPlayingStandbyViewModel());
        binding.textStandby.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.standby_msg, true));
        return binding.getRoot();
    }

    @Override
    public boolean isBackButtonHandledByFragment(boolean upButton) {
        return false;
    }

    @Override
    public void onBackButton() { }

    @Override
    public String getStaticTag() {
        return FRAGMENT_TAG;
    }

    @Override
    public void onFragmentActivated() {
        super.onFragmentActivatedBase();
    }

    @Override
    public void onFragmentDeactivated() {
        super.onFragmentDeactivatedBase();
    }
}
