package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.fragmetns

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.databinding.CaSmartRadioSettingsFragmentBinding

class CASmartRadioSettingsFragment: Fragment() {
    private lateinit var binding: CaSmartRadioSettingsFragmentBinding


        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
            binding = DataBindingUtil.inflate(inflater, R.layout.ca_smart_radio_settings_fragment, container, false)
            binding.smartRadioCheckText.setText(SmartRadioStringsManager.getSmartRadioString(R.string.ca_smart_radio_check, true))
            return binding.root
        }
    }
