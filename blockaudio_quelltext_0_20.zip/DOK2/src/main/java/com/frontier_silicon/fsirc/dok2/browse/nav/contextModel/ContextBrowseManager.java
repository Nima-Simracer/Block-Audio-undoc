package com.frontier_silicon.fsirc.dok2.browse.nav.contextModel;

import com.frontier_silicon.NetRemoteLib.Node.NodeNavContextNumItems;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowsePagesStore;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.PageRetrieverRunnable;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.UnifiedBrowseListItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextBrowseResultEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextCloseEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ContextShowLoadingProgressEvent;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * Created by adanaila on 19/11/2016.
 */
public class ContextBrowseManager extends BrowseManager {
    private static ContextBrowseManager mInstance = null;
    private boolean mShouldActivateContext = true;

    public static ContextBrowseManager getInstance() {
        if (mInstance == null) {
            mInstance = new ContextBrowseManager();
        }

        return mInstance;
    }

    protected ContextBrowseManager() {
        super();

        ConnectionStateUtil.getInstance().addListener(this, false);
        addSpeakerSettingsListener();
    }

    public void CloseContextDialog(boolean shouldRefresh){
        EventBus.getDefault().post(new ContextCloseEvent(shouldRefresh));
    }

    //this is used to identify the type of items inside a contextMenu page based on first item
    //returns -1 if no items in pagesStore
    public int getPageTypeBasedOnItems(){
        //try to get the first item in the page Store.
        BrowseItemModel model = mInstance.mBrowsePagesStore.tryGetBrowseItemModel(0);
        if(model != null)
            return model.getType();
        return -1;
    }

    @Override
    public void refreshCurrentList(final long id) {
        //navigateToCurrentList(true);

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        ContextListAirableRunnable retrieverRunnable = new ContextListAirableRunnable(radio, new ContextListAirableRunnable.IAirableRetrieverListener() {
            @Override
            public void onNavPageRetrieved(List<UnifiedBrowseListItem> listItems, EIRNavigationResult numberOfItemsRetreivedResult) {
                mBrowsePagesStore.clear();
                addNavListToStore(0, listItems);
                ContextBrowseResultEvent resultEvent = new ContextBrowseResultEvent(numberOfItemsRetreivedResult);
                EventBus.getDefault().post(resultEvent);
            }
        });

        mNavigateToCurrentListThread = new Thread(retrieverRunnable);
        mNavigateToCurrentListThread.start();
    }

    @Override
    protected void sendLoadingEvent() {
        EventBus.getDefault().post(new ContextShowLoadingProgressEvent());
    }

    @Override
    public void navigateToDirectory(final Long key) {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        prepareNavigation();

        ContextBrowseRunnable navigateRunnable = new ContextBrowseRunnable(key, mShouldActivateContext,
                radio, new IContextListener() {
            @Override
            public void onNavigationCompleted(EIRNavigationResult result) {
                toggleActivation();
                EventBus.getDefault().post(new ContextBrowseResultEvent(result));
            }
        });

        Thread thread = new Thread(navigateRunnable);
        thread.start();
    }

    @Override
    public void retrieveFirstPageSync(Radio radio, boolean firstPageOnly) {
        ContextPageRetrieverRunnable retrieverRunnable = new ContextPageRetrieverRunnable(
                BrowsePagesStore.DEFAULT_START_KEY_ID, radio, firstPageOnly, new PageRetrieverRunnable.IPageRetrieverListener() {
            @Override
            public void onNavPageRetrieved(List<UnifiedBrowseListItem> listItems) {

                addNavListToStore(0, listItems);
            }
        });

        retrieverRunnable.run();
    }

    @Override
    public EIRNavigationResult retrieveTotalNumberOfItemsFromCurrentListSync(Radio radio) {
        NodeNavContextNumItems nodeNumItems = (NodeNavContextNumItems) radio.nodeSyncGetter(NodeNavContextNumItems.class).get();
        if (nodeNumItems == null) {
            mTotalCountForCurrentList = 0;
            return EIRNavigationResult.TotalItemsNotRetrieved;
        }

        int totalNumber = nodeNumItems.getValue().intValue();
        // TODO lsuhov or adanaila remove totalNumber == 0 when bug on FW is fixed
        if (totalNumber == -1 || totalNumber == 0) {
            mTotalCountForCurrentList = -1;
            return EIRNavigationResult.TotalItemsNotRetrieved;
        }

        mTotalCountForCurrentList = totalNumber;

        return  EIRNavigationResult.Success;
    }

    private void toggleActivation(){
        if(this.mShouldActivateContext)
            this.mShouldActivateContext = false;
    }

    @Override
    public void clearAll() {
        super.clearAll();
        FirebaseCrashlytics.getInstance().log("ContextBrowseManger clearAll");
        this.mShouldActivateContext = true;
    }
}
