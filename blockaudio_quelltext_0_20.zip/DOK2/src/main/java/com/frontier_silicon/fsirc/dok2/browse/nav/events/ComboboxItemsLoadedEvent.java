package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by adanaila on 11/10/2016.
 */

public class ComboboxItemsLoadedEvent {
}
