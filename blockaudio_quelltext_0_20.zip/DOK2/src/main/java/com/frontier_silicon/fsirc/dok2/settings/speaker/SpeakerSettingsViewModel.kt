package com.frontier_silicon.fsirc.dok2.settings.speaker

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.frontier_silicon.NetRemoteLib.Node.BaseSysNetKeepConnected
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetKeepConnected
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse
import com.frontier_silicon.NetRemoteLib.Radio.Radio
import com.frontier_silicon.components.common.CommonPreferences
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences
import kotlinx.coroutines.launch

class SpeakerSettingsViewModel: ViewModel() {
    val keepNetworkConnectedLiveData: MutableLiveData<Boolean> = MutableLiveData()
    val responseStatus: MutableLiveData<KeepNetworkConnectedUIState> = MutableLiveData()


    private var _radio: Radio? = null

    fun setRadio(radio: Radio?) {
        _radio = radio
    }
    fun getNetworkSpeakerConnection() {
        viewModelScope.launch {
            _radio?.let {
                it.getNode(NodeSysNetKeepConnected::class.java, false, object: IGetNodeCallback {
                    override fun getNodeResult(node: NodeInfo?) {
                        val isEnabled = (node as NodeSysNetKeepConnected).valueEnum == BaseSysNetKeepConnected.Ord.YES
                        keepNetworkConnectedLiveData.value = isEnabled
                    }

                    override fun getNodeError(nodeType: Class<*>?, error: NodeErrorResponse?) {
                        keepNetworkConnectedLiveData.value = false
                    }

                })
            }
        }
    }

    fun setNetworkSpeakerConnectionOption(keepConnected: Boolean) {
        if (keepConnected == keepNetworkConnectedLiveData.value) {
            return
        }

        viewModelScope.launch {
            _radio?.let {
                var nodeSysNetKeepConnected: NodeSysNetKeepConnected = if (keepConnected) {
                    NodeSysNetKeepConnected(1)
                } else {
                    NodeSysNetKeepConnected(0)
                }

                it.setNode(nodeSysNetKeepConnected, false, object : ISetNodeCallback {
                    override fun setNodeSuccess(node: NodeInfo?) {
                        responseStatus.value = KeepNetworkConnectedUIState.Success
                        keepNetworkConnectedLiveData.value = keepConnected
                        persistKeepNetworkConnectedOptionInUserPreferences(keepConnected)
                    }

                    override fun setNodeError(node: NodeInfo?, error: NodeErrorResponse?) {
                        responseStatus.value = KeepNetworkConnectedUIState.Error
                    }
                })
            }
        }
    }

    private fun persistKeepNetworkConnectedOptionInUserPreferences(keepNetworkConnected: Boolean) {
        _radio?.let {
                CommonPreferences.getInstance().setKeepNetworkEnabledOption(it.sn, keepNetworkConnected)
        }
    }

}