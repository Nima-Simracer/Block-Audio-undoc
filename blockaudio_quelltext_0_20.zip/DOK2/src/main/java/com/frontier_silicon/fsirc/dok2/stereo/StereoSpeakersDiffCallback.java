package com.frontier_silicon.fsirc.dok2.stereo;

import androidx.recyclerview.widget.DiffUtil;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.stereo.StereoItemModel;

import java.util.List;

/**
 * Created by lsuhov on 04/08/2017.
 */

public class StereoSpeakersDiffCallback extends DiffUtil.Callback {
    List<StereoItemModel> mOldList;
    List<StereoItemModel> mNewList;

    public StereoSpeakersDiffCallback(List<StereoItemModel> oldList, List<StereoItemModel> newList) {
        mOldList = oldList;
        mNewList = newList;
    }

    @Override
    public int getOldListSize() {
        return mOldList.size();
    }

    @Override
    public int getNewListSize() {
        return mNewList.size();
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        StereoItemModel oldItem = mOldList.get(oldItemPosition);
        StereoItemModel newItem = mNewList.get(newItemPosition);

        if (oldItem != null) {
            if (newItem != null) {
                return oldItem.equals(newItem);
            } else {
                return false;
            }
        } else {
            if (newItem != null) {
                return false;
            } else {
                return true;
            }
        }
    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        StereoItemModel oldItem = mOldList.get(oldItemPosition);
        StereoItemModel newItem = mNewList.get(newItemPosition);

        // checking single speakers
        if (newItem.isSpeaker()) {

            return areContentsTheSame(oldItem.deviceModel, newItem.deviceModel);
        }

        // checking groups
        if (oldItem.systemName == null) {
            if (newItem.systemName != null) {
                return false;
            }
        } else if (!oldItem.systemName.equals(newItem.systemName)) {
            return false;
        }

        List<MultiroomDeviceModel> oldDevices = oldItem.deviceModels;
        List<MultiroomDeviceModel> newDevices = newItem.deviceModels;

        if (oldDevices.size() != newDevices.size()) {
            return false;
        }

        // checking group contents
        for (MultiroomDeviceModel oldDevice : oldDevices) {
            MultiroomDeviceModel newDevice = null;

            for (MultiroomDeviceModel newDeviceCandidate : newDevices) {
                if (oldDevice.mMultiroomUDN.equals(newDeviceCandidate.mMultiroomUDN)) {
                    newDevice = newDeviceCandidate;
                    break;
                }
            }

            if (newDevice == null) {
                return false;
            }

            return areContentsTheSame(oldDevice, newDevice);
        }

        return true;
    }

    private boolean areContentsTheSame(MultiroomDeviceModel oldDevice, MultiroomDeviceModel newDevice) {

        if (oldDevice.mGroupRole != newDevice.mGroupRole) {
            return false;
        }

        if (!oldDevice.mFrozenFriendlyName.equals(newDevice.mRadio.getFriendlyName())) {
            return false;
        }

        if (oldDevice.mFrozenIsCheckingAvailability != newDevice.mRadio.isCheckingAvailability()) {
            return false;
        }

        if (oldDevice.mFrozenIsAvailable != newDevice.mRadio.isAvailable()) {
            return false;
        }

        if (!oldDevice.mStereoSystemId.equals(newDevice.mStereoSystemId)) {
            return false;
        }

        if (oldDevice.mStereoRole != newDevice.mStereoRole) {
            return false;
        }

        Radio oldRadio = oldDevice.mRadio;
        Radio newRadio = newDevice.mRadio;

        if (oldRadio == null) {
            if (newRadio != null) {
                return false;
            }
        } else {
            if (newRadio == null) {
                return false;
            }

            return oldRadio.areContentsTheSame(newRadio);
        }

        return true;
    }
}
