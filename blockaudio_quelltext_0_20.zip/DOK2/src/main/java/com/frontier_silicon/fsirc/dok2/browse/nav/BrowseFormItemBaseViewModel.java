package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.databinding.ObservableField;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;

/**
 * Created by lsuhov on 24/10/2016.
 */

public class BrowseFormItemBaseViewModel {
    public ObservableField<String> label = new ObservableField<>();

    protected int mPosition;
    protected FormItem mFormItemBase;

    public BrowseFormItemBaseViewModel(int position, FormItem item) {
        mPosition = position;
        mFormItemBase = item;

        init();
    }

    protected void init() {
        label.set(mFormItemBase.getLabel());
    }

    public void dispose() {
        mFormItemBase = null;
    }
}
