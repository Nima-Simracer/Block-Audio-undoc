package com.frontier_silicon.fsirc.dok2.baseActivity;

import android.app.Activity;
import android.view.KeyEvent;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.volume.UpdateVolumeFromHWButtonsTask;

/**
 * Created by lsuhov on 09/11/2017.
 */

public class VolumeFromHwButtonsWatcher {

    private final static int MIN_VOL_KEY_UPDATE_MS = 100;
    private long mLastVolumeKeyUpdateTime = 0;

    private Activity mActivity;

    VolumeFromHwButtonsWatcher(Activity activity) {
        mActivity = activity;
    }

    public boolean canHandleKey(int keyCode) {
        // Disable volume hard buttons for Cast
        if (SpeakerDataManager.getInstance().getCurrentMode() == NodeSysCapsValidModes.Mode.Cast)
            return false;

        if (!NetRemoteManager.getInstance().checkConnection()) {
            return false;
        }

        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false;
        }

        return (System.currentTimeMillis() - mLastVolumeKeyUpdateTime) >= MIN_VOL_KEY_UPDATE_MS;
    }

    public void startVolumeUpdateTask(int keyCode) {

        UpdateVolumeFromHWButtonsTask updateVolTask = new UpdateVolumeFromHWButtonsTask(mActivity, keyCode);
        TaskHelper.execute(updateVolTask);

        mLastVolumeKeyUpdateTime = System.currentTimeMillis();
    }

    public void dispose() {
        mActivity = null;
    }
}
