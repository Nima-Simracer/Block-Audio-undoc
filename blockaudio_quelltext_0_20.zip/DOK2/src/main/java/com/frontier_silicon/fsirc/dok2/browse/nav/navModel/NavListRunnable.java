package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import com.frontier_silicon.NetRemoteLib.Node.BaseNavList;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.UnifiedBrowseListItem;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 30/06/16.
 */

public class NavListRunnable implements Runnable {
    public interface INavListRetrieverListener {
        void onNavPageRetrieved(List<UnifiedBrowseListItem> listItems,EIRNavigationResult numberOfItemsRetreivedResult );
    }

    private Radio mRadio;
    private INavListRetrieverListener mListener;

    public NavListRunnable(Radio radio, INavListRetrieverListener listener) {
        mRadio = radio;
        this.mListener = listener;
    }

    @Override
    public void run() {
        FsLogger.log("NavListRunnable runnable started ", LogLevel.Info);
        if (mRadio == null) {
            return;
        }

        String startKey = "" + -1;
        ArrayList<UnifiedBrowseListItem> navList = new ArrayList<>();
        List<BaseNavList.ListItem> returnedNavList = RadioNavigationUtil.getInstance().getNavList(mRadio, startKey, true);

        EIRNavigationResult retrieveTotalNumberOfItemsResult = NavBrowseManager.getInstance().retrieveTotalNumberOfItemsFromCurrentListSync(mRadio);

        if (returnedNavList == null) {
            returnedNavList = new ArrayList<>();
        }

        for (BaseNavList.ListItem li: returnedNavList) {
            navList.add(new UnifiedBrowseListItem(li));
        }

        if (mListener != null) {
            mListener.onNavPageRetrieved(navList, retrieveTotalNumberOfItemsResult);
        }

        dispose();
    }

    private void dispose() {
        mRadio = null;
    }
}
