package com.frontier_silicon.fsirc.dok2.browse.nav.navAirable;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.common.UnifiedFormListItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormRetrieverRunnable;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;

public class NavFormRetrieverRunnable extends FormRetrieverRunnable{

    public NavFormRetrieverRunnable(Radio radio, INavFormRetrieverListener listener) {
        super(radio, listener);
    }

    @Override
    public void run() {
        FsLogger.log("form retriever runnable started ", LogLevel.Info);

        ArrayList<UnifiedFormListItem> formItemNode = RadioNavigationUtil.getNavFormList(mRadio);

        if (formItemNode != null) {
            sendNavListToListener(formItemNode);
        }
        dispose();
    }
}
