package com.frontier_silicon.fsirc.dok2.setup.speakerName;

import android.app.Activity;
import androidx.databinding.ObservableField;
import android.text.TextUtils;

import com.frontier_silicon.components.common.ErrorSanitizerMessageType;
import com.frontier_silicon.components.common.FriendlyNameSanitizer;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.databinding.SetupNameYourSpeakerActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.clock.ConfigureClockActivity;
import com.frontier_silicon.fsirc.dok2.setup.connectionType.SelectConnectionTypeActivity;
import com.frontier_silicon.fsirc.dok2.setup.language.ConfigureLanguageActivity;
import com.frontier_silicon.fsirc.dok2.util.FriendlyNameSanitizerErrorHandler;

/**
 * Created by nbalazs on 08/03/2018.
 *
 */

public final class NameYourSpeakerActivityVM implements FriendlyNameSanitizer.IFriendlyNameSanitizerListener{

    private Activity mActivity;
    private SetupNameYourSpeakerActivityBinding mBinding;
    private FriendlyNameSanitizerErrorHandler mErrorHandler;

    public ObservableField<Boolean> isRetrievingFriendlyName = new ObservableField<>(true);

    NameYourSpeakerActivityVM(Activity activity, SetupNameYourSpeakerActivityBinding binding) {
        mActivity = activity;
        mBinding = binding;
        mErrorHandler = new FriendlyNameSanitizerErrorHandler(SetupManager.getInstance().getIsCastSupported() ?
                FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME_WHEN_GOOGLE_CAST_IS_PRESENT : FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME);
    }

    @Override
    public void onSubmitFriendlyName(String friendlyName) {
        onFriendlyNameConfigured();
    }

    @Override
    public void onNewFriendlyName(String friendlyName) {
        SetupManager.getInstance().setFriendlyName(friendlyName);
    }

    @Override
    public void onBadFriendlyName(ErrorSanitizerMessageType errorMessageType) {
        mErrorHandler.handleMessageErrorType(mActivity, errorMessageType, mBinding.editTextFriendlyName);
    }

    void retrieveFriendlyName() {
        isRetrievingFriendlyName.set(true);

        SetupManager.getInstance().getRadioFriendlyNameAsync(friendlyName -> {
            mBinding.editTextFriendlyName.setText(friendlyName);
            mBinding.editTextFriendlyName.setEnabled(true);
            mBinding.editTextFriendlyName.requestFocus();
            mBinding.editTextFriendlyName.selectAll();

            isRetrievingFriendlyName.set(false);

            GuiUtils.showKeyboardForGivenEditText(mBinding.editTextFriendlyName, mActivity);
        });
    }

    public void onBackPressed() {
        mActivity.onBackPressed();
    }

    public void onNextPressed() {
        onFriendlyNameConfigured();
    }

    private void onFriendlyNameConfigured() {
        String friendlyName = mBinding.editTextFriendlyName.getText().toString().trim();
        if (TextUtils.isEmpty(friendlyName)) {
            return;
        }

        Boolean mDateTimeSetupIsSupported = SetupManager.getInstance().getDateAndTimeSetupIsSupported();
        if (mDateTimeSetupIsSupported != null && mDateTimeSetupIsSupported) {
            NavigationHelper.goToActivity(mActivity, ConfigureClockActivity.class, NavigationHelper.AnimationType.SlideToLeft);
            return;
        } else {
            Boolean mLanguageIsSupported = SetupManager.getInstance().getLanguageIsSupported();
            if (mLanguageIsSupported != null && mLanguageIsSupported) {
                NavigationHelper.goToActivity(mActivity, ConfigureLanguageActivity.class, NavigationHelper.AnimationType.SlideToLeft);
                return;
            }
        }

        NavigationHelper.goToActivity(mActivity, SelectConnectionTypeActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }
}