package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

/**
 * Created by lsuhov on 30/06/16.
 */

public interface IBrowseItemModelRetrieveListener {
    void onBrowseItemModelRetrieved(BrowseItemModel itemModel);
}
