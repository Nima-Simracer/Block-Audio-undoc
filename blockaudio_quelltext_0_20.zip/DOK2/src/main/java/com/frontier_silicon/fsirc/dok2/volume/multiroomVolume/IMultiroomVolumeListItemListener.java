package com.frontier_silicon.fsirc.dok2.volume.multiroomVolume;

import com.frontier_silicon.components.multiroom.MultiroomVolumeModel;

public interface IMultiroomVolumeListItemListener {

	void onVolumeChange(MultiroomVolumeModel item, boolean forceUpdate);
	void onMuteChange(MultiroomVolumeModel item);
    void onEqualizerBtnClick(MultiroomVolumeModel item);
}
