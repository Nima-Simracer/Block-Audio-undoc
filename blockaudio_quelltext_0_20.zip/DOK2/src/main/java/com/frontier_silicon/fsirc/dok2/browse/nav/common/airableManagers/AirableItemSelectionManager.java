package com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers;

import androidx.databinding.Observable;
import android.view.View;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ResetFormManagerEvent;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by adanaila on 09/12/2016.
 */

public class AirableItemSelectionManager {
    private List<View> itemsOnPage;
    private static AirableItemSelectionManager mInstance;

    public static AirableItemSelectionManager getInstance() {
        if (mInstance == null) {
            mInstance = new AirableItemSelectionManager();
        }

        return mInstance;
    }

    protected AirableItemSelectionManager() {
        this.itemsOnPage = new ArrayList<>();
        EventBus.getDefault().register(this);

        addSpeakerSettingsListener();
    }

    private void addSpeakerSettingsListener() {
        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();

        speakerDataModel.currentMode.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                clearItemsCached();
            }
        });
    }

    @Subscribe
    public void onBackPressedWhileBrowseEventTriggered(ResetFormManagerEvent event) {
        clearItemsCached();
    }

    public void addSelectableItem(View item){
        this.itemsOnPage.add(item);
    }

    public void selectNextItemOnPage(View currentItem){
        int currentItemPosition = this.itemsOnPage.lastIndexOf(currentItem);
        if(currentItemPosition >= 0 && currentItemPosition + 1 < itemsOnPage.size()){
            this.itemsOnPage.get(currentItemPosition + 1).requestFocus();
            this.itemsOnPage.get(currentItemPosition + 1).setSelected(true);
        }
    }

    private void clearItemsCached(){
        this.itemsOnPage.clear();
    }
}
