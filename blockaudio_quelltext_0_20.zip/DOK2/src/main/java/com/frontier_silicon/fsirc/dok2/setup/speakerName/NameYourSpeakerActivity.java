package com.frontier_silicon.fsirc.dok2.setup.speakerName;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.components.common.FriendlyNameSanitizer;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupNameYourSpeakerActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;

/**
 * Created by nbalazs on 07/03/2018.
 *
 */

public class NameYourSpeakerActivity extends SetupActivityBase {

    private SetupNameYourSpeakerActivityBinding mBinding;
    private NameYourSpeakerActivityVM mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.setup_name_your_speaker_activity);

        mViewModel = new NameYourSpeakerActivityVM(this, mBinding);

        mBinding.setViewModel(mViewModel);

        configureToolbarWithExitButton(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_title_name_of_device, true));

        init();
    }

    @Override
    protected void onStart() {
        super.onStart();
        enableRadioConnectionCallbackAndWiFiMonitor();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mViewModel.retrieveFriendlyName();
    }

    private void init() {
        mBinding.editTextFriendlyName.setSaveEnabled(false);
        mBinding.editTextFriendlyName.setHint(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.friendly_name_hint, true));
        mBinding.textViewFriendlyNameInfo.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.friendly_name_info, true));

        int maxLengthOfFriendlyName = SetupManager.getInstance().getIsCastSupported() ?
                FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME_WHEN_GOOGLE_CAST_IS_PRESENT : FsComponentsConfig.MAX_LENGTH_OF_FRIENDLY_NAME;

        FriendlyNameSanitizer friendlyNameSanitizer = new FriendlyNameSanitizer(maxLengthOfFriendlyName);
        friendlyNameSanitizer.appendSanitizerToEditText(mBinding.editTextFriendlyName, this, mViewModel);
    }
}
