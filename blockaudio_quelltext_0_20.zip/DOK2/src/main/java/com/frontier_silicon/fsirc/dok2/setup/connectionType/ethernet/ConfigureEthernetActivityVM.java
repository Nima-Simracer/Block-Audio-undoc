package com.frontier_silicon.fsirc.dok2.setup.connectionType.ethernet;

import android.app.Activity;
import androidx.databinding.ObservableField;
import android.text.TextUtils;
import android.widget.CompoundButton;
import android.widget.EditText;

import com.frontier_silicon.components.setup.RadioNetworkConfig.EConnectionType;
import com.frontier_silicon.components.setup.RadioNetworkConfig.RadioNetworkConfigParams;
import com.frontier_silicon.components.setup.RadioNetworkConfig.StaticIPAddressesParam;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SetupConfigureEthernetActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.finishing.FinishingSetupActivity;

/**
 * Created by nbalazs on 08/03/2018.
 *
 */

public class ConfigureEthernetActivityVM implements CompoundButton.OnCheckedChangeListener{

    private Activity mActivity;

    private SetupConfigureEthernetActivityBinding mBinding;

    public ObservableField<Boolean> isStaticIPLayoutVisible = new ObservableField<>(false);

    ConfigureEthernetActivityVM(Activity activity, SetupConfigureEthernetActivityBinding binding) {
        mActivity = activity;
        mBinding = binding;

        init();
    }

    private void init() {
        mBinding.compoundButton.setOnCheckedChangeListener(this);
        mBinding.compoundButton.setChecked(true);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        isStaticIPLayoutVisible.set(!isChecked);
    }

    public void onNextPressed() {
        SetupManager.getInstance().setIsWiFiSetup(false);
        SetupManager.getInstance().setIsEthernetSetup(true);

        updateConfigParams();
        NavigationHelper.goToActivity(mActivity, FinishingSetupActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    public void onBackPressed() {
        mActivity.onBackPressed();
    }

    private void updateConfigParams() {
        RadioNetworkConfigParams configParams = new RadioNetworkConfigParams();
        configParams.mConnectionType = EConnectionType.Ethernet;

        if (mBinding.compoundButton.isChecked()) {
            configParams.mUseDhcp = true;
        } else {
            EditText mEditTextIP = mBinding.staticIPLayout.findViewById(R.id.editTextIP);
            EditText mEditTextGatewayIP = mBinding.staticIPLayout.findViewById(R.id.editTextGatewayIP);
            EditText mEditTextSubnetMask = mBinding.staticIPLayout.findViewById(R.id.editTextSubnetMask);
            EditText mEditTextPrimaryDNS = mBinding.staticIPLayout.findViewById(R.id.editTextPrimaryDNS);
            EditText mEditTextSecondaryDNS = mBinding.staticIPLayout.findViewById(R.id.editTextSecondaryDNS);

            String ip = mEditTextIP.getText().toString();
            String gateway = mEditTextGatewayIP.getText().toString();
            String subnet = mEditTextSubnetMask.getText().toString();
            String dns1 = mEditTextPrimaryDNS.getText().toString();
            String dns2 = mEditTextSecondaryDNS.getText().toString();

            boolean isMissingMandatoryIP = (TextUtils.isEmpty(ip) || TextUtils.isEmpty(gateway) || TextUtils.isEmpty(subnet));
            if (!isMissingMandatoryIP) {
                StaticIPAddressesParam staticIPAdresses = new StaticIPAddressesParam();
                staticIPAdresses.mIPAdress = ip;
                staticIPAdresses.mGatewayAdress = gateway;
                staticIPAdresses.mSubnetMask = subnet;
                staticIPAdresses.mPrimaryDNSAdress = dns1;
                staticIPAdresses.mSecondaryDNSAdress = dns2;

                configParams.mUseDhcp = false;
                configParams.mStaticIPAdresses = staticIPAdresses;
            }
        }

        SetupManager.getInstance().setNetworkConfigParams(configParams);
    }
}
