package com.frontier_silicon.fsirc.dok2.presets.bottomFragment

import com.frontier_silicon.fsirc.dok2.presets.PresetItemModel

interface IBottomFragment {
    fun onReplace(presetItem: PresetItemModel)
    fun onEdit(presetItem: PresetItemModel)
    fun onDelete(presetItem: PresetItemModel)
    fun onSwap(presetItem: PresetItemModel)
}