package com.frontier_silicon.fsirc.dok2.browse.bluetooth.settings;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import android.content.Context;
import androidx.databinding.ObservableField;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothConnectedDevices;
import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothDiscoverableState;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.bluetooth.BrowseBluetoothManager;
import com.frontier_silicon.fsirc.dok2.browse.bluetooth.IBrowseBluetoothNodesListener;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.List;

public class BluetoothSettingsViewModel implements LifecycleObserver {

    public ObservableField<String> bluetoothStatus = new ObservableField<>();

    private Lifecycle mLifecycle;
    private IBrowseBluetoothNodesListener mListener;
    private BluetoothArrayAdapter mAdapter;

    public BluetoothSettingsViewModel(Lifecycle lifecycle, BluetoothArrayAdapter adapter) {
        mLifecycle = lifecycle;
        mAdapter = adapter;

        lifecycle.addObserver(this);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    public void onResume() {
        updateInformation();
    }

    private void updateInformation() {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        mListener = nodes -> {
            NodeBluetoothDiscoverableState state = (NodeBluetoothDiscoverableState)
                    nodes.get(NodeBluetoothDiscoverableState.class);

            List<NodeBluetoothConnectedDevices.ListItem> connectedDevicesList =
                    (List<NodeBluetoothConnectedDevices.ListItem>)nodes.get(NodeBluetoothConnectedDevices.class);

            Context context = MainApplication.getContext();

            if (state == null) {
                bluetoothStatus.set(context.getString(R.string.bluetooth_unavailable_status));
            } else {

                if (connectedDevicesList != null) {
                    boolean connectedDeviceFound = false;
                    for (NodeBluetoothConnectedDevices.ListItem deviceListItem : connectedDevicesList) {
                        if (deviceListItem.getDeviceState() == NodeListItem.DeviceState.Connected) {

                            FsLogger.log("paired with: " + deviceListItem.getDeviceName());
                            bluetoothStatus.set(MainApplication.getContext().getString(R.string.bluetooth_connected));
                            connectedDeviceFound = true;
                            break;
                        }
                    }

                    if (!connectedDeviceFound) {
                        updateBluetoothStateBasedOnNodeDiscoverableState(state);
                    }
                } else {
                    updateBluetoothStateBasedOnNodeDiscoverableState(state);
                }
            }

            mAdapter.newDataAvailable();
        };

        BrowseBluetoothManager.getInstance().addListenerAndRetrieveResults(radio, mListener);
    }

    private void updateBluetoothStateBasedOnNodeDiscoverableState(NodeBluetoothDiscoverableState nodeState) {
        if (nodeState.getValueEnum() == NodeBluetoothDiscoverableState.Ord.DISCOVERABLE) {

            bluetoothStatus.set(MainApplication.getContext().getString(R.string.bluetooth_discoverable));
        } else {
            bluetoothStatus.set(MainApplication.getContext().getString(R.string.bluetooth_idle));
        }
    }

    public void onPairClicked(View v) {
        BrowseBluetoothManager.getInstance().pair();
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    public void onPause() {
        BrowseBluetoothManager.getInstance().removeListener(mListener);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void dispose() {
        if (mLifecycle != null) {
            mLifecycle.removeObserver(this);
            mLifecycle = null;
        }

        mListener = null;
        mAdapter = null;
    }
}
