package com.frontier_silicon.fsirc.dok2.settings.sleepTimer

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.frontier_silicon.NetRemoteLib.Node.NodeSysSleep
import com.frontier_silicon.NetRemoteLib.Radio.Radio
import com.frontier_silicon.components.common.RadioNodeUtil

class SleepTimerViewModel : ViewModel() {
    lateinit var radio : Radio

    val sleepTimer: MutableLiveData<Boolean> by lazy {
        MutableLiveData<Boolean>().also {
            checkIfSleepTimerActive()
        }
    }

    fun getSleepTimerSeconds(): Long {
        var seconds: Long = 0

        if (radio != null) {
            val sleepNode = radio.nodeSyncGetter(NodeSysSleep::class.java).get()
            if (sleepNode != null) {
                seconds = (sleepNode as NodeSysSleep).value!!
            }
        }

        return seconds
    }

     fun checkIfSleepTimerActive() {
        if (!this::radio.isInitialized) {
            return
        }

        RadioNodeUtil.getNodeFromRadioAsync(radio, NodeSysSleep::class.java) { node ->
            if (node == null) {
                return@getNodeFromRadioAsync
            }

            val sleepNode = node as NodeSysSleep
            if (sleepNode != null) {
                sleepTimer.value = sleepNode.value > 0
            }
        }
    }
}