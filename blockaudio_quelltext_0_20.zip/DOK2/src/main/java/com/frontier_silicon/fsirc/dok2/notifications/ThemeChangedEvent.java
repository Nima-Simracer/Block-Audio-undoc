package com.frontier_silicon.fsirc.dok2.notifications;

public class ThemeChangedEvent {
}
