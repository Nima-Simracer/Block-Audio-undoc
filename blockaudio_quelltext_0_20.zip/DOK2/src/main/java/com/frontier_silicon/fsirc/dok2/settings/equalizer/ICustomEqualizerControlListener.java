package com.frontier_silicon.fsirc.dok2.settings.equalizer;

public interface ICustomEqualizerControlListener {

	void onValueChange(CustomEqualizerItemModel item);
	void onLoudnessValueChange(boolean isEnabled);
	
}
