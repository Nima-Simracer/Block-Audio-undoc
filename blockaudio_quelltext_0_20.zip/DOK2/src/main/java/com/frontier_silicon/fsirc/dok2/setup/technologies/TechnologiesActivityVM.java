package com.frontier_silicon.fsirc.dok2.setup.technologies;

import android.app.Activity;

import androidx.databinding.ObservableBoolean;

import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.fsdca.SetupFSDCAAssociationActivity;
import com.frontier_silicon.fsirc.dok2.setup.setupdone.SetupDoneActivity;

/**
 * Created by nbalazs on 22/03/2018.
 */

public class TechnologiesActivityVM {

    private Activity mActivity;

    public ObservableBoolean isCastSupported = new ObservableBoolean(false);
    public ObservableBoolean isSpotifySupported = new ObservableBoolean(false);
    public ObservableBoolean isBluetoothSupported = new ObservableBoolean(false);

   // public ObservableBoolean is3PdaSupported = new ObservableBoolean(false);
    public ObservableBoolean isAvsSupported = new ObservableBoolean(false);

    TechnologiesActivityVM(Activity activity) {
        mActivity = activity;

        SetupManager setupManager = SetupManager.getInstance();
        isCastSupported.set(setupManager.getIsCastSupported());
        isSpotifySupported.set(setupManager.getIsSpotifySupported());
        isBluetoothSupported.set(setupManager.getIsBluetoothSupported());
        // is3PdaSupported.set(setupManager.getIs3PdaSupported());
        isAvsSupported.set(setupManager.getIsAvsSupported());
    }

    public void onNextPressed() {
        NavigationHelper.goToActivity(mActivity, SetupDoneActivity.class);
    }
}
