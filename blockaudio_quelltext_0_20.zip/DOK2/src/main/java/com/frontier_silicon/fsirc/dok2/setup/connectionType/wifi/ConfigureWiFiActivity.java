package com.frontier_silicon.fsirc.dok2.setup.connectionType.wifi;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SetupConfigureWifiActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;


/**
 * Created by nbalazs on 08/03/2018.
 *
 */

public class ConfigureWiFiActivity extends SetupActivityBase {

    private ConfigureWiFiActivityVM mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetupConfigureWifiActivityBinding mBinding = DataBindingUtil.setContentView(this, R.layout.setup_configure_wifi_activity);

        mViewModel = new ConfigureWiFiActivityVM(this, mBinding);

        mBinding.setViewModel(mViewModel);

        configureToolbarWithExitButton(R.string.setup_title_wifi);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
    }

    @Override
    protected void onStart() {
        super.onStart();
        enableRadioConnectionCallbackAndWiFiMonitor();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mViewModel.onActivityResumed();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_refresh_auto_manual, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (mViewModel.isManualWifiConfigShowing()){
            menu.findItem(R.id.action_auto_setup).setVisible(true);
            menu.findItem(R.id.action_manual_setup).setVisible(false);
        } else {
            menu.findItem(R.id.action_auto_setup).setVisible(false);
            menu.findItem(R.id.action_manual_setup).setVisible(true);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_rescan) {
            mViewModel.onRefreshTriggered();
            return true;
        }

        if (id == R.id.action_manual_setup) {
            mViewModel.showManualWiFiConfig(true);
            invalidateOptionsMenu();
            return true;
        }

        if (id == R.id.action_auto_setup) {
            mViewModel.showManualWiFiConfig(false);
            invalidateOptionsMenu();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
