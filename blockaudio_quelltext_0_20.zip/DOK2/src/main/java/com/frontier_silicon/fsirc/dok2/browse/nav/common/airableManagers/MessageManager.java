package com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.messageItems.MessageItem;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by adanaila on 10/4/2016.
 */

public abstract class MessageManager {
    private final int corePoolSize = 0;
    private final int maxPoolSize = 1;
    // Sets the amount of time an idle thread waits before terminating
    private final int KEEP_ALIVE_TIME = 1;
    // Sets the Time Unit to seconds
    private final TimeUnit KEEP_ALIVE_TIME_UNIT = TimeUnit.SECONDS;
    private BlockingQueue<Runnable> mNavigationRunnablesQueue = new LinkedBlockingQueue<>(15);
    protected ExecutorService mThreadPoolExecutor;

    protected MessageManager() {

        mThreadPoolExecutor = new ThreadPoolExecutor(corePoolSize, maxPoolSize, KEEP_ALIVE_TIME,
                KEEP_ALIVE_TIME_UNIT, mNavigationRunnablesQueue, new RejectedExecutionHandler() {
            @Override
            public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
                FsLogger.log("BrowsePagesStore: thread execution was rejected", LogLevel.Error);
            }
        });
    }

    public MessageItem getItem(BrowseItemModel navItem) {
        if(navItem!= null) {
            MessageItem item = new MessageItem(navItem.getKey(),
                    navItem.getSubType(),
                    navItem.getName());
            return item;
        }
        return null;
    }

    public abstract void sendMessageData(long id);

    protected void clearItemsLoaded() {
        //TODO if needed
    }
}
