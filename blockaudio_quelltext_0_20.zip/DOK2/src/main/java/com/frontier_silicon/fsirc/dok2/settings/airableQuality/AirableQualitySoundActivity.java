package com.frontier_silicon.fsirc.dok2.settings.airableQuality;

/**
 * Created by hcostescu on 11/3/2016.
 */
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioAirableQuality;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.RadioFromBundleExtractor;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.CustomEqualizerItemModel;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.EqualizerArrayAdapter;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.EqualizerItemModel;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.ICustomEditListener;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.ICustomEqualizerControlListener;

import java.util.ArrayList;

public class AirableQualitySoundActivity extends UndokActivityBase implements ICustomEditListener,
        IAirableQualitySoundListener, ICustomEqualizerControlListener {

    private EqualizerArrayAdapter mAdapter;
    private ListView mListView;
    private ArrayList<EqualizerItemModel> mAirableQualitySoundItemsList;
    private AirableSoundQualityUtil mAirableSoundQualityUtil;
    private Radio mClientRadio;
    private INodeNotificationCallback mSoundQualityNotifCallback;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_airable_sound_quality_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.airable_quality);

        Bundle bundle = getIntent().getExtras();
        mClientRadio = RadioFromBundleExtractor.extractRadio(bundle, AirableQualitySoundActivity.class);

        setupControls();

        // Get sound quality
        if (mAirableSoundQualityUtil == null) {
            mAirableSoundQualityUtil = new AirableSoundQualityUtil();
            mAirableSoundQualityUtil.addListener(this);
        }

        mAirableSoundQualityUtil.setClientRadio(mClientRadio);
        mAirableSoundQualityUtil.checkWhichNodeShouldBeUsed();

        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
        addUdnToSpeakerLostWatcher(bundle.getString(NavigationHelper.RADIO_UDN_ARG));
    }

    @Override
    public void onResume() {
        super.onResume();

        fragmentInitialize();
    }

    @Override
    public void onPause() {
        super.onPause();
        unregisterAirableSoundQualityNotifCallback();
    }

    @Override
    protected void onDestroy() {
        mClientRadio = null;
        mAirableSoundQualityUtil.dispose();
        mSoundQualityNotifCallback = null;

        super.onDestroy();
    }

    private void fragmentInitialize() {
        registerAirableSoundQualityNotifCallback();
    }

    private void registerAirableSoundQualityNotifCallback() {
        if (NetRemoteManager.getInstance().checkConnection()) {

            unregisterAirableSoundQualityNotifCallback();

            mSoundQualityNotifCallback = new INodeNotificationCallback() {
                @Override
                public void onNodeUpdated(NodeInfo node) {
                    if (node instanceof NodeSysAudioAirableQuality) {
                        mAirableSoundQualityUtil.setAirableSoundQuality(((NodeSysAudioAirableQuality)node).getValue());
                    }
                }
            };

            Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
            if (NetRemoteManager.getInstance().checkConnection() && radio != null) {
                radio.addNotificationListener(mSoundQualityNotifCallback);
            }
        }
    }

    public void unregisterAirableSoundQualityNotifCallback() {
        if (NetRemoteManager.getInstance().checkConnection()) {
            if (mSoundQualityNotifCallback != null) {
                NetRemoteManager.getInstance().getCurrentRadio().removeNotificationListener(mSoundQualityNotifCallback);
                mSoundQualityNotifCallback = null;
            }
        }
    }

    private void setupControls() {
        mAirableQualitySoundItemsList = new ArrayList<>();
        mAirableQualitySoundItemsList.add(new EqualizerItemModel(getString(R.string.airable_quality_low),false,false,0));
        mAirableQualitySoundItemsList.add(new EqualizerItemModel(getString(R.string.airable_quality_normal),true,false,1));
        mAirableQualitySoundItemsList.add(new EqualizerItemModel(getString(R.string.airable_quality_high),false,false,2));

        mAdapter = new EqualizerArrayAdapter(this, R.layout.equalizer_list_item ,R.id.text1,mAirableQualitySoundItemsList, this,this);
        mListView = findViewById(R.id.equalizersList);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                onListItemClick(position);
            }
        });

    }

    protected void onListItemClick(int position) {
        try {
            EqualizerItemModel eqItem = mAdapter.getItem(position);
            setEqualizer(eqItem);
        } catch (Exception e) {
        }
    }

    private void setEqualizer(EqualizerItemModel eqItem) {
        onAirableQualitySoundUpdate(eqItem.mKeyId);
        // Send value to speaker
        mAirableSoundQualityUtil.setAirableSoundQuality(eqItem.mKeyId);
    }

    @Override
    public void onListItemClick(EqualizerItemModel item)
   {
       setEqualizer(item);
   }

    @Override
    public void onValueChange(CustomEqualizerItemModel item){}

    @Override
    public void onLoudnessValueChange(boolean isEnabled){}

    @Override
    public void onAirableQualitySoundUpdate(Long keyId) {
        if (keyId != null && mAdapter != null) {
            for (EqualizerItemModel eqItem : mAirableQualitySoundItemsList) {
                if (eqItem.mKeyId == keyId) {
                    eqItem.mIsSet = true;
                } else {
                    eqItem.mIsSet = false;
                }
            }
            mAdapter.notifyDataSetChanged();
        }
    }
}
