package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by lsuhov on 20/10/2016.
 */

public class ShowLoadingProgressEvent {}
