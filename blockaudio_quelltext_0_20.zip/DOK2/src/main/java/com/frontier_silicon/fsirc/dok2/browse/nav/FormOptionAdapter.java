package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormComboboxOption;

import java.util.List;

public class FormOptionAdapter extends ArrayAdapter<FormComboboxOption> {
    LayoutInflater inflater;

    public FormOptionAdapter(@NonNull Context context, int resource, @NonNull List<FormComboboxOption> objects) {
        super(context, resource, objects);
        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        FormComboboxOption option = getItem(position);
        View view = inflater.inflate(R.layout.form_spinner_item, null, true);
        TextView optionName = view.findViewById(R.id.optionName);

        if (option.isSelected()) {
            optionName.setTypeface(null, Typeface.BOLD);
        } else {
            optionName.setTypeface(null, Typeface.NORMAL);
        }

        optionName.setText(option.name);
        return view;
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        FormComboboxOption option = getItem(position);
        View view = inflater.inflate(R.layout.form_spinner_item, null, true);
        TextView optionName = view.findViewById(R.id.optionName);
        if (option.isSelected()) {
            optionName.setTypeface(null, Typeface.BOLD);
        } else {
            optionName.setTypeface(null, Typeface.NORMAL);
        }
        optionName.setText(option.name);
        return view;
    }
}