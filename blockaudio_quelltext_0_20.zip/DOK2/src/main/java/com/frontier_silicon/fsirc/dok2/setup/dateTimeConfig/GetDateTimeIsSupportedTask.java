package com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig;

import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsUtcSettingsList;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 5/12/2015.
 */
public class GetDateTimeIsSupportedTask extends AsyncTask<Void, Integer, Boolean> {

    private List<IDateTimeCapsListener> mListeners = new ArrayList<>();
    private Radio mRadio;

    public GetDateTimeIsSupportedTask(Radio radio, IDateTimeCapsListener dateTimeCapsListener) {
        setInterfaceListener(dateTimeCapsListener);
        mRadio = radio;
    }

    @Override
    protected Boolean doInBackground(Void... params) {
        boolean isDateTimeSupported = false;

        if (mRadio != null) {
            NodeSysCapsClockSourceList clockSourceList = (NodeSysCapsClockSourceList) mRadio.
                    nodeSyncGetter(NodeSysCapsClockSourceList.class, true).get();

            List<NodeSysCapsUtcSettingsList.ListItem> utcList = mRadio.nodeListSyncGetter(NodeSysCapsUtcSettingsList.class).get();

            if (clockSourceList != null) {
                notifyOnDateTimeCapsUpdated(clockSourceList, utcList);
                isDateTimeSupported = true;
            }
        }

        return isDateTimeSupported;
    }

    @Override
    protected void onPostExecute(Boolean dateTimeIsSupported) {
        notifyOnDateTimeSupported(dateTimeIsSupported);

        mListeners.clear();
        mRadio = null;
        SetupManager.getInstance().removeDateAndTimeIsSupportedTask();
    }

    private void notifyOnDateTimeSupported(Boolean dateTimeIsSupported) {
        for (int i = 0; i < mListeners.size(); i++) {
            IDateTimeCapsListener listener = mListeners.get(i);
            listener.onDateTimeSupportUpdate(dateTimeIsSupported);
        }
    }

    private void notifyOnDateTimeCapsUpdated(NodeSysCapsClockSourceList clockSourceList, List<NodeSysCapsUtcSettingsList.ListItem> utcTimeZoneList) {
        for (int i = 0; i < mListeners.size(); i++) {
            IDateTimeCapsListener listener = mListeners.get(i);
            listener.onDateTimeCapsUpdate(clockSourceList, utcTimeZoneList);
        }
    }

    public void setInterfaceListener(IDateTimeCapsListener dateTimeCapsListener) {
        if (dateTimeCapsListener != null)
            mListeners.add(dateTimeCapsListener);
    }
}
