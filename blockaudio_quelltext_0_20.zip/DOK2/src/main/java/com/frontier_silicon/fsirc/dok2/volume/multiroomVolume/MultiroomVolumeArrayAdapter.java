package com.frontier_silicon.fsirc.dok2.volume.multiroomVolume;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.frontier_silicon.components.multiroom.MultiroomVolumeModel;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.R;

import java.util.List;

public class MultiroomVolumeArrayAdapter extends ArrayAdapter<MultiroomVolumeModel> {

	private Context mContext;
	protected IMultiroomVolumeListItemListener mListener;

    public MultiroomVolumeArrayAdapter(Context context, int textViewResourceId, List<MultiroomVolumeModel> objects, IMultiroomVolumeListItemListener listener) {
        super(context, textViewResourceId, objects);       
        
        mContext = context;
        mListener = listener;
    }
    
    @SuppressLint("InflateParams")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
    	View v = convertView;
		LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		final MultiroomVolumeModel volumeItem = getItem(position);
		
		if (v == null)
			v = li.inflate(R.layout.multiroom_list_item_volume, null);
			
		String text = volumeItem.mRadioFriendlyName;
		int volume = volumeItem.mVolume;
		
		TextView tv = (TextView) v.findViewById(R.id.textRadioName);
		tv.setText(text);
		
		SeekBar volSeekBar = (SeekBar) v.findViewById(R.id.seekBarVolume);

		volSeekBar.setOnSeekBarChangeListener(null);
		volSeekBar.setProgress(volume);
		
		volSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				volumeItem.mInTouchMode = false;
				
				notifyListenerOnVolumeChange(volumeItem, true);
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				volumeItem.mInTouchMode = true;
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				boolean muteChanged = false;
				volumeItem.mVolume = progress;
				
				if (volumeItem.mMute)
					muteChanged = true;
				
				volumeItem.mMute = false;
				
				if (fromUser)
					notifyListenerOnVolumeChange(volumeItem, false);
				
				if (muteChanged)
					MultiroomVolumeArrayAdapter.this.notifyDataSetChanged();
			}
		});

        final ImageButton muteButton = (ImageButton)v.findViewById(R.id.buttonMute);

        muteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                volumeItem.mMute = !volumeItem.mMute;
                updateStateOfMuteButton(volumeItem, muteButton);
                notifyListenerOnMuteChange(volumeItem);
            }
        });

        updateStateOfMuteButton(volumeItem, muteButton);

		v.setEnabled(!volumeItem.mSyncEnabled);
		volSeekBar.setEnabled(!volumeItem.mSyncEnabled);
		tv.setEnabled(!volumeItem.mSyncEnabled);
        muteButton.setEnabled(!volumeItem.mSyncEnabled);

        ImageButton equalizerBtn = (ImageButton) v.findViewById(R.id.buttonEqualizer);
        equalizerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notifyListenerOnEqualizerBtnClick(volumeItem);
            }
        });

        if (volumeItem.mEqualizerSupported) {
            equalizerBtn.setVisibility(View.VISIBLE);
        } else {
            equalizerBtn.setVisibility(View.INVISIBLE);
        }

		return v;
	}

    private void updateStateOfMuteButton(MultiroomVolumeModel volumeItem, ImageButton muteButton) {
        DokUiUtils.decideStateOfMuteButton(volumeItem.mMute, muteButton,
                R.attr.volume_controlbar_icon_color, R.attr.grouping_delete_button_color);
    }

    private void notifyListenerOnVolumeChange(MultiroomVolumeModel volumeItem, boolean forceUpdate) {
		if (mListener != null)
			mListener.onVolumeChange(volumeItem, forceUpdate);		
	}

    private void notifyListenerOnMuteChange(MultiroomVolumeModel volumeItem) {
		if (mListener != null)
			mListener.onMuteChange(volumeItem);	
	}

    private void notifyListenerOnEqualizerBtnClick(MultiroomVolumeModel volumeItem) {
        if (mListener != null) {
            mListener.onEqualizerBtnClick(volumeItem);
        }
    }
}
