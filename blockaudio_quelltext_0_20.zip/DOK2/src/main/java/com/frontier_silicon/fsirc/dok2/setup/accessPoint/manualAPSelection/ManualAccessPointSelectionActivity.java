package com.frontier_silicon.fsirc.dok2.setup.accessPoint.manualAPSelection;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupLocationNotGrantedActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;

/**
 * Created by nbalazs on 01/03/2018.
 */
public class ManualAccessPointSelectionActivity extends SetupActivityBase {

    private SetupLocationNotGrantedActivityBinding mBinding;
    private ManualAccessPointSelectionActivityVM mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.setup_location_not_granted_activity);

        configureToolbarWithExitButton(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_title_select_wifi, true));

        mViewModel = new ManualAccessPointSelectionActivityVM(this);

        mBinding.setViewModel(mViewModel);
        mBinding.textTopInfo.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_manually_connect_to_access_point, true));
    }

    @Override
    protected void onResume() {
        super.onResume();
        mViewModel.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mViewModel.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mBinding.setViewModel(null);
        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }
    }
}
