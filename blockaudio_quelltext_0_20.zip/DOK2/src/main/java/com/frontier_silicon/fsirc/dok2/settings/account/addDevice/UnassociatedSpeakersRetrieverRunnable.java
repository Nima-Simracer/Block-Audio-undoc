package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import com.frontier_silicon.NetRemoteLib.Node.BaseFsdcaState;
import com.frontier_silicon.NetRemoteLib.Node.NodeFsdcaFsdcaId;
import com.frontier_silicon.NetRemoteLib.Node.NodeFsdcaState;
import com.frontier_silicon.NetRemoteLib.Radio.ErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.settings.account.FSAuthManager;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * Created by cvladu on 01/03/2018.
 */

public class UnassociatedSpeakersRetrieverRunnable implements Runnable {

    private List<MultiroomItemModel> mMultiroomItemModelList;
    private List<MultiroomItemModel> mUnassociatedSpeakers = new ArrayList<>();
    private IFSDCAAssociationChecked mListener;
    private CountDownLatch mCountDownLatch;

    public interface IFSDCAAssociationChecked {
        void onFsdcaListRetrieved(List<MultiroomItemModel> unassociatedSpeakers);
    }

    public UnassociatedSpeakersRetrieverRunnable(List<MultiroomItemModel> multiroomItemModelList, IFSDCAAssociationChecked callback) {
        mMultiroomItemModelList = multiroomItemModelList;
        mListener = callback;
        mCountDownLatch = new CountDownLatch(multiroomItemModelList.size() + 1); // +1 is from retrieving the associated devices from cloud
    }

    @Override
    public void run() {
        getUnassociatedSpeakers();

        getAssociatedDevicesFromFsdcaCloud();

        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (mListener != null) {
            mListener.onFsdcaListRetrieved(mUnassociatedSpeakers);
        }
    }

    private void getUnassociatedSpeakers() {
        for (MultiroomItemModel multiroomItemModel : mMultiroomItemModelList) {
            if (multiroomItemModel == null || multiroomItemModel.getRadio() == null) {
                return;
            }

            multiroomItemModel.getRadio().getNodes(new Class[]{NodeFsdcaFsdcaId.class, NodeFsdcaState.class}, nodeResponses -> {
                mCountDownLatch.countDown();

                if (nodeResponses == null || nodeResponses.size() == 0) {
                    return;
                }

                NodeErrorResponse fsdcaIdNodeError = nodeResponses.get(NodeFsdcaFsdcaId.class).getError();
                NodeFsdcaState fsdcaStateNode = (NodeFsdcaState) nodeResponses.get(NodeFsdcaState.class).getNodeInfo();

                // if there is no fsdcaID the speaker will return FS_FAIL (by implementation)
                if (fsdcaIdNodeError != null && fsdcaIdNodeError.getFSStatus() == ErrorResponse.FSStatusCode.FS_FAIL &&
                        canAddSpeaker(fsdcaStateNode)) {
                    mUnassociatedSpeakers.add(multiroomItemModel);
                }
            });
        }
    }

    private void getAssociatedDevicesFromFsdcaCloud() {
        FSAuthManager.getInstance().getAssociatedDevices(() -> mCountDownLatch.countDown());
    }

    private boolean canAddSpeaker(NodeFsdcaState fsdcaState) {
        boolean canAdd = false;
        if (fsdcaState != null && fsdcaState.getValueEnum() == BaseFsdcaState.Ord.FSDCA_STATE_NOT_ASSOCIATED) {
            return true;
        }

        return canAdd;
    }
}
