package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import android.content.Context;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseFormStringViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.AirableItemSelectionManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.HideErrorMessageEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.StringValidationFailedEvent;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseFormItemPasswordBinding;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

/**
 * Created by lsuhov on 06/11/2016.
 */

public class BrowseFormItemPasswordDelegate extends AirableSelectableItemDelegate {

    TextWatcher mTextWatcher;
    BrowseFormItemPasswordBinding mBinding = null;
    Context context;

    private int mBrowseType;

    public BrowseFormItemPasswordDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(context);

        mBinding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_form_item_password,
                parent, false);
        AirableItemSelectionManager.getInstance().addSelectableItem(mBinding.passwordItem);
        this.createEditorListeners(mBinding.passwordItem);

        EventBus.getDefault().register(this);
        return new BrowseFormItemPasswordViewHolder(mBinding, this);
    }

    protected void finalize() throws Throwable
    {
        try
        {
            EventBus.getDefault().unregister(this);

            mTextWatcher = null;
            mBinding = null;
            context = null;
        }finally{super.finalize();}
    }

    @Subscribe
    public void AddValidationErrorMessage(StringValidationFailedEvent obj)
    {
        passwordValidation();
    }

    private void passwordValidation() {
        if (mBinding != null) {
            if (mBinding.passwordItem.getText().toString().isEmpty() || mBinding.passwordItem.getText().toString().trim().isEmpty()) {
                mBinding.passwordItem.setError(context.getString(R.string.field_cannot_be_empty));
                mBinding.passwordItem.requestFocus();
            }
            if (mBinding.passwordItem.getText().toString().length() > USERNAME_PASSWORD_MAX_LENGTH) {
                super.replaceCharacters(mBinding.passwordItem.getText());
                mBinding.passwordItem.setError(context.getString(R.string.field_less_50_chars));
                mBinding.passwordItem.requestFocus();
            }
        }
    }

    @Subscribe
    public void hideErrorMessage(HideErrorMessageEvent event) {
        if (mBinding != null) {
            mBinding.passwordItem.setError(null);
        }
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        FormManager formManager = BrowseManagerFactory.getFormManager(mBrowseType);
        FormItem formItem = formManager.getItemByPosition(position);

        final BrowseFormItemPasswordViewHolder viewHolder = (BrowseFormItemPasswordViewHolder) holder;
        BrowseFormStringViewModel viewModel = new BrowseFormStringViewModel(position, formItem);
        viewHolder.mBinding.setViewModel(viewModel);

        mTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                //Apply general behavior for all editTexts
                passwordValidation();
                viewHolder.mBinding.getViewModel().onValueChanged(s.toString());
            }
        };

        viewHolder.mBinding.passwordItem.addTextChangedListener(mTextWatcher);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseFormItemPasswordViewHolder viewHolder = (BrowseFormItemPasswordViewHolder) holder;
        BrowseFormStringViewModel viewModel = viewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            viewHolder.mBinding.setViewModel(null);
        }

        viewHolder.mBinding.passwordItem.removeTextChangedListener(mTextWatcher);
        viewHolder.mBinding.passwordItem.setText("");
        mTextWatcher = null;
    }

    private static class BrowseFormItemPasswordViewHolder extends ListItemViewHolder {
        BrowseFormItemPasswordBinding mBinding;

        BrowseFormItemPasswordViewHolder(BrowseFormItemPasswordBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
