package com.frontier_silicon.fsirc.dok2.nowPlaying;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;


/**
 * Created by lsuhov on 28/11/2016.
 */

public class AlbumPostprocessRunnable implements Runnable {
    private Bitmap mAlbum;
    private Context mAppContext;
    private IAlbumPostprocessListener mListener;

    public AlbumPostprocessRunnable(Bitmap album, Context appContext, IAlbumPostprocessListener listener) {
        mAlbum = album;
        mAppContext = appContext;
        mListener = listener;
    }

    @Override
    public void run() {

        if (mAlbum == null) {
            notifyListener(null, null);
        } else {
            mAlbum = createTrimmedBitmap(mAlbum);
            Bitmap blurredBitmap = blurImage(mAlbum);
            notifyListener(mAlbum, blurredBitmap);
        }

        dispose();
    }

    // this seems a very slow solution
    private Bitmap createTrimmedBitmap(Bitmap bmp) {

        int imgHeight = bmp.getHeight();
        int imgWidth  = bmp.getWidth();
        int smallX=0,largeX=imgWidth,smallY=0,largeY=imgHeight;
        int left=imgWidth,right=imgWidth,top=imgHeight,bottom=imgHeight;

        for(int i=0; i<imgWidth; i++)
        {
            for(int j=0; j<imgHeight; j++)
            {
                if(bmp.getPixel(i, j) != Color.TRANSPARENT){
                    if((i-smallX) < left)
                        left = i-smallX;
                    if((largeX-i) < right)
                        right = largeX-i;
                    if((j-smallY) < top)
                        top = j-smallY;
                    if((largeY-j) < bottom)
                        bottom = largeY-j;
                }
            }
        }

        bmp=Bitmap.createBitmap(bmp,left,top,imgWidth-left-right, imgHeight-top-bottom);

        return bmp;
    }

    private Bitmap blurImage(Bitmap input)
    {
        Bitmap result = null;

        try {
            RenderScript mRenderScript = RenderScript.create(mAppContext);

            Allocation alloc = Allocation.createFromBitmap(mRenderScript, input);

            ScriptIntrinsicBlur blur = ScriptIntrinsicBlur.create(mRenderScript, Element.U8_4(mRenderScript));
            blur.setRadius(25);
            blur.setInput(alloc);

            result = Bitmap.createBitmap(input.getWidth(), input.getHeight(), input.getConfig());
            Allocation outAlloc = Allocation.createFromBitmap(mRenderScript, result);
            blur.forEach(outAlloc);
            outAlloc.copyTo(result);

            mRenderScript.destroy();

        } catch (Exception e) {
            result = null;
        }

        return result;
    }

    private void notifyListener(Bitmap postprocessedAlbum, Bitmap blurredAlbum) {
        if (mListener != null) {
            mListener.onPostprocessedAlbum(postprocessedAlbum, blurredAlbum);
        }
    }

    private void dispose() {
        mAlbum = null;
        mAppContext = null;
        mListener = null;
    }
}
