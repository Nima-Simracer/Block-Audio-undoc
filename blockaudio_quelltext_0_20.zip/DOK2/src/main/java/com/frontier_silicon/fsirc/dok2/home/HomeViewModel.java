package com.frontier_silicon.fsirc.dok2.home;

import androidx.databinding.BaseObservable;
import androidx.databinding.Observable;
import androidx.databinding.ObservableBoolean;

import android.graphics.drawable.Drawable;

import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.ObservableField;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.components.multiroom.MultiroomRescanUtil;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.UpdateActionBarTitleTask;
import com.frontier_silicon.fsirc.dok2.UserFeedbackForm;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.ConnectedSpeakerActivity;
import com.frontier_silicon.fsirc.dok2.connection.ConnectionManager;
import com.frontier_silicon.fsirc.dok2.connection.IConnectToSpeakerOrGroup;
import com.frontier_silicon.fsirc.dok2.databinding.HomeActivityBinding;
import com.frontier_silicon.fsirc.dok2.gdpr.GDPRActivity;
import com.frontier_silicon.fsirc.dok2.gdpr.GDPRVersionManager;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;
import com.frontier_silicon.fsirc.dok2.settings.staticRadioSearch.ActivityStaticRadio;
import com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant.ConnectivityAssistantActivity;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;
import com.frontier_silicon.fsirc.dok2.stereo.selectPrimary.SelectPrimarySpeakerActivity;
import com.frontier_silicon.fsirc.dok2.update.AllDevicesIsuActivity;
import com.frontier_silicon.fsirc.dok2.update.IsuBackgroundListener;
import com.frontier_silicon.fsirc.dok2.update.IsuBackgroundManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.List;

/**
 * Created by cvladu on 22/05/2017.
 */

public class HomeViewModel extends BaseObservable implements IConnectionStateListener,
        IMultiroomGroupingListener, IsuBackgroundListener, IConnectToSpeakerOrGroup {

    public ObservableBoolean isNoRadiosFoundVisible = new ObservableBoolean(false);
    public ObservableBoolean isProgressBarVisible = new ObservableBoolean(false);
    public ObservableBoolean isUpdateAvailableLayoutVisible = new ObservableBoolean(false);
    public ObservableBoolean isStereoButtonVisible = new ObservableBoolean(false);
    public ObservableBoolean isStereoSystemIncomplete = new ObservableBoolean(false);
    public ObservableBoolean isSmartRadioVisible = new ObservableBoolean(false);
    public ObservableField<Drawable> smartRadioIcon = new ObservableField<>();

    private Observable.OnPropertyChangedCallback mSmartRadioOberver;


    private AppCompatActivity mActivity;
    private HomeActivityBinding mBinding;
    private HomeSpeakersAdapter mAdapter;
    private DashboardUnconfiguredRadiosUtil mUnconfiguredRadiosUtil;
    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;
    private Long lastRescanTimeStamp = 0l;
    private static int RESCAN_ALLOWED_INTERVAL = 1200;

    HomeViewModel() {
       // mUnconfiguredRadiosUtil = new DashboardUnconfiguredRadiosUtil();
    }

    public void onStart(AppCompatActivity activity, HomeActivityBinding binding) {
        mActivity = activity;
        mBinding = binding;

        startUpdateCheckingOncePerDay();
        UserFeedbackForm.getInstance().init(mActivity, mActivity.getString(R.string.contact_link));

        initAdapter();
        registerPropertyChangedCallback();
        initObservers();
    }

    private void initObservers() {
        setSmartRadioLogo();
    }

    private void registerPropertyChangedCallback() {
        mSmartRadioOberver = new OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observalble, int propertyId) {
                if (observalble == SmartRadioStringsManager.INSTANCE.isAnySmartRadioAvailable()) {
                    setSmartRadioLogo();
                }
            }
        };

        SmartRadioStringsManager.INSTANCE.isAnySmartRadioAvailable().addOnPropertyChangedCallback(mSmartRadioOberver);
    }

    private void removePropertyChangedCallback() {
        SmartRadioStringsManager.INSTANCE.isAnySmartRadioAvailable().removeOnPropertyChangedCallback(mSmartRadioOberver);
    }

    private void setSmartRadioLogo() {
        if (SmartRadioStringsManager.INSTANCE.isAnySmartRadioAvailable().get()) {
            isSmartRadioVisible.set(true);
            if (DokUiUtils.isLightTheme()) {
                smartRadioIcon.set(mActivity.getResources().getDrawable(R.drawable.ic_smart_radio_colored));
            } else {
                smartRadioIcon.set(mActivity.getResources().getDrawable(R.drawable.is_smart_radio_white_home_screen));
            }
        } else {
            DelayedPostsManager.getInstance().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!SmartRadioStringsManager.INSTANCE.isAnySmartRadioAvailable().get()) {
                        isSmartRadioVisible.set(false);
                    }
                }
            }, 2000);
        }
    }

    private void initAdapter() {
        mAdapter = new HomeSpeakersAdapter(mActivity);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity.getApplicationContext());
        mBinding.groupList.setHasFixedSize(true);
        mBinding.groupList.setLayoutManager(layoutManager);
        mBinding.groupList.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
    }

    public void onResume() {

        addListeners();
        updateBottomToolbarButtons();
        updateToolbarTitle();

        if (MultiroomGroupManager.getInstance().listIsEmpty()) {
            MultiroomRescanUtil.getInstance().rescanMultiroomDevicesAndGroups();
        }

        checkGDPRIsChecked();
    }

    public void onPause() {
        removeListeners();
        removePropertyChangedCallback();
    }

    private void addListeners() {
        ConnectionManager.getInstance().init();
        ConnectionManager.getInstance().addListener(this);

        ConnectionStateUtil.getInstance().addListener(this, true);
        IsuBackgroundManager.getInstance().addListener(this);

        FsLogger.log("HomeSpeakersMediator: attach to multiroom discovery");
        MultiroomGroupManager.getInstance().addListener(this);

        addSpeakerSettingsListener();
    }

    private void addSpeakerSettingsListener() {
        mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                if (observable == SpeakerDataManager.getInstance().getSpeakerDataModel().friendlyName) {
                    updateToolbarTitle();
                }
            }
        };

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.friendlyName.addOnPropertyChangedCallback(mPropertyChangedCallback);
    }

    private void removeSpeakerSettingsListener() {

        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();
        speakerDataModel.friendlyName.removeOnPropertyChangedCallback(mPropertyChangedCallback);

        mPropertyChangedCallback = null;
    }

    private void startUpdateCheckingOncePerDay() {
        if (IsuBackgroundManager.getInstance().shouldCheckForUpdates()) {
            IsuBackgroundManager.getInstance().startScan(mActivity);
        }
    }

    @Override
    public void onStateUpdate(final ConnectionState newState) {
        FsLogger.log("HomeViewModel onStateUpdate " + newState.name());

        updateHomeViewBasedOnConnectionState(newState);
    }

    @Override
    public void onGroupingUpdate() {

        ConnectionState connectionState = ConnectionStateUtil.getInstance().getConnectionState();
        FsLogger.log("HomeViewModel grouping update " + connectionState.name());

        updateHomeViewBasedOnConnectionState(connectionState);
    }

    private void updateHomeViewBasedOnConnectionState(final ConnectionState newState) {
        NetRemote.getMainThreadExecutor().execute(() -> {
            if (DokUiUtils.isDestroyed(mActivity)) {
                return;
            }

            checkGDPRIsChecked();

            switch (newState) {
                case SEARCHING_RADIOS_NO_SPEAKER_FOUND_YET:
                    setRescanInProgressLayout();
                    break;

                case NO_RADIOS_FOUND:
                    setNoSpeakersFoundLayout();
                    break;

                case NO_WIFI_OR_ETHERNET:
                    return;

                default:
                    if (MultiroomGroupManager.getInstance().listIsEmpty()) {
                        setRescanInProgressLayout();
                    } else {
                        updateListOfHomeSpeakers();
                        setListOfSpeakersLayout();
                    }
                    break;
            }

            updateToolbarTitle();
        });
    }

    private void setRescanInProgressLayout() {
        isNoRadiosFoundVisible.set(false);
        isProgressBarVisible.set(true);
    }

    private void setNoSpeakersFoundLayout() {
        isNoRadiosFoundVisible.set(true);
        mBinding.noRadioImage.setImageResource(R.drawable.img_no_action);
        int tintColor = GuiUtils.getColorFromAttribute(mActivity, R.attr.sources_icon_color);

        mBinding.noRadioImage.setColorFilter(tintColor);
        isProgressBarVisible.set(false);
    }

    private void setListOfSpeakersLayout() {
        isNoRadiosFoundVisible.set(false);
        isProgressBarVisible.set(false);
    }

    public Boolean canRescan() {
        if (System.currentTimeMillis() - lastRescanTimeStamp > RESCAN_ALLOWED_INTERVAL) {
            lastRescanTimeStamp = System.currentTimeMillis();
            return true;
        }

        return false;
    }

    @Override
    public void onNewIsuResults() {

        if (!DokUiUtils.isDestroyed(mActivity)) {
            mActivity.runOnUiThread(() -> {
                if (mActivity == null) {
                    return;
                }
                updateUpdateAvailableButton();
            });
        }
    }

    @Override
    public void onConnectedToSpeakerOrGroup(boolean connectedOk, boolean isServer) {
        //updateToolbarTitle();

        if (connectedOk) {
            goToConnectedSpeakerActivity();
        } else {
            FsLogger.log("onManualConnectionToRadio failed!", LogLevel.Error);
        }
    }

    void goToConnectedSpeakerActivity() {
        NavigationHelper.goToActivity(mActivity, ConnectedSpeakerActivity.class);
    }

    private void updateBottomToolbarButtons() {
        updateUpdateAvailableButton();
    }

    private void updateUpdateAvailableButton() {


        if (mActivity != null) {
            int numberOfRadiosWithUpdate = IsuBackgroundManager.getInstance().getNumberOfRadiosWithUpdateAvailable();
            if (numberOfRadiosWithUpdate > 0) {
                isUpdateAvailableLayoutVisible.set(true);
                mBinding.numberOfRadiosWithUpdatesTextView.setText(String.valueOf(numberOfRadiosWithUpdate));

                if (IsuBackgroundManager.getInstance().atLeastOneRadioHasImportantUpdate()) {
                    mBinding.typeOfUpdateImage.setBackgroundResource(R.drawable.bg_round_important_update);
                    mBinding.numberOfRadiosWithUpdatesTextView.setTextColor(ContextCompat.getColor(mActivity, android.R.color.white));
                } else if (IsuBackgroundManager.getInstance().atLeastOneRadioHasRecommendedUpdate()) {
                    mBinding.typeOfUpdateImage.setBackgroundResource(R.drawable.bg_round_normal_update);
                    mBinding.numberOfRadiosWithUpdatesTextView.setTextColor(ContextCompat.getColor(mActivity, android.R.color.black));
                }
            } else {
                isUpdateAvailableLayoutVisible.set(false);
            }
        }
    }

    @SuppressWarnings("unused")
    public void onSetupNewDeviceButtonClicked(View view) {
        switchToSetupActivity();
    }

    @SuppressWarnings("unused")
    public void onUpdateAvailableClicked(View view) {
        NavigationHelper.goToActivity(mActivity, AllDevicesIsuActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    @SuppressWarnings("unused")
    public void onStereoSetupClicked(View view) {
        NavigationHelper.goToActivity(mActivity, SelectPrimarySpeakerActivity.class, NavigationHelper.AnimationType.SlideToLeft);
    }

    public void onSearchSpeakerByIpClicked(View view) {
        NavigationHelper.goToActivity(mActivity, ActivityStaticRadio.class);
    }

    private void switchToSetupActivity() {
        NavigationHelper.goToSetupActivity(mActivity);
    }

    private void switchToConnectivityAssistant() {
        AnalyticsSender.sendConnectivityAssistantStartedEvent();
        NavigationHelper.goToActivity(mActivity, ConnectivityAssistantActivity.class);
    }

    private void updateListOfHomeSpeakers() {
        List<MultiroomItemModel> multiroomItemModels = MultiroomGroupManager.getInstance().getFlatGroupDeviceList();

        if (mAdapter != null) {
            mAdapter.swapItems(multiroomItemModels);
        }

        updateStereoButtonVisibility(multiroomItemModels);
    }

    private void updateStereoButtonVisibility(List<MultiroomItemModel> multiroomItemModels) {

        boolean foundStereoCapableSpeaker = false;
        boolean foundIncompleteStereoSystem = false;

        for (MultiroomItemModel multiroomItemModel : multiroomItemModels) {
            if (multiroomItemModel.getIsGroupHeader()) {
                List<MultiroomDeviceModel> deviceModels = multiroomItemModel.getFrozenMultiroomDeviceModels();

                for (MultiroomDeviceModel deviceModel : deviceModels) {
                    if (deviceModel.isStereoCapable()) {
                        foundStereoCapableSpeaker = true;
                        if (deviceModel.mIsIncompleteStereoSystem) {
                            foundIncompleteStereoSystem = true;
                            break;
                        }
                    }
                }
            } else {
                MultiroomDeviceModel deviceModel = multiroomItemModel.getDeviceModel();
                if (deviceModel.isStereoCapable()) {
                    foundStereoCapableSpeaker = true;
                    if (deviceModel.mIsIncompleteStereoSystem) {
                        foundIncompleteStereoSystem = true;
                        break;
                    }
                }
            }
        }

        isStereoButtonVisible.set(foundStereoCapableSpeaker);
        isStereoSystemIncomplete.set(foundIncompleteStereoSystem);
    }

    private void updateToolbarTitle() {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        mActivity.runOnUiThread(() -> {
            if (DokUiUtils.isDestroyed(mActivity)) {
                return;
            }

            String title = mActivity.getString(R.string.dashboard);

            UpdateActionBarTitleTask updateTitleTask = new UpdateActionBarTitleTask(mActivity, title);
            TaskHelper.execute(updateTitleTask);
        });
    }

//    private void displayHowToUse3PdaIfNecessary() {
//       isAmazonAlexaInfoVisible.set(shouldDisplay3PdaInfo());
//    }
//
//    @SuppressWarnings("unused")
//    public void onGotItClicked(View view) {
//        if (isAmazonAlexaInfoVisible.get()) {
//            UndokPreferences.getInstance().setShouldDisplay3PdaInfo(false);
//        }
//    }
//
//    private boolean shouldDisplay3PdaInfo() {
//        if (!UndokPreferences.getInstance().getShouldDisplay3PdaInfo()) {
//            return false;
//        }
//
//        List<Radio> radios = NetRemoteManager.getInstance().getRadios();
//        for (Radio radio : radios) {
//            if (radio.hasFSDCA()) {
//                return true;
//            }
//        }
//
//        return false;
//    }
//
//    @SuppressWarnings("unused")
//    public void onAmazonAlexaLayoutClicked(View view) {
//        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.amazon.com/alexa"));
//        MainApplication.getCurrentActivity().startActivity(browserIntent);
//    }
//
//    private void collapse(final View v) {
//        final int initialHeight = v.getMeasuredHeight();
//
//        Animation a = new Animation() {
//            @Override
//            protected void applyTransformation(float interpolatedTime, Transformation t) {
//                if (interpolatedTime == 1) {
//                     isAmazonAlexaInfoVisible.set(false);
//                } else {
//                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
//                    v.requestLayout();
//                }
//            }
//
//            @Override
//            public boolean willChangeBounds() {
//                return true;
//            }
//        };
//
//        // 1dp/ms
//        a.setDuration((int) (initialHeight / v.getContext().getResources().getDisplayMetrics().density * 2.5));
//        v.startAnimation(a);
//    }

    @SuppressWarnings("unused")
    public void onRescanClicked(View v) {
        switchToConnectivityAssistant();
    }

    private void removeListeners() {
        ConnectionManager.getInstance().removeListener(this);
        ConnectionStateUtil.getInstance().removeListener(this);
        IsuBackgroundManager.getInstance().removeListener(this);

        FsLogger.log("HomeSpeakersMediator: detach from multiroom discovery");
        MultiroomGroupManager.getInstance().removeListener(this);

        removeSpeakerSettingsListener();
    }

    public void dispose() {
        if (mBinding.groupList != null) {
            mBinding.groupList.setAdapter(null);
            mBinding.groupList.clearOnChildAttachStateChangeListeners();
            mBinding.groupList.clearOnScrollListeners();
            mBinding.groupList.getRecycledViewPool().clear();
            mBinding.groupList.removeAllViewsInLayout();
        }

        if (mAdapter != null) {
            mAdapter.dispose();
            mAdapter = null;
        }

        IsuBackgroundManager.getInstance().stopScan();

        mActivity = null;
        mBinding = null;
        mUnconfiguredRadiosUtil = null;
    }

    private void checkGDPRIsChecked() {
        if (GDPRVersionManager.firstCheckIsDone()) {
            return;
        }
        if (GDPRVersionManager.isInternetConnectionAvailable(mActivity)) {
            startGDPRChecking();
        }
    }

    private void startGDPRChecking() {
        GDPRVersionManager.setFirstCheckIsDone();
        GDPRVersionManager.checkAsync(mActivity.getResources().getString(R.string.gdpr_version_link), newVersionIsAvailable -> {
            if (newVersionIsAvailable) {
                NavigationHelper.goToActivityClearingCurrentStack(mActivity, GDPRActivity.class, NavigationHelper.AnimationType.SlideToLeft);
            }
        });
    }
}
