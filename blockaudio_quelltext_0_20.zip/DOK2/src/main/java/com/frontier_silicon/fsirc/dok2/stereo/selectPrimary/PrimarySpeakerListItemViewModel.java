package com.frontier_silicon.fsirc.dok2.stereo.selectPrimary;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.stereo.StereoBundleHelper;
import com.frontier_silicon.fsirc.dok2.stereo.StereoSpeakerListItemViewModel;
import com.frontier_silicon.fsirc.dok2.stereo.selectSecondary.SelectSecondarySpeakerActivity;

/**
 * Created by lsuhov on 10/08/2017.
 */

public class PrimarySpeakerListItemViewModel extends StereoSpeakerListItemViewModel {
    public PrimarySpeakerListItemViewModel(StereoItemModel stereoItemModel, Activity activity) {
        super(stereoItemModel, activity);
    }

    public void onListItemClicked(View v) {
        Radio radio = mStereoItemModel.deviceModel.mRadio;
        if (radio == null) {
            return;
        }

        Bundle bundle = new Bundle();
        bundle.putString(StereoBundleHelper.PRIMARY_SPEAKER_UDN, radio.getUDN());

        NavigationHelper.goToActivity(mActivity, SelectSecondarySpeakerActivity.class,
                NavigationHelper.AnimationType.SlideToLeft, false, bundle);
    }
}
