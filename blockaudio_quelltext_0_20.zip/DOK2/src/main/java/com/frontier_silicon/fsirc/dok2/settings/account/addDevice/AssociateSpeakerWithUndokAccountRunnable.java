package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import android.os.Handler;
import android.os.Looper;

import com.frontier_silicon.NetRemoteLib.Node.NodeFsdcaAuthCode;
import com.frontier_silicon.NetRemoteLib.Node.NodeFsdcaClientId;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.settings.account.AuthorizeDeviceCode;
import com.frontier_silicon.fsirc.dok2.settings.account.FSAuthManager;

import java.util.concurrent.CountDownLatch;

/**
 * Created by cvladu on 07/03/2018.
 */

public class AssociateSpeakerWithUndokAccountRunnable implements Runnable {

    private Radio mRadio;
    private IAssociationFinished mListener;


    public interface IAssociationFinished {
        void onAssociationFinished(boolean success);
    }

    public AssociateSpeakerWithUndokAccountRunnable(Radio radio, IAssociationFinished listener) {
        mRadio = radio;
        mListener = listener;
    }

    @Override
    public void run() {
        getClientId();
    }

    private void getClientId() {
        if (mRadio == null) {
            onFailed();
            return;
        }

        mRadio.getNode(NodeFsdcaClientId.class, true, new IGetNodeCallback() {
            @Override
            public void getNodeResult(NodeInfo node) {
                NodeFsdcaClientId clientId = (NodeFsdcaClientId) node;
                getAuthorizeCodeFromCloud(clientId.getValue());
            }

            @Override
            public void getNodeError(Class nodeType, NodeErrorResponse error) {
                onFailed();
            }
        });
    }

    private void getAuthorizeCodeFromCloud(String clientId) {
        CountDownLatch countDownLatch = new CountDownLatch(1);

        FSAuthManager.getInstance().authorizeDevice(clientId, new FSAuthManager.IAuthorizeCode() {
            @Override
            public void onAuthorizeCode(AuthorizeDeviceCode authorizeCode) {
                countDownLatch.countDown();
                String encrytedCode = RadioNodeUtil.encryptWithRsaNode(mRadio, authorizeCode.getAuthorizeCode());
                sendAuthorizationCode(encrytedCode);

            }

            @Override
            public void onRetrievingFailed(FSAuthManager.Error error) {
                countDownLatch.countDown();
                AssociateSpeakerWithUndokAccountRunnable.this.onFailed();
            }
        });

        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }


    private void sendAuthorizationCode(String code) {
        if (mRadio == null) {
            onFailed();
            return;
        }

        mRadio.setNode(new NodeFsdcaAuthCode(code), true, new ISetNodeCallback() {
            @Override
            public void setNodeSuccess(NodeInfo node) {
                onSuccess();
            }

            @Override
            public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                if (error.getFSStatus() != null) {
                    onFailed();
                }
            }
        });
    }

    private void onFailed() {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> {
            if (mListener != null) {
                mListener.onAssociationFinished(false);
            }
        });
    }

    private void onSuccess() {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(() -> {
            if (mListener != null) {
                mListener.onAssociationFinished(true);
            }
        });
    }


}
