package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import org.json.JSONException;
import org.json.JSONObject;

public class FSDCADeviceModel {
    private int mId;
    private String mName;
    private String mFsdcaId;

    public interface IDevicesListener {
        void onDevicesRetrieved();
    }

    public FSDCADeviceModel(int id, String name, String fsdcaId) {
        mId = id;
        mName = name;
        mFsdcaId = fsdcaId;
    }

    public int getId() {
        return mId;
    }

    public String getName() {
        return mName;
    }

    public String getFsdcaId() {
        return mFsdcaId;
    }

    public static FSDCADeviceModel getDeviceFromJsonObject(JSONObject device) {
        FSDCADeviceModel deviceModel = null;
        try {
            int id = device.getInt("id");
            JSONObject attributes = device.getJSONObject("attributes");
            String name = attributes.getString("name");
            String fsdcaID = attributes.getString("fsdca_id");

            deviceModel = new FSDCADeviceModel(id,name,fsdcaID);
        }catch (JSONException e) {
            e.printStackTrace();
        }

        return deviceModel;
    }
}
