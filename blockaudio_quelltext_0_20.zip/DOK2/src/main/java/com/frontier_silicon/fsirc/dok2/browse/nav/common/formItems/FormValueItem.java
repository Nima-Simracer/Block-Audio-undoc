package com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems;

import com.frontier_silicon.NetRemoteLib.Node.NodeListItem.FormItemType;

/**
 * Created by adanaila on 10/13/2016.
 * this is used for the form items that allow users to give input
 * like the username textblock or the password one.
 * For the password, this one should be derived to ensure encryption for the return value
 * or should be extended, depending on design decision then.
 */

public class FormValueItem extends FormItem {
    private String value;
    private String escapedEqual = "=";

    public FormValueItem(Long keyP, FormItemType typeP, String idP, String labelP, String descriptionP)
    {super(keyP, typeP, idP, labelP, descriptionP);}

    public void setValue(String valueP){this.value = valueP;}

    public String getValue()
    {
     return this.value;
    }


    public String getFormDataOutput()
    {
        String encodedValue = "";

        encodedValue = value.replaceAll("\\+", "%2B")
                .replaceAll(";", "%3B")
                .replaceAll("/", "%2F")
                .replaceAll("\\?", "%3F")
                .replaceAll(":", "%3A")
                .replaceAll("@", "%40")
                .replaceAll("=", "%3D")
                .replaceAll("&", "%26");


        /*try {
            encodedValue = URLEncoder.encode(this.value, "UTF-8");
            encodedValue = encodedValue.replaceAll("\\+", "%2B");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }*/
        return this.getId() + this.escapedEqual + encodedValue;
    }
}
