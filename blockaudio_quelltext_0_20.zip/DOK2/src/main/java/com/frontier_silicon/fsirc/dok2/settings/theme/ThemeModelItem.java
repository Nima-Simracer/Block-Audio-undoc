package com.frontier_silicon.fsirc.dok2.settings.theme;

/**
 * Created by lsuhov on 25/02/16.
 */
public class ThemeModelItem {
    String mThemeName;
    int mDrawableResource;

    public ThemeModelItem(String themeName, int drawableResource) {
        mThemeName = themeName;
        mDrawableResource = drawableResource;
    }
}
