package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import android.content.Context;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseFormStringViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.AirableItemSelectionManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.HideErrorMessageEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.StringValidationFailedEvent;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseFormItemStringBinding;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

/**
 * Created by lsuhov on 06/11/2016.
 */

public class BrowseFormItemStringDelegate extends AirableSelectableItemDelegate {

    TextWatcher mTextWatcher;
    BrowseFormItemStringBinding mBinding = null;
    Context context;

    private int mBrowseType;

    public BrowseFormItemStringDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(context);

        mBinding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_form_item_string,
                parent, false);
        AirableItemSelectionManager.getInstance().addSelectableItem(mBinding.stringItem);
        this.createEditorListeners(mBinding.stringItem);

        EventBus.getDefault().register(this);
        return new BrowseFormItemStringViewHolder(mBinding, this);
    }

    protected void finalize() throws Throwable
    {
        try{
            EventBus.getDefault().unregister(this);

            mTextWatcher = null;
            mBinding = null;
            context = null;
        }finally{super.finalize();}
    }

    @Subscribe
    public void AddValidationErrorMessage(StringValidationFailedEvent obj)
    {
        userNameValidation();
    }

    private void userNameValidation() {
        if (mBinding != null) {
            if (!mBinding.stringItem.getText().toString().isEmpty() && mBinding.stringItem.getText().toString().trim().isEmpty()) {
                mBinding.stringItem.setError(context.getString(R.string.field_cannot_contain_only_spaces));
                mBinding.stringItem.requestFocus();
            }else {
                if (mBinding.stringItem.getText().toString().isEmpty() || mBinding.stringItem.getText().toString().trim().isEmpty()) {
                    mBinding.stringItem.setError(context.getString(R.string.field_cannot_be_empty));
                    mBinding.stringItem.requestFocus();
                }
                if (mBinding.stringItem.getText().toString().length() > USERNAME_PASSWORD_MAX_LENGTH) {
                    super.replaceCharacters(mBinding.stringItem.getText());
                    mBinding.stringItem.setError(context.getString(R.string.field_less_50_chars));
                    mBinding.stringItem.requestFocus();
                }
            }
        }
    }

    @Subscribe
    public void hideErrorMessage(HideErrorMessageEvent event) {
        if (mBinding != null) {
            mBinding.stringItem.setError(null);
        }
    }


    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        FormManager formManager = BrowseManagerFactory.getFormManager(mBrowseType);
        FormItem formItem = formManager.getItemByPosition(position);

        final BrowseFormItemStringViewHolder formStringViewHolder = (BrowseFormItemStringViewHolder) holder;
        BrowseFormStringViewModel viewModel = new BrowseFormStringViewModel(position, formItem);
        formStringViewHolder.mBinding.setViewModel(viewModel);

        mTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                //Apply general behavior for all editTexts
                userNameValidation();
                formStringViewHolder.mBinding.getViewModel().onValueChanged(s.toString());
            }
        };

        formStringViewHolder.mBinding.stringItem.addTextChangedListener(mTextWatcher);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseFormItemStringViewHolder viewHolder = (BrowseFormItemStringViewHolder) holder;
        BrowseFormStringViewModel viewModel = viewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            viewHolder.mBinding.setViewModel(null);
        }

        viewHolder.mBinding.stringItem.removeTextChangedListener(mTextWatcher);
        viewHolder.mBinding.stringItem.setText("");
        mTextWatcher = null;
    }

    private static class BrowseFormItemStringViewHolder extends ListItemViewHolder {
        BrowseFormItemStringBinding mBinding;

        BrowseFormItemStringViewHolder(BrowseFormItemStringBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
