package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavDepth;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavNumItems;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNavigationUtil;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowsePagesStore;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.EIRNavigationResult;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavResultEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ShowLoadingProgressEvent;
import com.frontier_silicon.fsirc.dok2.notifications.ThemeChangedEvent;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import org.greenrobot.eventbus.EventBus;

import java.util.Map;

/**
 * Created by lsuhov on 19/10/2016.
 */
public class NavBrowseManager extends BrowseManager {
    private static NavBrowseManager mInstance = null;

    private BreadcrumbsKeeper mBreadcrumbsKeeper;
    private NavBrowseDataModel mNavBrowseDataModel;

    public static NavBrowseManager getInstance() {
        if (mInstance == null) {
            mInstance = new NavBrowseManager();
        }

        return mInstance;
    }

    protected NavBrowseManager() {
        super();

        mBreadcrumbsKeeper = new BreadcrumbsKeeper();
        mNavBrowseDataModel = new NavBrowseDataModel();

        ConnectionStateUtil.getInstance().addListener(this, false);
        addSpeakerSettingsListener();
    }

    public void navigateToCurrentList() {
          navigateToCurrentList(false);
    }

    @Override
    public void refreshCurrentList(final long id) {

        FirebaseCrashlytics.getInstance().log("NavBrowseManager refreshCurrentList");

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        NavListRunnable retrieverRunnable = new NavListRunnable(radio, (listItems, numberOfItemsRetrievedResult) -> {
            mBrowsePagesStore.clear();
            addNavListToStore(0, listItems);
            updateBreadcrumbsBasedOnNavigatedKey(id);
            EventBus.getDefault().post(new NavResultEvent(numberOfItemsRetrievedResult));
        });

        mNavigateToCurrentListThread = new Thread(retrieverRunnable);
        mNavigateToCurrentListThread.start();
    }

    private void navigateToCurrentList(boolean skipValidation) {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

        if (!skipValidation && !validateNavigation(radio)) {
            return;
        }

        FirebaseCrashlytics.getInstance().log("NavBrowseManager navigateToCurrentList");

        prepareNavigation();

        NavResetToCurrListRunnable runnable = new NavResetToCurrListRunnable(
                mBreadcrumbsKeeper, radio);
        mNavigateToCurrentListThread = new Thread(runnable);
        mNavigateToCurrentListThread.start();
    }

    private boolean validateNavigation(Radio radio) {

        if (radio == null) {
            EventBus.getDefault().post(new NavResultEvent(EIRNavigationResult.NavigationFailed));
            return false;
        } else {
            if (mNavigateToCurrentListThread != null && mNavigateToCurrentListThread.isAlive()) {
                sendLoadingEvent();
                return false;
            }

            if (TextUtils.isEmpty(mUdnOfLastConnectedDevice) || !TextUtils.equals(mUdnOfLastConnectedDevice, radio.getUDN())) {
                mUdnOfLastConnectedDevice = radio.getUDN();
                return true;
            }

            if (mTotalCountForCurrentList == 0) {
                return true;
            }

            if (!mBrowsePagesStore.isEmpty()) {
                EventBus.getDefault().post(new NavResultEvent(EIRNavigationResult.AlreadyLoaded));
                return false;
            }
        }

        return true;
    }

    public void resetNavToRoot() {

        FirebaseCrashlytics.getInstance().log("NavBrowseManager resetNavToRoot");

        clearAll();
        navigateToCurrentList();
    }

    public boolean searchIsAvailable(){
        return this.mBreadcrumbsKeeper.searchIsAvailable();
    }

    public void navigateUp(){
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        FirebaseCrashlytics.getInstance().log("NavBrowseManager navigateUp");

        navigateUpImpl();
    }

    private void navigateUpImpl() {
        if (mBreadcrumbsKeeper.hasSearchText()) {
            mBrowsePagesStore.clear();

            // clear text only if we are not going back from a directory in podcast after search
            if (mBreadcrumbsKeeper.notInSearchDirectory()){
                mBreadcrumbsKeeper.clearSearchText();
                mBreadcrumbsKeeper.resetSearchDepth();
            }
            navigateToCurrentList();
        } else {
            navigateToDirectory(RadioNavigationUtil.INVALID_INT32_KEY);
        }
    }

    public int getNavDepth() {
        return mBreadcrumbsKeeper.size();
    }

    public void search(String searchText) {

        FirebaseCrashlytics.getInstance().log("NavBrowseManager search");

        mBreadcrumbsKeeper.setSearchDepth();
        mBreadcrumbsKeeper.setSearchText(searchText);

        prepareNavigation();

        navigateToCurrentList();
    }

    public String getSearch() {
        return mBreadcrumbsKeeper.getSearchText();
    }

    @Override
    protected void sendLoadingEvent() {
        EventBus.getDefault().post(new ShowLoadingProgressEvent());
    }

    @Override
    public void navigateToDirectory(final Long key) {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        FirebaseCrashlytics.getInstance().log("NavBrowseManager navigateToDirectory - key: " + key);

        prepareNavigation();

        NavigateRunnable navigateRunnable = new NavigateRunnable(key,
                radio, result -> {
                    switch (result) {
                        case Success:
                        case TotalItemsNotRetrieved:
                        case EmptyList:
                            updateBreadcrumbsBasedOnNavigatedKey(key);
                            getAlbumArtistDetails();
                            break;
                    }

                    EventBus.getDefault().post(new NavResultEvent(result));
                });

        Thread thread = new Thread(navigateRunnable);
        thread.start();
    }

    private void updateBreadcrumbsBasedOnNavigatedKey(Long key) {
        mBreadcrumbsKeeper.updateNavPathAndDepth(key);

        if (mBrowsePagesStore.searchItemWasFound()) {
            mBreadcrumbsKeeper.createSearchPath(mBrowsePagesStore.getSearchKey());
        }
    }

    public NavBrowseDataModel getNavBrowseDataModel()
    {
        return mNavBrowseDataModel;
    }

    private void getAlbumArtistDetails() {

        new Thread(new NavDescriptionRetrieverRunnable()).start();
    }

    private void updateRegisteredDepth(NodeNavDepth depth){
        if(depth != null && depth.getValue() != null && depth.getValue() >= 0)
            this.mBreadcrumbsKeeper.updateRegisteredDepth(depth.getValue());
        else if(depth == null)
            this.mBreadcrumbsKeeper.resetRegisteredDepth();
    }

    @Override
    public void retrieveFirstPageSync(Radio radio, boolean firstPageOnly) {

        FirebaseCrashlytics.getInstance().log("NavBrowseManager retrieveFirstPageSync");

        NavPageRetrieverRunnable retrieverRunnable = new NavPageRetrieverRunnable(
                BrowsePagesStore.DEFAULT_START_KEY_ID, radio, firstPageOnly,
                listItems -> addNavListToStore(0, listItems));

        retrieverRunnable.run();
    }

    @Override
    public EIRNavigationResult retrieveTotalNumberOfItemsFromCurrentListSync(Radio radio) {
        FirebaseCrashlytics.getInstance().log("NavBrowseManager retrieveTotalNumberOfItemsFromCurrentListSync");

        Map<Class, NodeInfo> results = radio.nodesSyncGetter(new Class[] {NodeNavNumItems.class, NodeNavDepth.class}).get();
        NodeNavNumItems nodeNumItems = (NodeNavNumItems) results.get(NodeNavNumItems.class);

        if (nodeNumItems == null || nodeNumItems.getValue() == null) {
            FirebaseCrashlytics.getInstance().log("NavBrowseManager retrieveTotalNumberOfItemsFromCurrentListSync - totalItemsNode is null");

            mTotalCountForCurrentList = 0;
            return EIRNavigationResult.TotalItemsNotRetrieved;
        }

        int totalNumber = nodeNumItems.getValue().intValue();
        if (totalNumber == -1) {
            FirebaseCrashlytics.getInstance().log("NavBrowseManager retrieveTotalNumberOfItemsFromCurrentListSync - totalItemsNode value is -1");

            mTotalCountForCurrentList = -1;
            return EIRNavigationResult.TotalItemsNotRetrieved;
        }

        if (totalNumber == 0) {
            FirebaseCrashlytics.getInstance().log("NavBrowseManager retrieveTotalNumberOfItemsFromCurrentListSync - totalItemsNode value is 0");

            mTotalCountForCurrentList = 0;
            return EIRNavigationResult.EmptyList;
        }

        NodeNavDepth depthNode = (NodeNavDepth) results.get(NodeNavDepth.class);
        NavBrowseManager.getInstance().updateRegisteredDepth(depthNode);

        mTotalCountForCurrentList = totalNumber;

        return EIRNavigationResult.Success;
    }

    @Override
    public void clearAll() {
        super.clearAll();

        mNavBrowseDataModel.clear();
        mBreadcrumbsKeeper.clear();
    }
}
