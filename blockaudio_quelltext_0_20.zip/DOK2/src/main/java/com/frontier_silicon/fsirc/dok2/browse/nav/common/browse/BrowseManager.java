package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

import androidx.databinding.Observable;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.FsComponentsConfig;
import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.util.List;

/**
 * Created by lsuhov on 19/10/2016.
 */
public abstract class BrowseManager implements IConnectionStateListener {

    protected int mTotalCountForCurrentList = 0;

    protected BrowsePagesStore mBrowsePagesStore;
    protected String mUdnOfLastConnectedDevice = null;
    protected Thread mNavigateToCurrentListThread;
    private Observable.OnPropertyChangedCallback mPropertyChangedCallback;

    protected BrowseManager() {
        mBrowsePagesStore = new BrowsePagesStore();
    }

    public int getTotalCountForCurrentList() {
        if (mTotalCountForCurrentList < 0) {
            return mBrowsePagesStore.getNumberOfItemsInStore();
        }

        if (mBrowsePagesStore.searchItemWasFound()) {
            return mTotalCountForCurrentList > 0 ? mTotalCountForCurrentList - 1 : 0;
        } else {
            return mTotalCountForCurrentList;
        }
    }

    public boolean totalCountIsUndefined() {
        return mTotalCountForCurrentList < -1;
    }

    public void clearBrowsePageStore() {
        mBrowsePagesStore.clear();
    }

    public void prepareNavigation() {
        sendLoadingEvent();

        mBrowsePagesStore.clear();
    }

    public void getBrowseItemModelAsync(int position, IBrowseItemModelRetrieveListener listener) {
        mBrowsePagesStore.getBrowseItemModelAsync(position, listener);
    }


    public BrowseItemModel tryGetBrowseItemModel(int position) {
        BrowseItemModel browseItemModel = mBrowsePagesStore.tryGetBrowseItemModel(position);
        if (browseItemModel == null) {
            browseItemModel = new BrowseItemModel();
        }
        return browseItemModel;
    }

    public void deleteItem(int position) {
        if (position < mTotalCountForCurrentList) {
            mBrowsePagesStore.deleteItem(position);
            mTotalCountForCurrentList -= 1;
        }
    }

    public void playNavItemKey(Long key, IPlayNavigationListener listener) {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        PlayNavigationRunnable runnable = new PlayNavigationRunnable(key, radio, listener);

        Thread thread = new Thread(runnable);
        thread.start();
    }

    public abstract void refreshCurrentList(final long id);

    public abstract void navigateToDirectory(final Long key);

    public abstract void retrieveFirstPageSync(Radio radio, boolean firstPageOnly);

    public abstract EIRNavigationResult retrieveTotalNumberOfItemsFromCurrentListSync(Radio radio);

    protected abstract void sendLoadingEvent();

    public void clearAll() {
        mUdnOfLastConnectedDevice = null;
        mBrowsePagesStore.clear();
    }

    public void retrieveFirstPageSync(Radio radio) {
        retrieveFirstPageSync(radio, true);
    }

    //Needed in DAB. There is an issue with netRemote.nav.numItems, it returns -1
    public void retrieveAllPagesSync(Radio radio) {
        retrieveFirstPageSync(radio, false);
    }

    protected void addNavListToStore(int pagePosition, List<UnifiedBrowseListItem> listItems) {
        mBrowsePagesStore.addNavListToStore(pagePosition, listItems);
    }

    @Override
    public void onStateUpdate(ConnectionState newState) {
        switch (newState) {
            case DISCONNECTED:
            case DISCONNECTED_PIN_ERROR:
            case INVALID_SESSION:
            case NO_WIFI_OR_ETHERNET:
            case CONNECTED_TO_RADIO:
                FirebaseCrashlytics.getInstance().log("BrowseManager onStateUpdate - state: " + newState);
                clearAll();
                break;
        }
    }

    protected void addSpeakerSettingsListener() {
        final SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();

        if (mPropertyChangedCallback == null) {
            mPropertyChangedCallback = new Observable.OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable observable, int propertyId) {
                    if (observable == speakerDataModel.currentMode || observable == speakerDataModel.isInStandby) {
                        FirebaseCrashlytics.getInstance().log("BrowseManager addSpeakerSettingsListener");
                        clearAll();
                    }
                }
            };

            speakerDataModel.currentMode.addOnPropertyChangedCallback(mPropertyChangedCallback);
            speakerDataModel.isInStandby.addOnPropertyChangedCallback(mPropertyChangedCallback);
        }

    }
}
