package com.frontier_silicon.fsirc.dok2.browse.dmr.filter;

import com.frontier_silicon.fsirc.dok2.browse.dmr.BrowseDMRItemModel;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represent the internally stores list
 * of <code>BrowseDMRItemModel</code> items held by
 * the <code>BrowseDMRAdapter</code>.
 */
public class LocalMediaMemento {
  private List<BrowseDMRItemModel> mSavedItems;

  /**
   * Default constructor. The object references contained
   * in the list parameter are copied into a new list
   * to prevent modification in other parts of the app.
   *
   * @param originalList The adapters list <code>BrowseDMRItemModel</code> items
   */
  public LocalMediaMemento(List<BrowseDMRItemModel> originalList) {
    mSavedItems = new ArrayList<>();
    for (BrowseDMRItemModel currentItemModel : originalList) {
      mSavedItems.add(currentItemModel);
    }
  }

  /**
   * Returns the list of <code>BrowseDMRItemModel</code>
   * stored by the memento.
   *
   * @return The list of media items previously displayed
   */
  public List<BrowseDMRItemModel> getState() {
    return mSavedItems;
  }
}
