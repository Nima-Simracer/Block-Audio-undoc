package com.frontier_silicon.fsirc.dok2.update;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuControl;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuMandatory;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuSoftwareUpdateProgress;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class IsuBackgroundScannerRunnable implements Runnable {
	private static final long MAX_WAIT_FOR_RESP_MS = 4000;
	private static final long WAIT_FOR_RESP_MS = 200;
	private final int SECONDS_TO_WAIT_UNTIL_CHECK_FOR_UPDATES_IS_DONE = 45;
	
	private IsuInternalBackgroundListener mIsuInternalBackgroundListener;
	private List<Radio> mDevicesToScan;
	private List<Radio> mDevicesWithStartedIsuCheck = new CopyOnWriteArrayList<>();
	private Map<Radio, IsuBackgroundItemModel> mMapRadioIsuUpdates = new HashMap<>();
	private volatile Thread mThread;

	private int mNumResponses = 0;
	
	public IsuBackgroundScannerRunnable(IsuInternalBackgroundListener isuInternalBackgroundListener, List<Radio> radioItems) {
		mIsuInternalBackgroundListener = isuInternalBackgroundListener;
		mDevicesToScan = radioItems;
	}

	public void setThreadOwner(Thread thread) {
		mThread = thread;
	}

	@Override
	public void run() {
		
		if (mThread == null)
			return;
		
		if (!checkIsuAvailable(mDevicesToScan, true))
			return;

		notifyListener();

		if (mDevicesWithStartedIsuCheck.size() > 0) {
			try {
				Thread.sleep(1000 * SECONDS_TO_WAIT_UNTIL_CHECK_FOR_UPDATES_IS_DONE);
			} catch (InterruptedException e) {
				FsLogger.log("ISU Background check was interrupted during sleep of Runnable", LogLevel.Error);
			}

			FsLogger.log(">>>> ISU wait time over. check radio again", LogLevel.Error);

			if (!checkIsuAvailable(mDevicesWithStartedIsuCheck, false))
				return;

            notifyListener();
		}

		FsLogger.log(">>> FINISH ISU Update check");
	}
	
	private boolean checkIsuAvailable(List<Radio> radioItems, boolean startCheckIfNeeded) {
		mNumResponses = 0;

		for (Radio radio : radioItems) {
			checkUpdateState(radio, startCheckIfNeeded);
			
			if (mThread == null)
				return false;
		}

		int cnt = 0;
		int maxCnt = (int) (MAX_WAIT_FOR_RESP_MS / WAIT_FOR_RESP_MS);
		int expectedResponses = radioItems.size();
		while (mNumResponses < expectedResponses && cnt < maxCnt) {
			try {
				Thread.sleep(WAIT_FOR_RESP_MS);
			} catch (InterruptedException e) {
			}

			cnt++;
		}

		return true;
	}

	private void checkUpdateState(final Radio radio, final boolean startCheckIfNeeded) {
		FsLogger.log(">>> ISU state check for " + radio);

        NodeSysIsuSoftwareUpdateProgress progress = (NodeSysIsuSoftwareUpdateProgress)radio
                .nodeSyncGetter(NodeSysIsuSoftwareUpdateProgress.class).get();

        if (progress != null && progress.getValue() > 0) {
            FsLogger.log("Speaker " + radio.toString() + " is updating. Stopping check");
            return;
        }

		RadioNodeUtil.getNodeFromRadioAsync(radio, NodeSysIsuState.class, new RadioNodeUtil.INodeResultListener() {
			@Override
			public void onNodeResult(NodeInfo node) {
				if (node != null) {
					NodeSysIsuState stateNode = (NodeSysIsuState) node;

					FsLogger.log(">>> ISU state for " + radio + " " + stateNode.getValueEnum());

					switch (stateNode.getValueEnum()) {
						case IDLE:
						case CHECK_FAILED:
						case CHECK_IN_PROGRESS:
							if (startCheckIfNeeded) {
								startScanningForUpdate(radio);
							} else {
								onNoAvailableUpdate(radio);
							}
							break;
						case UPDATE_AVAILABLE:
							onAvailableUpdate(radio);
							break;
						default:
							if (startCheckIfNeeded) {
								startScanningForUpdate(radio);
							} else {
								onNoAvailableUpdate(radio);
							}
							break;
					}
				}

				mNumResponses++;
			}
		});
	}

	private void startScanningForUpdate(final Radio radio) {
		RadioNodeUtil.setNodeToRadioAsync(radio, new NodeSysIsuControl(NodeSysIsuControl.Ord.CHECK_FOR_UPDATE), new RadioNodeUtil.INodeSetResultListener() {
			@Override
			public void onNodeSetResult(boolean success) {
				if (success) {
					mDevicesWithStartedIsuCheck.add(radio);

					FsLogger.log(">>> START ISU Update check for " + radio, LogLevel.Warning);
				} else {
					FsLogger.log(">>> ERROR STARTING ISU Update check for " + radio, LogLevel.Error);
				}
			}
		});
	}

	private void onAvailableUpdate(final Radio radio) {
		RadioNodeUtil.getNodeFromRadioAsync(radio, NodeSysIsuMandatory.class, new RadioNodeUtil.INodeResultListener() {
			@Override
			public void onNodeResult(NodeInfo node) {
				if (node != null) {
					NodeSysIsuMandatory mandatoryNode = (NodeSysIsuMandatory) node;

					IsuBackgroundItemModel isuBackgroundItemModel = new IsuBackgroundItemModel();
					isuBackgroundItemModel.mUpdateIsAvailable = true;
					isuBackgroundItemModel.mUpdateIsMandatory = mandatoryNode != null && mandatoryNode.getValueEnum() == NodeSysIsuMandatory.Ord.YES;

					mMapRadioIsuUpdates.put(radio, isuBackgroundItemModel);
				}
			}
		});
	}

	private void onNoAvailableUpdate(Radio radio) {
		IsuBackgroundItemModel isuBackgroundItemModel = new IsuBackgroundItemModel();
		
		mMapRadioIsuUpdates.put(radio, isuBackgroundItemModel);
	}
	
	private void notifyListener() {
        Map<Radio, IsuBackgroundItemModel> map = new HashMap<>(mMapRadioIsuUpdates);

		mIsuInternalBackgroundListener.onIsuResults(map);
	}
	
	public void stop() {
		mThread = null;
	}
}
