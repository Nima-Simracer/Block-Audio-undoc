package com.frontier_silicon.fsirc.dok2.baseActivity;

import android.app.Activity;

import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.connection.ConnectionManager;
import com.frontier_silicon.fsirc.dok2.connection.connectionLost.ConnectionLostActivity;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;


public class ConnectionLostWatcher implements IConnectionStateListener {
    private Activity mActivity;

    public ConnectionLostWatcher(Activity activity) {
        mActivity = activity;
    }

    public void registerConnectionStateListener() {
        ConnectionStateUtil.getInstance().addListener(this, true);
    }

    @Override
    public void onStateUpdate(ConnectionState newState) {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        mActivity.runOnUiThread(() -> {
            switch (newState) {
                case INVALID_SESSION:
                case DISCONNECTED:
                    if (ConnectionManager.getInstance().getLastConnectedDevice() != null) {
                        NavigationHelper.goToActivity(mActivity, ConnectionLostActivity.class);
                    } else {
                        NavigationHelper.goToHomeAndClearActivityStack(mActivity);
                    }
                    break;
                case DISCONNECTED_PIN_ERROR:
                    NavigationHelper.goToHomeAndClearActivityStack(mActivity);
                    break;
                default:
                    break;
            }
        });
    }

    public void removeConnectionStateListener() {
        ConnectionStateUtil.getInstance().removeListener(this);
    }

    public void dispose() {
        mActivity = null;
    }
}
