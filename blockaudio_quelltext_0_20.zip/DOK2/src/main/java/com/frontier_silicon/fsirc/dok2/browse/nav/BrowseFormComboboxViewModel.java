package com.frontier_silicon.fsirc.dok2.browse.nav;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormCombobox;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormComboboxOption;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ComboboxItemsLoadedEvent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.List;

/**
 * Created by adanaila on 10/31/2016.
 */

public class BrowseFormComboboxViewModel extends BrowseFormItemBaseViewModel
                                        implements AdapterView.OnItemSelectedListener {

    BaseAdapter mAdapter;
    List<FormComboboxOption> mComboboxItems;

    public BrowseFormComboboxViewModel(int position, FormItem item, FormOptionAdapter spinnerAdapter, List<FormComboboxOption> items) {
        super(position, item);

        mAdapter = spinnerAdapter;
        mComboboxItems = items;

        EventBus.getDefault().register(this);

        if (getComboboxItems() != null) {
            populateAdapter();
        }
    }

    public List<FormComboboxOption> getComboboxItems() {
        List<FormComboboxOption> result = ((FormCombobox) this.mFormItemBase).getFormComboBoxOptions();

        return result;
    }

    public void onItemSelected(int position) {
        ((FormCombobox) this.mFormItemBase).setSelectedOption(position);
    }

    @Subscribe
    public void onComboboxLoadedResult(final ComboboxItemsLoadedEvent event) {
        populateAdapter();
    }

    private void populateAdapter() {
        List<FormComboboxOption> items = getComboboxItems();

        mComboboxItems.clear();
        mComboboxItems.addAll(items);

        mAdapter.notifyDataSetChanged();
    }

    public void dispose() {
        super.dispose();

        mAdapter = null;
        mComboboxItems = null;

        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        onItemSelected(position);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
