package com.frontier_silicon.fsirc.dok2.home;

import android.app.Activity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.HomeListItemGroupBinding;
import com.frontier_silicon.fsirc.dok2.databinding.HomeListItemGroupSgBinding;
import com.frontier_silicon.fsirc.dok2.databinding.HomeListItemSpeakerBinding;
import com.frontier_silicon.fsirc.dok2.databinding.HomeListItemSpeakerCoreBinding;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 03/05/2017.
 */

public class HomeSpeakersAdapter extends Adapter<RecyclerView.ViewHolder> {

    private Activity mActivity;
    private RecyclerView mRecyclerView;
    private List<MultiroomItemModel> mItemModels = new ArrayList<>();

    private class HomeSpeakerViewHolder extends RecyclerView.ViewHolder {
        HomeListItemSpeakerBinding mBinding;

        HomeSpeakerViewHolder(HomeListItemSpeakerBinding speakerBinding) {
            super(speakerBinding.getRoot());

            mBinding = speakerBinding;
        }
    }

    private class HomeGroupViewHolder extends RecyclerView.ViewHolder {
        HomeListItemGroupBinding mBinding;

        HomeGroupViewHolder(HomeListItemGroupBinding groupBinding) {
            super(groupBinding.getRoot());

            mBinding = groupBinding;
        }
    }

    private class HomeSingleGroupViewHolder extends RecyclerView.ViewHolder {
        HomeListItemGroupSgBinding mBinding;

        HomeSingleGroupViewHolder(HomeListItemGroupSgBinding binding) {
            super(binding.getRoot());

            mBinding = binding;
        }
    }

    public HomeSpeakersAdapter(Activity activity) {
        mActivity = activity;
    }

    public void swapItems(List<MultiroomItemModel> itemModels) {
        HomeSpeakersModelDiffCallback diffCallback = new HomeSpeakersModelDiffCallback(mItemModels, itemModels);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        mItemModels.clear();
        mItemModels.addAll(itemModels);

        diffResult.dispatchUpdatesTo(this);

        mRecyclerView.getLayoutManager().scrollToPosition(0);
    }

    @Override
    @MultiroomItemModel.MultiroomItemModelType
    public int getItemViewType(int position) {
        MultiroomItemModel multiroomItemModel = mItemModels.get(position);

        return multiroomItemModel.getType();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, @MultiroomItemModel.MultiroomItemModelType int viewType) {
        @MultiroomItemModel.MultiroomItemModelType int speakerType = viewType;
        switch (speakerType) {
            case MultiroomItemModel.SimpleSpeaker:
            case MultiroomItemModel.MultiroomSpeaker:
            case MultiroomItemModel.SingleGroupSpeaker: {
                HomeListItemSpeakerBinding binding = DataBindingUtil.inflate(
                        LayoutInflater.from(parent.getContext()),
                        R.layout.home_list_item_speaker,
                        parent, false);

                return new HomeSpeakerViewHolder(binding);
            }
            case MultiroomItemModel.MultiroomGroup: {
                HomeListItemGroupBinding binding = DataBindingUtil.inflate(
                        LayoutInflater.from(parent.getContext()),
                        R.layout.home_list_item_group,
                        parent, false);

                return new HomeGroupViewHolder(binding);
            }
            case MultiroomItemModel.SingleGroup: {
                HomeListItemGroupSgBinding binding = DataBindingUtil.inflate(
                        LayoutInflater.from(parent.getContext()),
                        R.layout.home_list_item_group_sg,
                        parent, false);

                return new HomeSingleGroupViewHolder(binding);
            }
        }
        return null;
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MultiroomItemModel multiroomItemModel = mItemModels.get(position);

        switch (multiroomItemModel.getType()) {
            case MultiroomItemModel.SimpleSpeaker:
            case MultiroomItemModel.MultiroomSpeaker:
            case MultiroomItemModel.SingleGroupSpeaker: {
                HomeSpeakerViewHolder homeSpeakerViewHolder = (HomeSpeakerViewHolder) holder;
                HomeListItemSpeakerBinding binding = homeSpeakerViewHolder.mBinding;

                HomeSpeakerViewModel viewModel = new HomeSpeakerViewModel(multiroomItemModel, mActivity);
                binding.setViewModel(viewModel);
                break;
            }
            case MultiroomItemModel.MultiroomGroup: {
                HomeGroupViewHolder homeGroupViewHolder = (HomeGroupViewHolder) holder;
                HomeListItemGroupBinding binding = homeGroupViewHolder.mBinding;

                HomeGroupViewModel viewModel = new HomeGroupViewModel(multiroomItemModel, mActivity);
                binding.setViewModel(viewModel);

                inflateMultiroomGroupItems(multiroomItemModel, homeGroupViewHolder);
                break;
            }
            case MultiroomItemModel.SingleGroup: {
                HomeSingleGroupViewHolder singleGroupViewHolder = (HomeSingleGroupViewHolder) holder;
                HomeListItemGroupSgBinding binding = singleGroupViewHolder.mBinding;

                HomeSingleGroupViewModel viewModel = new HomeSingleGroupViewModel(multiroomItemModel, mActivity);
                binding.setViewModel(viewModel);

                inflateSingleGroupItems(multiroomItemModel, singleGroupViewHolder, viewModel);
                break;
            }
        }
    }

    private void inflateSingleGroupItems(MultiroomItemModel multiroomItemModel, HomeSingleGroupViewHolder singleGroupViewHolder,
                                         HomeSingleGroupViewModel singleGroupViewModel) {

        ViewGroup listItemsLayout = singleGroupViewHolder.mBinding.layoutSpeakers;
        listItemsLayout.removeAllViews();

        LayoutInflater layoutInflater = LayoutInflater.from(listItemsLayout.getContext());

        List<MultiroomDeviceModel> deviceModels = multiroomItemModel.getFrozenMultiroomDeviceModels();
        for (MultiroomDeviceModel deviceModel : deviceModels) {
            HomeListItemSpeakerCoreBinding itemBinding = DataBindingUtil.inflate(layoutInflater,
                    R.layout.home_list_item_speaker_core, listItemsLayout, false);

            MultiroomItemModel speakerMultiroomItemModel = new MultiroomItemModel(deviceModel);
            HomeSpeakerFromSGGroupViewModel speakerViewModel = new HomeSpeakerFromSGGroupViewModel(
                    speakerMultiroomItemModel, singleGroupViewModel.isAvailable.get(), mActivity);

            itemBinding.setViewModel(speakerViewModel);

            singleGroupViewModel.addItemBinding(itemBinding);

            listItemsLayout.addView(itemBinding.getRoot());
        }
    }

    private void inflateMultiroomGroupItems(MultiroomItemModel multiroomItemModel, HomeGroupViewHolder homeGroupViewHolder) {
        ViewGroup listItemsLayout = homeGroupViewHolder.mBinding.layoutSpeakers;
        listItemsLayout.removeAllViews();

        LayoutInflater layoutInflater = LayoutInflater.from(listItemsLayout.getContext());

        List<MultiroomDeviceModel> deviceModels = multiroomItemModel.getFrozenMultiroomDeviceModels();
        for (MultiroomDeviceModel deviceModel : deviceModels) {
            View groupItemLayout = layoutInflater.inflate(R.layout.home_list_item_group_item, null);

            TextView textView = groupItemLayout.findViewById(R.id.speakerName);
            textView.setText(deviceModel.toString());

            View notAvailableImage = groupItemLayout.findViewById(R.id.imageNotAvailable);
            notAvailableImage.setVisibility(deviceModel.mFrozenIsAvailable ? View.GONE : View.VISIBLE);

            listItemsLayout.addView(groupItemLayout);
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {

        if (holder instanceof HomeSpeakerViewHolder) {
            HomeSpeakerViewHolder speakerViewHolder = (HomeSpeakerViewHolder)holder;
            disposeHomeSpeakerViewHolder(speakerViewHolder);
        } else if (holder instanceof HomeGroupViewHolder) {
            HomeGroupViewHolder groupViewHolder = (HomeGroupViewHolder)holder;
            disposeHomeGroupViewHolder(groupViewHolder);
        } else if (holder instanceof HomeSingleGroupViewHolder) {
            HomeSingleGroupViewHolder singleGroupViewHolder = (HomeSingleGroupViewHolder)holder;
            disposeHomeSingleGroupViewHolder(singleGroupViewHolder);
        }
    }

    private void disposeHomeGroupViewHolder(HomeGroupViewHolder groupViewHolder) {
        HomeGroupViewModel groupViewModel = groupViewHolder.mBinding.getViewModel();
        if (groupViewModel != null) {
            groupViewModel.dispose();
            groupViewHolder.mBinding.setViewModel(null);
        }

        groupViewHolder.mBinding.layoutSpeakers.removeAllViews();
    }

    private void disposeHomeSpeakerViewHolder(HomeSpeakerViewHolder speakerViewHolder) {
        HomeSpeakerViewModel speakerViewModel = speakerViewHolder.mBinding.getViewModel();
        if (speakerViewModel != null) {
            speakerViewModel.dispose();
            speakerViewHolder.mBinding.setViewModel(null);
        }
    }

    private void disposeHomeSingleGroupViewHolder(HomeSingleGroupViewHolder singleGroupViewHolder) {
        HomeSingleGroupViewModel singleGroupViewModel = singleGroupViewHolder.mBinding.getViewModel();

        if (singleGroupViewModel != null) {
            List<HomeListItemSpeakerCoreBinding> speakerBindings = singleGroupViewModel.getListOfItemBinding();
            for (HomeListItemSpeakerCoreBinding speakerBinding : speakerBindings) {
                HomeSpeakerViewModel speakerViewModel = speakerBinding.getViewModel();

                speakerViewModel.dispose();
                speakerBinding.setViewModel(null);
            }
        }

        singleGroupViewHolder.mBinding.layoutSpeakers.removeAllViews();
    }


    @Override
    public int getItemCount() {
        return mItemModels.size();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);

        mRecyclerView = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);

        mRecyclerView = null;
    }

    @Override
    public boolean onFailedToRecycleView(RecyclerView.ViewHolder holder) {
        //trying to recycle all viewHolders
        return true;
    }

    public void dispose() {
        FsLogger.log("SpeakersAdapter: dispose");

        mActivity = null;
        mRecyclerView = null;
        mItemModels.clear();
    }
}
