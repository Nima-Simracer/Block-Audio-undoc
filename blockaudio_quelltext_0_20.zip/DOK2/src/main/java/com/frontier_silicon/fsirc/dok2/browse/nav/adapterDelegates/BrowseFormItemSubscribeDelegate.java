package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseFormItemBaseViewModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.databinding.BrowseFormItemBaseBinding;

public class BrowseFormItemSubscribeDelegate extends RecyclerViewListItemDelegate {
    private int mBrowseType;

    public BrowseFormItemSubscribeDelegate(int browseType) {
        mBrowseType = browseType;
    }

    @Override
    public ListItemViewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        BrowseFormItemBaseBinding binding = DataBindingUtil.inflate(
                layoutInflater,
                R.layout.browse_form_item_base,
                parent, false);
        return new BrowseFormItemSubscribeDelegate.BrowseFormItemSubscribeViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(ListItemViewHolder holder, int position, RecyclerView.Adapter<ListItemViewHolder> adapter) {
        FormManager formManager = BrowseManagerFactory.getFormManager(mBrowseType);
        FormItem formItem = formManager.getItemByPosition(position);

        BrowseFormItemSubscribeDelegate.BrowseFormItemSubscribeViewHolder descriptionViewHolder = (BrowseFormItemSubscribeDelegate.BrowseFormItemSubscribeViewHolder) holder;

        BrowseFormItemBaseViewModel viewModel = new BrowseFormItemBaseViewModel(position, formItem);
        descriptionViewHolder.mBinding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(ListItemViewHolder holder) {
        BrowseFormItemSubscribeDelegate.BrowseFormItemSubscribeViewHolder formBaseViewHolder = (BrowseFormItemSubscribeDelegate.BrowseFormItemSubscribeViewHolder) holder;
        BrowseFormItemBaseViewModel viewModel = formBaseViewHolder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            formBaseViewHolder.mBinding.setViewModel(null);
        }

        formBaseViewHolder.mBinding.text1.setText("");
    }

    private static class BrowseFormItemSubscribeViewHolder extends ListItemViewHolder {
        BrowseFormItemBaseBinding mBinding;

        BrowseFormItemSubscribeViewHolder(BrowseFormItemBaseBinding binding, RecyclerViewListItemDelegate delegate) {
            super(binding.getRoot(), delegate);

            mBinding = binding;
        }
    }
}
