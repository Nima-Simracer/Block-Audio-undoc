package com.frontier_silicon.fsirc.dok2.settings.avs;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.StyleSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.frontier_silicon.components.common.ExternalAppsOpener;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;

public class AvsFinishActivity extends UndokActivityBase {
    private TextView txtFooter, screenDescription;
    private static final int ACTION_DONE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.avs_finish_activity);

        setupAppBar();
        setTitle(R.string.avs_things_to_try);

        txtFooter = findViewById(R.id.avs_footer);
        screenDescription = findViewById(R.id.screen_description);

        setText(txtFooter, R.string.footer_avs_login_finish);
    }

    private void setText(TextView textView, int stringToShowId) {
        String alexaApp = getString(R.string.logout_alexa_app);

        String stringToShow = getString(stringToShowId, alexaApp);
        int startIndex = stringToShow.indexOf(alexaApp);
        int endIndex = startIndex + alexaApp.length();

        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(stringToShow);
        spannableStringBuilder.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                ExternalAppsOpener.openAlexaApp(AvsFinishActivity.this);
            }
        },startIndex, endIndex,  Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);


        spannableStringBuilder.setSpan(new StyleSpan(Typeface.BOLD), startIndex, endIndex, 0);

        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setText(spannableStringBuilder,  TextView.BufferType.SPANNABLE);
    }

    @Override
    protected void onResume(){
        super.onResume();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            screenDescription.setText(Html.fromHtml(getString(R.string.educated_avs_login_texts), Html.FROM_HTML_MODE_COMPACT));
        } else {
            screenDescription.setText(Html.fromHtml(getString(R.string.educated_avs_login_texts)));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(Menu.NONE, ACTION_DONE, Menu.NONE, R.string.avs_login_finish_done).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);;
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case ACTION_DONE:
                finish();
                return true;

            default:
                return false;
        }
    }
}
