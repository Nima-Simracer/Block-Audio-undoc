package com.frontier_silicon.fsirc.dok2.settings.language;

import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.Node.NodeDefs;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidLang;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysLang;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseManager;
import com.frontier_silicon.fsirc.dok2.settings.SettingsUtil;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;

/**
 * Created by hcostescu on 11/21/2016.
 */

public class LanguageUtil{
    private ArrayList<LanguageItemModel> mLanguageList;

    Radio mRadio;

    public LanguageUtil(Radio radio)
    {
        mRadio = radio;
    }

    public void getLanguageList(ILanguageUpdate listener, ILanguageSupported languageSupportedListener) {
        LanguageUtilTask languageTask = new LanguageUtilTask(mRadio,listener,languageSupportedListener);
        TaskHelper.execute(languageTask);
    }

    public void setLanguage(long keyId, final ILanguageSet listener) {
        if (mRadio == null) {
            return;
        }

       RadioNodeUtil.setNodeToRadioAsync(mRadio, new NodeSysLang(keyId), new RadioNodeUtil.INodeSetResultListener() {
           @Override
           public void onNodeSetResult(boolean success) {
               if (listener != null)
                   listener.langugageSet();
               if (success) {
                   // reset navigation list
                   NavBrowseManager.getInstance().clearBrowsePageStore();
                   // reset sources list
                   mRadio.getListNode(NodeSysCapsValidModes.class, "-1", NodeDefs.MaxItemsForList, false, true, new IGetNodeCallback() {
                       @Override
                       public void getNodeResult(NodeInfo node) {
                       }

                       @Override
                       public void getNodeError(Class nodeType, NodeErrorResponse error) {
                       }
                   });
               }
           }
       });
    }

    public class LanguageUtilTask extends AsyncTask<Void,Void,Boolean> {

        private ILanguageUpdate mListener;
        private Radio mRadio;
        private ILanguageSupported mLanguageSupportedListener;

        public LanguageUtilTask(Radio radio,ILanguageUpdate languageUpdateListener, ILanguageSupported languageSupportedListener) {
            mListener = languageUpdateListener;
            mLanguageSupportedListener = languageSupportedListener;
            mRadio = radio;

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            if (mRadio == null)
                return false;

            NodeSysLang currLanguage = (NodeSysLang) mRadio.nodeSyncGetter(NodeSysLang.class).get();

            final long currentLanguageValue;
            if (currLanguage != null) {
                currentLanguageValue = currLanguage.getValue();
            }
            else {
                currentLanguageValue = -1;
            }

            mLanguageList = new ArrayList<>();

            mRadio.getListNode(NodeSysCapsValidLang.class, true, new IGetNodeCallback() {
                @Override
                public void getNodeResult(NodeInfo node) {
                    NodeSysCapsValidLang lListNode = (NodeSysCapsValidLang) node;

                    for (NodeSysCapsValidLang.ListItem lItem : lListNode.getEntries()) {
                        boolean isCurrentSelected = (currentLanguageValue == lItem.getKey());

                      LanguageItemModel equalizerPresetItem = new LanguageItemModel(lItem.getLangLabel(), isCurrentSelected, false, lItem.getKey());
                        mLanguageList.add(equalizerPresetItem);
                    }
                }

                @Override
                public void getNodeError(Class nodeType, NodeErrorResponse error) {
                    FsLogger.log("getListNode failed " + nodeType + " " + error, LogLevel.Error);
                }
            });

            return true;
        }

        @Override
        protected void onPostExecute(final Boolean result){
            Boolean isSupported = false;
            if(mLanguageSupportedListener != null && mLanguageList != null) {

			String testLang = SettingsUtil.testLang;
                if (mLanguageList.size() == 2 && (mLanguageList.get(0).mName.contentEquals(testLang)  ||
                    mLanguageList.get(1).mName.contentEquals(testLang) )) {
                    isSupported = false;
                } else {
                    isSupported = true;
                }
                mLanguageSupportedListener.OnLanguageIsSupported(isSupported && !mLanguageList.isEmpty());
            }
            super.onPostExecute(result);
            if (mListener != null && result != null && result == true) {
                mListener.onLanguageUpdate(mLanguageList);
            }
        }
    }
}