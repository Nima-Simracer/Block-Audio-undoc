package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.UnifiedBrowseListItem;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowsePageModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.PageRetrieverRunnable;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.List;
import java.util.concurrent.ExecutorService;

/**
 * Created by lsuhov on 30/06/16.
 */

public class NavigationPageModel extends BrowsePageModel{

    public NavigationPageModel(int key, ExecutorService executorService) {
        super(key,executorService);
    }

    public NavigationPageModel(int key, List<UnifiedBrowseListItem> listItems, ExecutorService executorService) {
        super(key, listItems, executorService);
    }

    protected void startRetrievingBrowsePage() {
        if (mIsDisposed) {
            return;
        }

        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        NavPageRetrieverRunnable runnable = new NavPageRetrieverRunnable(startIndex, radio, true, listItems -> NetRemote.getMainThreadExecutor().execute(() -> {
            if (!mIsDisposed) {
                parseBrowseList(listItems);
            }
        }));

        FsLogger.log("adding navigation runnable " + startIndex, LogLevel.Info);
        mExecutorService.submit(runnable);
    }
}
