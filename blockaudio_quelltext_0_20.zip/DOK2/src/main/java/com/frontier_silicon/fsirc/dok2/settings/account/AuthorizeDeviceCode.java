package com.frontier_silicon.fsirc.dok2.settings.account;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by cvladu on 13/03/2018.
 */

public class AuthorizeDeviceCode {
    private String mAuthorizeCode;
    private String mScope;
    private int mExpireTime;

    public void parseResponse(JSONObject object) {
        try {
            mAuthorizeCode = object.getString("code");
            mExpireTime = object.getInt("expires_in");
            mScope = object.getString("scopes");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public String getAuthorizeCode() {
        return mAuthorizeCode;
    }
}
