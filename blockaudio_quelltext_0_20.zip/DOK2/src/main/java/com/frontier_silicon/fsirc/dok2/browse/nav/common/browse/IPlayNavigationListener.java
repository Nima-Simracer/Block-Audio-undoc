package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

/**
 * Created by lsuhov on 15/02/2018.
 *
 * Listener that will inform us after the play command was sent
 */

public interface IPlayNavigationListener {
    void onPlayInitiationResult(boolean success);
}
