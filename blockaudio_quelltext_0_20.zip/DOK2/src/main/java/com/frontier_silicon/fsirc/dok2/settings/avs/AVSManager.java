package com.frontier_silicon.fsirc.dok2.settings.avs;

import com.amazon.identity.auth.device.api.authorization.AuthorizationManager;
import com.amazon.identity.auth.device.api.authorization.AuthorizeRequest;
import com.amazon.identity.auth.device.api.authorization.ScopeFactory;
import com.amazon.identity.auth.device.api.workflow.RequestContext;
import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeAvsAuthcode;
import com.frontier_silicon.NetRemoteLib.Node.NodeAvsProductmetadata;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.loggerlib.FsLogger;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by cvladu on 09/01/2019.
 */

public class AVSManager {
    private static AVSManager mInstance;
    private String mProductId;
    private String mDeviceSerialNumber;
    private String mCodeChallenge;
    private String mCodeChallengeMethod;


    private AVSManager() {
    }

    public static AVSManager getInstance() {
        if (mInstance == null) {
            mInstance = new AVSManager();
        }

        return mInstance;
    }

    public void getMetadataInfoFromSpeaker(Radio radio, IAvsResponse listener) {
        if (radio == null) {
            return;
        }

        RadioNodeUtil.getNodeFromRadioAsync(radio, NodeAvsProductmetadata.class, node -> {
            NodeAvsProductmetadata avsProductmetadata = (NodeAvsProductmetadata) node;

            if (avsProductmetadata != null) {
                JSONObject jsonMeta;
                try {
                    jsonMeta = new JSONObject(avsProductmetadata.getValue());
                    jsonMeta = jsonMeta.getJSONObject("authDelegate");

                    mProductId = jsonMeta.getString("productId");
                    mDeviceSerialNumber = jsonMeta.getString("deviceSerialNumber");
                    mCodeChallenge = jsonMeta.getString("code_challenge");
                    mCodeChallengeMethod = jsonMeta.getString("code_challenge_method");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (listener != null) {
                    listener.onSuccess();
                }
            }
        });
    }

    public void authorize(RequestContext requestContext) {
        final JSONObject scopeData = new JSONObject();
        final JSONObject productInstanceAttributes = new JSONObject();

        try {
            productInstanceAttributes.put("deviceSerialNumber", mDeviceSerialNumber);
            scopeData.put("productInstanceAttributes", productInstanceAttributes);
            scopeData.put("productID", mProductId);

            AuthorizationManager.authorize(new AuthorizeRequest.Builder(requestContext)
                    .addScopes(ScopeFactory.scopeNamed("alexa:voice_service:pre_auth"),
                            ScopeFactory.scopeNamed("alexa:all", scopeData))
                    .forGrantType(AuthorizeRequest.GrantType.AUTHORIZATION_CODE)
                    .withProofKeyParameters(mCodeChallenge, mCodeChallengeMethod)
                    .build());


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void sendDataToTheSpeaker(String authorizationCode, String redirectUri, String clientId, Radio radio, IAvsResponse listener) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("code", authorizationCode);
            jsonObject.put("client_id", clientId);
            jsonObject.put("redirect_uri", redirectUri);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        FsLogger.log("AVS: authorization code: " + authorizationCode + " json: \n" + jsonObject.toString());

        if (radio == null) {
            return;
        }

        NodeAvsAuthcode avsAuthcode = new NodeAvsAuthcode(jsonObject.toString());
        RadioNodeUtil.setNodeToRadioAsync(radio, avsAuthcode, success -> NetRemote.getMainThreadExecutor().execute(() -> {
            if (success) {
                if (listener != null) {
                    listener.onSuccess();
                }
            } else {
                if (listener != null) {
                    listener.onError();
                }
            }
        }));
    }

    public interface IAvsResponse {
        void onSuccess();

        void onError();
    }


}
