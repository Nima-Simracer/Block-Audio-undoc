package com.frontier_silicon.fsirc.dok2.settings.language;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.R;

import java.util.List;

/**
 * Created by hcostescu on 17/01/17.
 */

public class LanguageArrayAdapter extends ArrayAdapter<LanguageItemModel> {
    private Context mContext;

    private final ILanguageSettingClickListener mListener;

    public LanguageArrayAdapter(Context context, int resource, int textViewResourceId, List<LanguageItemModel> objects, ILanguageSettingClickListener listener) {
        super(context, resource, textViewResourceId, objects);

        mContext = context;
        mListener = listener;

    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final LanguageItemModel item = getItem(position);

        if (v == null)
            v = li.inflate(R.layout.language_settings_list_item, null);

        String text = item.mName;

        TextView tv = (TextView) v.findViewById(R.id.text1);
        tv.setText(text);

        ImageView imageSelected = (ImageView) v.findViewById(R.id.imageViewSelected);
        if (item.mIsSet) {
            imageSelected.setVisibility(View.VISIBLE);
        } else {
            imageSelected.setVisibility(View.GONE);
        }

        ProgressBar progressBar = (ProgressBar)v.findViewById(R.id.progressBarLanguageSettings);
        if (item.mIsProgressVisible){
            progressBar.setVisibility(View.VISIBLE);
        }
        else{
            progressBar.setVisibility(View.GONE);
        }

        View layoutLanguageSettingsItem = v.findViewById(R.id.layoutLanguageSettingsItem);
        layoutLanguageSettingsItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    mListener.onListItemClick(item);
                }
            }
        });

        return v;
    }
}

