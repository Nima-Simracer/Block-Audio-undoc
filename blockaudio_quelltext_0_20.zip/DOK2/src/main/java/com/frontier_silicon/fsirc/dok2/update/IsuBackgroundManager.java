package com.frontier_silicon.fsirc.dok2.update;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AlertDialog;

import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.fsirc.dok2.util.UndokPreferences;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class IsuBackgroundManager implements IsuInternalBackgroundListener {
	private final int SECONDS_TO_WAIT_UNTIL_TRIGGER_ISU_BACKGROUND = 25;

	private final int WAIT_BEFORE_ISU_RADIO_RESCAN_MS = 12 * 60 * 60 * 1000; // 12 hours
    private final String SHOULD_SHOW_UPDATE_DIALOG_PREF_KEY = "SHOULD_SHOW_UPDATE_DIALOG_PREF";
    private final String SHOW_UPDATE_DIALOG_KEY = "SHOW_UPDATE_DIALOG_KEY";
	
	private final Object mLock = new Object();
	private static IsuBackgroundManager mInstance;
	private Timer mTimer;
	private IsuBackgroundScannerRunnable mIsuBackgroundRunnable;
	private Thread mIsuBackgroundThread;
	private HashMap<String, IsuBackgroundItemModel> mMapRadioIsuUpdates;
	private HashMap<String, Long> mRadioIsuUpdatesLastTimeCheck;
    private List<IsuBackgroundListener> mListeners;
    Activity mActivity;

	private IRadioDiscoveryListener mRadioBackgroundScanListener = null;
	
	private IsuBackgroundManager() {
        mListeners = new ArrayList<>();
		mMapRadioIsuUpdates = new HashMap<>();
		mRadioIsuUpdatesLastTimeCheck = new HashMap<>();
    }
	
	public static IsuBackgroundManager getInstance() {
		if (mInstance == null)
			mInstance = new IsuBackgroundManager();
		
		return mInstance;
	}

	public void startScan(Activity activity) {
        mActivity = activity;

		addRadioScanListener();

		startScanTimer();
	}

	void startScanTimer() {
		clearTimerAndThread();

		mTimer = new Timer();
        try {
            mTimer.schedule(new TimerTask() {

                @Override
                public void run() {
                    startBackgroundCheck();
                }
            }, 1000 * SECONDS_TO_WAIT_UNTIL_TRIGGER_ISU_BACKGROUND);
        } catch (Exception e) {
            FsLogger.log(e.getMessage(), LogLevel.Error);
        }
	}

	public void stopScan() {
        mActivity = null;

		clearTimerAndThread();

		removeRadioScanListener();
	}

	void startBackgroundCheck() {
		clearTimerAndThread();

		List<Radio> radios = getListOfRadiosForUpdateCheck();

		if (radios.size() > 0) {
			mIsuBackgroundRunnable = new IsuBackgroundScannerRunnable(this, radios);
			mIsuBackgroundThread = new Thread(mIsuBackgroundRunnable, "IsuBackgroundCheckThread");

			mIsuBackgroundRunnable.setThreadOwner(mIsuBackgroundThread);
			mIsuBackgroundThread.run();
		} else {
			notifyListeners();
		}
	}

	synchronized private void clearTimerAndThread() {
		if (mTimer != null) {
			mTimer.cancel();
			mTimer.purge();
			mTimer = null;
		}

		if (mIsuBackgroundThread != null) {
			mIsuBackgroundRunnable.stop();
			mIsuBackgroundThread.interrupt();
			
			mIsuBackgroundRunnable = null;
			mIsuBackgroundThread = null;
		}
	}

	@Override
	public void onIsuResults(Map<Radio, IsuBackgroundItemModel> hashItemModels) {
		mergeHashResults(hashItemModels);

        showUpdateDialogIfNeeded();
	}

    private void showUpdateDialogIfNeeded() {
        if (mActivity != null) {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showUpdateDialogIfNeededImpl();
                }
            });
        }
    }

    void showUpdateDialogIfNeededImpl() {
        if (mActivity == null) {
            return;
        }

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mActivity);
        boolean shouldShowUpdateDialog = prefs.getBoolean(SHOULD_SHOW_UPDATE_DIALOG_PREF_KEY, true);
        if (!shouldShowUpdateDialog) {
            return;
        }

        if (!checkIfUpdateIsAvailable()) {
            return;
        }

        if (DialogsHolder.isShowingOrActivityIsFinishing(SHOW_UPDATE_DIALOG_KEY, mActivity)) {
            return;
        }

        SharedPreferences.Editor prefEditor = prefs.edit();
        prefEditor.putBoolean(SHOULD_SHOW_UPDATE_DIALOG_PREF_KEY, false);
        prefEditor.apply();

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(mActivity);
        builder.setTitle(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.isu_available_title, true));
        builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.isu_available_message, false));

        builder.setPositiveButton(R.string.update, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (mActivity == null || mActivity.isFinishing())
                    return;

                NavigationHelper.goToActivity(mActivity, AllDevicesIsuActivity.class, NavigationHelper.AnimationType.SlideToLeft);

            }
        });
        builder.setNeutralButton(R.string.not_now, null);

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(SHOW_UPDATE_DIALOG_KEY, dlg);

        dlg.show();
    }

    private void mergeHashResults(Map<Radio, IsuBackgroundItemModel> hashItemModels) {
		if (hashItemModels == null || hashItemModels.size() == 0)
			return;
		
		synchronized (mLock) {
			Set<Radio> keySet = hashItemModels.keySet();
			for (Radio radio : keySet) {
				mMapRadioIsuUpdates.put(radio.getUDN(), hashItemModels.get(radio));
				mRadioIsuUpdatesLastTimeCheck.put(radio.getUDN(), System.currentTimeMillis());
			}
		}
		
		notifyListeners();
	}

	private List<Radio> getListOfRadiosForUpdateCheck() {
		List<Radio> radios = NetRemoteManager.getInstance().getRadios();

		long currentTimeMS = System.currentTimeMillis();

		List<Radio> selectedRadiosList = new ArrayList<>();
		if (radios != null) {
			for (Radio radio : radios) {
				boolean needsScan = false;

				if (!mMapRadioIsuUpdates.containsKey(radio.getUDN())) {
					needsScan = true;
				} else {
					Long lastUpdateCheckTimeMS = mRadioIsuUpdatesLastTimeCheck.get(radio.getUDN());
					if (lastUpdateCheckTimeMS != null) {
						if (currentTimeMS - lastUpdateCheckTimeMS > WAIT_BEFORE_ISU_RADIO_RESCAN_MS) {
							needsScan = true;
						}
					} else {
						needsScan = true;
					}
				}

				if (needsScan) {
					selectedRadiosList.add(radio);
				} else {
                    IsuBackgroundItemModel itemModel = mMapRadioIsuUpdates.get(radio.getUDN());
					FsLogger.log(">>> NO CHECK for " + radio + " update: " + (itemModel != null ? itemModel.mUpdateIsAvailable : ""));
				}
			}
		}

		return selectedRadiosList;
	}

	public boolean atLeastOneRadioHasImportantUpdate() {
		return checkIfUpdateIsAvailable(true);
	}
	
	public boolean atLeastOneRadioHasRecommendedUpdate() {
		return checkIfUpdateIsAvailable(false);
	}
	
	private boolean checkIfUpdateIsAvailable(boolean checkForImportantUpdate) {
		boolean isUpdateAvailable = false;

		if (!mMapRadioIsuUpdates.isEmpty()) {
			List<Radio> radios = NetRemoteManager.getInstance().getRadios();

			if (radios != null) {
				for (Radio radio : radios) {
					IsuBackgroundItemModel itemModel = mMapRadioIsuUpdates.get(radio.getUDN());
					if (itemModel != null) {
						if (checkForImportantUpdate && itemModel.mUpdateIsMandatory) {
							isUpdateAvailable = true;
							break;
						} else if (!checkForImportantUpdate && itemModel.mUpdateIsAvailable) {
							isUpdateAvailable = true;
							break;
						}
					}
				}
			}

		}

		return isUpdateAvailable;
	}

    private boolean checkIfUpdateIsAvailable() {
        boolean isUpdateAvailable = false;

        if (!mMapRadioIsuUpdates.isEmpty()) {
            List<Radio> radios = NetRemoteManager.getInstance().getRadios();

            if (radios != null) {
                for (Radio radio : radios) {
                    IsuBackgroundItemModel itemModel = mMapRadioIsuUpdates.get(radio.getUDN());
                    if (itemModel != null && itemModel.mUpdateIsAvailable) {
                        isUpdateAvailable = true;
                        break;
                    }
                }
            }

        }

        return isUpdateAvailable;
    }

    public int getNumberOfRadiosWithUpdateAvailable() {
        int numberOfRadiosWithUpdate = 0;

        if (!mMapRadioIsuUpdates.isEmpty()) {
            List<Radio> radios = NetRemoteManager.getInstance().getRadios();

            if (radios != null) {
                for (Radio radio : radios) {
                    IsuBackgroundItemModel itemModel = mMapRadioIsuUpdates.get(radio.getUDN());
                    if (itemModel != null && itemModel.mUpdateIsAvailable) {
                        numberOfRadiosWithUpdate++;
                    }
                }
            }
        }

        return numberOfRadiosWithUpdate;
    }

	public void updateIsuInfoOfRadio(Radio radio, boolean updateIsAvailable, boolean isMandatory) {
		synchronized (mLock) {
			IsuBackgroundItemModel itemModel = new IsuBackgroundItemModel(updateIsAvailable, isMandatory);
			mMapRadioIsuUpdates.put(radio.getUDN(), itemModel);
		}
		
		notifyListeners();
	}

    public void addListener(IsuBackgroundListener backgroundListener) {
        synchronized (mLock) {
            mListeners.add(backgroundListener);
        }
    }

    public void removeListener(IsuBackgroundListener backgroundListener) {
        synchronized (mLock) {
            mListeners.remove(backgroundListener);
        }
    }
	
	private void notifyListeners() {
        synchronized (mLock) {
            for (int i = 0; i < mListeners.size(); i++) {
                mListeners.get(i).onNewIsuResults();
            }
        }
	}

	private void addRadioScanListener() {
		removeRadioScanListener();

		mRadioBackgroundScanListener = new RadioDiscoveryListener();
		NetRemoteManager.getInstance().addRadioDiscoveryListener(mRadioBackgroundScanListener);
	}

	private void removeRadioScanListener() {
		if (mRadioBackgroundScanListener != null) {
			NetRemoteManager.getInstance().removeRadioDiscoveryListener(mRadioBackgroundScanListener);
			mRadioBackgroundScanListener = null;
		}
	}

    private class RadioDiscoveryListener implements IRadioDiscoveryListener {
		@Override
		public void onRadioFound(Radio radio) {
			startScanTimer();
		}

		@Override
		public void onRadioLost(Radio radio, boolean rescanInProgress) {
		}

		@Override
		public void onRadioUpdated(Radio radio) {
		}
	}

	public boolean shouldCheckForUpdates() {
		boolean shouldCheck = false;
		long currentTime = getTimeInHours(System.currentTimeMillis());
		long prefsTime = UndokPreferences.getInstance().getLastTimeForUpdateChecking();

		if (firstTimeCheckingForUpdates() || getDifferenceInHours(currentTime, prefsTime) >= 24 ) {
			shouldCheck = true;
			markUpdateCheckedForCurrentDay();
		}

		return shouldCheck;
	}

	private boolean firstTimeCheckingForUpdates() {
		if ((UndokPreferences.getInstance().getLastTimeForUpdateChecking()) == -1) {
			return true;
		}
		return false;
	}

	private void markUpdateCheckedForCurrentDay() {
		UndokPreferences.getInstance().setCurrentTimeForUpdateChecking(getTimeInHours(System.currentTimeMillis()));
	}

	private long getTimeInHours(long milis) {
		int second = 1000;
		int minute = 60 * second;
		int hour = 60 * minute;

		return milis/hour;
	}

	private long getDifferenceInHours(long value1, long value2) {
		return Math.abs(value1-value2);
	}

}
