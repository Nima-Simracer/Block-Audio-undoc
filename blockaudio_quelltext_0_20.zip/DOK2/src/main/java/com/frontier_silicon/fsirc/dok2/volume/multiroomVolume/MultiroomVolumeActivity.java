package com.frontier_silicon.fsirc.dok2.volume.multiroomVolume;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientMute0;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientMute1;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientMute2;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientMute3;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientVolume0;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientVolume1;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientVolume2;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomClientVolume3;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomGroupMasterVolume;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioMute;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioVolume;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsEqPresets;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.NetRemoteLib.Radio.nodeCommunication.IListNodeListener;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomVolumeModel;
import com.frontier_silicon.components.multiroom.MultiroomVolumeUtil;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.EqualizerActivity;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.volume.VolumeManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MultiroomVolumeActivity extends UndokActivityBase implements IMultiroomVolumeListItemListener,
        IMultiroomGroupingListener {

    private static final int SERVER_IDX = 0;

    private final Object mLock = new Object();
    private List<MultiroomVolumeModel> mDevicesVolumeList;
    private MultiroomVolumeArrayAdapter mAdapter;
    private ListView mListView;
	private SeekBar mMasterVolumeSeekBar;
    private ImageButton mMuteButton;

	private INodeNotificationCallback mVolumeNodesNotifListener = null;

	private String mProgressDlgKey = "loading_volumes";
	private int mMasterVolumeValue = 0;
	private boolean mIsStopping = false;
    private long mMaxNumClients = 0;
    private boolean mMuted = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.multiroom_volume_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.multiroom_volumes);
        initSpeakerConnectionLostWatcher();

        setupControls();
    }

	@Override
	public void onResume() {
		super.onResume();

		mIsStopping = false;

		registerVolumeNotifCallback();

		MultiroomGroupManager.getInstance().addListener(this);

		initVolumes();
	}

	@Override
	public void onPause() {
		super.onPause();

		mIsStopping = true;
		
		unregisterVolumeNotifClient();
		
		MultiroomGroupManager.getInstance().removeListener(this);

		closeInitVolumesDlg();

	}


	private void setupControls() {
		mDevicesVolumeList = new ArrayList<>();
		
        mAdapter = new MultiroomVolumeArrayAdapter(this, R.id.textRadioName, mDevicesVolumeList, this);
        mListView = findViewById(R.id.listSlaveVolumes);
        mListView.setAdapter(mAdapter);
        
        mMasterVolumeSeekBar = findViewById(R.id.seekBarVolumeMaster);
        mMasterVolumeSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				int progress = seekBar.getProgress();
				MultiroomGroupManager.getInstance().setVolume(progress, MultiroomVolumeUtil.MASTER_VOLUME_ID, true);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
			}

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				if (fromUser) {
					MultiroomGroupManager.getInstance().setVolume(progress, MultiroomVolumeUtil.MASTER_VOLUME_ID, false);
					VolumeManager.getInstance().getVolumeDataModel().volume.set(progress);
				}
			}
		});        
        mMasterVolumeSeekBar.setEnabled(true);

        mMuteButton = findViewById(R.id.buttonMute);
	}

    private void initVolumes() {
		showInitVolumesDlg();
		
		Thread t = new Thread(() -> {
			List<MultiroomVolumeModel> volumesList = getVolumesListWithServerFirst();

			notifyVolumeInitOnMainThread(volumesList);
		});
		t.start();		
	}

	private List<MultiroomVolumeModel> getVolumesListWithServerFirst() {
		List<MultiroomVolumeModel> volumesList = initVolumesSync();

    	List<MultiroomVolumeModel> finalList = new ArrayList<>();

    	MultiroomVolumeModel server = null;
    	for(MultiroomVolumeModel model : volumesList) {
    		if (model.isServer()) {
    			server = model;
			}
		}

		if (server != null) {
			finalList.add(server);
			volumesList.remove(server);
		}

		Collections.sort(volumesList, (lhs, rhs) -> lhs.mRadioFriendlyName.compareToIgnoreCase(rhs.mRadioFriendlyName));

		finalList.addAll(volumesList);

    	return finalList;
	}

	protected void notifyVolumeInitOnMainThread(final List<MultiroomVolumeModel> volumesList) {

		if (!DokUiUtils.isDestroyed(this)) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					if (!mIsStopping) {
                        synchronized (mLock) {
                            mDevicesVolumeList.clear();
                            mDevicesVolumeList.addAll(volumesList);
                        }

						mAdapter.notifyDataSetChanged();

						if (mMasterVolumeSeekBar != null)
							mMasterVolumeSeekBar.setProgress(mMasterVolumeValue);

                        updateMasterMuteState();

						closeInitVolumesDlg();
					}
				}			
			});		
		} else {
			FsLogger.log("MultiroomVolumeActivity parent activity null", LogLevel.Warning);
		}
	}

	private List<MultiroomVolumeModel> initVolumesSync() {
		List<MultiroomVolumeModel> volumesList = new ArrayList<MultiroomVolumeModel>();
		
		MultiroomGroupManager.getInstance().initVolumeSteps();
		
		MultiroomVolumeModel vol = new MultiroomVolumeModel();
		
		// server device
		vol.mClientId = MultiroomGroupManager.SERVER_NUM_ID;
		vol.mVolume = MultiroomGroupManager.getInstance().getVolume(vol.mClientId);
		vol.mMute = MultiroomGroupManager.getInstance().getMute(vol.mClientId);		
		Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();
		if (currentRadio != null) {
			vol.mRadioFriendlyName = DokUiUtils.getFriendlyNameOrStereoSystemName(currentRadio);
			vol.mClientUDN = currentRadio.getUDN();
			getIsEqualizerSupported(null, vol);
		}
		volumesList.add(vol);
		
		// client devices
		//long numClients = MultiroomGroupManager.getInstance().getNumClientsForCurrentGroup();
		long numClients = MultiroomGroupManager.getInstance().getMaxNumClients();
		
		for (int i = 0; i < numClients; i++) {
			vol = new MultiroomVolumeModel();
			vol.mClientId = i;
			vol.mVolume = MultiroomGroupManager.getInstance().getVolume(vol.mClientId);
			vol.mMute = MultiroomGroupManager.getInstance().getMute(vol.mClientId);			
			vol.mRadioFriendlyName = MultiroomGroupManager.getInstance().getClientFriendlyName(vol.mClientId);
			
			MultiroomDeviceModel clientDevice = MultiroomGroupManager.getInstance().findClient(vol.mClientId);
			if (clientDevice != null) {
				if (clientDevice.mRadio != null) {
					vol.mClientUDN = clientDevice.mRadio.getUDN();
					
					getIsEqualizerSupported(clientDevice.mRadio, vol);
				}
			}
			
			//Add only valid clients
			if (!TextUtils.isEmpty(vol.mRadioFriendlyName))
				volumesList.add(vol);		
		}
		
		mMasterVolumeValue = MultiroomGroupManager.getInstance().getVolume(MultiroomVolumeUtil.MASTER_VOLUME_ID);

		return volumesList;
	}

	@Override
	public void onVolumeChange(MultiroomVolumeModel item, boolean forceUpdate) {
		MultiroomGroupManager.getInstance().setVolume(item.mVolume, item.mClientId, forceUpdate);

        updateMasterMuteState();
	}

	@Override
	public void onMuteChange(MultiroomVolumeModel item) {
		MultiroomGroupManager.getInstance().setMute(item.mMute, item.mClientId);

        updateMasterMuteState();
	}

    @Override
    public void onEqualizerBtnClick(MultiroomVolumeModel item) {
        Bundle bundle = new Bundle();
        bundle.putString(NavigationHelper.RADIO_UDN_ARG, item.mClientUDN);

        NavigationHelper.goToActivity(this, EqualizerActivity.class,
                NavigationHelper.AnimationType.SlideToLeft, false, bundle);
    }

    private void registerVolumeNotifCallback() {
		if (NetRemoteManager.getInstance().checkConnection()) {

			Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

			unregisterVolumeNotifClient();

			mVolumeNodesNotifListener = new INodeNotificationCallback() {
				@Override
				public void onNodeUpdated(NodeInfo node) {

					if (node instanceof NodeMultiroomGroupMasterVolume) {
						NodeMultiroomGroupMasterVolume masterVolNode = (NodeMultiroomGroupMasterVolume) node;
						FsLogger.log("NodeMultiroomGroupMasterVolume changed " + node.toString());
						updateVolumeOnMainThread(MultiroomVolumeUtil.MASTER_VOLUME_ID, masterVolNode.getValue());
					} else if (node instanceof NodeSysAudioVolume) {
						NodeSysAudioVolume serverVolNode = (NodeSysAudioVolume) node;
						FsLogger.log("NodeSysAudioVolume changed " + node.toString());
						updateVolumeOnMainThread((int) MultiroomGroupManager.SERVER_NUM_ID, serverVolNode.getValue());
					} else if (node instanceof NodeMultiroomClientVolume0) {
						NodeMultiroomClientVolume0 clientVolNode = (NodeMultiroomClientVolume0) node;
						FsLogger.log("NodeMultiroomClientVolume0 changed " + node.toString());
						updateVolumeOnMainThread(0, clientVolNode.getValue());
					} else if (node instanceof NodeMultiroomClientVolume1) {
						NodeMultiroomClientVolume1 clientVolNode = (NodeMultiroomClientVolume1) node;
						FsLogger.log("NodeMultiroomClientVolume1 changed " + node.toString());
						updateVolumeOnMainThread(1, clientVolNode.getValue());
					} else if (node instanceof NodeMultiroomClientVolume2) {
						NodeMultiroomClientVolume2 clientVolNode = (NodeMultiroomClientVolume2) node;
						FsLogger.log("NodeMultiroomClientVolume2 changed " + node.toString());
						updateVolumeOnMainThread(2, clientVolNode.getValue());
					} else if (node instanceof NodeMultiroomClientVolume3) {
						NodeMultiroomClientVolume3 clientVolNode = (NodeMultiroomClientVolume3) node;
						FsLogger.log("NodeMultiroomClientVolume3 changed " + node.toString());
						updateVolumeOnMainThread(3, clientVolNode.getValue());
					} else if (node instanceof NodeSysAudioMute) {
						NodeSysAudioMute muteNode = (NodeSysAudioMute) node;
						FsLogger.log("NodeSysAudioMute changed " + node.toString());
						updateMuteOnMainThread((int) MultiroomGroupManager.SERVER_NUM_ID, muteNode.getValue());
					} else if (node instanceof NodeMultiroomClientMute0) {
						NodeMultiroomClientMute0 clientMuteNode = (NodeMultiroomClientMute0) node;
						FsLogger.log("NodeMultiroomClientMute0 changed " + node.toString());
						updateMuteOnMainThread(0, clientMuteNode.getValue());
					} else if (node instanceof NodeMultiroomClientMute1) {
						NodeMultiroomClientMute1 clientMuteNode = (NodeMultiroomClientMute1) node;
						FsLogger.log("NodeMultiroomClientMute1 changed " + node.toString());
						updateMuteOnMainThread(1, clientMuteNode.getValue());
					} else if (node instanceof NodeMultiroomClientMute2) {
						NodeMultiroomClientMute2 clientMuteNode = (NodeMultiroomClientMute2) node;
						FsLogger.log("NodeMultiroomClientMute2 changed " + node.toString());
						updateMuteOnMainThread(2, clientMuteNode.getValue());
					} else if (node instanceof NodeMultiroomClientMute3) {
						NodeMultiroomClientMute3 clientMuteNode = (NodeMultiroomClientMute3) node;
						FsLogger.log("NodeMultiroomClientMute3 changed " + node.toString());
						updateMuteOnMainThread(3, clientMuteNode.getValue());
					}

				}
			};

			radio.addNotificationListener(mVolumeNodesNotifListener);
		}
	}
	
	protected void updateVolumeOnMainThread(final int clientId, final long volume) {

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                final int masterVolumePercent = MultiroomGroupManager.getInstance().getVolume(MultiroomVolumeUtil.MASTER_VOLUME_ID);

                if (!DokUiUtils.isDestroyed(MultiroomVolumeActivity.this)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateVolume(clientId, volume, masterVolumePercent);
                        }
                    });
                } else {
                    FsLogger.log("MultiroomVolumeActivity parent activity null", LogLevel.Warning);
                }
            }
        });
        thread.start();
	}
	
	private void updateVolume(int clientId, long volume, int masterVolumePercent) {
		int idx = -1;
		
		switch (clientId) {
			case MultiroomVolumeUtil.MASTER_VOLUME_ID:
				idx = -1;
				break;
				
			case (int) MultiroomGroupManager.SERVER_NUM_ID:
				idx = SERVER_IDX;
				break;	
				
			default:
				idx = clientId + 1;	
		}		
		
		int volumeInPercent = RadioNodeUtil.convertValueToPercent(volume, MultiroomGroupManager.getInstance().getMaxVolumeSteps());
		
		if (idx >= 0) {
			try {
				MultiroomVolumeModel volumeItem = getVolumeItem(idx);
				if (volumeItem != null && volumeItem.canChangeVolume()) {
					volumeItem.mVolume = volumeInPercent; 
							
					mAdapter.notifyDataSetChanged();
					
					// make sure the master vol. is in sync (fix 18918)
					mMasterVolumeSeekBar.setProgress(masterVolumePercent);
				}
			} catch (Exception e) {}
		} else {
			//update master volume seekbar
			mMasterVolumeSeekBar.setProgress(volumeInPercent);
		}			
	}

	private void unregisterVolumeNotifClient() {
		if (NetRemoteManager.getInstance().checkConnection()) {
			Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

			if (mVolumeNodesNotifListener != null) {
				radio.removeNotificationListener(mVolumeNodesNotifListener);
				mVolumeNodesNotifListener = null;
			}
		}
	}

	protected void updateMuteOnMainThread(final int clientId, final long isMute) {

		if (!DokUiUtils.isDestroyed(this)) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					updateMute(clientId, isMute);
				}			
			});		
		} else {
			FsLogger.log("MultiroomVolumeActivity parent activity null", LogLevel.Warning);
		}
	}
	
	protected void updateMute(int clientId, long isMute) {
		int idx = -1;
		boolean mute = (isMute == NodeSysAudioMute.Ord.MUTE.ordinal());
		
		switch (clientId) {
			case (int) MultiroomGroupManager.SERVER_NUM_ID:
				idx = 0;
				break;	
				
			default:
				idx = clientId + 1;	
		}		
		
		if (idx >= 0) {
			try {
				MultiroomVolumeModel volumeItem = getVolumeItem(idx);
				if (volumeItem != null) {
					volumeItem.mMute = mute; 
							
					mAdapter.notifyDataSetChanged();
				}
			} catch (Exception e) {}
		}

        // UNDC-449, now that clients have updated review state of Master Mute.
        updateMasterMuteState();
	}	

	@Override
	public void onGroupingUpdate() {
		if (!DokUiUtils.isDestroyed(this)) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					initVolumes();
				}
			});
		}
	}

	private void showInitVolumesDlg() {

		if (!DokUiUtils.isDestroyed(this) &&
                !DialogsHolder.isShowingOrActivityIsFinishing(mProgressDlgKey, this)) {
			ProgressDialog mProgressDlg = new ProgressDialog(this);
			mProgressDlg.setMessage(getString(R.string.loading_multiroom_vol_dlg));
			mProgressDlg.setIndeterminate(true);
			mProgressDlg.setCancelable(true);
			mProgressDlg.show();

			DialogsHolder.addDialogToCollection(mProgressDlgKey, mProgressDlg);
		}
	}
	
	private void closeInitVolumesDlg() {
		DialogsHolder.dismissDialog(mProgressDlgKey);
	}

	private MultiroomVolumeModel getVolumeItem(int idx) {
        int clientId;

        synchronized (mLock) {
            if (idx == SERVER_IDX) {
                clientId = (int) MultiroomGroupManager.SERVER_NUM_ID;
            } else {
                clientId = idx - 1;
            }

            for (MultiroomVolumeModel volumeItem : mDevicesVolumeList) {
                if (volumeItem.mClientId == clientId) {
                    return volumeItem;
                }
            }
        }

        return null;
	}

	private void getIsEqualizerSupported(Radio radio, final MultiroomVolumeModel volumeItem) {
		if (radio == null) {
			radio = NetRemoteManager.getInstance().getCurrentRadio();
		}

		if (radio != null) {
			RadioNodeUtil.getListNodeItems(radio, NodeSysCapsEqPresets.class, false, new IListNodeListener() {
				@Override
				public void onListNodeResult(List resultList, boolean isListComplete) {
					if (resultList != null) {
						volumeItem.mEqualizerSupported = true;

						notifyVolumeListItemsUpdatedOnMainThread();
					}
				}
			});
		}
	}

	protected void notifyVolumeListItemsUpdatedOnMainThread() {

		if (!DokUiUtils.isDestroyed(this)) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					if (!mIsStopping) {
						mAdapter.notifyDataSetChanged();
					}
				}
			});
		} else {
			FsLogger.log("MultiroomVolumeActivity parent activity null", LogLevel.Warning);
		}
	}

    private void updateMasterMuteState() {
        UpdateMasterMuteTask muteUpdateTask = new UpdateMasterMuteTask();
        TaskHelper.execute(muteUpdateTask);
    }

	protected class UpdateMasterMuteTask extends AsyncTask<Void, Integer, Boolean> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            setMuteToggleListener(false);
        }

        @Override
        protected Boolean doInBackground(Void... arg0) {
            return getMasterMute();
        }

        @Override
        protected void onPostExecute(Boolean isMuted) {
            mMuted = isMuted;
            updateStateOfMuteButton(isMuted);

            setMuteToggleListener(true);
        }
    }

    private void setMuteToggleListener(boolean enableListener) {
        if (enableListener) {
            mMuteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mMuted = !mMuted;
                    setMute(mMuted);
                    updateStateOfMuteButton(mMuted);
                }
            });
        } else {
            mMuteButton.setOnClickListener(null);
        }
    }

    private void updateStateOfMuteButton(boolean mute) {
		VolumeManager.getInstance().getVolumeDataModel().muted.set(mute);
        DokUiUtils.decideStateOfMuteButton(mute, mMuteButton,
                R.attr.volume_controlbar_icon_color, R.attr.grouping_delete_button_color);
    }

    private boolean getMasterMute() {
        boolean mute = false;
        MultiroomVolumeModel volumeItem = getVolumeItem(SERVER_IDX);
        if (volumeItem != null) {
            mute = volumeItem.mMute;
        }

        mMaxNumClients = MultiroomGroupManager.getInstance().getMaxNumClients();
        for (int i = SERVER_IDX + 1; i < (mMaxNumClients + 1); i++) {
            volumeItem = getVolumeItem(i);
            if (volumeItem != null) {
                mute = mute && volumeItem.mMute;
            }
        }

        return mute;
    }

    protected void setMute(boolean isChecked) {
        VolumeManager.getInstance().mute(isChecked);

        // update the volume controls
        updateListVolItemsMute(isChecked);
    }

    private void updateListVolItemsMute(boolean mute) {
        MultiroomVolumeModel volumeItem = getVolumeItem(SERVER_IDX);
        if (volumeItem != null) {
            volumeItem.mMute = mute;
        }

        for (int i = SERVER_IDX + 1; i < (mMaxNumClients + 1); i++) {
            volumeItem = getVolumeItem(i);
            if (volumeItem != null) {
                volumeItem.mMute = mute;
            }
        }

        mAdapter.notifyDataSetChanged();
    }
}
