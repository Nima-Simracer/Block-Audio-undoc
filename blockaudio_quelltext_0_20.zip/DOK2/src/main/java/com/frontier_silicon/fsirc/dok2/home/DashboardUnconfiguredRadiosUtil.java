package com.frontier_silicon.fsirc.dok2.home;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.net.wifi.ScanResult;
import android.os.AsyncTask;

import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;
import com.frontier_silicon.components.common.TaskHelper;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;
import com.frontier_silicon.fsirc.dok2.setup.AccessPointConfig.AccessPointModel;

public class DashboardUnconfiguredRadiosUtil {

	public interface IUncofiguredDevicesListener {
		void onNewUncofiguredDevices(ArrayList<String> uncofiguredDevices);
	}

	public void checkForUnconfiguredDevices(Activity parentActivity, IUncofiguredDevicesListener listener) {
		if (PermissionsUtil.requestLocationPermission(parentActivity, false)) {
			UncofiguredDevicesCheckerTask task = new UncofiguredDevicesCheckerTask(parentActivity, listener);
			TaskHelper.execute(task);
		}
	}

	private class UncofiguredDevicesCheckerTask extends AsyncTask<Void, Integer, ArrayList<String>> {
		private Activity mParentActivity;
		private IUncofiguredDevicesListener mListener;

		public UncofiguredDevicesCheckerTask(Activity parentActivity, IUncofiguredDevicesListener listener) {
			mParentActivity = parentActivity;
			mListener = listener;
		}

		@Override
		protected ArrayList<String> doInBackground(Void... params) {
			ArrayList<String> unconfiguredDevices = getUnconfiguredRadioSSIDs(mParentActivity);

			return unconfiguredDevices;
		}

		@Override
		public void onPostExecute(ArrayList<String> uncofiguredDevices) {
			if (mListener != null)
				mListener.onNewUncofiguredDevices(uncofiguredDevices);

			dispose();
		}

		private void dispose() {
			mListener = null;
			mParentActivity = null;
		}
	}

	public ArrayList<String> getUnconfiguredRadioSSIDs(Activity parentActivity) {
    	ArrayList<String> radioList = new ArrayList<>();
        if (DokUiUtils.isDestroyed(parentActivity))
            return radioList;

        SetupManager setupManager = SetupManager.getInstance();

        List<AccessPointModel> devicesList = setupManager.getCurrentAccessPoints(parentActivity);

        for (AccessPointModel apDevice : devicesList) {
            if (!apDevice.getIsGroupHeader() && apDevice.getScanResult() != null) {
                ScanResult apScanResult = apDevice.getScanResult();
                radioList.add(apScanResult.SSID);
            }
        }
		
		return radioList;
	}

}
