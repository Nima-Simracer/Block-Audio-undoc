package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import androidx.lifecycle.Lifecycle;
import androidx.databinding.ObservableBoolean;
import android.view.View;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.databinding.FsdcaAddSpeakersActivityBinding;
import com.frontier_silicon.fsirc.dok2.settings.account.FSAuthManager;
import com.frontier_silicon.fsirc.dok2.settings.account.FSDCALoginActivity;
import com.frontier_silicon.fsirc.dok2.settings.account.IFSDCAAuthenticationStatus;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.List;



/**
 * Created by cvladu on 28/02/2018.
 */

public class FSDCAAddDeviceViewModel implements IMultiroomGroupingListener, IFSDCAAuthenticationStatus {
    private Lifecycle mLifecycle;
    private AddDevicesAdapter mAdapter;
    private FsdcaAddSpeakersActivityBinding mBinding;
    private AddDeviceManager mFSDCAManager = AddDeviceManager.getInstance();
    private long mPostDelayedId;

    public ObservableBoolean isProgressBarVisible = new ObservableBoolean(false);

    public FSDCAAddDeviceViewModel(Lifecycle lifecycle, FsdcaAddSpeakersActivityBinding binding) {
        mLifecycle = lifecycle;
        mBinding = binding;

        init();
    }

    private void init() {
        mAdapter = new AddDevicesAdapter(mLifecycle);
    }

    public void onResume() {
        MultiroomGroupManager.getInstance().addListener(this);
        FSAuthManager.getInstance().setAuthenticationListener(this);
        EventBus.getDefault().register(this);
        updateSpeakerList();
    }

    public AddDevicesAdapter getAdapter() {
        return mAdapter;
    }


    @Override
    public void onGroupingUpdate() {
        NetRemote.getMainThreadExecutor().execute(()-> {

            if (DokUiUtils.isDestroyed(mLifecycle)) {
                return;
            }

            updateSpeakerList();
        });
    }

    @Subscribe
    public void onRefreshEvent(RefreshFsdcaListEvent event) {
        updateSpeakerList();
    }

    private void updateSpeakerList() {
        if (mAdapter != null && mAdapter.getItemCount() == 0) {
           displayProgressBarWithDelay();
        }

        List<MultiroomItemModel> multiroomItemModelList = MultiroomGroupManager.getInstance().getFlatGroupDeviceList();

        if (multiroomItemModelList.size() == 0) {
            mBinding.noItemsInTheList.setVisibility(View.VISIBLE);
            stopDisplayingProgressBarWithDelay();
            mAdapter.swapItems(multiroomItemModelList);
        } else {
            getUnassociatedSpeakers(multiroomItemModelList);
        }
    }

    private void getUnassociatedSpeakers(List<MultiroomItemModel> multiroomItemModelList) {
        mFSDCAManager.getUnassociatedSpeakers(multiroomItemModelList, unassociatedSpeakers  -> {
            NetRemote.getMainThreadExecutor().execute(() -> {
                if (DokUiUtils.isDestroyed(mLifecycle) || mBinding == null) {
                    return;
                }

                if (unassociatedSpeakers.size() != 0) {
                    mBinding.noItemsInTheList.setVisibility(View.GONE);
                } else {
                    mBinding.noItemsInTheList.setVisibility(View.VISIBLE);
                }

                mAdapter.swapItems(unassociatedSpeakers);
                stopDisplayingProgressBarWithDelay();
            });
        });
    }

    private void displayProgressBarWithDelay() {
        Runnable runnable = (() -> {
            isProgressBarVisible.set(true);
        });

         mPostDelayedId = DelayedPostsManager.getInstance().registerNewCallbackID();
         DelayedPostsManager.getInstance().postDelayed(runnable, mPostDelayedId, 1000);
    }

    private void stopDisplayingProgressBarWithDelay() {
        DelayedPostsManager.getInstance().removeCallbackId(mPostDelayedId);
        isProgressBarVisible.set(false);
    }

    public void onPause() {
        MultiroomGroupManager.getInstance().removeListener(this);
        FSAuthManager.getInstance().setAuthenticationListener(null);
        EventBus.getDefault().unregister(this);
    }

    public void dispose() {
        mAdapter.dispose();
        mLifecycle = null;
        mAdapter = null;
        mBinding = null;
        mFSDCAManager = null;
    }

    @Override
    public void notAuthenticated() {
        NavigationHelper.goToActivity(MainApplication.getCurrentActivity(), FSDCALoginActivity.class,
                NavigationHelper.AnimationType.SlideToRight, true);
    }
}
