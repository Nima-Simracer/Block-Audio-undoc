package com.frontier_silicon.fsirc.dok2.settings.equalizer;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysAudioExtStaticDelay;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsExtStaticDelayMax;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.components.NetRemoteManager;

import java.util.Map;

public class ExternalAudioDelayUtil
{

    private long mMaxAudioDelayUSec = 0;
    private long mAudioDelayUSec = 0;
    private boolean mAudioDelaySupported = false;

    public ExternalAudioDelayUtil() {

    }

    public void getExternalAudioDelay(Radio radio, final IExternalAudioDelayListener listener) {
        if (radio == null) {
            radio = NetRemoteManager.getInstance().getCurrentRadio();
        }

        if (radio != null) {
            RadioNodeUtil.getNodesFromRadioAsync(radio, new Class[]{NodeSysAudioExtStaticDelay.class, NodeSysCapsExtStaticDelayMax.class}, false, new RadioNodeUtil.INodesResultListener() {
                @Override
                public void onNodesResult(Map<Class, NodeInfo> nodes) {
                    getValuesFromNodes(nodes, listener);
                }
            });
        }
    }

    private void getValuesFromNodes(Map<Class, NodeInfo> nodes, IExternalAudioDelayListener listener) {
        boolean isAudioDelaySupported = false;
        long audioDelayValue = 0;
        long maxAudioDelayValue = 0;

        if (nodes != null) {
            NodeSysAudioExtStaticDelay audioDelayNode = (NodeSysAudioExtStaticDelay) nodes.get(NodeSysAudioExtStaticDelay.class);
            NodeSysCapsExtStaticDelayMax maxAudioDelayNode = (NodeSysCapsExtStaticDelayMax) nodes.get(NodeSysCapsExtStaticDelayMax.class);

            if (audioDelayNode != null) {
                audioDelayValue = audioDelayNode.getValue();
                isAudioDelaySupported = true;
            }

            if (maxAudioDelayNode != null) {
                maxAudioDelayValue = maxAudioDelayNode.getValue();
            }
        }

        mAudioDelaySupported = isAudioDelaySupported;
        mAudioDelayUSec = audioDelayValue;
        mMaxAudioDelayUSec = maxAudioDelayValue;

        if (listener != null) {
            listener.onExternalAudioDelayUpdate(isAudioDelaySupported, audioDelayValue, maxAudioDelayValue);
        }
    }

    public long getMaxExternalAudioDelay() {
        return mMaxAudioDelayUSec;
    }

    public long getExternalAudioDelay() {
        return mAudioDelayUSec;
    }

    public boolean isExternalAudioDelaySupported() {
        return mAudioDelaySupported;
    }

    public void setExternalAudioDelay(Radio radio, long audioDelayUSec, final IExternalAudioDelayListener listener) {
        NodeInfo audioDelayNode = new NodeSysAudioExtStaticDelay(audioDelayUSec);

        if (radio == null) {
            radio = NetRemoteManager.getInstance().getCurrentRadio();
        }

        if (radio != null) {
            final Radio finalRadio = radio;
            RadioNodeUtil.setNodeToRadioAsync(radio, audioDelayNode, new RadioNodeUtil.INodeSetResultListener() {
                @Override
                public void onNodeSetResult(boolean success) {
                    getExternalAudioDelay(finalRadio, listener);
                }
            });
        }
    }

}
