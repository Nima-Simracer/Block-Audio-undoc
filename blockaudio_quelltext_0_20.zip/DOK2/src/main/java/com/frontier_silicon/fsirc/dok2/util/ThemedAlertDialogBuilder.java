package com.frontier_silicon.fsirc.dok2.util;

import android.content.Context;
import androidx.appcompat.app.AlertDialog;

import com.frontier_silicon.fsirc.dok2.R;

/**
 * Created by nbalazs on 23/02/2018.
 */

public class ThemedAlertDialogBuilder {

    public static AlertDialog.Builder create(Context context) {
        return new AlertDialog.Builder(context, R.style.CustomAlertDialogTheme);
    }

    public static AlertDialog.Builder createThemeChooserDialog(Context context) {
        return new AlertDialog.Builder(context, R.style.ThemeChooserDialogStyle);
    }
}
