package com.frontier_silicon.fsirc.dok2.settings.account.addDevice;

import androidx.lifecycle.Lifecycle;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.frontier_silicon.components.multiroom.MultiroomItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.FsdcaAddDeviceListItemBinding;
import com.frontier_silicon.fsirc.dok2.settings.speakerList.SpeakerListSettingsDiffCallback;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cvladu on 28/02/2018.
 */

public class AddDevicesAdapter extends RecyclerView.Adapter<AddDevicesAdapter.AddDeviceItemViewHolder> {
    private List<MultiroomItemModel> mItemModels = new ArrayList<>();
    private Lifecycle mLifecycle;

    class AddDeviceItemViewHolder extends RecyclerView.ViewHolder {
        FsdcaAddDeviceListItemBinding mBinding;

        public AddDeviceItemViewHolder(FsdcaAddDeviceListItemBinding binding) {
            super(binding.getRoot());

            mBinding = binding;
        }
    }

    public AddDevicesAdapter(Lifecycle lifecycle) {
        mLifecycle = lifecycle;
    }

    public void swapItems(List<MultiroomItemModel> itemModels) {
        SpeakerListSettingsDiffCallback diffCallback = new SpeakerListSettingsDiffCallback(mItemModels, itemModels);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        mItemModels.clear();
        mItemModels.addAll(itemModels);

        diffResult.dispatchUpdatesTo(this);
    }

    @Override
    public AddDeviceItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        FsdcaAddDeviceListItemBinding binding = DataBindingUtil.inflate
                (LayoutInflater.from(parent.getContext()),
                        R.layout.fsdca_add_device_list_item,
                        parent, false);

        return new AddDeviceItemViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(AddDeviceItemViewHolder holder, int position) {
        MultiroomItemModel multiroomItemModel = mItemModels.get(position);
        if (multiroomItemModel == null || multiroomItemModel.getRadio() == null) {
            return;
        }

        AddDevicesListItemViewModel viewModel = new AddDevicesListItemViewModel(multiroomItemModel.getRadio(), mLifecycle);

        FsdcaAddDeviceListItemBinding binding = holder.mBinding;
        binding.setViewModel(viewModel);
    }

    @Override
    public void onViewRecycled(AddDeviceItemViewHolder holder) {
        AddDevicesListItemViewModel viewModel = holder.mBinding.getViewModel();
        if (viewModel != null) {
            viewModel.dispose();
            holder.mBinding.setViewModel(null);
        }

        super.onViewRecycled(holder);
    }

    @Override
    public int getItemCount() {
        return mItemModels.size();
    }

    public void dispose() {
        mItemModels.clear();
        mLifecycle = null;
    }

}
