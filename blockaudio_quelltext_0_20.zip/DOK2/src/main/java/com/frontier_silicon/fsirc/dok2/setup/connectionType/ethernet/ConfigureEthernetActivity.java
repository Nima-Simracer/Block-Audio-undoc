package com.frontier_silicon.fsirc.dok2.setup.connectionType.ethernet;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupConfigureEthernetActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;


/**
 * Created by nbalazs on 08/03/2018.
 */

public class ConfigureEthernetActivity extends SetupActivityBase {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetupConfigureEthernetActivityBinding mBinding = DataBindingUtil.setContentView(this, R.layout.setup_configure_ethernet_activity);

        mBinding.setViewModel(new ConfigureEthernetActivityVM(this, mBinding));

        configureToolbarWithExitButton(R.string.setup_title_ethernet);
        mBinding.dhcpOnTextView.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.dhcp_description, true));
    }

    @Override
    protected void onStart() {
        super.onStart();
        enableRadioConnectionCallbackAndWiFiMonitor();
    }
}
