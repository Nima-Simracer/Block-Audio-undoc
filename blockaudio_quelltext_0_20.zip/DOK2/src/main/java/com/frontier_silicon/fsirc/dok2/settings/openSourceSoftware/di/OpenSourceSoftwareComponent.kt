package com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.di

import android.app.Activity
import android.content.Context
import androidx.lifecycle.ViewModelStoreOwner
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.IOnItemSelected
import com.frontier_silicon.fsirc.dok2.settings.openSourceSoftware.OpenSourceSoftwareActivity
import dagger.BindsInstance
import dagger.Subcomponent

@OpenSourceSoftwareScope
@Subcomponent(modules = [OpenSourceSoftwareModule::class])
interface OpenSourceSoftwareComponent {

    @Subcomponent.Builder
    interface Builder {

        @BindsInstance
        fun openSourceModule(listener: IOnItemSelected): Builder
        @BindsInstance
        fun setContext( activity: OpenSourceSoftwareActivity): Builder
        @BindsInstance
        fun setViewModelOwner(viewModelOwner: ViewModelStoreOwner): Builder
        fun build() : OpenSourceSoftwareComponent
    }

    fun inject(activity: OpenSourceSoftwareActivity)
}