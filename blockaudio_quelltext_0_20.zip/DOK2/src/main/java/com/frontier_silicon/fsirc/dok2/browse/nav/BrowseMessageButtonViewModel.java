package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.databinding.ObservableField;
import android.view.View;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.MessageManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.messageItems.MessageItem;

/**
 * Created by adanaila on 10/31/2016.
 */

public class BrowseMessageButtonViewModel {
    private MessageManager mMessageManager;

    public ObservableField<String> name = new ObservableField<>();

    protected int mPosition;
    protected MessageItem mMessageBase;

    public BrowseMessageButtonViewModel(int position, MessageItem item, MessageManager mngr) {
        this.mMessageManager = mngr;
        mMessageBase = item;
        mPosition = position;

        init();
    }

    protected void init() {
        name.set(mMessageBase.getName());
    }

    public void onButtonClicked(View view) {

        mMessageManager.sendMessageData(mMessageBase.getKey());
    }

    public void dispose() {
        mMessageManager = null;
    }
}
