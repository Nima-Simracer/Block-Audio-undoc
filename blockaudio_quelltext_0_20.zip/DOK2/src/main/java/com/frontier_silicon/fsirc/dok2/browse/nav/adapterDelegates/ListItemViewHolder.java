package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

/**
 * Created by lsuhov on 06/11/2016.
 */

public abstract class ListItemViewHolder extends RecyclerView.ViewHolder {

    public RecyclerViewListItemDelegate mRecyclerViewListItemDelegate;

    public ListItemViewHolder(View itemView, RecyclerViewListItemDelegate listItemDelegate) {
        super(itemView);

        mRecyclerViewListItemDelegate = listItemDelegate;
    }
}
