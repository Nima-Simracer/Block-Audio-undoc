package com.frontier_silicon.fsirc.dok2.setup.clock;

import android.annotation.SuppressLint;
import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsClockSourceList;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsUtcSettingsList;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SetupConfigureClockActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by nbalazs on 19/03/2018.
 */

public class ConfigureClockActivity extends SetupActivityBase {

    private SetupConfigureClockActivityBinding mBinding;
    private ConfigureClockActivityVM mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.setup_configure_clock_activity);

        configureToolbarWithExitButton(R.string.setup_title_set_clock);

        initActivity();
    }

    private void initActivity(){

        NodeSysCapsClockSourceList clockSourceList = SetupManager.getInstance().getClockSourceList();
        if (clockSourceList == null) {
            return;
        }

        List<String> clockSourceListAsString = ConfigureClockActivityVM.getClockSourceStringList(this, clockSourceList.getEntries());
        String[] clockSourceSpinnerData = clockSourceListAsString.toArray(new String[0]);

        String[] hourFormatSpinnerData = getResources().getStringArray(R.array.hour_format_array);

        List<NodeSysCapsUtcSettingsList.ListItem> nodeUTCList = SetupManager.getInstance().getUtcTimeZoneList();
        List<String> nodeUTCStringList = new ArrayList<>();
        if (nodeUTCList != null) {
            for (NodeSysCapsUtcSettingsList.ListItem nodeListItem : nodeUTCList) {
                nodeUTCStringList.add(getString(R.string.utc) + " " + getFormattedTimeOffset(nodeListItem.getTime()) +
                        ": " + nodeListItem.getRegion());
            }
        }

        String[] timeZoneSpinnerData = nodeUTCStringList.toArray(new String[0]);

        mViewModel = new ConfigureClockActivityVM(this, hourFormatSpinnerData, clockSourceSpinnerData, timeZoneSpinnerData);

        mBinding.setViewModel(mViewModel);
        mBinding.setHourSpinnerData(mViewModel.mHourSpinnerData);
        mBinding.setTimeSourceData(mViewModel.mClockSpinnerData);
        mBinding.setTimeZoneData(mViewModel.mTimeZoneSpinnerData);


    }

    @Override
    protected void onStart() {
        super.onStart();
        enableRadioConnectionCallbackAndWiFiMonitor();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mViewModel.onActivityResumed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mViewModel.onActivityPaused();
    }

    private String getFormattedTimeOffset(Long time) {
        int hours = (int) (time / 3600);
        int minutes = Math.abs((int) ((time % 3600) / 60));

        @SuppressLint("DefaultLocale") String formatedTime = String.format("%02d:%02d", hours, minutes);
        if (time >= 0) {
            formatedTime = "+" + formatedTime;
        } else if (hours == 0 && time < 0) {
            formatedTime = "-" + formatedTime;
        }

        return formatedTime;
    }
}
