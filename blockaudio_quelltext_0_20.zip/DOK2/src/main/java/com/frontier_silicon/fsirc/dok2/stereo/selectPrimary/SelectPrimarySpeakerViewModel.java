package com.frontier_silicon.fsirc.dok2.stereo.selectPrimary;

import android.app.Activity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.frontier_silicon.components.multiroom.IMultiroomGroupingListener;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.fsirc.dok2.widgets.DividerItemDecoration;

import java.util.List;

/**
 * Created by lsuhov on 03/08/2017.
 */

public class SelectPrimarySpeakerViewModel implements IMultiroomGroupingListener {

    Activity mActivity;
    RecyclerView mRecyclerView;
    SelectPrimarySpeakerAdapter mAdapter;

    public SelectPrimarySpeakerViewModel(Activity activity, RecyclerView recyclerView) {
        mActivity = activity;
        mRecyclerView = recyclerView;

        init();
    }

    private void init() {
        mAdapter = new SelectPrimarySpeakerAdapter(mActivity);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity.getApplicationContext());
        DividerItemDecoration itemDecoration = new DividerItemDecoration(mActivity.getApplicationContext(), LinearLayoutManager.VERTICAL);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.addItemDecoration(itemDecoration);
        mRecyclerView.setAdapter(mAdapter);
    }

    public void onResume() {
        MultiroomGroupManager.getInstance().addListener(this);

        updateStereoList();
    }

    public void onPause() {
        MultiroomGroupManager.getInstance().removeListener(this);
    }

    @Override
    public void onGroupingUpdate() {
        if (mActivity == null) {
            return;
        }

        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mActivity == null) {
                    return;
                }

                updateStereoList();
            }
        });
    }

    public void updateStereoList() {
        List<StereoItemModel> stereoItemModels = StereoManager.getInstance().getStereoList();

        mAdapter.swapItems(stereoItemModels);
    }

    public void dispose() {
        mActivity = null;
        mRecyclerView = null;
    }
}
