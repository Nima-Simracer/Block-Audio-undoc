package com.frontier_silicon.fsirc.dok2.baseActivity;

import android.app.Activity;

import com.frontier_silicon.components.connection.ConnectionState;
import com.frontier_silicon.components.connection.ConnectionStateUtil;
import com.frontier_silicon.components.connection.IConnectionStateListener;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.connection.noWiFi.NoWiFiActivity;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;

/**
 * Created by lsuhov on 08/11/2017.
 *
 * Class that intends to redirect the user to No WiFi screen when no WiFi or ethernet is detected
 */

public class NoWiFiWatcher implements IConnectionStateListener {

    private Activity mActivity;

    NoWiFiWatcher(Activity activity) {
        mActivity = activity;
    }

    void registerListener() {
        ConnectionStateUtil.getInstance().addListener(this, true);
    }

    void unregisterListener() {
        ConnectionStateUtil.getInstance().removeListener(this);
    }

    @Override
    public void onStateUpdate(final ConnectionState newState) {
        if (DokUiUtils.isDestroyed(mActivity)) {
            return;
        }

        mActivity.runOnUiThread(() -> {
            if (DokUiUtils.isDestroyed(mActivity)) {
                return;
            }

            if (newState == ConnectionState.NO_WIFI_OR_ETHERNET) {
                NavigationHelper.goToActivity(mActivity, NoWiFiActivity.class);
            }
        });
    }

    void dispose() {
        mActivity = null;
    }
}
