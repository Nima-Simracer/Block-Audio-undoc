package com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers;

import androidx.databinding.Observable;

import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.components.common.UnifiedFormListItem;
import com.frontier_silicon.components.common.UnifiedFormOptionsListItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormCombobox;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormComboboxOption;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormValueItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ResetFormManagerEvent;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataModel;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by adanaila on 10/4/2016.
 */

public abstract class FormManager {
    protected final int corePoolSize = 0;
    protected final int maxPoolSize = 1;
    // Sets the amount of time an idle thread waits before terminating
    protected final int KEEP_ALIVE_TIME = 1;
    // Sets the Time Unit to seconds
    protected final TimeUnit KEEP_ALIVE_TIME_UNIT = TimeUnit.SECONDS;
    protected BlockingQueue<Runnable> mNavigationRunnablesQueue = new LinkedBlockingQueue<>(15);
    protected ExecutorService mThreadPoolExecutor;
    public List<FormItem> formItemsList = new ArrayList<>();
    private boolean itemsWereRetrieved = false;
    private boolean issuedAttemptToRetreive = false;
    private final Object mLock = new Object();
    private Queue<FormItemWaitingInfo> queueOfListeners = new ConcurrentLinkedQueue<>();



    protected FormManager() {
        mThreadPoolExecutor = new ThreadPoolExecutor(corePoolSize, maxPoolSize, KEEP_ALIVE_TIME,
                KEEP_ALIVE_TIME_UNIT, mNavigationRunnablesQueue, new RejectedExecutionHandler() {
            @Override
            public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
                FsLogger.log("BrowsePagesStore: thread execution was rejected", LogLevel.Error);
            }
        });

        addSpeakerSettingsListener();
    }

    private void addSpeakerSettingsListener() {
        SpeakerDataModel speakerDataModel = SpeakerDataManager.getInstance().getSpeakerDataModel();

        speakerDataModel.currentMode.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                clearItemsLoaded();
            }
        });
    }

    public boolean isItemLoaded(int position) {
        if (formItemsList == null || formItemsList.size() < 1)
            return false;
        for (FormItem fi : formItemsList) {
            if (fi.getKey() == position)
                return true;
        }
        return false;
    }

    public FormItem getItemByPosition(int position) {
        if (formItemsList == null || formItemsList.size() < 1)
            return null;
        for (FormItem fi : formItemsList) {
            if (fi.getKey() == position)
                return fi;
        }
        return null;
    }

    public void getFormItemModelAsync(int position, IFormItemRetrieveListener listener) {
        if (itemsWereRetrieved) {
            if (position < formItemsList.size()) {
                listener.onFormItemRetrieved(formItemsList.get(position));
            } else {
                //one of the calls to complete a form request has failed
                sendFailedEvent();
            }
        } else {
            synchronized (mLock) {
                if (!issuedAttemptToRetreive) {
                    this.issuedAttemptToRetreive = true;
                    startRetrievingForm();
                }
            }
            addListenerToQueue(position, listener);
        }
    }

    public abstract void sendDataCompletedEvent();

    public abstract void sendValidationFailedEvent();

    protected abstract void sendComboboxItemsLoadedEvent();

    protected abstract void sendFailedEvent();

    protected abstract void startRetrievingForm();

    protected abstract void startRetrievingOptions();

    protected void callFormDataSet(long id, String params) {}

    public void parseForm(List<UnifiedFormListItem> formItemsList) {
        List<FormItem> formItems = new ArrayList<>();
        if (formItemsList.size() > 0) {
            for (int i = 0; i < formItemsList.size(); i++) {
                UnifiedFormListItem currentFormItem = formItemsList.get(i);
                if (currentFormItem.getFormItemType() == NodeListItem.FormItemType.PASSWORD
                        || currentFormItem.getFormItemType() == NodeListItem.FormItemType.STRING) {
                    FormValueItem item = new FormValueItem(currentFormItem.getKey(),
                            currentFormItem.getFormItemType(),
                            currentFormItem.getId(),
                            currentFormItem.getLabel(),
                            currentFormItem.getDescription());
                    formItems.add(item);
                } else if (currentFormItem.getOptionsCount() != null && currentFormItem.getOptionsCount() > 0) {
                    startRetrievingOptions();

                    FormCombobox item = new FormCombobox(currentFormItem.getKey(),
                            currentFormItem.getFormItemType(),
                            currentFormItem.getId(),
                            currentFormItem.getLabel(),
                            currentFormItem.getDescription(),
                            null);
                    formItems.add(item);
                } else {
                    FormItem item = new FormItem(currentFormItem.getKey(),
                            currentFormItem.getFormItemType(),
                            currentFormItem.getId(),
                            currentFormItem.getLabel(),
                            currentFormItem.getDescription());
                    formItems.add(item);
                }
            }
        }

        this.formItemsList = formItems;
        this.itemsWereRetrieved = true;
        this.notifyAllListenersFromQueue();
    }

    public void parseFormOptions(List<UnifiedFormOptionsListItem> optionsItemsList) {
        List<FormComboboxOption> comboOptions = new ArrayList<FormComboboxOption>();
        if (optionsItemsList != null && optionsItemsList.size() > 0) {
            for (int i = 0; i < optionsItemsList.size(); i++) {
                FormComboboxOption toAdd = new FormComboboxOption(optionsItemsList.get(i).getKey()
                        , optionsItemsList.get(i).getName(), optionsItemsList.get(i).getState());
                comboOptions.add(toAdd);
            }
        }

        if(comboOptions.size() < 1){
            //one of the calls to complete a form request has failed
            sendFailedEvent();
        }else{
            for (FormItem fi: this.formItemsList) {
                if(fi instanceof FormCombobox){
                    ((FormCombobox)fi).setOptions(comboOptions);
                }
            }
            sendComboboxItemsLoadedEvent();
        }
    }

    public Boolean sendFormData(long id) {
        String escapedAnd = "&";
        String params = "";
        Boolean isInputDataValid = true;
        for (int i = 0; i < this.formItemsList.size(); i++) {
            if (formItemsList.get(i) instanceof FormValueItem) {
                FormValueItem fvi = (FormValueItem) formItemsList.get(i);
                if((fvi.getValue() != null) && (!fvi.getValue().isEmpty()) && (fvi.getValue().length()<=255)) {
                    params = params == "" ? fvi.getFormDataOutput() :
                            params + escapedAnd + fvi.getFormDataOutput();
                }
                else
                    isInputDataValid = false;
            }
            if(formItemsList.get(i) instanceof FormCombobox){
                FormCombobox fco = (FormCombobox) formItemsList.get(i);
                params = params == "" ? fco.getSelectedOptionKey():
                        params + escapedAnd + fco.getSelectedOptionKey();
            }

        }
        if (isInputDataValid) {
            callFormDataSet(id, params);
        }
        return isInputDataValid;
    }

    @Subscribe
    public void onBackPressedWhileBrowseEventTriggered(ResetFormManagerEvent event) {
        clearItemsLoaded();
    }

    public void clearItemsLoaded() {
        if(this.formItemsList != null)
            this.formItemsList.clear();
        this.itemsWereRetrieved = false;
        this.issuedAttemptToRetreive = false;
        if(this.queueOfListeners != null)
            this.queueOfListeners.clear();
    }

    private void addListenerToQueue(int position, IFormItemRetrieveListener listener) {
        FormItemWaitingInfo formItemWaitingInfo = new FormItemWaitingInfo(position, listener);
        synchronized (mLock) {
            queueOfListeners.add(formItemWaitingInfo);
        }
    }

    private void notifyAllListenersFromQueue() {
        synchronized (mLock) {
            while (queueOfListeners.peek() != null) {
                FormItemWaitingInfo waitingInfo = queueOfListeners.poll();
                getFormItemModelAsync(waitingInfo.position, waitingInfo.listener);

                waitingInfo.listener = null;
            }
            queueOfListeners.clear();
        }
    }

    protected class FormItemWaitingInfo {
        int position;
        IFormItemRetrieveListener listener;

        FormItemWaitingInfo(int position, IFormItemRetrieveListener listener) {
            this.position = position;
            this.listener = listener;
        }
    }
}
