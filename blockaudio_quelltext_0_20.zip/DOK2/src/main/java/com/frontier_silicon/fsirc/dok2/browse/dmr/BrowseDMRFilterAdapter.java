package com.frontier_silicon.fsirc.dok2.browse.dmr;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.frontier_silicon.fsirc.dok2.R;

import java.util.List;

public class BrowseDMRFilterAdapter extends ArrayAdapter<BrowseDMRItemModel> {
  private List<String> mItems;
  public static final int mArtistsFilter = 0;
  public static final int mAlbumsFilter = 1;
  public static final int mSongsFilter = 2;
  public static final int mGenreFilter = 3;
  public static final int mPlaylistsFilter = 4;
  private int mInitialSelection;
  private ImageView mSelectionTick;

  /**
   * Default constructor. The selected position passed in as a parameter allows the adapter
   * to determine which filter category should display the active 'tick'. This variable is only
   * used during initialisation and will not be used when updating the tick after a user selection.
   *
   * @param context          The Activity context in which the adapter is running
   * @param resource         A resource ID for the layout being used
   * @param items            The data items the adapter should represent
   * @param selectedPosition The filter category selected at initialisation time
   */
  public BrowseDMRFilterAdapter(Context context, int resource, List<String> items, int selectedPosition) {
    super(context, resource);
    mInitialSelection = selectedPosition;
    mItems = items;
  }


  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    String currentFilter = mItems.get(position);

    if (convertView == null) {
      convertView = LayoutInflater.from(getContext()).inflate(R.layout.browse_filter_list_item, parent, false);
    }

    TextView displayText = (TextView) convertView.findViewById(R.id.filterText);
    displayText.setText(currentFilter);

    ImageView filterIcon = (ImageView) convertView.findViewById(R.id.filterIcon);
    setFilterIcon(filterIcon, position);

    if(position == mInitialSelection) {
      mSelectionTick = (ImageView) convertView.findViewById(R.id.imageViewSelected);
      mSelectionTick.setVisibility(View.VISIBLE);
      mInitialSelection = -1;
    }

    return convertView;
  }

  @Override
  public int getCount() {
    return mItems.size();
  }

  /**
   * A helper function used to set the icon for
   * each filter option
   *
   * @param imageView The view to hold the icon
   * @param filterPosition The position in the list determining the filter
   */
  private void setFilterIcon(ImageView imageView, int filterPosition) {

    int iconResId = 0;
    switch (filterPosition) {
      case mArtistsFilter:
        iconResId = R.drawable.ic_filter_artist_off;
        break;

      case mAlbumsFilter:
        iconResId = R.drawable.ic_filter_album_off;
        break;

      case mSongsFilter:
        iconResId = R.drawable.ic_filter_song_off;
        break;

      case mGenreFilter:
        iconResId = R.drawable.ic_filter_genre_off;
        break;

      case mPlaylistsFilter:
        iconResId = R.drawable.ic_filter_playlist_off;
        break;
    }

    if(iconResId > 0) {
      imageView.setImageResource(iconResId);
    }

  }

  /**
   * Moves the selection tick from the previously selected filter.
   *
   * The tick will be removed from the adapters internally stored reference
   * to the previous selection. Before the new one is set to visible and
   * stored replacing the previous.
   *
   * @param newSelectionTick
     */
  public void moveSelectionTick(ImageView newSelectionTick) {
    if (mSelectionTick != null) {
      mSelectionTick.setVisibility(View.GONE);
    }

    if(newSelectionTick != null) {
      mSelectionTick = newSelectionTick;
      mSelectionTick.setVisibility(View.VISIBLE);
    }
  }

}
