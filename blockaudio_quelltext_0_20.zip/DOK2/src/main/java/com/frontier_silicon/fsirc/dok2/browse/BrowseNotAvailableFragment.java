package com.frontier_silicon.fsirc.dok2.browse;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.frontier_silicon.components.common.BaseFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IChildFragment;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.IPageSwitchListener;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;

/**
 * Created by adanaila on 10/18/2016.
 */

public class BrowseNotAvailableFragment extends BaseFragment implements IChildFragment,
        IPageSwitchListener {
    public static final String FRAGMENT_TAG = "TAG_BROWSE_NA_FRAGMENT";
    private TextView mTextNotAvailable;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.browse_not_available_fragment, container, false);
        mTextNotAvailable = (TextView) rootView.findViewById(R.id.textNotAvailable);
        setMessage();
        return rootView;
    }

    private void setMessage() {

        if (SpeakerDataManager.getInstance().isInStandby()) {
            mTextNotAvailable.setText(getString(R.string.browse_not_supported_standby));
        } else {
            mTextNotAvailable.setText(getString(R.string.browse_not_supported));
        }

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        setHasOptionsMenu(false);
    }

    @Override
    public synchronized void onFragmentActivated() {
    }

    @Override
    public synchronized void onFragmentDeactivated() {
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public boolean isBackButtonHandledByFragment(boolean upButton) {
        return false;
    }

    @Override
    public void onBackButton() {
    }

    @Override
    public String getStaticTag() {
        return FRAGMENT_TAG;
    }
}
