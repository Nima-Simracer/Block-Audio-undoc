package com.frontier_silicon.fsirc.dok2.browse.nav.navAirable;

import android.os.Build;

import androidx.annotation.RequiresApi;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.common.UnifiedFormListItem;
import com.frontier_silicon.components.common.UnifiedFormOptionsListItem;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.IRegisterLinkListener;
import com.frontier_silicon.fsirc.dok2.browse.nav.NavBrowseAdapter;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ResetFormManagerEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ComboboxItemsLoadedEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.FormFailedAirableEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavRefreshEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.HideKeyboardEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.ShowLoadingProgressEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.StringValidationFailedEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseManager;
import com.frontier_silicon.loggerlib.FsLogger;
import com.frontier_silicon.loggerlib.LogLevel;
import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * Created by adanaila on 10/4/2016.
 */

public class NavFormManager extends FormManager{
    private static NavFormManager mInstance;
    private IRegisterLinkListener registerLinkListener;

    public static NavFormManager getInstance() {
        if (mInstance == null) {
            mInstance = new NavFormManager();
        }
        return mInstance;
    }

    private NavFormManager() {
        super();
        EventBus.getDefault().register(this);
    }

    @Override
    public void sendDataCompletedEvent() {
        EventBus.getDefault().post(new ShowLoadingProgressEvent());
        EventBus.getDefault().post(new HideKeyboardEvent());
        EventBus.getDefault().post(new ResetFormManagerEvent());
    }

    @Override
    public void sendValidationFailedEvent() {
        EventBus.getDefault().post(new StringValidationFailedEvent());
    }

    @Override
    public void startRetrievingForm() {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        NavFormRetrieverRunnable runnable = new NavFormRetrieverRunnable(radio, new NavFormRetrieverRunnable.INavFormRetrieverListener() {
            @Override
            public void onNavFormRetrieved(final List<UnifiedFormListItem> listItems) {
                NetRemote.getMainThreadExecutor().execute(() -> {
                    parseForm(listItems);
                    registerLinkVisibility(listItems);
                });
            }
        });

        FsLogger.log("adding form navigation runnable ", LogLevel.Info);
        mThreadPoolExecutor.submit(runnable);
    }

    @Override
    protected void startRetrievingOptions() {
        //add a combo-box item, not a normal one
        //the call should be in a runnable item, but as it is not used for login
        //this is left for a future cycle of dev.
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        NavFormOptionsRetrieverRunnable runnable = new NavFormOptionsRetrieverRunnable(radio, new NavFormOptionsRetrieverRunnable.INavFormOptionRetrieverListener() {
            @Override
            public void onNavFormOptionRetrieved(final List<UnifiedFormOptionsListItem> listItems) {
                NetRemote.getMainThreadExecutor().execute(() -> parseFormOptions(listItems));
            }
        });

        FsLogger.log("adding form OPTIONS navigation runnable ", LogLevel.Info);
        this.mThreadPoolExecutor.submit(runnable);
    }

    @Override
    protected void callFormDataSet(final long id, String params) {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        NavFormSetRunnable runnable = new NavFormSetRunnable(radio, params, id, new NavFormSetRunnable.INavFormDataSendListener() {
            @Override
            public void onNavFormSend(final boolean result) {
                if (result) {
                    EventBus.getDefault().post(new NavRefreshEvent(id));
                } else {
                    EventBus.getDefault().post(new FormFailedAirableEvent());
                }
            }
        });
        mThreadPoolExecutor.submit(runnable);
    }

    @Override
    protected void sendFailedEvent(){
        EventBus.getDefault().post(new FormFailedAirableEvent());
    }

    @Override
    protected void sendComboboxItemsLoadedEvent(){
        EventBus.getDefault().post(new ComboboxItemsLoadedEvent());
    }

    @Override
    public void clearItemsLoaded()
    {
        super.clearItemsLoaded();
        disableRegisterLink();
    }

    private void registerLinkVisibility(List<UnifiedFormListItem> formItemsList) {
        if (registerLinkListener != null) {
            if (formItemsList.size() > 0) {
                for (int i = 0; i < formItemsList.size(); i++) {
                    UnifiedFormListItem currentFormItem = formItemsList.get(i);
                    if (currentFormItem.getFormItemType() == NodeListItem.FormItemType.PASSWORD) {
                        registerLinkListener.setRegisterLinkVisibility(true);
                    }

                    if (currentFormItem.getFormItemType() == NodeListItem.FormItemType.SUBSCRIBE) {
                        registerLinkListener.setRegisterLinkUrl(currentFormItem.getDescription());
                        NavBrowseManager.getInstance().deleteItem(i);
                    }
                }
            }
        }
    }

    public void addRegisterLinkListener(IRegisterLinkListener listener)
    {
        if (listener != null)
            registerLinkListener = listener;
    }

    private void disableRegisterLink()
    {
        if (registerLinkListener != null)
            registerLinkListener.setRegisterLinkVisibility(false);
    }

    public void removeRegisterLinkListener() {
        registerLinkListener = null;
    }
}
