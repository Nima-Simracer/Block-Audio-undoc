package com.frontier_silicon.fsirc.dok2.browse;

public interface IFMRadioInfoListener {

	void onUpdateFrequencyInfo(boolean fmFreqChanged);
	
}
