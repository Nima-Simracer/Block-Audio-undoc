package com.frontier_silicon.fsirc.dok2.presets.widget

interface ItemTouchHelperAdapter {
    fun onItemMove(fromPosition: Int, toPosition: Int)
    fun onItemMoveFinished(fromPosition: Int, toPosition: Int)

}