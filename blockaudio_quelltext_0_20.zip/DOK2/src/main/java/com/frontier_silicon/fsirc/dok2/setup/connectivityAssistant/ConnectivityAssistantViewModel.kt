package com.frontier_silicon.fsirc.dok2.setup.connectivityAssistant

import android.graphics.drawable.Drawable
import androidx.lifecycle.MutableLiveData
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.SpeakersDiscoveryManager
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication
import com.frontier_silicon.fsirc.dok2.settings.staticRadioSearch.StaticRadioViewModel
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils

class ConnectivityAssistantViewModel: StaticRadioViewModel() {
    var source: MutableLiveData<Drawable> = MutableLiveData()
    var nextButtonState: MutableLiveData<Boolean> = MutableLiveData(true)
    var nextButtonName: MutableLiveData<String> = MutableLiveData(MainApplication.getContext().getString(R.string.label_next))
    var ipAddressToSearch: MutableLiveData<String> = MutableLiveData()
    var startRadioSearch: MutableLiveData<Boolean> = MutableLiveData(false)


    init {
        initObservables()
    }

    private fun initObservables() {
        if (SmartRadioStringsManager.isAnySmartRadioAvailable.get()) {
            showSmartRadioLogo()
        }
    }

    private fun showSmartRadioLogo() {
        if (DokUiUtils.isLightTheme()) {
            source.setValue(
                MainApplication.getContext().getDrawable(R.drawable.ic_smart_radio_colored)
            )
        } else {
            source.setValue(
                MainApplication.getContext()
                    .getDrawable(R.drawable.is_smart_radio_white_home_screen)
            )
        }
    }


    fun rescan() {
        SpeakersDiscoveryManager.getInstance().rescan()
    }

}