package com.frontier_silicon.fsirc.dok2.sources;

import java.util.List;

public interface IAvailableSourcesListener {

	void onSourcesUpdate(List<SourceItemModel> sourcesList);
	
}
