package com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers;

import com.frontier_silicon.NetRemoteLib.Radio.Radio;

public abstract class FormSetRunnable implements Runnable {

    public interface INavFormDataSendListener {
        void onNavFormSend(boolean params);
    }

    protected Radio mRadio;
    protected INavFormDataSendListener mListener;
    protected String mParams;
    protected long mId;

    public FormSetRunnable(Radio radio, String params, long id, INavFormDataSendListener listener) {
        mRadio = radio;
        mListener = listener;
        this.mParams = params;
        this.mId = id;
    }

    protected void sendResultToListener(boolean result) {
        if (mListener != null) {
            mListener.onNavFormSend(result);
        }
    }

    protected void dispose() {
        mRadio = null;
        mListener = null;
    }
}
