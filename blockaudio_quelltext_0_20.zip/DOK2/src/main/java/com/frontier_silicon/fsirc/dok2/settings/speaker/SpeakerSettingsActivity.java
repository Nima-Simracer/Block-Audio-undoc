package com.frontier_silicon.fsirc.dok2.settings.speaker;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Node.NodeAvsLogout;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysMode;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.GuiUtils;
import com.frontier_silicon.components.common.IButtonsResponseWithTextListener;
import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.components.stereo.StereoManager;
import com.frontier_silicon.fsirc.dok2.DialogsOpener;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.RadioFromBundleExtractor;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.SpeakersDiscoveryManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.settings.avs.AvsSettingsActivity;
import com.frontier_silicon.fsirc.dok2.settings.avs.LwaLoginActivity;
import com.frontier_silicon.fsirc.dok2.settings.dateTime.ClockSettingsActivity;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.EqualizerActivity;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.ExternalAudioDelaySanitizer;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.ExternalAudioDelayUtil;
import com.frontier_silicon.fsirc.dok2.settings.equalizer.IExternalAudioDelayListener;
import com.frontier_silicon.fsirc.dok2.settings.ISettingsControlListener;
import com.frontier_silicon.fsirc.dok2.settings.SettingsArrayAdapter;
import com.frontier_silicon.fsirc.dok2.settings.SettingsItemModel;
import com.frontier_silicon.fsirc.dok2.settings.SettingsUtil;
import com.frontier_silicon.fsirc.dok2.settings.airableQuality.AirableQualitySoundActivity;
import com.frontier_silicon.fsirc.dok2.settings.language.LanguageActivity;
import com.frontier_silicon.fsirc.dok2.settings.sleepTimer.SleepTimerActivity;
import com.frontier_silicon.fsirc.dok2.speakerData.SpeakerDataManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.ArrayList;
import java.util.List;

public class SpeakerSettingsActivity extends UndokActivityBase implements IExternalAudioDelayListener,
        IAboutSpeakerListener, ISettingsControlListener {

    private SettingsArrayAdapter mAdapter;
    private ArrayList<SettingsItemModel> mSettingsItemsList = new ArrayList<>();

    private SettingsUtil mSettingsUtil = new SettingsUtil();

    private INodeNotificationCallback mNodeNotificationCallback;

    private Radio mClientRadio;

    private EditText mExtAudioDelayEditText;
    private ExternalAudioDelaySanitizer mEditExtAudioDelayTextSanitizer;
    private View mExtAudioDelayLayout;

    private ExternalAudioDelayUtil mExternalAudioDelayUtil = new ExternalAudioDelayUtil();

    private AboutSpeakerArrayAdapter mDeviceInfoAdapter;
    private ListView mDeviceInfoListView;
    private ArrayList<AboutSpeakerModel> mAboutDevicesItemsList;

    private AboutSpeakerUtil mAboutUtil = new AboutSpeakerUtil();

    private SpeakerSettingsViewModel viewModel;
    private Observer<Boolean> keepNetworkConnectedObserver;
    private Observer<KeepNetworkConnectedUIState> keepNetworkConnectedSetObserver;
    AlertDialog mConnectionDialog;

    private static final String KEEP_NETWORK_CONNECTED_DIALOG = "KEEP_NETWORK_CONNECTED_DIALOG";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_speaker_activity);
        viewModel = new ViewModelProvider(this).get(SpeakerSettingsViewModel.class);
        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.settings);

        Bundle bundle = getIntent().getExtras();
        mClientRadio = RadioFromBundleExtractor.extractRadio(bundle, SpeakerSettingsActivity.class);

        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
        addUdnToSpeakerLostWatcher(bundle.getString(NavigationHelper.RADIO_UDN_ARG));

        setupControls();
        registerLiveDataObserver();
    }

    public void registerLiveDataObserver() {
        keepNetworkConnectedObserver = isKeepNetworkSettingsEnabled -> {
            if (DialogsHolder.getDialog(KEEP_NETWORK_CONNECTED_DIALOG).isShowing()) {
                updateNetworkConnectedUI(isKeepNetworkSettingsEnabled);
            }
        };

        keepNetworkConnectedSetObserver = keepNetworkConnectedUIState -> {
            if (keepNetworkConnectedUIState == KeepNetworkConnectedUIState.Success) {
                Toast.makeText(this,getString(R.string.keep_network_connected_changed), Toast.LENGTH_LONG).show();
            } else  {
                Toast.makeText(this,getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
            }
        };

        viewModel.getKeepNetworkConnectedLiveData().observe(this,keepNetworkConnectedObserver);
        viewModel.getResponseStatus().observe(this, keepNetworkConnectedSetObserver);
    }


    public void onResume() {
        super.onResume();

        retrieveSettingsAsync();

        registerModeChangeNotifCallback();

        updateExternalDelay();
        updateDeviceInfo();
    }

    public void onPause() {
        super.onPause();

        unregisterModeChangeNotifCallback();
    }

    @Override
    protected void onDestroy() {
        DialogsHolder.dismissAllRegisteredDialogs();
        super.onDestroy();
    }

    protected void setupControls() {

        mAdapter = new SettingsArrayAdapter(this, R.layout.settings_list_item ,R.id.text1, mSettingsItemsList);
        ListView mListView = findViewById(R.id.settingsList);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                onListItemClick(position);
            }
        });

        View mEmptyListView = findViewById(R.id.empty);
        mListView.setEmptyView(mEmptyListView);

        mExtAudioDelayLayout = findViewById(R.id.layoutExternalAudioDelay);
        mExtAudioDelayEditText = findViewById(R.id.editAudioDelay);

        ImageButton extAudioDelayMinusBtn = findViewById(R.id.buttonDelayMinus);
        extAudioDelayMinusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeAudioDelay(-1);
            }
        });

        ImageButton extAudioDelayPlusBtn = findViewById(R.id.buttonDelayPlus);
        extAudioDelayPlusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeAudioDelay(1);
            }
        });

        mAboutDevicesItemsList = new ArrayList<>();

        mDeviceInfoAdapter = new AboutSpeakerArrayAdapter(this, R.layout.settings_about_device_list_item, R.id.textEditName, mAboutDevicesItemsList, this);

        mDeviceInfoListView = findViewById(R.id.listDeviceInfo);
        mDeviceInfoListView.setAdapter(mDeviceInfoAdapter);
    }

    private void updateSettings(List<SettingsItemModel> settingsList) {
        if (mAdapter != null) {
            mSettingsItemsList.clear();
            mSettingsItemsList.addAll(settingsList);

            mAdapter.notifyDataSetChanged();
        }
    }

    private void onListItemClick(int position) {
        try {
            SettingsItemModel settingsItem = mAdapter.getItem(position);
            onSelectSetting(settingsItem);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateExternalDelay() {
        mExternalAudioDelayUtil.getExternalAudioDelay(mClientRadio, this);
    }

    private void onSelectSetting(SettingsItemModel settingsItem) {

        Bundle bundle = new Bundle();
        bundle.putString(NavigationHelper.RADIO_UDN_ARG, mClientRadio.getUDN());

        switch (settingsItem.mType) {
            case EQUALIZER:

                NavigationHelper.goToActivity(this, EqualizerActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                break;

            case CLOCK:
                NavigationHelper.goToActivity(this, ClockSettingsActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                break;

            case FACTORY_RESET:
                factoryReset();
                break;

            case AIRABLE_SOUND_QUALITY:

                NavigationHelper.goToActivity(this, AirableQualitySoundActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                break;

            case LANGUAGE:

                NavigationHelper.goToActivity(this, LanguageActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                break;

            case SLEEP:
                NavigationHelper.goToActivity(this, SleepTimerActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);

                break;
            case AVS_LOGOUT:
                /*
                NavigationHelper.goToActivity(this, AvsLogoutTutorialActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                        */

                avsLogout();
                break;
            case AVS_LOGIN:

                NavigationHelper.goToActivity(this, LwaLoginActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                break;

            case AVS_ALARMS:

                NavigationHelper.goToActivity(this, AvsSettingsActivity.class,
                        NavigationHelper.AnimationType.SlideToLeft, false, bundle);
                break;

            default:
                break;
        }
    }

    protected void retrieveSettingsAsync() {

        mSettingsUtil.getDeviceSettings(mClientRadio, SpeakerSettingsActivity.this, this);
    }

    @Override
    public void onExternalAudioDelayUpdate(final boolean isSupported, final long audioDelayValue, final long maxAudioDelayValue) {

        if (!DokUiUtils.isDestroyed(this)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    updateExternalAudioDelayViews(isSupported, audioDelayValue, maxAudioDelayValue);
                }
            });
        }
    }

    private void updateExternalAudioDelayViews(boolean isSupported, long audioDelayValue, long maxAudioDelayValue) {
        if (isSupported) {
            mExtAudioDelayLayout.setVisibility(View.VISIBLE);

            mExtAudioDelayEditText.setText("" + (audioDelayValue / 1000));

            if (mEditExtAudioDelayTextSanitizer == null) {
                mEditExtAudioDelayTextSanitizer = new ExternalAudioDelaySanitizer(maxAudioDelayValue/1000);
                mEditExtAudioDelayTextSanitizer.appendSanitizerToEditText(mExtAudioDelayEditText, this, new ExternalAudioDelaySanitizer.IExternalAudioDelaySanitizerListener() {
                    @Override
                    public void onExternalAudioDelayValue(long audioDelayMSec) {

                    }
                });

                mExtAudioDelayEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                    @Override
                    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                        if (actionId == EditorInfo.IME_ACTION_DONE) {
                            String value = v.getText().toString();

                            long audioDelayValueMS = Long.valueOf("" + value);
                            setAudioDelay(audioDelayValueMS * 1000);

                            return false;
                        }

                        return false;
                    }
                });
            }
        } else {
            mExtAudioDelayLayout.setVisibility(View.GONE);
        }
    }

    private void changeAudioDelay(int audioDelayIncrementMS) {
        long audioDelayUSec = mExternalAudioDelayUtil.getExternalAudioDelay();
        long maxAudioDelayUSec = mExternalAudioDelayUtil.getMaxExternalAudioDelay();
        long minAudioDelayUSec = 0;

        audioDelayUSec = audioDelayUSec + audioDelayIncrementMS * 1000;

        if (audioDelayUSec > maxAudioDelayUSec) {
            audioDelayUSec = maxAudioDelayUSec;
        } else if (audioDelayUSec < minAudioDelayUSec) {
            audioDelayUSec = minAudioDelayUSec;
        }

        setAudioDelay(audioDelayUSec);
    }

    private void setAudioDelay(long audioDelayUSec) {
        mExternalAudioDelayUtil.setExternalAudioDelay(mClientRadio, audioDelayUSec, this);
    }

    private void updateDeviceInfo() {
        mAboutUtil.getDeviceInfo(mClientRadio, this);
    }

    @Override
    public void onUpdateAboutDevicesList(List<AboutSpeakerModel> devicesInfoList) {
        if (mAboutUtil != null && devicesInfoList != null) {
            mAboutDevicesItemsList.clear();
            mAboutDevicesItemsList.addAll(devicesInfoList);

            mDeviceInfoAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onKeepNetworkConnectedClicked() {
        viewModel.setRadio(mClientRadio);
        initAndShowKeepNetworkConnectedDialog();
    }

    private void initAndShowKeepNetworkConnectedDialog() {
        final AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(this);

        final View dialogLayout = getLayoutInflater().inflate(R.layout.keep_network_connected_view, null);
        builder.setView(dialogLayout);

        builder.setPositiveButton(getString(android.R.string.ok), (dialogInterface, i) -> {
            DialogsHolder.dismissDialog(KEEP_NETWORK_CONNECTED_DIALOG);
        });

        mConnectionDialog = builder.create();
        DialogsHolder.addDialogToCollection(KEEP_NETWORK_CONNECTED_DIALOG, mConnectionDialog);
        mConnectionDialog.show();
        CompoundButton switchButton = dialogLayout.findViewById(R.id.switchButton);

        switchButton.setOnCheckedChangeListener((compoundButton, checked) -> {
            viewModel.setNetworkSpeakerConnectionOption(checked);
        });

        viewModel.getNetworkSpeakerConnection();
    }

    private void updateNetworkConnectedUI(boolean isKeepNetworkConnectedEnabled) {
        CompoundButton switchButton = mConnectionDialog.findViewById(R.id.switchButton);
        switchButton.setChecked(isKeepNetworkConnectedEnabled);
    }


    @Override
    public void onEditNameBtnClick(AboutSpeakerModel item) {
        mAboutUtil.changeFriendlyName(item, this, this);
    }

    @Override
    public void onDeviceInfoUpdated() {
        if (!DokUiUtils.isDestroyed(this)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (DokUiUtils.isDestroyed(SpeakerSettingsActivity.this)) {
                        return;
                    }

                    if (mDeviceInfoAdapter != null) {
                        mDeviceInfoAdapter.notifyDataSetChanged();
                    }
                }
            });
        }
    }

    private void factoryReset() {

        if (!DokUiUtils.isDestroyed(this)) {
            DialogsOpener.showMessageDialog(this, R.string.factory_reset, R.string.factory_reset_dlg_message, new IButtonsResponseWithTextListener() {
                @Override
                public void onOkClicked(String response) {
                    Radio firstRadio = mClientRadio;
                    Radio secondRadio = null;

                    if (firstRadio.isStereoCapable()) {
                        StereoItemModel stereoItemModel = StereoManager.getInstance().getStereoItemModel(mClientRadio.getUDN());
                        if (stereoItemModel != null && stereoItemModel.isStereoSystem() && stereoItemModel.deviceModels.size() > 1) {
                            if (stereoItemModel.deviceModels.get(0) != null) {
                                firstRadio = stereoItemModel.deviceModels.get(0).mRadio;
                            }
                            secondRadio = stereoItemModel.deviceModels.get(1).mRadio;
                        }
                    }

                    firstRadio.factoryReset(new ISetNodeCallback() {
                        @Override
                        public void setNodeSuccess(NodeInfo node) {
                            mClientRadio.close();
                            NetRemoteManager.getInstance().setCurrentRadio(null);
                            SpeakersDiscoveryManager.getInstance().rescan();

                            SpeakerSettingsActivity.this.onBackPressed();
                        }

                        @Override
                        public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                            FsLogger.log("factoryReset error " + error + " for " + mClientRadio);
                        }
                    });

                    if (secondRadio != null) {
                        secondRadio.factoryReset(null);
                    }
                }

                @Override
                public void onCancelClicked() {
                }
            });
        }
    }

    private void avsLogout() {

        if (!DokUiUtils.isDestroyed(this)) {
            DialogsOpener.showMessageDialog(this, R.string.settings_avs_logout, R.string.settings_avs_logout_message, new IButtonsResponseWithTextListener() {
                @Override
                public void onOkClicked(String response) {
                    NodeAvsLogout avslogout = new NodeAvsLogout(0L);
                    mClientRadio.setNode(avslogout, new ISetNodeCallback() {
                        @Override
                        public void setNodeSuccess(NodeInfo node) {
                            GuiUtils.showToast(getString(R.string.avs_logged_out_message), SpeakerSettingsActivity.this);

                            onRadioStatusChanged();
                            SpeakerDataManager.getInstance().setAvsLoginStatus(false);
                        }

                        @Override
                        public void setNodeError(NodeInfo node, NodeErrorResponse error) {
                            GuiUtils.showToast(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.avs_logged_out_message_error, true), SpeakerSettingsActivity.this);
                        }
                    });
                }

                @Override
                public void onCancelClicked(){
                }
            });
        }
    }

    public void registerModeChangeNotifCallback() {
        unregisterModeChangeNotifCallback();

        if (NetRemoteManager.getInstance().checkConnection()) {

            mNodeNotificationCallback = new INodeNotificationCallback() {
                @Override
                public void onNodeUpdated(NodeInfo node) {
                    if (node instanceof NodeSysMode) {
                        onRadioStatusChanged();
                    }
                }
            };

            NetRemoteManager.getInstance().getCurrentRadio().addNotificationListener(mNodeNotificationCallback);
        }
    }

    public void unregisterModeChangeNotifCallback() {
        if (mNodeNotificationCallback != null) {
            if (NetRemoteManager.getInstance().checkConnection()) {
                NetRemoteManager.getInstance().getCurrentRadio().removeNotificationListener(mNodeNotificationCallback);
            }

            mNodeNotificationCallback = null;
        }
    }

    protected void onRadioStatusChanged() {
        if (!DokUiUtils.isDestroyed(this)) {
            runOnUiThread(() -> retrieveSettingsAsync());
        }
    }

    @Override
    public void onSettingsUpdated(final List<SettingsItemModel> settingsList) {
        if (!DokUiUtils.isDestroyed(this)) {
            runOnUiThread(() -> updateSettings(settingsList));
        }
    }
}
