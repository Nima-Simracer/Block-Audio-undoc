package com.frontier_silicon.fsirc.dok2.browse.nav.adapterDelegates;

import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseManagerFactory;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;

import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.OAuth;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.ButtonFormItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.ComboboxFormItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.DescriptionFormItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.Directory;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.FetchErrItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.FormItemNotLoadedYet;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.MessageButton;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.MessageItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.MessageText;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.NotLoadedYet;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.PasswordFormItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.PlayableItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.TextFormItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.TrackNotAvailable;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.Unknown;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.SubscribeFormItem;
import static com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemType.MultiselFormItem;



/**
 * Created by lsuhov on 06/11/2016.
 */

public class BrowseListItemFactory {

    @BrowseItemType.EBrowseNavItemType
    public static int getItemViewType(int position, int browseManagerType) {
        BrowseManager browseManager = BrowseManagerFactory.getBrowseManager(browseManagerType);
        BrowseItemModel browseItemModel = browseManager.tryGetBrowseItemModel(position);

        if (browseItemModel.getType() == BrowseItemType.FormItem) {

            FormManager formManager = BrowseManagerFactory.getFormManager(browseManagerType);
            FormItem formItem = formManager.getItemByPosition(position);

            //if we can't retrieve an FormItem then the loading is not yet done
            if (formItem == null)
                return FormItemNotLoadedYet;
            int result = -1;
            switch (formItem.getType()) {
                case STRING:
                    result = TextFormItem;
                    break;
                case PASSWORD:
                    result = PasswordFormItem;
                    break;
                case COMBOBOX:
                    result = ComboboxFormItem;
                    break;
                case BUTTON:
                    result = ButtonFormItem;
                    break;
                case DESCRIPTION:
                    result = DescriptionFormItem;
                    break;
                case SUBSCRIBE:
                    result = SubscribeFormItem;
                    break;
                case MULTISEL:
                    result = MultiselFormItem;
                    break;

                default:
                    result = TextFormItem;
            }
            return result;
        } else if (browseItemModel.getType() == MessageItem) {
            return browseItemModel.getSubType();
        } else {
            return browseItemModel.getType();
        }
    }

    public static RecyclerViewListItemDelegate getListItemDelegate(@BrowseItemType.EBrowseNavItemType int viewType,
                                                                   int browseManagerType) {

        switch (viewType) {

            case NotLoadedYet:
                return new BrowseItemNotLoadedDelegate(browseManagerType);

            case Directory:
                return new BrowseItemDirectoryDelegate(browseManagerType);

            case PlayableItem:
                return new BrowseItemPlayableDelegate(browseManagerType);

            case Unknown:
            case FetchErrItem:
                return new BrowseItemLabelDelegate(browseManagerType);

            case FormItemNotLoadedYet:
                return new BrowseFormItemNotLoadedDelegate(browseManagerType);

            case DescriptionFormItem:
                return new BrowseFormItemDescriptionDelegate(browseManagerType);

            case TextFormItem:
                return new BrowseFormItemStringDelegate(browseManagerType);

            case PasswordFormItem:
                return new BrowseFormItemPasswordDelegate(browseManagerType);

            case ComboboxFormItem:
                return new BrowseFormItemComboboxDelegate(browseManagerType);

            case ButtonFormItem:
                return new BrowseFormItemButtonDelegate(browseManagerType);

            case MessageText:
                return new BrowseMessageBaseDelegate(browseManagerType);

            case MessageButton:
                return new BrowseMessageButtonDelegate(browseManagerType);

            case OAuth:
                return new OAuthLoginDelegate(browseManagerType);

            case TrackNotAvailable:
                return new BrowseItemTrackNotAvailable(browseManagerType);

            case SubscribeFormItem:
                return new BrowseFormItemSubscribeDelegate(browseManagerType);

            case MultiselFormItem:
                return new BrowseFormItemMultiselDelegate(browseManagerType);
        }

        return null;
    }
}
