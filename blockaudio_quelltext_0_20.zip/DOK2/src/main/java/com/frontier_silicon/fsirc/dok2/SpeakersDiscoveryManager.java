package com.frontier_silicon.fsirc.dok2;

import com.frontier_silicon.NetRemoteLib.Discovery.IRadioDiscoveryListener;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomRescanUtil;
import com.frontier_silicon.loggerlib.FsLogger;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

/**
 * Created by lsuhov on 03/04/17.
 */
public class SpeakersDiscoveryManager implements IRadioDiscoveryListener {
    private static SpeakersDiscoveryManager mInstance;
    private final long mTimerCallbackId;
    private final long mRebuildPeriod = 30_000;
    private RebuildRunnable mRebuildRunnable;

    public static SpeakersDiscoveryManager getInstance() {
        if (mInstance == null) {
            mInstance = new SpeakersDiscoveryManager();
        }
        return mInstance;
    }

    private SpeakersDiscoveryManager() {
        mTimerCallbackId = DelayedPostsManager.getInstance().registerNewCallbackID();
        mRebuildRunnable = new RebuildRunnable();

        EventBus.getDefault().register(this);
    }

    public void tryStartDiscovery() {
        NetRemoteManager.getInstance().addRadioDiscoveryListener(this);

        if (NetRemoteManager.getInstance().isDiscoveryScanActive()) {
            return;
        }

        NetRemoteManager.getInstance().startBackgroundRadioScan(false);

        NetRemoteManager.getInstance().resumeRadios();

        startRebuildTimer();
    }

    public void stopDiscovery() {
        NetRemoteManager.getInstance().removeRadioDiscoveryListener(this);
        NetRemoteManager.getInstance().stopBackgroundRadioScan();

        NetRemoteManager.getInstance().pauseRadios();

        stopRebuildTimer();
    }

    public void rescan() {
        if (NetRemoteManager.getInstance().isDiscoveryScanActive()) {

            // Attempt to fix UNDC-2449. When the rescan was done, sometimes the queue from MultiroomRescanUtil was full
            // and refresh was blocked for a period of time
            MultiroomRescanUtil.getInstance().clearRescanQueue();
            MultiroomGroupManager.getInstance().clearDevicesList();
            NetRemoteManager.getInstance().rescan();
        } else {
            tryStartDiscovery();
        }
    }

    @Override
    public void onRadioFound(Radio radio) {
        FsLogger.log("DiscoveryManager: onRadioFound "  + radio);
        rebuildGroupsAndDevices();
    }

    @Override
    public void onRadioLost(Radio radio, boolean rescanInProgress) {
        if (rescanInProgress) {
            return;
        }

        FsLogger.log("DiscoveryManager: onRadioLost "  + radio);
        MultiroomGroupManager.getInstance().onRadioLost(radio);
        rebuildGroupsAndDevices();
    }

    @Override
    public void onRadioUpdated(Radio radio) {
        FsLogger.log("DiscoveryManager: onRadioUpdated "  + radio);
        rebuildGroupsAndDevices();
    }


    private void rebuildGroupsAndDevices() {
        MultiroomRescanUtil.getInstance().rescanMultiroomDevicesAndGroups();
    }

    @Subscribe
    public void onAppNotVisible(AppInBackgroundEvent event) {
        stopDiscovery();
    }

    private void startRebuildTimer() {
        stopRebuildTimer();

        DelayedPostsManager.getInstance().postDelayed(mRebuildRunnable, mTimerCallbackId, mRebuildPeriod);
    }

    private void stopRebuildTimer() {
        DelayedPostsManager.getInstance().cancelCallback(mTimerCallbackId);
    }

    private boolean shouldSendRescanCommand() {
        long periodFromLastRescan = System.currentTimeMillis() - MultiroomRescanUtil.getInstance().getLastTimeWhenRescanWasRun();

        return periodFromLastRescan >= mRebuildPeriod;
    }

    private class RebuildRunnable implements Runnable {

        @Override
        public void run() {
            if (shouldSendRescanCommand()) {
                FsLogger.log("DiscoveryManager: trying to trigger periodical rescan");
                rebuildGroupsAndDevices();
            }

            DelayedPostsManager.getInstance().postDelayed(mRebuildRunnable, mTimerCallbackId, mRebuildPeriod);
        }
    }
}
