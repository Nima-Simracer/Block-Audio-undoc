package com.frontier_silicon.fsirc.dok2.util;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;

public class PermissionsUtil {

    public static final int PERMISSIONS_REQUEST_FINE_LOCATION = 1;
    public static final int PERMISSIONS_REQUEST_NOTIFICATIONS = 2;

    private static final String PREF_PERMISSION_RATIONALE_SHOWN_LOCATION = "PREF_PERMISSION_RATIONALE_SHOWN_LOCATION";
     public static final String PREF_PERMISSION_RATIONALE_SHOWN_NOTIFICATIONS = "PREF_PERMISSION_RATIONALE_SHOWN_NOTIFICATIONS";


    static public boolean requestLocationPermission(final Activity activity, boolean askUserForPermission) {
        boolean isPermissionGranted = false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                if (askUserForPermission) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.ACCESS_FINE_LOCATION)) {
                        setPermissionRationaleShown(activity, true, PREF_PERMISSION_RATIONALE_SHOWN_LOCATION);
                        showPermissionRationaleDialog(activity);
                    } else {
                        if (wasPermissionRationaleShown(activity, PREF_PERMISSION_RATIONALE_SHOWN_LOCATION)) {
                            showResetPermissionDialog(activity);
                        }

                        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.R) {
                            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSIONS_REQUEST_FINE_LOCATION);
                        } else {
                            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS_REQUEST_FINE_LOCATION);
                        }
                    }
                }
            } else {
                isPermissionGranted = true;
            }
        } else {
            isPermissionGranted = true;
        }

        return isPermissionGranted;
    }

    private static void showPermissionRationaleDialog(final Activity activity) {
        AlertDialog.Builder permissionRationaleDlgBuilder = ThemedAlertDialogBuilder.create(activity);
        permissionRationaleDlgBuilder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.location_permission_message, false));
        permissionRationaleDlgBuilder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.R) {
                    ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSIONS_REQUEST_FINE_LOCATION);
                } else {
                    ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS_REQUEST_FINE_LOCATION);
                }
            }
        });

        permissionRationaleDlgBuilder.create().show();
    }

    public static boolean isNotificationPermissionGranted(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean shouldShowNotificationPermissionRationale(Activity context) {
        return ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.POST_NOTIFICATIONS);
    }

    public static boolean shouldShowNotificationPermission(Activity activity) {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !PermissionsUtil.isNotificationPermissionGranted(activity) &&
                !PermissionsUtil.wasPermissionRationaleShown(activity, PermissionsUtil.PREF_PERMISSION_RATIONALE_SHOWN_NOTIFICATIONS);
    }

    public static void showNotificationPermissionDialog(final Activity activity) {
        AlertDialog.Builder permissionRationaleDlgBuilder = ThemedAlertDialogBuilder.create(activity);
        permissionRationaleDlgBuilder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.notification_permission_message, false));
        permissionRationaleDlgBuilder.setPositiveButton(android.R.string.ok, (dialogInterface, i) -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS,}, PERMISSIONS_REQUEST_NOTIFICATIONS);
            }
        });
        setPermissionRationaleShown(activity, true, PREF_PERMISSION_RATIONALE_SHOWN_NOTIFICATIONS);
        permissionRationaleDlgBuilder.create().show();
    }

    private static void showResetPermissionDialog(Activity activity) {
        AlertDialog.Builder resetPermissionDlgBuilder = ThemedAlertDialogBuilder.create(activity);
        resetPermissionDlgBuilder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.location_permission_denied_message, false));
        resetPermissionDlgBuilder.setPositiveButton(android.R.string.ok, null);
        resetPermissionDlgBuilder.create().show();
    }

    public static void setPermissionRationaleShown(Context context, boolean shown, String key) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor prefEditor = prefs.edit();
        prefEditor.putBoolean(key, shown).apply();
    }

    public static boolean wasPermissionRationaleShown(Context context, String key) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getBoolean(key, false);
    }

    public static void showLocationDialog(Context context) {
        String dialogKey = "hui_no_location_dialog";

        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, (Activity) context)) {
            return;
        }

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(context);
        builder.setTitle(R.string.no_location_title);
        builder.setMessage(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.no_location_message, false));

        builder.setPositiveButton(context.getString(R.string.go_to_settings), (dialog, which) -> context.startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)));
        builder.setNegativeButton(android.R.string.cancel, null);

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);

        dlg.show();
    }

}
