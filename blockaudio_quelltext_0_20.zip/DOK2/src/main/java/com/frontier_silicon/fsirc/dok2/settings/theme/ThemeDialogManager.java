package com.frontier_silicon.fsirc.dok2.settings.theme;

import android.app.Activity;
import androidx.appcompat.app.AlertDialog;
import android.content.DialogInterface;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lsuhov on 26/02/16.
 */
public class ThemeDialogManager {

    private static ThemeDialogManager mInstance;

    private List<UndokThemes> mThemeModelItemList;

    public static ThemeDialogManager getInstance() {
        if (mInstance == null) {
            mInstance = new ThemeDialogManager();
        }
        return mInstance;
    }

    public void init(List<UndokThemes> themeModelItemList) {
        mThemeModelItemList = themeModelItemList;
    }

    public List<ThemeModelItem> getThemes() {
        String[] themeNames = MainApplication.getContext().getResources().getStringArray(R.array.themes_array);
        List<ThemeModelItem> themeModelItems = new ArrayList<>();

        for (UndokThemes theme : mThemeModelItemList) {
            switch (theme) {
                case DEFAULT:
                    themeModelItems.add(new ThemeModelItem(themeNames[0], R.drawable.theme_rect_default));
                    break;
                case DARK:
                    themeModelItems.add(new ThemeModelItem(themeNames[1], R.drawable.theme_rect_dark));
                    break;
            }
        }

        return themeModelItems;
    }

    private ThemeDialogManager() {}

    public final void showDialog(final Activity activity, final DialogInterface.OnClickListener onClickListener) {
        String dialogKey = "switch_theme_dlg_info";
        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, activity))
            return;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity);

        builder.setTitle(activity.getString(R.string.select_theme));

        int index = CommonPreferences.getInstance().getCurrentThemeIndex();

        ThemesAdapter themeModelItemArrayAdapter = new ThemesAdapter(activity, R.layout.qobuz_track_info, getThemes());

        builder.setSingleChoiceItems(themeModelItemArrayAdapter, index, (dialog, which) -> {
            if (onClickListener != null) {
                onClickListener.onClick(dialog, which);
            }
        });

        builder.setNegativeButton(activity.getString(R.string.cancel), null);

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);
        dlg.show();
    }
}
