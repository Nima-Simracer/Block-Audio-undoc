package com.frontier_silicon.fsirc.dok2.browse.dab;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavActionDabScan;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavDabScanUpdate;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysMode;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysPower;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.nav.BrowseNavFragment;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.NavRefreshEvent;
import com.frontier_silicon.fsirc.dok2.browse.nav.navModel.NavBrowseManager;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;

import org.greenrobot.eventbus.Subscribe;

import java.util.Timer;
import java.util.TimerTask;

public class BrowseDABFragment extends BrowseNavFragment implements IDABFrequencyListener {

	public static final String FRAGMENT_TAG = "TAG_BROWSE_DAB_FRAGMENT";
    private static final int MAX_SECONDS_TO_SCAN = 30;
	
	private BrowseDABUtil mBrowseDABUtil;
	private String mRescanProgressDlgKey = "rescan_dab_progress";

	private long mNumStationsFound = 0;

	private INodeNotificationCallback mDABNotifCallback;
    boolean dabScanNotificationsNodesExists = true;
    private Timer mProgressTimer;

	public BrowseDABFragment() {
	}

	public void onResume() {
		super.onResume();

		if (mBrowseDABUtil == null) {
			mBrowseDABUtil = new BrowseDABUtil();
		}
		
		registerNotificationCallbacks();
		
		mBrowseDABUtil.checkScanActive(this);
	}
	
	public void onPause() {
		super.onPause();
		
		unregisterNotificationCallbacks();
		
		stopDABRescan();
	}
	
	@Override
	protected void setupControls() {
		super.setupControls();
	}

	@Override
	public String getStaticTag() {
		return FRAGMENT_TAG;
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
	   if (isDABToolbarIconsVisible()) {

		   // prevent action rescan btn to show multiple times #UNDC31-257
		   MenuItem rescanMenuItem = menu.findItem(R.id.action_rescan);
		   if (rescanMenuItem != null) {
			   rescanMenuItem.setVisible(true);
		   }
       }

       super.onCreateOptionsMenu(menu, inflater);
	}

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem menuItem = menu.findItem(R.id.action_rescan);
        DokUiUtils.setTintToActionMenu(getContext(), menuItem);

        super.onPrepareOptionsMenu(menu);
    }

    @Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		
		if (id == R.id.action_rescan) {

            if (mIsFragmentActive) {
                startDABRescan();
                return true;
            }
		}
		
		return super.onOptionsItemSelected(item);
	}

	private void startDABRescan() {
		mBrowseDABUtil.rescanDAB(this);
	}

	private void showDABScanningDialog(Activity parentActivity) {
		if (parentActivity != null && !DialogsHolder.isShowingOrActivityIsFinishing(mRescanProgressDlgKey, parentActivity)) {
			mNumStationsFound = 0;
			
			ProgressDialog mRescanProgressDlg = new ProgressDialog(parentActivity);
			
			mRescanProgressDlg.setTitle(R.string.rescan_dab_stations);
			mRescanProgressDlg.setMessage(getString(R.string.rescan_dab_dlg_message, Long.toString(mNumStationsFound)));
			mRescanProgressDlg.setButton(Dialog.BUTTON_NEGATIVE, getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					stopDABRescan();
				}
			});
			
			mRescanProgressDlg.setCancelable(false);
			
			DialogsHolder.addDialogToCollection(mRescanProgressDlgKey, mRescanProgressDlg);
			
			mRescanProgressDlg.show();

			if (!dabScanNotificationsNodesExists) {
			    // notifications for scan not exists so use a timer to stop scanning

                mProgressTimer = new Timer();
                mProgressTimer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        mProgressTimer.cancel();
                        mProgressTimer = null;

                        mBrowseDABUtil.stopDABRescan();
                        onDABScanUpdated(false);
                    }
                }, MAX_SECONDS_TO_SCAN * 1000);
            }
		}
	}
	
	protected void stopDABRescan() {
		closeProgressDlg();
		
		mBrowseDABUtil.stopDABRescan();
	}

	private void updateProgressDlg() {
		Activity parentActivity = getActivity();
		if (parentActivity != null) {
			parentActivity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					if (DialogsHolder.isShowing(mRescanProgressDlgKey)) {
						((ProgressDialog)DialogsHolder.getDialog(mRescanProgressDlgKey)).setMessage(getString(R.string.rescan_dab_dlg_message, Long.toString(mNumStationsFound)));
					}
				}
			});
		}
	}
	
	public void closeProgressDlg() {
		if (DialogsHolder.isShowing(mRescanProgressDlgKey)) {
			DialogsHolder.dismissDialog(mRescanProgressDlgKey);
			
			// rescan finished => get new list  
		    NavBrowseManager.getInstance().resetNavToRoot();
		}
	}

	private void registerNotificationCallbacks() {
        final Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

		if (!NetRemoteManager.getInstance().checkConnection(radio)) {
		    return;
        }

        if (mDABNotifCallback != null) {
            unregisterNotificationCallbacks();
        }

        RadioNodeUtil.fsNodeExists(radio, NodeNavActionDabScan.class, new RadioNodeUtil.NodeExists(){

            @Override
            public void onNode(boolean exists) {
                FsLogger.log("NodeNavActionDabScan node exists: " + exists);

                if (!NetRemoteManager.getInstance().checkConnection(radio)) {
                    return;
                }

                dabScanNotificationsNodesExists = exists;
                if (exists) {
                    mDABNotifCallback = new DABNotifCallback();

                    radio.addNotificationListener(mDABNotifCallback);
                }
            }
        });
	}
	
	private void unregisterNotificationCallbacks() {
        Radio radio = NetRemoteManager.getInstance().getCurrentRadio();

		if (NetRemoteManager.getInstance().checkConnection(radio)) {
			if (mDABNotifCallback != null) {
				radio.removeNotificationListener(mDABNotifCallback);
				mDABNotifCallback = null;
			}
		}
	}

	private class DABNotifCallback implements INodeNotificationCallback {

		@Override
		public void onNodeUpdated(NodeInfo node) {
			if (node instanceof NodeNavDabScanUpdate) {
				NodeNavDabScanUpdate update = (NodeNavDabScanUpdate)node;
				
				mNumStationsFound = update.getValue();
				updateProgressDlg();
				
			} else if (node instanceof NodeNavActionDabScan) {
				NodeNavActionDabScan status = (NodeNavActionDabScan)node;
				
				if (status.getValueEnum() == NodeNavActionDabScan.Ord.IDLE) {
					closeProgressDlg();
				} else if (status.getValueEnum() == NodeNavActionDabScan.Ord.SCAN) {
					
				}
			} else if ((node instanceof NodeSysPower) || (node instanceof NodeSysMode)) {
				closeProgressDlg();
			}
		}
		
	}

	@Override
	public void onDABScanUpdated(boolean isScanning) {
		if (isScanning) {
			showDABScanningDialog(getActivity());
		} else {
			closeProgressDlg();
		}
	}

	private boolean isDABToolbarIconsVisible() {
        boolean isVisible = mIsFragmentActive;

        return isVisible;
    }

    @Override
    public synchronized void onFragmentActivated() {
        if (!super.onFragmentActivatedBase())
            return;

    }

    @Override
    public synchronized void onFragmentDeactivated() {
        if (!super.onFragmentDeactivatedBase()) {
            return;

        }
    }

    @Subscribe
    public void onRefreshEventCompleted(NavRefreshEvent event) {
        mBrowseDABUtil.checkScanActive(this);
    }
}
