package com.frontier_silicon.fsirc.dok2.browse.dmr.filter;

import com.frontier_silicon.fsirc.dok2.browse.dmr.BrowseDMRAdapter;
import com.frontier_silicon.fsirc.dok2.browse.dmr.BrowseDMRItemModel;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TextFilterHelper {
    private String LOG_TAG = TextFilterHelper.class.getSimpleName();

    /**
     * Removes <code>BrowseDMRItemModel</code> objects from the list provided
     * as a parameter if they do not contain the specified search string. Items are
     * discarded if no java regex match is found against the items displayed text
     *
     * @param regex          The sub string to search for
     * @param unfilteredList The list to be filtered
     * @return The parameter arguments with non matching results removed.
     */
    public List<BrowseDMRItemModel> filterMediaList(String regex, List<BrowseDMRItemModel> unfilteredList) {
        Pattern pattern = Pattern.compile("(?i).*\\Q" + regex + "\\E.*");

        for (int i = 0; i < unfilteredList.size(); i++) {
            BrowseDMRItemModel currentItem = unfilteredList.get(i);
            Matcher matcher = pattern.matcher(currentItem.getDisplayText());
            if (!matcher.find()) {
                unfilteredList.remove(currentItem);
                //Items in the list have now shifted, recheck the current index.
                i--;
            }
        }

        return unfilteredList;
    }

    /**
     * Helper method to filter and update the adapter with the contents of
     * the provided list of <code>BrowseDMRItemModel</code> based
     * using java regex.
     *
     * @param regex          The sub string to search for
     * @param unfilteredList The list to be filtered
     * @param adapter        The adapter to be updated with the filtered list
     * @return The size of the filtered media list
     */
    public int filterMediaList(String regex, List<BrowseDMRItemModel> unfilteredList, BrowseDMRAdapter adapter) {
        List<BrowseDMRItemModel> filteredList = filterMediaList(regex, unfilteredList);
        adapter.replaceContents(filteredList);

        return filteredList.size();
    }
}
