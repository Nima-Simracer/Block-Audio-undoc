package com.frontier_silicon.fsirc.dok2.setup;

import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import android.util.TypedValue;
import android.view.MenuItem;
import com.frontier_silicon.components.common.DelayedPostsManager;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;

/**
 * Created by nbalazs on 01/03/2018.
 */

public abstract class SetupActivityBase extends UndokActivityBase {
    private SetupWithRedirectionBase mSetupWithRedirectionBase;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        disableNoWiFiWatcher();
        disableDiscoveryOfSpeakers();
        disableVolumeFromHwButtonsWatcher();
    }

    protected void enableRadioConnectionCallbackAndWiFiMonitor() {
        mSetupWithRedirectionBase = new SetupWithRedirectionBase(this, getLifecycle());
        mSetupWithRedirectionBase.enableRadioConnectionCallback();
    }

    protected final void configureToolbarWithoutExitButton(int resourceID) {
        setupAppBar();
        setTitle(getString(resourceID));
    }
    protected final void configureToolbarWithoutExitButton(String title) {
        setupAppBar();
        setTitle(title);
    }

    protected final void configureToolbarWithExitButton(int resourceID) {
        setupAppBar();
        setTitle(getString(resourceID));
        enableUpNavigation();
        replaceBackWithExitIcon();
    }

    protected final void configureToolbarWithExitButton(String title) {
        setupAppBar();
        setTitle(title);
        enableUpNavigation();
        replaceBackWithExitIcon();
    }

    private void replaceBackWithExitIcon() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            Drawable drawable = getResources().getDrawable(R.drawable.ic_close);
            drawable.setColorFilter(new PorterDuffColorFilter(getTintColor(), PorterDuff.Mode.MULTIPLY));
            actionBar.setHomeAsUpIndicator(drawable);
        }
    }

    private int getTintColor() {
        TypedValue typedValue = new TypedValue();
        Resources.Theme theme = this.getTheme();
        theme.resolveAttribute(R.attr.navigationbar_icon_color, typedValue, true);

        return typedValue.data;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            NavigationHelper.goToHomeAndClearActivityStack(this);
            disableRadioConnectionCallback();

            DelayedPostsManager.getInstance().postDelayed(() -> {
                SetupManager.getInstance().dispose();
                SetupManager.getInstance().reconnectToInitialWiFiNetwork();
            }, 500);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void disableRadioConnectionCallback() {
        if (mSetupWithRedirectionBase != null) {
            mSetupWithRedirectionBase.disableRadioConnectionCallback();
            mSetupWithRedirectionBase = null;
        }
    }
}
