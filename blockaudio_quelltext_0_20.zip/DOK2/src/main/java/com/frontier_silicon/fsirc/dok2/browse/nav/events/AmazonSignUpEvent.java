package com.frontier_silicon.fsirc.dok2.browse.nav.events;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;

/**
 * Created by cvladu on 21/01/2018.
 */

public class AmazonSignUpEvent {
    public BrowseItemModel mBrowseItemModel;

    public AmazonSignUpEvent(BrowseItemModel browseItemModel) {
        mBrowseItemModel = browseItemModel;
    }
}
