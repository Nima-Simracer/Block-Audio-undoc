package com.frontier_silicon.fsirc.dok2.browse.nav.common.messageItems;

/**
 * Created by adanaila on 11/3/2016.
 */

public class MessageItem {
    private Long key;
    private int subType;
    private String name;

    public MessageItem(long keyP, int typeP, String nameP){
        this.key = keyP;
        this.name = nameP;
        this.subType = typeP;
    }

    public Long getKey(){return this.key;}
    public int getSubType(){return this.subType;}
    public String getName(){return this.name;}
}
