package com.frontier_silicon.fsirc.dok2.update;

import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuSoftwareUpdateProgress;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIsuState;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.HashMap;
import java.util.List;

class AllDevicesCheckForUpdateRunnable implements Runnable {
    private final Object mLock = new Object();
    private IAllDevicesIsuListener mAllDevicesIsuListener;

    private List<Radio> mAllDevices;
    private HashMap<String, IsuItemModel> mHashItemModels = new HashMap<>();

    public AllDevicesCheckForUpdateRunnable(IAllDevicesIsuListener iAllDevicesIsuListener, List<Radio> devicesList,
                                            HashMap<String, IsuItemModel> mapDevicesUpdates) {
        setIAllDevicesCheckUpdatesListener(iAllDevicesIsuListener);

        mAllDevices = devicesList;
        mHashItemModels = mapDevicesUpdates;
    }

    public void setIAllDevicesCheckUpdatesListener(IAllDevicesIsuListener iAllDevicesIsuListener) {
        synchronized (mLock) {
            mAllDevicesIsuListener = iAllDevicesIsuListener;
        }
    }

    @Override
    public void run() {
        if (mAllDevices == null || mHashItemModels == null) {
            onFailed();
            return;
        }

        for (int i = 0; i < mAllDevices.size(); i++) {
            checkInfoForReceivedItem(mAllDevices.get(i));
        }
    }

    public void checkInfoForReceivedItem(Radio radio) {
        String sn = radio.getSN();

        IsuItemModel isuItem = mHashItemModels.get(sn);
        if (isuItem == null) {
            FsLogger.log("IsuItemModel not found for radio " + radio.getFriendlyName());
            return;
        }

        NodeSysIsuSoftwareUpdateProgress progress = (NodeSysIsuSoftwareUpdateProgress)radio
                .nodeSyncGetter(NodeSysIsuSoftwareUpdateProgress.class).get();

        if (progress != null && progress.getValue() > 0) {
            FsLogger.log("Speaker " + radio.toString() + " is updating. Stopping check");
            isuItem.mIsUpdating = true;
            return;
        }

        isuItem.mUpdateFailed = false;

        if (isuItem.mCurrentVersionWasRetrieved && isuItem.mUpdateState == NodeSysIsuState.Ord.UPDATE_AVAILABLE) {
            onCurrentVersionRetrievedLock(isuItem);
            onAvailableUpdateLock(isuItem);
        }
        else {
            isuItem.mUpdateState = NodeSysIsuState.Ord.CHECK_IN_PROGRESS;

            onCheckingUpdateLock(isuItem);

            checkForUpdate(radio, isuItem);
        }
    }

    private void checkForUpdate(Radio radio, final IsuItemModel isuItem) {
        CheckForUpdateRunnable checkUpdateRunnable = new CheckForUpdateRunnable(new ICheckForUpdateListener() {

            @Override
            public void onNoAvailableUpdate() {
                isuItem.mUpdateState = NodeSysIsuState.Ord.UPDATE_NOT_AVAILABLE;
                onNoAvailableUpdateLock(isuItem);
            }

            @Override
            public void onCurrentVersionRetrieved(String version) {
                isuItem.mCurrentVersion = version;
                isuItem.mCurrentVersionWasRetrieved = !TextUtils.isEmpty(version);

                onCurrentVersionRetrievedLock(isuItem);
            }

            @Override
            public void onCheckingUpdate() {}

            @Override
            public void onCheckFailed(ErrorType errorType) {
                isuItem.mUpdateState = NodeSysIsuState.Ord.CHECK_FAILED;
                isuItem.mErrorType = errorType;
                onCheckFailedLock(isuItem);
            }

            @Override
            public void onAvailableUpdate(String updateVersion, String updateChanges, long isMandatory) {
                isuItem.mUpdateState = NodeSysIsuState.Ord.UPDATE_AVAILABLE;
                isuItem.mUpdateVersion = updateVersion;
                isuItem.mUpdateDescription = updateChanges;
                isuItem.mIsMandatory = isMandatory;

                onAvailableUpdateLock(isuItem);
            }
        }, radio);

        Thread checkUpdateThread = new Thread(checkUpdateRunnable, "CheckForUpdateThread");
        checkUpdateThread.start();
    }

    private void onCurrentVersionRetrievedLock(IsuItemModel isuItem) {
        synchronized (isuItem.mLock) {
            if (isuItem.mCheckUpdateListener != null)
                isuItem.mCheckUpdateListener.onCurrentVersionRetrieved(isuItem.mCurrentVersion);
        }
    }

    private void onAvailableUpdateLock(IsuItemModel isuItem) {
        synchronized (isuItem.mLock) {
            if (isuItem.mCheckUpdateListener != null)
                isuItem.mCheckUpdateListener.onAvailableUpdate(isuItem.mUpdateVersion, isuItem.mUpdateDescription,
                        isuItem.mIsMandatory);
        }

        sendUpdateInfoToGroupListener();
    }

    private void onCheckingUpdateLock(IsuItemModel isuItem) {
        synchronized (isuItem.mLock) {
            if (isuItem.mCheckUpdateListener != null)
                isuItem.mCheckUpdateListener.onCheckingUpdate();
        }
    }

    private void onNoAvailableUpdateLock(IsuItemModel isuItem) {
        synchronized (isuItem.mLock) {
            if (isuItem.mCheckUpdateListener != null)
                isuItem.mCheckUpdateListener.onNoAvailableUpdate();
        }

        sendUpdateInfoToGroupListener();
    }

    private void onCheckFailedLock(IsuItemModel isuItem) {
        synchronized (isuItem.mLock) {
            if (isuItem.mCheckUpdateListener != null)
                isuItem.mCheckUpdateListener.onCheckFailed(isuItem.mErrorType);
        }

        sendUpdateInfoToGroupListener();
    }

    private void onFailed() {
        synchronized (mLock) {
            if (mAllDevicesIsuListener != null)
                mAllDevicesIsuListener.failed();
        }
    }

    private void sendUpdateInfoToGroupListener() {
        int updatesCount = 0;

        for (int i = 0; i < mAllDevices.size(); i++) {
            Radio radio = mAllDevices.get(i);
            if (radio == null)
                continue;

            String sn = radio.getSN();
            if (TextUtils.isEmpty(sn))
                continue;

            IsuItemModel isuItemModel = mHashItemModels.get(sn);
            if (isuItemModel != null) {
                if (isuItemModel.mUpdateState == NodeSysIsuState.Ord.UPDATE_AVAILABLE) {
                    updatesCount++;
                }
            }
        }

        synchronized (mLock) {
            if (mAllDevicesIsuListener == null)
                return;

            if (updatesCount == 0)
                mAllDevicesIsuListener.noUpdatesAvailable();
            else {
                boolean allDevicesHaveUpdates = (updatesCount == mAllDevices.size());
                mAllDevicesIsuListener.updatesAreAvailable(allDevicesHaveUpdates);
            }
        }

    }

    public void addDevice(Radio radio, IsuItemModel itemModel) {
        synchronized (mLock) {
            mAllDevices.add(radio);

            String sn = radio.getSN();
            if (!mHashItemModels.containsKey(sn)) {
                mHashItemModels.put(sn, itemModel);
            }
        }
    }

    public void removeDevice(Radio radio) {
        synchronized (mLock) {
            mAllDevices.remove(radio);
        }
    }
}
