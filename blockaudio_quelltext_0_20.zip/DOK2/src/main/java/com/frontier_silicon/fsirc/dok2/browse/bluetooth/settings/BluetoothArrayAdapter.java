package com.frontier_silicon.fsirc.dok2.browse.bluetooth.settings;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.frontier_silicon.NetRemoteLib.Node.NodeBluetoothConnectedDevices;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.browse.bluetooth.BrowseBluetoothManager;

import java.util.List;
import java.util.Map;


public class BluetoothArrayAdapter extends ArrayAdapter {

    public BluetoothArrayAdapter(Context context, int resource) {
        super(context, resource);
    }

    private List<NodeBluetoothConnectedDevices.ListItem> mDeviceList;

    // Calling this function triggers the data fetch, the controlling fragment must do this
    public void newDataAvailable() {
        Map<Class, Object> nodes = BrowseBluetoothManager.getInstance().getNodes();
        mDeviceList = (List<NodeBluetoothConnectedDevices.ListItem>)nodes.get(NodeBluetoothConnectedDevices.class);

        BluetoothArrayAdapter.this.notifyDataSetChanged();
    }


    @Override
    public int getCount() {
        if (mDeviceList != null)
            return mDeviceList.size();

        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.bluetooth_list_item, parent, false);
        }

        TextView name = convertView.findViewById(R.id.bluetoothDeviceName);
        TextView state = convertView.findViewById(R.id.bluetoothDeviceConnectionState);

        if ((mDeviceList != null) && (mDeviceList.size() > position)) {
            NodeBluetoothConnectedDevices.ListItem btConn = mDeviceList.get(position);
            name.setText(btConn.getDeviceName());

            switch(btConn.getDeviceState()) {
                case Connected:
                    state.setText(R.string.bluetooth_connected);
                    break;
                case Paired:
                    state.setText(R.string.bluetooth_paired);
                    break;
                case Disconnected:
                    state.setText(R.string.disconnected);
                    break;
            }
        }

        return convertView;
    }
}
