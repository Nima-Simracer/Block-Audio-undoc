package com.frontier_silicon.fsirc.dok2

class AppInForegroundEvent {
}