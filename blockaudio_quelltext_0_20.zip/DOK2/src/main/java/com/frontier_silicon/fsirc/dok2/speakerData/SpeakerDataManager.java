package com.frontier_silicon.fsirc.dok2.speakerData;

import com.frontier_silicon.NetRemoteLib.Node.BaseCastTos;
import com.frontier_silicon.NetRemoteLib.Node.NodeAvsHastoken;
import com.frontier_silicon.NetRemoteLib.Node.NodeCastTos;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeMultiroomCapsMaxClients;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavCaps;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavPresetDelete;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysCapsValidModes;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysInfoFriendlyName;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysIpodDockStatus;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysMode;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetAuthorisationReturnUrl;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysPower;
import com.frontier_silicon.NetRemoteLib.Radio.ErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.IGetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.INodeNotificationCallback;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNodeUtil;
import com.frontier_silicon.fsirc.dok2.BuildConfig;
import com.frontier_silicon.fsirc.dok2.connectedSpeaker.ConnectedSpeakerViewModel;
import com.frontier_silicon.fsirc.dok2.util.DokUiUtils;
import com.frontier_silicon.loggerlib.FsLogger;

import java.util.Map;

/**
 * This class is intended to keep general up to date data, about the current radio
 *
 * Created by lsuhov on 07/04/2017.
 */

public class SpeakerDataManager implements INodeNotificationCallback {
    private static SpeakerDataManager mInstance;

    private Radio mRadio;
    private SpeakerDataModel mSpeakerDataModel = new SpeakerDataModel();

    private SpeakerDataManager() {}

    public static SpeakerDataManager getInstance() {
        if (mInstance == null) {
            mInstance = new SpeakerDataManager();
        }

        return mInstance;
    }

    public void bindToRadio(Radio radio) {
        unbindFromPreviousRadio();

        if (radio == null) {
            return;
        }

        mRadio = radio;
        mRadio.addNotificationListener(this);

        updateSpeakerData();
    }

    private void unbindFromPreviousRadio() {
        if (mRadio != null) {
            mRadio.removeNotificationListener(this);
        }
    }

    public SpeakerDataModel getSpeakerDataModel() {
        return mSpeakerDataModel;
    }

    @Override
    public void onNodeUpdated(NodeInfo node) {
        if (node instanceof NodeSysMode ||
                node instanceof NodeSysPower) {

            //keep these together because on when setting power, the mode notification is received instead of power
            updateCurrentMode(false);
            updateStandbyState();
        } else if (node instanceof NodeSysInfoFriendlyName) {
            updateFriendlyName((NodeSysInfoFriendlyName)node);
        } else if (node instanceof NodeSysIpodDockStatus) {
            onIPodDockChange((NodeSysIpodDockStatus) node);
        } else if (node instanceof NodeAvsHastoken) {
            NodeAvsHastoken nodeAvsHastoken = (NodeAvsHastoken) node;
            if (nodeAvsHastoken.getValueEnum() == NodeAvsHastoken.Ord.FALSE) {
                mSpeakerDataModel.isAvsLoggedIn.set(false);
            } else {
                mSpeakerDataModel.isAvsLoggedIn.set(true);
            }
        }
    }

    private void onIPodDockChange(NodeSysIpodDockStatus nodeSysIpodDockStatus) {
        mSpeakerDataModel.ipodDockStatus.set(nodeSysIpodDockStatus.getValueEnum());
    }

    private void updateFriendlyName(NodeSysInfoFriendlyName nodeSysInfoFriendlyName) {
        String newFriendlyName = nodeSysInfoFriendlyName.getValue();

        mRadio.setFriendlyName(newFriendlyName);
        mSpeakerDataModel.friendlyName.set(newFriendlyName);
    }

    private void updateSpeakerData() {
        updateCurrentMode(true);
        updateStandbyState();
        updateFromNodes();
        setIsClearButtonFromPresetVisible();

        mSpeakerDataModel.friendlyName.set(DokUiUtils.getFriendlyNameOrStereoSystemName(mRadio));
    }

    private void updateFromNodes() {
        Map<Class, NodeInfo> nodes;

        if (!BuildConfig.putOnAmazonStore) {
            nodes = mRadio.nodesSyncGetter(new Class[]{NodeAvsHastoken.class, NodeCastTos.class, NodeMultiroomCapsMaxClients.class}).get();
        } else{
            nodes = mRadio.nodesSyncGetter(new Class[]{NodeAvsHastoken.class, NodeMultiroomCapsMaxClients.class}).get();
        }

        updateTosAcceptance((NodeCastTos) nodes.get(NodeCastTos.class));
        updateMaxMultiroomClients((NodeMultiroomCapsMaxClients) nodes.get(NodeMultiroomCapsMaxClients.class));
        updateAvsNotification((NodeAvsHastoken) nodes.get(NodeAvsHastoken.class));
    }

    private void updateAvsNotification(NodeAvsHastoken nodeAvsHastoken){
        if (nodeAvsHastoken == null) {
            return;
        }

        FsLogger.log("AVS: " + nodeAvsHastoken.getValueEnum());

        if (nodeAvsHastoken.getValueEnum() == NodeAvsHastoken.Ord.FALSE) {
            mSpeakerDataModel.isAvsLoggedIn.set(false);
        } else {
            mSpeakerDataModel.isAvsLoggedIn.set(true);
        }
    }

    private void updateMaxMultiroomClients(NodeMultiroomCapsMaxClients nodeMultiroomCapsMaxClients) {

        if (nodeMultiroomCapsMaxClients != null) {
            mSpeakerDataModel.maxNumberOfMultiroomClients.set(nodeMultiroomCapsMaxClients.getValue().intValue());
        }
    }

    private void updateTosAcceptance(NodeCastTos nodeCastTos) {

        if (nodeCastTos != null) {
            mSpeakerDataModel.castTosStatus.set(nodeCastTos.getValueEnum());
        } else {
            mSpeakerDataModel.castTosStatus.set(BaseCastTos.Ord.UNSET);
        }
    }

    private void updateCurrentMode(final boolean sync) {
        if (sync) {
            NodeSysCapsValidModes.Mode currentMode = mRadio.getModeSync();
            setCurrentModeAndCheckIfNavigationIsSupportedForCurrentMode(currentMode, sync);
        } else {
            mRadio.getMode(new Radio.IRadioModeCallback() {
                @Override
                public void getCurrentMode(NodeSysCapsValidModes.Mode currentMode) {
                    setCurrentModeAndCheckIfNavigationIsSupportedForCurrentMode(currentMode, sync);
                }
            });
        }
    }

     private void setCurrentModeAndCheckIfNavigationIsSupportedForCurrentMode(final NodeSysCapsValidModes.Mode currentMode, boolean synchronous) {
        mRadio.getNode(NodeNavCaps.class, synchronous, new IGetNodeCallback() {
            @Override
            public void getNodeResult(NodeInfo node) {

                NodeNavCaps navCapsNode = (NodeNavCaps) node;

                setNavigationAndPresetsCapabilities(navCapsNode);
                mSpeakerDataModel.currentMode.set(currentMode);

                if (currentMode == NodeSysCapsValidModes.Mode.AIRABLE_SAAVN) {
                    setAuthenticationUrlForSaavnMode();
                }
            }

            @Override
            public void getNodeError(Class nodeType, NodeErrorResponse error) {
                mSpeakerDataModel.isNavigationSupportedForCurrentMode.set(false);
                mSpeakerDataModel.isPresetNavigationSupported.set(false);
                mSpeakerDataModel.currentMode.set(currentMode);
            }
        });
    }

    private void setAuthenticationUrlForSaavnMode() {
        Radio currentRadio = NetRemoteManager.getInstance().getCurrentRadio();

        if (currentRadio != null) {
            currentRadio.setNode(new NodeSysNetAuthorisationReturnUrl(ConnectedSpeakerViewModel.REDIRECT_URL), false);
        }
    }


    private void setNavigationAndPresetsCapabilities(NodeNavCaps navCapsNode) {
        boolean navigationIsAllowed = false;
        boolean isPresetNavigationSupported = false;
        boolean isPresetEditionSupported = false;

        if (navCapsNode != null) {
            navigationIsAllowed = navCapsNode.DoesSupport(NodeNavCaps.NodeNavCapability.NodeNavCapabilityNavigation);
            isPresetNavigationSupported = navCapsNode.DoesSupport(NodeNavCaps.NodeNavCapability.NodeNavCapabilityPresets);
            isPresetEditionSupported = navCapsNode.DoesSupport(NodeNavCaps.NodeNavCapability.NodeNavPresetsEdition);

        }

        mSpeakerDataModel.isNavigationSupportedForCurrentMode.set(navigationIsAllowed);
        mSpeakerDataModel.isPresetNavigationSupported.set(isPresetNavigationSupported);
        mSpeakerDataModel.isPresetEditionSupported.set(isPresetEditionSupported);
    }

    private void updateStandbyState() {
        mSpeakerDataModel.isInStandby.set(mRadio.isInStandby());
    }

    public boolean hasAvs(){
        if (mRadio != null) {
            return mRadio.hasAVS();
        }

        return false;
    }

    public void setAvsLoginStatus(boolean isLoggedIn){
        mSpeakerDataModel.isAvsLoggedIn.set(isLoggedIn && hasAvs());
    }

    public boolean isInStandby() {
        // Returning data from radio in case the one from dataModel it's outdated.
        // This can happen after the connection is lost

        return mRadio != null && mRadio.isInStandby();
    }

    public void enablePower(boolean enable) {

        if (mRadio == null) {
            return;
        }

        NodeSysPower.Ord ord = enable ? NodeSysPower.Ord.ON : NodeSysPower.Ord.OFF;

        RadioNodeUtil.setNodeToRadioAsync(mRadio, new NodeSysPower(ord), new RadioNodeUtil.INodeSetResultListener() {
            @Override
            public void onNodeSetResult(boolean success) {
                mRadio.getNode(NodeSysPower.class, false, true, new IGetNodeCallback() {
                    @Override
                    public void getNodeResult(NodeInfo node) {
                        updateStandbyState();
                    }

                    @Override
                    public void getNodeError(Class nodeType, NodeErrorResponse error) {}
                });
            }
        });
    }

    public NodeSysCapsValidModes.Mode getCurrentMode() {
        return mSpeakerDataModel.currentMode.get();
    }

    public boolean isNavigationSupportedForCurrentMode() {
        return mSpeakerDataModel.isNavigationSupportedForCurrentMode.get();
    }

    public boolean isPresetNavigationSupported() {
        return mSpeakerDataModel.isPresetNavigationSupported.get();
    }

    public void setIsClearButtonFromPresetVisible() {
      mRadio.setNode(new NodeNavPresetDelete((long) 1000), true, new ISetNodeCallback() {
          @Override
          public void setNodeSuccess(NodeInfo node) {
              mSpeakerDataModel.isCLearButtonFromPresetsVisible.set(true);
          }

          @Override
          public void setNodeError(NodeInfo node, NodeErrorResponse error) {
            if (error.getFSStatus() == ErrorResponse.FSStatusCode.FS_NODE_DOES_NOT_EXIST) {
                mSpeakerDataModel.isCLearButtonFromPresetsVisible.set(false);
            } else if (error.getFSStatus() == ErrorResponse.FSStatusCode.FS_NODE_BLOCKED) {
                mSpeakerDataModel.isCLearButtonFromPresetsVisible.set(true);
            }
          }
      });
    }

    public void setMode(long key) {
        if (mRadio == null) {
            FsLogger.log("setMode: radio is null");

            return;
        }

        NodeSysMode modeNode = new NodeSysMode(key);

        mRadio.setNode(modeNode, false);
    }

    public boolean isNotificationAllowed() {
        NodeSysCapsValidModes.Mode currentMode = getCurrentMode();
        if (currentMode == NodeSysCapsValidModes.Mode.IR ||
                currentMode == NodeSysCapsValidModes.Mode.DMR ||
        currentMode == NodeSysCapsValidModes.Mode.MP) {
            return true;
        }

        return false;
    }
}
