package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.recyclerview.widget.RecyclerView;

import com.frontier_silicon.NetRemoteLib.NetRemote;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.FormManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.formItems.FormItem;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.airableManagers.IFormItemRetrieveListener;

/**
 * Created by adanaila on 21/10/2016.
 */

public class BrowseFormItemNotLoadedViewModel  implements IFormItemRetrieveListener {
    int mPosition;
    RecyclerView.Adapter mAdapter;
    private FormManager manager;

    public BrowseFormItemNotLoadedViewModel(int position, RecyclerView.Adapter adapter, FormManager manag) {
        mPosition = position;
        mAdapter = adapter;
        this.manager = manag;
        init();
    }

    private void init() {
        //call to BrowseFormManager
        manager.getFormItemModelAsync(mPosition, this);
    }


    @Override
    public void onFormItemRetrieved(FormItem itemModel) {
        if (mAdapter != null) {
            NetRemote.getMainThreadExecutor().execute(() -> {
                if (mAdapter != null) {
                    mAdapter.notifyItemChanged(mPosition);
                }
            });
        }
    }

    public void dispose() {
        mAdapter = null;
        this.manager = null;
    }
}
