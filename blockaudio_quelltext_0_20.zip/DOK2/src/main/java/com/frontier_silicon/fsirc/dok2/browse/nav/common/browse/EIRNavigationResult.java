package com.frontier_silicon.fsirc.dok2.browse.nav.common.browse;

/**
 * Created by lsuhov on 20/10/2016.
 */

public enum EIRNavigationResult {
    Success,
    AlreadyLoaded,
    NavigationFailed,
    TotalItemsNotRetrieved,
    EmptyList,
    RootReached
}
