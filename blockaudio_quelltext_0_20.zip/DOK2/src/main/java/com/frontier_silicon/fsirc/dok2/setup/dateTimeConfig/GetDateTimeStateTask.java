package com.frontier_silicon.fsirc.dok2.setup.dateTimeConfig;

import android.content.Context;
import android.os.AsyncTask;

import com.frontier_silicon.NetRemoteLib.Node.NodeListItem;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysClockDst;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysClockLocalDate;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysClockLocalTime;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysClockMode;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysClockSource;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysClockTimeZone;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysClockUtcOffset;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;

public class GetDateTimeStateTask extends AsyncTask<Void, Void, Boolean> {

    private Radio mRadio;
    private IDateTimeStateListener mListener;
    private DateTimeParams mDateTimeParams;

    public GetDateTimeStateTask(Context context, Radio radio, IDateTimeStateListener listener) {
        mRadio = radio;
        mListener = listener;
        mDateTimeParams = new DateTimeParams(context);
    }

    @Override
    protected Boolean doInBackground(Void... voids) {
        boolean result = true;

        NodeSysClockMode clockModeNode = (NodeSysClockMode) mRadio.
                nodeSyncGetter(NodeSysClockMode.class).get();
        if (clockModeNode != null && clockModeNode.getValueEnum() != null) {
            mDateTimeParams.mHourFormat = clockModeNode.getValueEnum();
        } else {
            result = false;
        }

        NodeSysClockSource clockSourceNode = (NodeSysClockSource) mRadio.
                nodeSyncGetter(NodeSysClockSource.class).get();
        if (clockSourceNode != null && clockSourceNode.getValueEnum() != null) {
            mDateTimeParams.mClockSource = getClockSourceFieldEnum(clockSourceNode.getValueEnum());
        } else {
            result = false;
        }

        NodeSysClockUtcOffset clockUTCOffsetNode = (NodeSysClockUtcOffset) mRadio.
                nodeSyncGetter(NodeSysClockUtcOffset.class).get();
        if (clockUTCOffsetNode != null) {
            mDateTimeParams.mUtcOffsetSeconds = clockUTCOffsetNode.getValue();
        } else {
            result = false;
        }

        NodeSysClockDst clockDSTNode = (NodeSysClockDst) mRadio.
                nodeSyncGetter(NodeSysClockDst.class).get();
        if (clockDSTNode != null && clockDSTNode.getValueEnum() != null) {
            mDateTimeParams.mDaylightSaving = (clockDSTNode.getValueEnum() == NodeSysClockDst.Ord.ON);
        } else {
            result = false;
        }

        NodeSysClockLocalDate clockLocalDateNode = (NodeSysClockLocalDate) mRadio.
                nodeSyncGetter(NodeSysClockLocalDate.class).get();
        if (clockLocalDateNode != null) {
            mDateTimeParams.setDateFromString(clockLocalDateNode.getValue());
        } else {
            result = false;
        }

        NodeSysClockLocalTime clockLocalTimeNode = (NodeSysClockLocalTime) mRadio.
                nodeSyncGetter(NodeSysClockLocalTime.class).get();
        if (clockLocalTimeNode != null) {
            mDateTimeParams.setTimeFromString(clockLocalTimeNode.getValue());
        } else {
            result = false;
        }

        NodeSysClockTimeZone clockTimeZone = (NodeSysClockTimeZone) mRadio.
                nodeSyncGetter(NodeSysClockTimeZone.class).get();
        if (clockTimeZone != null)
            mDateTimeParams.setSelectedTimeZone(clockTimeZone.getValue());
        else {
            mDateTimeParams.setSelectedTimeZone("");
            result = false;
        }
        return result;
    }

    @Override
    protected void onPostExecute(Boolean resultOk) {
        if (mListener != null) {
            if (resultOk) {
                mListener.onDateTimeStateUpdate(mDateTimeParams);
            } else {
                mListener.onDateTimeStateUpdate(mDateTimeParams);
            }
        }

        mListener = null;
        mRadio = null;
    }

    private NodeListItem.FieldSource getClockSourceFieldEnum(NodeSysClockSource.Ord clockSourceEnum) {
        return NodeListItem.FieldSource.values()[clockSourceEnum.ordinal()];
    }

}
