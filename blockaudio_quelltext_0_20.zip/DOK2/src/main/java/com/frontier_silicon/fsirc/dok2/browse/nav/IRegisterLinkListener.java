package com.frontier_silicon.fsirc.dok2.browse.nav;

/**
 * Created by hcostescu on 09/03/17.
 */

public interface IRegisterLinkListener {
    void setRegisterLinkVisibility(boolean visibility);
    void setRegisterLinkUrl(String url);
}
