package com.frontier_silicon.fsirc.dok2.browse.nav.navModel;

import android.text.TextUtils;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavDescription;
import com.frontier_silicon.NetRemoteLib.Node.NodeNavReleaseDate;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.common.RadioNavigationUtil;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * Created by lsuhov on 07/03/2018.
 */

public class NavDescriptionRetrieverRunnable implements Runnable {

    private final String markerForSignalingBiggerText = "~!@#$~";

    @Override
    public void run() {
        final Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        RadioNavigationUtil.waitForNavStatusReady(radio);

        Map<Class, NodeInfo> nodes = radio.nodesSyncGetter(new Class[]{NodeNavDescription.class,
                NodeNavReleaseDate.class}).get();

        extractReleaseDate(nodes);

        extractArtistDescription(nodes);
    }

    private void extractReleaseDate(Map<Class, NodeInfo> nodes) {
        NavBrowseDataModel navBrowseDataModel = NavBrowseManager.getInstance().getNavBrowseDataModel();

        NodeNavReleaseDate nodeNavReleaseDate = (NodeNavReleaseDate) nodes.get(NodeNavReleaseDate.class);
        if (nodeNavReleaseDate != null && nodeNavReleaseDate.getValue() != 0) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");
            long dateAsLong = nodeNavReleaseDate.getValue();
            navBrowseDataModel.releaseDate.set(sdf.format(new Date(dateAsLong * 1000)));
        } else
            navBrowseDataModel.releaseDate.set("");
    }

    private void extractArtistDescription(Map<Class, NodeInfo> nodes) {
        NavBrowseDataModel navBrowseDataModel = NavBrowseManager.getInstance().getNavBrowseDataModel();

        NodeNavDescription nodeNavDescription = (NodeNavDescription) nodes.get(NodeNavDescription.class);
        if (nodeNavDescription != null) {
            String navDescription = nodeNavDescription.getValue();

            if (navDescription.endsWith(markerForSignalingBiggerText)) {
                navDescription = navDescription.replace(markerForSignalingBiggerText, "");

                retrieveMoreDataFromNavDescription(navDescription);
            } else {
                navBrowseDataModel.artistAlbumDescription.set(navDescription);
            }
        } else {
            navBrowseDataModel.artistAlbumDescription.set("");
        }
    }

    private void retrieveMoreDataFromNavDescription(String currentNavDescription) {
        final Radio radio = NetRemoteManager.getInstance().getCurrentRadio();
        if (radio == null) {
            return;
        }

        NavBrowseDataModel navBrowseDataModel = NavBrowseManager.getInstance().getNavBrowseDataModel();

        NodeNavDescription nodeNavDescription = (NodeNavDescription)radio.nodeSyncGetter(NodeNavDescription.class).get();

        if (nodeNavDescription != null && !TextUtils.isEmpty(nodeNavDescription.getValue())) {
            String continuationOfNavDescription = nodeNavDescription.getValue();

            if (continuationOfNavDescription.endsWith(markerForSignalingBiggerText)) {
                currentNavDescription += continuationOfNavDescription.replace(markerForSignalingBiggerText, "");
                retrieveMoreDataFromNavDescription(currentNavDescription);

            } else {
                navBrowseDataModel.artistAlbumDescription.set(currentNavDescription + continuationOfNavDescription);
            }
        } else {
            navBrowseDataModel.artistAlbumDescription.set(currentNavDescription);
        }
    }
}
