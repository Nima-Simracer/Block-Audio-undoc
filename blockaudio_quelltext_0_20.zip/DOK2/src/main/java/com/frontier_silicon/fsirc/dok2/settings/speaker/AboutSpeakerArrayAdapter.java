package com.frontier_silicon.fsirc.dok2.settings.speaker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Node.NodeSysNetKeepConnected;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.util.SpeakerImageDownloader;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class AboutSpeakerArrayAdapter extends ArrayAdapter<AboutSpeakerModel> {

	private Context mContext;
	private IAboutSpeakerListener mListener;

	public AboutSpeakerArrayAdapter(Context context, int resource, int textViewResourceId, List<AboutSpeakerModel> objects, IAboutSpeakerListener listener) {
		super(context, resource, textViewResourceId, objects);	

		mContext = context;
		mListener = listener;
	}	

    @SuppressLint("InflateParams")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
    	View v = convertView;
		LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		final AboutSpeakerModel item = getItem(position);
		
		if (v == null) {
			v = li.inflate(R.layout.settings_about_device_list_item, null);
		}

        if (item.mDeviceRadio != null) {
            TextView deviceNameText = (TextView) v.findViewById(R.id.textEditName);
            Button editNameBtn = (Button) v.findViewById(R.id.buttonEditName);
			editNameBtn.setContentDescription(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.change_name, true));
            MultiroomDeviceModel deviceModel = MultiroomGroupManager.getInstance().getDeviceByUdn(
                    item.mDeviceRadio.getUDN());

            if (deviceModel == null) {
                setupFriendlyNameOfRadio(item, deviceNameText, editNameBtn);

            } else {
                if (deviceModel.isStereoSystem()) {
                    deviceNameText.setText(deviceModel.toString());
                    editNameBtn.setVisibility(View.GONE);
                } else {
                    setupFriendlyNameOfRadio(item, deviceNameText, editNameBtn);
                }
            }
        }

		TextView modelName = v.findViewById(R.id.textModelName);
		modelName.setText(item.mModelName);
		
		TextView versionText = v.findViewById(R.id.textVersion);
		versionText.setText(item.mVersion);
		
		TextView ipAddressText = v.findViewById(R.id.textIPAddress);
		ipAddressText.setText(item.mIPAddress);
		
		TextView macAddressText = v.findViewById(R.id.textMACAddress);
		macAddressText.setText(item.mMACAddress);

		TextView wifiNetworkNameText = v.findViewById(R.id.textWifiNetworkName);
		TextView ethernetNetworkNameText = v.findViewById(R.id.textEthernetNetworkName);
		ethernetNetworkNameText.setText(mContext.getString(R.string.ethernet_network_name));

		View wifiStrengthLayout = v.findViewById(R.id.layoutWifiStrength);

		if (item.mWiredInterfaceConnected) {
			ethernetNetworkNameText.setVisibility(View.VISIBLE);
			wifiNetworkNameText.setVisibility(View.GONE);

			wifiStrengthLayout.setVisibility(View.GONE);
		} else {
			wifiNetworkNameText.setText(mContext.getString(R.string.name_of_wifi_network, getWifiNetworkName(item)));
			wifiNetworkNameText.setVisibility(View.VISIBLE);

			ethernetNetworkNameText.setVisibility(View.GONE);

			ProgressBar wifiStrengthProgress = v.findViewById(R.id.progressWifiStrength);
			wifiStrengthProgress.setProgress(item.mWifiNetworkStrengthPercent);

			wifiStrengthLayout.setVisibility(View.VISIBLE);
		}

		ImageView radioIconImage = v.findViewById(R.id.imageRadioIcon);
		updateRadioIcon(item.mDeviceRadio, radioIconImage);

		enableHiddenSettingForNetworkCOnnection(radioIconImage);
		return v;
	}

	private void enableHiddenSettingForNetworkCOnnection(ImageView imageVIew) {
		imageVIew.setOnLongClickListener(view -> {
			mListener.onKeepNetworkConnectedClicked();
			return true;
		});
	}

	private void setupFriendlyNameOfRadio(final AboutSpeakerModel item, TextView deviceNameText, Button editNameBtn) {
        deviceNameText.setText(item.mDeviceRadio.getFriendlyName());
        deviceNameText.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                notifyOnEditNameClicked(item);
            }
        });

        editNameBtn.setVisibility(View.VISIBLE);
        editNameBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                notifyOnEditNameClicked(item);
            }
        });
    }

	protected void notifyOnEditNameClicked(AboutSpeakerModel item) {
    	if (mListener != null) {
    		mListener.onEditNameBtnClick(item);
    	}
	}

	private String getWifiNetworkName(AboutSpeakerModel item) {
		return item.mWifiNetworkName;
	}

	private void updateRadioIcon(final Radio radio, final ImageView radioIconImageView) {
        if (radio == null || radio.getImageURL() == null) {
            radioIconImageView.setVisibility(View.GONE);
            return;
        }

		SpeakerImageDownloader downloader = new SpeakerImageDownloader(radio, mContext,
				bitmapDrawable -> {
					radioIconImageView.setImageDrawable(bitmapDrawable);
					radioIconImageView.setVisibility(View.VISIBLE);
				});

		downloader.download();
	}
}
