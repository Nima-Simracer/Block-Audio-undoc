package com.frontier_silicon.fsirc.dok2.presets;

import java.util.ArrayList;

public interface IPresetsListener {

	void onPresetsUpdate(ArrayList<PresetItemModel> presetsList);

	void onPresetsSupportedCapsUpdate(boolean navigatePresetsSupported, boolean addPresetsSupported);

}
