package com.frontier_silicon.fsirc.dok2.settings.language;

/**
 * Created by hcostescu on 17/01/17.
 */

public interface ILanguageSettingClickListener {
    void onListItemClick(LanguageItemModel item);
}
