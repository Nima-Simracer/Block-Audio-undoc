package com.frontier_silicon.fsirc.dok2.connectedSpeaker;

public interface IPageSwitchListener {

	void onFragmentActivated();
	
	void onFragmentDeactivated();
}
