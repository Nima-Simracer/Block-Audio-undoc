package com.frontier_silicon.fsirc.dok2.setup.welcome;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupWelcomeActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;
import com.frontier_silicon.fsirc.dok2.setup.SetupManager;

/**
 * Created by nbalazs on 01/03/2018.
 */

public class WelcomeActivity extends SetupActivityBase {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetupManager.getInstance().Init(this);

        SetupWelcomeActivityBinding mBinding = DataBindingUtil.setContentView(this, R.layout.setup_welcome_activity);

        mBinding.setViewModel(new WelcomeActivityVM(this));

        configureToolbarWithExitButton(R.string.setup_title_introduction);
        mBinding.textContent1.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.introduction_description_1, true));
        mBinding.textContent2.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.introduction_description_2, true));

    }
}
