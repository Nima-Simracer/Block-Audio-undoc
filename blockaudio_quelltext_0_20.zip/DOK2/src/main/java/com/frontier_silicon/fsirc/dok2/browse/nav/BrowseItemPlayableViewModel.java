package com.frontier_silicon.fsirc.dok2.browse.nav;

import androidx.databinding.ObservableBoolean;
import android.view.View;

import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseItemModel;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.BrowseManager;
import com.frontier_silicon.fsirc.dok2.browse.nav.common.browse.IPlayNavigationListener;
import com.frontier_silicon.fsirc.dok2.browse.nav.events.PlayStationEvent;
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by lsuhov on 21/10/2016.
 */

public class BrowseItemPlayableViewModel extends BrowseNavItemViewModel {

    public ObservableBoolean startPlayIsInProgress = new ObservableBoolean(false);

    private BrowseManager mBrowseManager;

    public BrowseItemPlayableViewModel(int position, BrowseItemModel navBrowseItemModel, BrowseManager manager) {
        super(position, navBrowseItemModel);
        this.mBrowseManager = manager;
    }

    public void onListItemClicked(View view) {

        startPlayIsInProgress.set(true);

        mBrowseManager.playNavItemKey(mNavBrowseItemModel.getKey(), new IPlayNavigationListener() {
            @Override
            public void onPlayInitiationResult(boolean success) {

                startPlayIsInProgress.set(false);

                if (success) {
                    EventBus.getDefault().post(new PlayStationEvent());
                }
            }
        });
        AnalyticsSender.sendIRStation(mNavBrowseItemModel.getName(), mNavBrowseItemModel.getKey());
    }

}
