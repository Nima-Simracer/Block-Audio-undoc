package com.frontier_silicon.fsirc.dok2.stereo.selectSecondary;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.components.stereo.StereoItemModel;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.databinding.StereoSelectSecondaryBinding;
import com.frontier_silicon.fsirc.dok2.stereo.StereoBundleHelper;

/**
 * Created by lsuhov on 06/08/2017.
 */

public class SelectSecondarySpeakerActivity extends UndokActivityBase {

    SelectSecondarySpeakerViewModel mViewModel;
    StereoSelectSecondaryBinding mBinding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.stereo_select_secondary);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.stereo_setup);
        mBinding.stereoSelectTextView.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.select_secondary_speaker, true));
        mBinding.notFoundSmartRadiosTextView.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.no_secondary_speakers_found, false));
    }

    @Override
    protected void onStart() {
        super.onStart();

        Bundle bundle = getIntent().getExtras();
        StereoItemModel primaryStereoItemModel = StereoBundleHelper.getPrimaryStereoItemModel(bundle);

        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
        addUdnToSpeakerLostWatcher(bundle.getString(StereoBundleHelper.PRIMARY_SPEAKER_UDN));

        if (!StereoBundleHelper.isStereoItemModelSpeakerValid(primaryStereoItemModel)) {
            onBackPressed();
            return;
        }

        mViewModel = new SelectSecondarySpeakerViewModel(primaryStereoItemModel, this, mBinding.list);

        mBinding.setViewModel(mViewModel);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mViewModel != null) {
            mViewModel.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mViewModel != null) {
            mViewModel.onPause();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (mViewModel != null) {
            mViewModel.dispose();
            mViewModel = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mBinding = null;
    }
}
