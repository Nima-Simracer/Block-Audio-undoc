package com.frontier_silicon.fsirc.dok2.setup.fsdca;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.R;

import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.databinding.SetupFsdcaAssociationActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;

public class SetupFSDCAAssociationActivity extends SetupActivityBase {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetupFsdcaAssociationActivityBinding binding = DataBindingUtil.setContentView(this,
                R.layout.setup_fsdca_association_activity);

        SetupFSDCAAssociationViewModel viewModel = new SetupFSDCAAssociationViewModel(this);

        binding.setViewModel(viewModel);

        configureToolbarWithoutExitButton(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_fsdca_info, true));
        binding.associateButton.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_fsdca_info, true));
        binding.textView1.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.setup_fsdca_info1, true));
    }

}
