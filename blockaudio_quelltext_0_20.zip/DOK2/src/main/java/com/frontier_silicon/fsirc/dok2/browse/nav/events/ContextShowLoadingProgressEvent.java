package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by lsuhov on 24/11/2016.
 */

public class ContextShowLoadingProgressEvent {}
