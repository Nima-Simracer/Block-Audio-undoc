package com.frontier_silicon.fsirc.dok2.sources;

import java.util.List;
import java.util.Map;

/**
 * Created by lsuhov on 06/03/2018.
 */

public interface IAllSourcesRetrieverListener {

    void onAllSourcesRetrieved(List<SourceItemModel> groupList,
                      Map<SourceItemModel, List<SourceItemModel>> sourcesMap,
                      SourceItemModel currentSourceItem);
}
