package com.frontier_silicon.fsirc.dok2.setup.location;

import android.content.pm.PackageManager;
import androidx.databinding.DataBindingUtil;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.databinding.SetupAllowLocationAccessInfoActivityBinding;
import com.frontier_silicon.fsirc.dok2.setup.SetupActivityBase;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.listOfAP.ListOfAccessPointActivity;
import com.frontier_silicon.fsirc.dok2.setup.accessPoint.manualAPSelection.ManualAccessPointSelectionActivity;
import com.frontier_silicon.fsirc.dok2.util.PermissionsUtil;

/**
 * Created by nbalazs on 01/03/2018.
 *
 */

public class LocationAccessActivity extends SetupActivityBase {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetupAllowLocationAccessInfoActivityBinding mBinding = DataBindingUtil.setContentView(this, R.layout.setup_allow_location_access_info_activity);

        mBinding.setViewModel(new LocationAccessActivityVM(this));

        configureToolbarWithExitButton(R.string.setup_title_introduction);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionsUtil.PERMISSIONS_REQUEST_FINE_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    NavigationHelper.goToActivity(this, ManualAccessPointSelectionActivity.class, NavigationHelper.AnimationType.SlideToLeft, true, null);
                } else {
                    NavigationHelper.goToActivity(this, ListOfAccessPointActivity.class, NavigationHelper.AnimationType.SlideToLeft, true, null);
                }
            } else {
//                TODO: Maybe we should notify the user that we need this permission ...
            }
        }
    }
}
