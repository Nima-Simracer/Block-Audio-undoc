package com.frontier_silicon.fsirc.dok2.setup

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.frontier_silicon.fsirc.dok2.NavigationHelper
import com.frontier_silicon.fsirc.dok2.R
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase
import com.frontier_silicon.fsirc.dok2.settings.AnalyticsSender
import com.frontier_silicon.fsirc.dok2.settings.staticRadioSearch.ActivityStaticRadio

class SetupSearchSpeakerActivity: UndokActivityBase() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.setup_search_activity)

        setupAppBar()
        enableUpNavigation()
        setTitle(SmartRadioStringsManager.getSmartRadioString(R.string.setup_search_title, true))

        findViewById<Button>(R.id.searchRadioByIp).text = SmartRadioStringsManager.getSmartRadioString(R.string.search_smart_radio_by_ip, true)
        findViewById<Button>(R.id.setupRadioButton).text = SmartRadioStringsManager.getSmartRadioString(R.string.setup_smart_radio, true)
        findViewById<TextView>(R.id.title).text = SmartRadioStringsManager.getSmartRadioString(R.string.setup_search_message_title, true)
        findViewById<TextView>(R.id.message).text = SmartRadioStringsManager.getSmartRadioString(R.string.setup_search_message_description, true)
    }

    fun onSetupRadioButtonClick(view: View) {
        dispatchSetupActivity()
    }

    fun onSearchByIpButtonClick(view: View) {
        dispatchSearchByIpActivity()
    }

    private fun dispatchSetupActivity() {
        AnalyticsSender.sendNewAudioSystemTappingAnalytics()
        NavigationHelper.goToSetupActivity(this)
    }

    private fun dispatchSearchByIpActivity() {
        NavigationHelper.goToActivity(this, ActivityStaticRadio::class.java)
    }
}