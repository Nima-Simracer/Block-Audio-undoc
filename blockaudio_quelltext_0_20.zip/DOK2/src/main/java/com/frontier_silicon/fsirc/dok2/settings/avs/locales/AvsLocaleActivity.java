package com.frontier_silicon.fsirc.dok2.settings.avs.locales;



import androidx.lifecycle.ViewModelProviders;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.frontier_silicon.NetRemoteLib.Node.NodeAvsLocale;
import com.frontier_silicon.NetRemoteLib.Node.NodeInfo;
import com.frontier_silicon.NetRemoteLib.Radio.ISetNodeCallback;
import com.frontier_silicon.NetRemoteLib.Radio.NodeErrorResponse;
import com.frontier_silicon.NetRemoteLib.Radio.Radio;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.RadioFromBundleExtractor;
import com.frontier_silicon.fsirc.dok2.baseActivity.SpeakerLostHandlingType;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.loggerlib.FsLogger;


public class AvsLocaleActivity extends UndokActivityBase {
    private Radio mRadio;
    private AvsLocalesAdapter adapter;
    private AvsLocaleViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avs_locale);
        viewModel = ViewModelProviders.of(this).get(AvsLocaleViewModel.class);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.amazon_alexa);

        // get attached data to this intent
        Bundle bundle = getIntent().getExtras();
        mRadio = RadioFromBundleExtractor.extractRadio(bundle, AvsLocaleActivity.class);
        viewModel.setRadio(mRadio);

        initSpeakerLostWatcher(SpeakerLostHandlingType.GoBack);
        addUdnToSpeakerLostWatcher(bundle.getString(NavigationHelper.RADIO_UDN_ARG));

        setupControls();
    }

    public void setupControls() {
        RecyclerView lv = findViewById(R.id.recycler_view);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);

        lv.setLayoutManager(mLayoutManager);
        lv.setItemAnimator(new DefaultItemAnimator());

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, LinearLayoutManager.VERTICAL);
        lv.addItemDecoration(dividerItemDecoration);

        setAdapterInteraction();
        lv.setAdapter(adapter);
    }

    private void setAdapterInteraction() {
        adapter = new AvsLocalesAdapter(item -> {

            NodeAvsLocale avsLocale = new NodeAvsLocale(item.getKey());
            mRadio.setNode(avsLocale, new ISetNodeCallback() {
                @Override
                public void setNodeSuccess(NodeInfo node) {
                    FsLogger.log("locale node set - OK");
                   adapter.setSelected(avsLocale.getValue());
                }

                @Override
                public void setNodeError(NodeInfo node, NodeErrorResponse error) {

                }
            });
        });

    }


    @Override
    protected void onResume() {
        super.onResume();

        if (mRadio == null) {
            // mClientRadio is null, do not continue with login
            finish();
            return;
        }

        registerObservers();
    }

        private void registerObservers() {
            viewModel.getLocales().observe(this, locales -> {
                if (locales.size() > 0) {
                    adapter.swapItems(locales);
                }
            });

            viewModel.getCurrentLocale().observe(this, locale -> {
                adapter.setSelected(locale.getValue());
            });
        }
}
