package com.frontier_silicon.fsirc.dok2.util;

import androidx.appcompat.app.AppCompatActivity;

import com.frontier_silicon.components.common.CommonPreferences;
import com.frontier_silicon.fsirc.dok2.R;

/**
 * Created by lsuhov on 18/11/15.
 */
public class ThemeUtil {

    public static void applyTheme(AppCompatActivity activity) {
        int themeResId = getThemeResId();
        activity.setTheme(themeResId);
    }

    public static int getThemeResId() {
        int themeIndex = CommonPreferences.getInstance().getCurrentThemeIndex();
        int themeResId = R.style.UndokThemeMain;

        switch (themeIndex) {
            case 0:
                themeResId = R.style.UndokThemeMain;
                break;
            case 1:
                themeResId = R.style.UndokThemeDarkBlack;
                break;
        }

        return themeResId;
    }

}
