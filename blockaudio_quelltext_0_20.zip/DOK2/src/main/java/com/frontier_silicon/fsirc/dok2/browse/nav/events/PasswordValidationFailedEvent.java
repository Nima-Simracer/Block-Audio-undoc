package com.frontier_silicon.fsirc.dok2.browse.nav.events;

/**
 * Created by hcostescu on 11/11/2016.
 */

public class PasswordValidationFailedEvent {
    private final String message;
    public PasswordValidationFailedEvent(String message)
    {
        this.message = message;
    }
    public String getMessage()
    {return message;}
}
