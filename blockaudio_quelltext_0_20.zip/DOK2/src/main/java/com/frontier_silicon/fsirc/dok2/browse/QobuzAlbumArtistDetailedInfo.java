package com.frontier_silicon.fsirc.dok2.browse;

import android.app.Activity;

import androidx.appcompat.app.AlertDialog;
import android.view.View;
import android.widget.TextView;

import com.frontier_silicon.components.common.DialogsHolder;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.util.ThemedAlertDialogBuilder;

import static com.frontier_silicon.fsirc.dok2.R.id.description;
import static com.frontier_silicon.fsirc.dok2.R.id.releaseDate;

/**
 * Created by hcostescu on 11/19/2016.
 */

public class QobuzAlbumArtistDetailedInfo {

    public static void showBrowseDialogInfo(Activity activity,String strArtistAlbumDescription, String strReleaseDate) {

        String dialogKey = "qobuz_browse_info";
        if (DialogsHolder.isShowingOrActivityIsFinishing(dialogKey, activity))
            return;

        AlertDialog.Builder builder = ThemedAlertDialogBuilder.create(activity);
        builder.setTitle(activity.getString(R.string.info_button));

        View dialogView = View.inflate(activity,R.layout.qobuz_browse_info,null);

        TextView releaseDateTextView = dialogView.findViewById(releaseDate);
        if (strReleaseDate.length() == 0) {
            releaseDateTextView.setVisibility(View.GONE);
        } else {
            releaseDateTextView.setText(activity.getString(R.string.album_relase_date) + strReleaseDate);
        }

        TextView descriptionTextView = dialogView.findViewById(description);
        descriptionTextView.setText(strArtistAlbumDescription);

        builder.setView(dialogView);
        builder.setNegativeButton(android.R.string.cancel, null);

        AlertDialog dlg = builder.create();
        DialogsHolder.addDialogToCollection(dialogKey, dlg);

        dlg.show();
    }
}

