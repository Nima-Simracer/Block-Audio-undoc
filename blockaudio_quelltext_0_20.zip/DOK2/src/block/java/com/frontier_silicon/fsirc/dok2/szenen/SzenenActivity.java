package com.frontier_silicon.fsirc.dok2.szenen;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;

import java.util.ArrayList;
import java.util.List;

/**
 * Fassung 0.20 Audioblock (19.09.2026) — NEU.
 *
 * Die Seite "Aufstellungen". Hier merkt man sich, wie die Geraete gerade
 * gruppiert sind, und stellt das spaeter mit einem Tipp wieder her.
 *
 * Bewusst schlicht gebaut: eine Liste, ein Knopf. Kein RecyclerView, keine
 * Datenbindung — das haelt die Zahl der Stellen klein, an denen etwas
 * schiefgehen kann, und es ist eine Seite, die man zweimal am Tag benutzt.
 */
public class SzenenActivity extends UndokActivityBase {

    private ListView mListe;
    private TextView mLeerHinweis;
    private ProgressBar mLaeuft;
    private Button mMerken;

    private final List<Szene> mSzenen = new ArrayList<>();
    private ArrayAdapter<String> mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.szenen_activity);

        setupAppBar();
        enableUpNavigation();
        setTitle(R.string.szenen_titel);

        mListe = findViewById(R.id.szenenListe);
        mLeerHinweis = findViewById(R.id.szenenLeer);
        mLaeuft = findViewById(R.id.szenenLaeuft);
        mMerken = findViewById(R.id.szenenMerken);

        /* Eigene Zeile statt android.R.layout.simple_list_item_1: die
           Standardzeile nimmt die Textfarbe des Themas, und daran ist in
           dieser App schon zweimal Text unsichtbar geworden. */
        mAdapter = new ArrayAdapter<>(this, R.layout.szenen_list_item,
                R.id.szenenZeile, new ArrayList<String>());
        mListe.setAdapter(mAdapter);

        mListe.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> eltern, View blick, int stelle, long id) {
                frageWiederherstellen(stelle);
            }
        });

        mListe.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> eltern, View blick, int stelle, long id) {
                frageLoeschen(stelle);
                return true;
            }
        });

        mMerken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frageMerken();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        listeNeuLaden();
    }

    private void listeNeuLaden() {
        mSzenen.clear();
        mSzenen.addAll(SzenenSpeicher.alle(this));

        List<String> zeilen = new ArrayList<>();
        for (Szene s : mSzenen) {
            zeilen.add(s.name + "\n" + s.beschreibung());
        }

        mAdapter.clear();
        mAdapter.addAll(zeilen);
        mAdapter.notifyDataSetChanged();

        boolean leer = mSzenen.isEmpty();
        mLeerHinweis.setVisibility(leer ? View.VISIBLE : View.GONE);
        mListe.setVisibility(leer ? View.GONE : View.VISIBLE);
    }

    // ---------- Merken ----------

    private void frageMerken() {
        final Szene vorschau = SzenenSpeicher.ausJetzigemZustand("");

        if (vorschau.gruppen.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.szenen_titel)
                    .setMessage(R.string.szenen_nichts_zu_merken)
                    .setPositiveButton(android.R.string.ok, null)
                    .show();
            return;
        }

        final EditText feld = new EditText(this);
        feld.setInputType(InputType.TYPE_CLASS_TEXT);
        feld.setHint(R.string.szenen_name_hinweis);

        new AlertDialog.Builder(this)
                .setTitle(R.string.szenen_merken)
                .setMessage(getString(R.string.szenen_merken_frage, vorschau.beschreibung()))
                .setView(feld)
                .setPositiveButton(R.string.save, (dlg, welcher) -> {
                    String name = feld.getText().toString().trim();
                    if (name.isEmpty()) {
                        name = getString(R.string.szenen_ohne_namen);
                    }
                    vorschau.name = name;
                    SzenenSpeicher.hinzufuegen(SzenenActivity.this, vorschau);
                    listeNeuLaden();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ---------- Wiederherstellen ----------

    private void frageWiederherstellen(final int stelle) {
        if (stelle < 0 || stelle >= mSzenen.size()) {
            return;
        }
        final Szene s = mSzenen.get(stelle);

        new AlertDialog.Builder(this)
                .setTitle(s.name)
                .setMessage(getString(R.string.szenen_herstellen_frage, s.beschreibung()))
                .setPositiveButton(R.string.szenen_herstellen, (dlg, welcher) -> stelleHer(s))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void stelleHer(final Szene s) {
        arbeitAnzeigen(true);

        new Thread(new Runnable() {
            @Override
            public void run() {
                final SzenenSpeicher.Ergebnis e = SzenenSpeicher.wiederherstellen(s);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) {
                            return;
                        }
                        arbeitAnzeigen(false);

                        String text;
                        if (e.erfolg) {
                            text = getString(R.string.szenen_fertig, e.gebauteGruppen);
                        } else {
                            text = e.meldung;
                        }
                        if (!e.fehlend.isEmpty()) {
                            text = text + "\n" + getString(R.string.szenen_fehlende_geraete,
                                    e.fehlend.size());
                        }

                        new AlertDialog.Builder(SzenenActivity.this)
                                .setTitle(s.name)
                                .setMessage(text)
                                .setPositiveButton(android.R.string.ok, null)
                                .show();
                    }
                });
            }
        }).start();
    }

    private void arbeitAnzeigen(boolean an) {
        mLaeuft.setVisibility(an ? View.VISIBLE : View.GONE);
        mMerken.setEnabled(!an);
        mListe.setEnabled(!an);
    }

    // ---------- Loeschen ----------

    private void frageLoeschen(final int stelle) {
        if (stelle < 0 || stelle >= mSzenen.size()) {
            return;
        }
        final Szene s = mSzenen.get(stelle);

        new AlertDialog.Builder(this)
                .setTitle(s.name)
                .setMessage(R.string.szenen_loeschen_frage)
                .setPositiveButton(R.string.delete, (dlg, welcher) -> {
                    SzenenSpeicher.entfernen(SzenenActivity.this, stelle);
                    listeNeuLaden();
                    Toast.makeText(SzenenActivity.this, R.string.szenen_geloescht,
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
