package com.frontier_silicon.fsirc.dok2.szenen;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Fassung 0.20 Audioblock (19.09.2026) — NEU.
 *
 * Eine gespeicherte Aufstellung: welche Geraete gehoeren in welche Gruppe.
 *
 * Eine Szene kann MEHRERE Gruppen enthalten. Das ist der eigentliche Zweck:
 * Bei zehn Geraeten passen nicht alle in eine Gruppe (der Befehlssatz der
 * Geraete kennt nur vier Mitspieler plus Anfuehrer, also fuenf). Mit mehreren
 * Gruppen laesst sich trotzdem jede Aufteilung abbilden — 5+5, 3+3+4, was
 * auch immer.
 *
 * Gespeichert wird im Telefon, nicht im Geraet. Die Geraete koennen das nicht,
 * und so kann man auch Aufstellungen aufheben, die gerade gar nicht bestehen.
 *
 * Geraete werden ueber ihre Mehrraum-Kennung (UDN) gemerkt, nicht ueber den
 * Namen — ein umbenanntes Geraet bleibt dasselbe Geraet.
 */
public class Szene {

    /** Eine Gruppe innerhalb einer Szene. */
    public static class Gruppe {
        public String name = "";
        /** Kennung des Geraets, das die Gruppe anfuehrt. */
        public String anfuehrerUdn = "";
        /** Kennungen der Mitspieler, ohne den Anfuehrer. */
        public List<String> mitspielerUdn = new ArrayList<>();

        public int anzahl() {
            return 1 + mitspielerUdn.size();
        }
    }

    public String name = "";
    public List<Gruppe> gruppen = new ArrayList<>();

    public int anzahlGeraete() {
        int n = 0;
        for (Gruppe g : gruppen) {
            n += g.anzahl();
        }
        return n;
    }

    /** Kurze Beschreibung fuer die Liste, z.B. "3 Gruppen · 10 Geräte". */
    public String beschreibung() {
        int g = gruppen.size();
        return g + (g == 1 ? " Gruppe" : " Gruppen") + " · " + anzahlGeraete()
                + (anzahlGeraete() == 1 ? " Gerät" : " Geräte");
    }

    // ---------- Umwandlung in Text und zurueck ----------

    public JSONObject alsJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("name", name);
        JSONArray gs = new JSONArray();
        for (Gruppe g : gruppen) {
            JSONObject go = new JSONObject();
            go.put("name", g.name);
            go.put("anfuehrer", g.anfuehrerUdn);
            JSONArray ms = new JSONArray();
            for (String u : g.mitspielerUdn) {
                ms.put(u);
            }
            go.put("mitspieler", ms);
            gs.put(go);
        }
        o.put("gruppen", gs);
        return o;
    }

    public static Szene ausJson(JSONObject o) {
        Szene s = new Szene();
        if (o == null) {
            return s;
        }
        s.name = o.optString("name", "");
        JSONArray gs = o.optJSONArray("gruppen");
        if (gs == null) {
            return s;
        }
        for (int i = 0; i < gs.length(); i++) {
            JSONObject go = gs.optJSONObject(i);
            if (go == null) {
                continue;
            }
            Gruppe g = new Gruppe();
            g.name = go.optString("name", "");
            g.anfuehrerUdn = go.optString("anfuehrer", "");
            JSONArray ms = go.optJSONArray("mitspieler");
            if (ms != null) {
                for (int k = 0; k < ms.length(); k++) {
                    String u = ms.optString(k, "");
                    if (!u.isEmpty()) {
                        g.mitspielerUdn.add(u);
                    }
                }
            }
            if (!g.anfuehrerUdn.isEmpty()) {
                s.gruppen.add(g);
            }
        }
        return s;
    }
}
