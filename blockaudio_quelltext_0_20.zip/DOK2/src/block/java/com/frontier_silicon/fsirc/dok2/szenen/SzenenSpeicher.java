package com.frontier_silicon.fsirc.dok2.szenen;

import android.content.Context;
import android.content.SharedPreferences;

import com.frontier_silicon.components.multiroom.MultiroomDeviceModel;
import com.frontier_silicon.components.multiroom.MultiroomGroupManager;
import com.frontier_silicon.components.multiroom.MultiroomGroupModel;
import com.frontier_silicon.components.multiroom.MultiroomOperation;
import com.frontier_silicon.components.multiroom.MultiroomOperationResult;
import com.frontier_silicon.components.multiroom.MultiroomOperationsQueueExecutor;
import com.frontier_silicon.loggerlib.FsLogger;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Fassung 0.20 Audioblock (19.09.2026) — NEU.
 *
 * Verwaltet die gespeicherten Aufstellungen: ablegen, lesen, aus dem
 * jetzigen Zustand erzeugen und wiederherstellen.
 *
 * Abgelegt wird in den App-Einstellungen des Telefons als Text. Kein Server,
 * keine Datenbank — es sind ein paar Zeilen, und sie gehoeren dem Nutzer.
 */
public class SzenenSpeicher {

    private static final String ABLAGE = "audioblock_szenen";
    private static final String SCHLUESSEL = "szenen";

    private SzenenSpeicher() {
    }

    // ---------- Ablage ----------

    public static List<Szene> alle(Context ctx) {
        List<Szene> liste = new ArrayList<>();
        try {
            SharedPreferences p = ctx.getSharedPreferences(ABLAGE, Context.MODE_PRIVATE);
            String text = p.getString(SCHLUESSEL, "[]");
            JSONArray a = new JSONArray(text);
            for (int i = 0; i < a.length(); i++) {
                liste.add(Szene.ausJson(a.optJSONObject(i)));
            }
        } catch (Throwable e) {
            FsLogger.log("Szenen lesen fehlgeschlagen: " + e);
        }
        return liste;
    }

    public static void speichern(Context ctx, List<Szene> liste) {
        try {
            JSONArray a = new JSONArray();
            for (Szene s : liste) {
                a.put(s.alsJson());
            }
            ctx.getSharedPreferences(ABLAGE, Context.MODE_PRIVATE)
                    .edit().putString(SCHLUESSEL, a.toString()).apply();
        } catch (Throwable e) {
            FsLogger.log("Szenen schreiben fehlgeschlagen: " + e);
        }
    }

    public static void hinzufuegen(Context ctx, Szene s) {
        List<Szene> liste = alle(ctx);
        liste.add(s);
        speichern(ctx, liste);
    }

    public static void entfernen(Context ctx, int stelle) {
        List<Szene> liste = alle(ctx);
        if (stelle >= 0 && stelle < liste.size()) {
            liste.remove(stelle);
            speichern(ctx, liste);
        }
    }

    // ---------- Aus dem jetzigen Zustand erzeugen ----------

    /**
     * Liest, wie die Geraete GERADE gruppiert sind, und macht eine Szene daraus.
     * Einzelne Geraete ohne Gruppe bleiben aussen vor — eine Szene beschreibt
     * Gruppen, nicht Einzelgeraete.
     */
    public static Szene ausJetzigemZustand(String name) {
        Szene s = new Szene();
        s.name = name;

        MultiroomGroupManager m = MultiroomGroupManager.getInstance();
        Set<MultiroomGroupModel> gruppen = m.getGroupsFromDeviceMap();
        if (gruppen == null) {
            return s;
        }

        for (MultiroomGroupModel gm : gruppen) {
            if (gm == null || gm.mGroupId == null) {
                continue;
            }
            /* Die Sammelgruppe der ungruppierten Geraete ueberspringen. */
            if (m.isUngroupedDevicesGroup(gm.mGroupId)) {
                continue;
            }

            List<MultiroomDeviceModel> geraete = m.getAllDevicesForGroupId(gm.mGroupId);
            if (geraete == null || geraete.size() < 2) {
                continue;
            }

            MultiroomDeviceModel anfuehrer = m.getServerDeviceFromGroupId(gm.mGroupId);
            if (anfuehrer == null || anfuehrer.mMultiroomUDN == null
                    || anfuehrer.mMultiroomUDN.isEmpty()) {
                continue;
            }

            Szene.Gruppe g = new Szene.Gruppe();
            g.name = (gm.mGroupName == null || gm.mGroupName.isEmpty())
                    ? "Gruppe" : gm.mGroupName;
            g.anfuehrerUdn = anfuehrer.mMultiroomUDN;

            for (MultiroomDeviceModel d : geraete) {
                if (d == null || d.mMultiroomUDN == null || d.mMultiroomUDN.isEmpty()) {
                    continue;
                }
                if (d.mMultiroomUDN.equals(g.anfuehrerUdn)) {
                    continue;
                }
                g.mitspielerUdn.add(d.mMultiroomUDN);
            }

            s.gruppen.add(g);
        }

        return s;
    }

    // ---------- Wiederherstellen ----------

    /**
     * Was beim Wiederherstellen herauskam.
     */
    public static class Ergebnis {
        public boolean erfolg = true;
        public String meldung = "";
        public int gebauteGruppen = 0;
        public List<String> fehlend = new ArrayList<>();
    }

    /**
     * Stellt eine Szene wieder her.
     *
     * ACHTUNG: laeuft lange und darf NICHT auf dem Anzeigefaden aufgerufen
     * werden. Die Gruppenbefehle gehen einzeln an die Geraete und brauchen
     * jeweils Sekunden.
     *
     * Ablauf:
     *   1. alle bestehenden Gruppen aufloesen — sonst haengen Geraete noch
     *      irgendwo und lassen sich nicht neu zuordnen
     *   2. je Gruppe der Szene: Gruppe anlegen, dann Mitspieler dazu
     *
     * Geraete, die gerade nicht im Netz sind, werden uebersprungen und am
     * Ende gemeldet. Eine Gruppe mit nur noch einem Geraet wird gar nicht
     * erst gebaut — eine Gruppe aus einem Geraet ist keine Gruppe.
     */
    public static Ergebnis wiederherstellen(Szene s) {
        Ergebnis e = new Ergebnis();
        MultiroomGroupManager m = MultiroomGroupManager.getInstance();

        if (s == null || s.gruppen.isEmpty()) {
            e.erfolg = false;
            e.meldung = "Die Aufstellung ist leer.";
            return e;
        }

        List<MultiroomOperation> befehle = new ArrayList<>();

        /* 1. Bestehende Gruppen aufloesen */
        Set<MultiroomGroupModel> bestehende = m.getGroupsFromDeviceMap();
        if (bestehende != null) {
            for (MultiroomGroupModel gm : bestehende) {
                if (gm == null || gm.mGroupId == null || gm.mGroupId.isEmpty()) {
                    continue;
                }
                if (m.isUngroupedDevicesGroup(gm.mGroupId)) {
                    continue;
                }
                MultiroomOperation op = new MultiroomOperation();
                op.mMultiroomDeviceUDN = "";
                op.mGroupId = gm.mGroupId;
                op.mOldGroupId = gm.mGroupId;
                op.mGroupName = gm.mGroupName;
                op.mOldGroupName = gm.mGroupName;
                op.mOperationType = MultiroomOperation.MultiroomGroupEditOperation.DESTROY_GROUP;
                befehle.add(op);
            }
        }

        /* 2. Gruppen der Szene aufbauen */
        for (Szene.Gruppe g : s.gruppen) {
            MultiroomDeviceModel anfuehrer = m.getDeviceByUdn(g.anfuehrerUdn);
            if (anfuehrer == null) {
                e.fehlend.add(g.name + " (Anführer fehlt)");
                continue;
            }

            List<String> vorhandeneMitspieler = new ArrayList<>();
            for (String udn : g.mitspielerUdn) {
                if (m.getDeviceByUdn(udn) != null) {
                    vorhandeneMitspieler.add(udn);
                } else {
                    e.fehlend.add(g.name + " (ein Gerät fehlt)");
                }
            }

            if (vorhandeneMitspieler.isEmpty()) {
                /* Ohne Mitspieler waere es keine Gruppe. */
                continue;
            }

            String neueKennung = UUID.randomUUID().toString();

            MultiroomOperation anlegen = new MultiroomOperation();
            anlegen.mMultiroomDeviceUDN = g.anfuehrerUdn;
            anlegen.mGroupId = neueKennung;
            anlegen.mOldGroupId = MultiroomGroupManager.NO_GROUP_ID;
            anlegen.mGroupName = g.name;
            anlegen.mOldGroupName = MultiroomGroupManager.NO_GROUP_NAME;
            anlegen.mOperationType = MultiroomOperation.MultiroomGroupEditOperation.CREATE_GROUP;
            befehle.add(anlegen);

            for (String udn : vorhandeneMitspieler) {
                MultiroomOperation dazu = new MultiroomOperation();
                dazu.mMultiroomDeviceUDN = udn;
                dazu.mGroupId = neueKennung;
                dazu.mOldGroupId = MultiroomGroupManager.NO_GROUP_ID;
                dazu.mGroupName = g.name;
                dazu.mOldGroupName = MultiroomGroupManager.NO_GROUP_NAME;
                dazu.mOperationType =
                        MultiroomOperation.MultiroomGroupEditOperation.ADD_REMOVE_SPEAKER_TO_FROM_GROUP;
                befehle.add(dazu);
            }

            e.gebauteGruppen++;
        }

        if (e.gebauteGruppen == 0) {
            e.erfolg = false;
            e.meldung = "Keines der gespeicherten Geräte ist gerade erreichbar.";
            return e;
        }

        /* 3. Abarbeiten */
        try {
            MultiroomOperationsQueueExecutor warteschlange =
                    new MultiroomOperationsQueueExecutor(befehle);
            MultiroomOperationResult ergebnis = warteschlange.execute();

            if (ergebnis != null
                    && ergebnis.mOperationResult != MultiroomOperationResult.OperationResult.SUCCESS) {
                e.erfolg = false;
                e.meldung = "Nicht alles ließ sich herstellen (" + ergebnis.mOperationResult + ").";
            }
        } catch (Throwable t) {
            FsLogger.log("Szene wiederherstellen fehlgeschlagen: " + t);
            e.erfolg = false;
            e.meldung = "Es ist etwas schiefgegangen.";
        }

        m.rescanMultiroomGroupsAndDevices();
        return e;
    }
}
