package com.frontier_silicon.fsirc.dok2;

import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;

/**
 * Fassung 0.1 Block Audio (18.09.2026)
 *
 * Jede Geschmacksrichtung braucht eine eigene FlavorMainApplication — das Manifest
 * zeigt mit android:name=".FlavorMainApplication" darauf. store, internal und amazon
 * haben im Original jeweils ihre eigene; das hier ist die von block.
 *
 * Fuer einen weiteren Hersteller: den Ordner src/block kopieren, umbenennen und in
 * DOK2/build.gradle eine Geschmacksrichtung gleichen Namens eintragen. Mehr nicht.
 */
public class FlavorMainApplication extends MainApplication {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
