package com.frontier_silicon.fsirc.dok2;

import com.frontier_silicon.fsirc.dok2.mainApplciation.MainApplication;
/**
 * Created by mnisipeanu on 22/09/2017.
 */
public class FlavorMainApplication extends MainApplication {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
