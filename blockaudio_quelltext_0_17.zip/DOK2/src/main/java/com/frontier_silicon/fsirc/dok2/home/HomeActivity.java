package com.frontier_silicon.fsirc.dok2.home;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.frontier_silicon.components.NetRemoteManager;
import com.frontier_silicon.components.multiroom.MultiroomRescanUtil;
import com.frontier_silicon.fsirc.dok2.NavigationHelper;
import com.frontier_silicon.fsirc.dok2.SmartRadioStringsManager;
import com.frontier_silicon.fsirc.dok2.baseActivity.UndokActivityBase;
import com.frontier_silicon.fsirc.dok2.R;
import com.frontier_silicon.fsirc.dok2.SpeakersDiscoveryManager;
import com.frontier_silicon.fsirc.dok2.databinding.HomeActivityBinding;
import com.frontier_silicon.fsirc.dok2.multiroom.MultiroomEditGroupManager;
import com.frontier_silicon.fsirc.dok2.notifications.MediaNotificationService;
import com.frontier_silicon.fsirc.dok2.notifications.NotificationBase;
import com.frontier_silicon.fsirc.dok2.setup.SetupSearchSpeakerActivity;
import com.frontier_silicon.fsirc.dok2.update.AllDevicesIsuActivity;

public class HomeActivity extends UndokActivityBase {
    private HomeActivityBinding mBinding;
    private HomeViewModel mHomeViewModel;
    private boolean mExit = false;
    private boolean mIsStopped = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = DataBindingUtil.setContentView(this, R.layout.home_activity);

        setActionBar();
        enableMainMenu();

        setupControls();
    }

    private void setActionBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        super.setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            actionBar.setCustomView(R.layout.actionbar_custom);
            actionBar.getCustomView().setOnClickListener(v -> {
                    if (NetRemoteManager.getInstance().getCurrentRadio() != null) {
                    mHomeViewModel.goToConnectedSpeakerActivity();
            }
            });
            actionBar.getCustomView().findViewById(R.id.homeIcon).setVisibility(View.GONE);
        }
    }

    @Override
    public void onStart() {
        super.onStart();

        mIsStopped = false;

        MultiroomEditGroupManager.getInstance().setActivity(this);

        mHomeViewModel = new HomeViewModel();
        mBinding.setViewModel(mHomeViewModel);
        mHomeViewModel.onStart(this, mBinding);
    }

    @Override
    public void onResume() {
        super.onResume();

        mHomeViewModel.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();

        if (mHomeViewModel != null) {
            mHomeViewModel.onPause();
        }
    }

    @Override
    public void onStop() {
        super.onStop();

        mIsStopped = true;

        MultiroomEditGroupManager.getInstance().setActivity(null);

        mHomeViewModel.dispose();
        mHomeViewModel = null;
        mBinding.setViewModel(null);
    }

    private void setupControls() {
        mBinding.buttonRefresh.setOnClickListener(v -> MultiroomRescanUtil.getInstance().rescanMultiroomDevicesAndGroups());
        mBinding.noDevices.setText(SmartRadioStringsManager.INSTANCE.getSmartRadioString(R.string.no_devices_found, false));

        setRefreshGesture();
    }

    private void setRefreshGesture() {
        mBinding.swipeContainer.setOnRefreshListener(() -> {
            mBinding.swipeContainer.setRefreshing(false);
            if (mHomeViewModel.canRescan()) {
                SpeakersDiscoveryManager.getInstance().rescan();
                mBinding.swipeContainer.setRefreshing(false);
            }
        });
    }

    @Override
    public void onBackPressed() {
        closeAppWhenDoubleTapBack();
    }

    private void closeAppWhenDoubleTapBack() {
        if (mExit) {

            // check for IR/DMR/MP notification
            NotificationBase notification = MediaNotificationService.getNotification();
            if (notification != null) {
                if (!(notification.isPlaying() || notification.isBuffering())) {
                    notification.stopForeground().remove();
                }
            }

            finish();
        } else {
            Toast.makeText(this, getString(R.string.press_back_again), Toast.LENGTH_SHORT).show();
            mExit = true;
            new Handler().postDelayed(() -> mExit = false, 3 * 1000);
        }
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        boolean result = super.onPrepareOptionsMenu(menu);
        if (menu == null) {
            return result;
        }

        MenuItem refreshMenuItem = menu.findItem(R.id.action_rescan);
        if (refreshMenuItem != null) {
            refreshMenuItem.setVisible(true);
        }

        MenuItem standbyMenuItem = menu.findItem(R.id.action_standby_icon);
        if (standbyMenuItem != null) {
            standbyMenuItem.setVisible(false);
        }

        MenuItem addRadioByIp = menu.findItem(R.id.action_add_radio_by_ip);
        if (addRadioByIp != null) {
            addRadioByIp.setVisible(true);
        }

        return result;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_rescan) {
            if (mHomeViewModel.canRescan()) {
                SpeakersDiscoveryManager.getInstance().rescan();
            }
            return true;
        } else if (id == R.id.action_add_radio_by_ip) {
            dispatchStaticRadioActivity();
            return true;
        } else if (id == R.id.action_firmware_update) {
            // Fassung 0.14 Audioblock (18.09.2026) — NEU.
            // Fuehrt zur Seite mit den Geraete-Aktualisierungen. Die gab es
            // schon, war aber nur ueber ein Band auf der Startseite zu
            // erreichen, das nur bei gefundener Aktualisierung erscheint.
            NavigationHelper.goToActivity(this, AllDevicesIsuActivity.class,
                    NavigationHelper.AnimationType.SlideToLeft);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void dispatchStaticRadioActivity() {
        NavigationHelper.goToActivity(this, SetupSearchSpeakerActivity.class);
    }

    public boolean isStopped() {
        return mIsStopped;
    }
}
